import geometry.*;

public class GPoint extends GeometryPoint {
protected boolean is_query_selected_;

	public GPoint(int a, int b) {
		super(a,b);
	}

	public GPoint(GeometryPoint p) {
		super(p);
	}

	public GPoint(GeometryStreamTokenizer st) {
		super(st);
	}

	public void setQuerySelected(boolean b) {
		is_query_selected_ = b;
	}

	public boolean isQuerySelected() {
		return is_query_selected_;
	}
}
