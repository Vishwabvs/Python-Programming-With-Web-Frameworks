/** Brian Rogers
    cs252
    spring 1996
    Final Project */

import java.awt.*;


/**                           ThreeDVertex
    This is a point in three dimensions, with a position and color.
    It also has an array of ThreeDEdges that hold all of the edges incident
    on it.  Every vertex's color, diameter and position is modified to
    represent it's appearance using perspective */

public class ThreeDVertex {    
     public static final int CANVAS_DIMENSION = ThreeDCanvas.CANVAS_DIMENSION;
     public static final int MAX_DIAMETER = 9;
     public static final int DIAMETER_DECREMENT = 2; 
     public static final int MAX_EDGES = ThreeDSpace.MAX_VERTS;

     /** The vertex's absolute position */
     ThreeDVector _position;
     /** The vertex's apparent position from the viewer's perspective */
     ThreeDVector _apparent;

     /** The edges incident on this vertex */
     ThreeDEdge _edges[];
     int num_edges = 0;

     /** The absolute color of this vertex */
     Color _color = Color.lightGray;
     /** The apparent color from the viewer's perpective */
     Color _shade = Color.lightGray;

     /** The apparent diameter from the user's perspective */
     int _diameter = MAX_DIAMETER;



     public ThreeDVertex (int xcoord, int ycoord, int zcoord) {
          _position = new ThreeDVector(xcoord, ycoord, zcoord);
	  _apparent = new ThreeDVector(xcoord, ycoord, zcoord);

	  _edges = new ThreeDEdge[MAX_EDGES];
	  for (int i = 0; i < MAX_EDGES; i++) _edges[i] = null;
     }



     /** This returns true if this vertex's xcoordinate is less than the other
         one's.  If they are the same, it goes on to compare their y and z
	 coordinates also. */
     public boolean xLessThan (ThreeDVertex othervert) {
          ThreeDVector other = othervert.position();

	  int thisx = _position.xCoord();
	  int otherx = other.xCoord();

	  if (thisx < otherx) return true;	  

	  else if (thisx == otherx) {
	       int thisy = _position.yCoord();
	       int othery = other.yCoord();

	       if (thisy < othery) return true;

	       else if (thisy == othery) {
	            int thisz = _position.zCoord();
		    int otherz = other.zCoord();

		    if (thisz < otherz) return true;

		    else return false;
		}
		else return false;
	  }
	  else return false;
     }


     /** This returns true if this vertex's z-coordinate is less than the other
         one's. */
     public boolean zLessThan (ThreeDVertex othervert) {
          ThreeDVector other = othervert.position();

	  int thisz = _position.zCoord();
	  int otherz = other.zCoord();

	  if (thisz < otherz) return true;
	  else return false;
     }



     /** This adds the edge it is passed to the array if there is room */
     public void addEdge (ThreeDEdge edge) {
          if (num_edges < MAX_EDGES) {
               _edges[num_edges] = edge;
	       num_edges++;
	  }
     }

     /** This removes the last edge in the array */
     public void removeEdge () {
          if (num_edges > 0) {
               _edges[num_edges-1] = null;
	       num_edges--;
	  }
     }
     
     /** This gets rid of all of the edges in the array */
     public void dumpEdges () {
         for (int i = 0; i < MAX_EDGES; i++) _edges[i] = null;
	 num_edges = 0;
     }



     /** This draws the vertex as it would be seen by a viewer at the
         current zoom (zcurr) z coordinate. */
     public void draw (Graphics graphics, int zcurr, float modifier) {
          int zcoord = _position.zCoord();

          /* If this vertex is in front of the viewer */
	  if (zcoord <= zcurr) {
	       updateAppearance(modifier);

	       for (int i = 0; i < num_edges; i++) 
	            _edges[i].draw(graphics);

               graphics.setColor(_shade);
               draw(graphics);
	  }
     }

     /** This draws the vertex in the color that it is passed */
     public void draw (Graphics graphics, Color color) {
          graphics.setColor(color);
	  draw(graphics);
     }

     /** This draws the vertex on the canvas */
     public void draw (Graphics graphics) {
          int drawx = _apparent.xCoord() + CANVAS_DIMENSION/2;
	  int drawy = CANVAS_DIMENSION/2 - _apparent.yCoord();

	  graphics.fillOval(drawx-_diameter/2, drawy-_diameter/2, 
	                         _diameter, _diameter);
     }



     public ThreeDVector position () {return _position;}
     public ThreeDVector apparent () {return _apparent;}

     public int xCoord () {return _position.xCoord();}
     public int yCoord () {return _position.yCoord();}
     public int zCoord () {return _position.zCoord();}



     /** This updates the Vertex's appearance based on the modifier it is
         passed, which was derived based on the distance between this 
	 vertex, and the current viewer's position */
     private void updateAppearance (float modifier) {

          float max = (float)(MAX_DIAMETER);
	  float x = (float)(_position.xCoord());
	  float y = (float)(_position.yCoord());

          /* Adjust the diameter */
          float dia = modifier * max;
	  _diameter = (int)(dia);

          /* Adjust the apparent position */	  
	  float appx = modifier * x;
	  float appy = modifier * y;
	  _apparent.setX((int)(appx));
	  _apparent.setY((int)(appy));

          /* adjust the shade that the vertex will be drawn in */	 
	  int colormod = (int)(255 * ((3/2) * (1-modifier)));

	  int redmod = _color.getRed() - colormod;
          int greenmod = _color.getGreen() - colormod;
	  int bluemod = _color.getBlue() - colormod;

	  if (redmod < 0) redmod = 0;
          if (greenmod < 0) greenmod = 0;
	  if (bluemod < 0) bluemod = 0;
	       
	  _shade = new Color(redmod, greenmod, bluemod);      
     }
     
     
     public void setColor (Color color) {_color = color;}
}
