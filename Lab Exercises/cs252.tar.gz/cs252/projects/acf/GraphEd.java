
import java.awt.*;
import java.applet.*;
import java.io.*;
import java.net.*;
import java.util.Vector;


class GraphEd
{
    final static String SAMPLE_NAMES[] = {
        "c60.g",
        "entring.g", 
        "hcube4d.g", 
        "star30.g",
        "torus.g",
        "trimesh.g",
        "comcon.g", 
        "bintree.g", 
        "test.g"
    };

    static boolean write(String fname,Graph g)
    {
        try {
            FileOutputStream fout =  new FileOutputStream(fname);
            PrintStream output = new PrintStream(fout);
            
            output.println("GRAPH \"" + g.graph_name + "\" = UNDIRECTED");

            for (int v_num=0;v_num<g.vertices.size();v_num++) 
            {
                Vertex v = (Vertex) g.vertices.elementAt(v_num);
                if (v==null) continue;
                
                output.print(""+v_num+" {$NP "+v.x+" "+v.y+"$} \"\"");

                for (int e_num=0; e_num<v.adjedges.size();e_num++) {
                    Edge e = (Edge) v.adjedges.elementAt(e_num);
                    Vertex u = e.otherVertex(v);
                    int u_num = g.vertices.indexOf(u);
                    if (u_num>v_num) output.print("\n"+u_num+" \"\"");
                }
                output.println(";");
            }
            output.println("END");
        } catch (IOException e) {
            return false;
        }           
        return true;
    }

    static final int MAXWORDLEN = 1024;
    static char buf[] = new char[MAXWORDLEN];
    static final String DELIMITERS = "{}$;=";

    static public char skipSpace(DataInputStream f)
    {
        try { 
            char ch = (char) f.readByte();
            while (Character.isSpace(ch)) ch = (char) f.readByte();
            return ch;
        } catch (IOException ex) { }
        return (char) -1;
    }

    
    static boolean valid_lastchar = false;;
    static char lastchar=0;
    
    static public String readWord(DataInputStream f)
    {
        int i=0;
        char ch = lastchar;
        try { 
            if (valid_lastchar==false) ch=skipSpace(f);
            else valid_lastchar=false;

            if (ch==-1) { ch=0; ch=skipSpace(f); }
            if (ch==-1) return null;
            if (ch=='\"') {
                while (true) {
                    buf[i++] = ch;
                    ch = (char) f.readByte();
                    if (ch=='\"') break;
                }
                buf[i++] = ch;
            } else {
                while (Character.isSpace(ch)==false && i<MAXWORDLEN-1) {
                    buf[i++] = ch;
                    if (i==1 && DELIMITERS.indexOf(ch)!=-1) break;
                    ch = (char) f.readByte();
                    if (DELIMITERS.indexOf(ch)!=-1) { 
                        lastchar=ch; 
                        valid_lastchar=true;
                        break; 
                    }
                }
            }
            if (i==MAXWORDLEN-1) System.err.println("#ERROR#: Very long word in file.");
        } catch (IOException ex) {
        }
        if (i==0) return null;
        return new String(buf,0,i);
    }

    static protected boolean expect(DataInputStream f,String exp)
    {
        String str = readWord(f);
        if (exp.equals(str)==false) {
            System.err.println("Expects <"+exp+">, read <"+str+">");
            return false;
        }
        return true;
    }

    static public DataInputStream openfile (String fname, Graph g)
    {
        DataInputStream f;
        URL urlfile;
        
        try {
            urlfile = new URL(URLInfo.URLPREFIX+"/"+fname);
        } catch(Exception ex) {
            System.err.println("#ERROR#: Can't open localhost URL,"+ex);
            return null;
        }
        
        try {
            f = new DataInputStream(urlfile.openStream());
        } catch (Exception  ex) {
            System.err.println("#ERROR#: Can't open file stream."+ex);
            System.err.println("         "+urlfile);
            return null;
        }           

        if (f==null) return null;
        if (!expect(f,"GRAPH")) return null;
        g.graph_name = readWord(f);
        if (!expect(f,"=")) return null;
        if (!expect(f,"UNDIRECTED")) return null;
        return f;
    }
    
    static public boolean read (String fname, Graph g)
    {
        // Find vertex size
        DataInputStream f = openfile(fname,g);
        if (f==null) return false;
        
        Vector fvertices = new Vector();
        Vector fedges = new Vector();
        Vector fvnum = new Vector();
        int vert_max = -1;
        
        String str;
        while ( (str=readWord(f))!=null && str.equals("END")==false)
        {
            int v_num = Integer.parseInt(str);
            if (v_num > vert_max) vert_max=v_num;
            
            if (!expect(f,"{") || !expect(f,"$") || !expect(f,"NP")) 
                return false;
            
            int x = Integer.parseInt(readWord(f));
            int y = Integer.parseInt(readWord(f));
            
            fvertices.addElement(new Vec2d(x,y));
            fvnum.addElement(new Vec2d(v_num,0));
            
            if (!expect(f,"$") || !expect(f,"}") || !expect(f,"\"\"")) 
                return false;

            while ( (str=readWord(f)).equals(";")==false) {
                int v2_num = Integer.parseInt(str);
                fedges.addElement(new Vec2d(v_num,v2_num));
                //System.err.println("Edge: "+v_num+","+v2_num);
                if (!expect(f,"\"\"")) return false;
            }
        }
        if (vert_max==-1) return false;
        
        Vector map = new Vector();
        map.setSize(vert_max+1);

        for (int i=0;i<fvertices.size();i++) {
            Vec2d v = (Vec2d) fvertices.elementAt(i);
            Vec2d vmap = (Vec2d) fvnum.elementAt(i);
            vmap.y = g.addVertex(v.x,v.y);
            map.setElementAt(vmap,vmap.x);
        }
        
        for (int i=0;i<fedges.size();i++) {
            Vec2d e = (Vec2d) fedges.elementAt(i);
            Vec2d vmap1 = (Vec2d) map.elementAt(e.x);
            Vec2d vmap2 = (Vec2d) map.elementAt(e.y);
            g.addEdge(vmap1.y,vmap2.y);
        }
        return true;
    }
}
