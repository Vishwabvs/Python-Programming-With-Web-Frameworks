import java.util.*;
import java.awt.*;
import LayoutAlgorithm;
import Node;
import WebTree;


public class RandomColorAlgorithm extends LayoutAlgorithm {

  final boolean DEBUG = false;
  WebTree webtree_;


RandomColorAlgorithm(WebTree webtree){
    webtree_ = webtree;
  }



public void execute (Vector nodeList)
  {

    if (DEBUG) System.out.println("random color algorithm execute called");

    int total = nodeList.size();
    
    if (DEBUG) System.out.println("total nodes: " + total);
    
    if (total == 0) return; // make sure there is a graph

    Date date = new Date();

    Random random = new Random();

    random.setSeed(date.getTime());

    int randomR, randomG, randomB;

    for (int i = 0; i < total; i++) {

       Node tempNode = (Node)nodeList.elementAt(i);

       randomR = (int)(random.nextDouble() * 256);
       randomG = (int)(random.nextDouble() * 256);
       randomB = (int)(random.nextDouble() * 256);

       tempNode.setColor(randomR, randomG, randomB);

    }


  }


}
