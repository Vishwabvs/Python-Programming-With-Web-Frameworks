/*
 * @(#)NullTreeGraphics.java	1.0 1/18/96 Michael John Radwin
 */

package mjr.treegraphics;

/**
 * An implementation of TreeGraphics that displays nothing.
 *
 * This code was ported by
 * <A HREF="http://www.cs.brown.edu/people/mjr/">mjr</A>
 * from the pascal source written by
 * <A HREF="http://www.cs.brown.edu/people/bmc/">bmc</A>.
 * <p>
 * @see mjr.treegraphics.TreeGraphics
 * @version 1.0 1/18/96
 * @author <A HREF="http://www.cs.brown.edu/people/mjr/">Michael John Radwin</A>
 * @author <A HREF="http://www.cs.brown.edu/people/bmc/">Bryan Cantrill</A>
 */
public
class NullTreeGraphics extends TreeGraphics {
    public NullTreeGraphics()
    {
	super();
    }
    
    public void DrawInternal(String nodeLabel, String color)
    {
	// ignore this request
    }

    public void DrawLeaf(String color)
    {
	// ignore this request
    }
}
