import java.awt.*;
import java.applet.*;
import java.io.*;
import java.net.*;
import java.util.Vector;

public class IGem extends Applet
{
    Graph graph;
    GraphUpdate graph_algo;
    Label message_label;
    Label status_label;
    DisplayArea disp_area;
    Ruler horiz_rule, vertic_rule;
    CheckButton randomize, arrange, optimize, stop;
    Scrollbar slider;
    Label slider_label;
    ProgressMeter meter;

    public IGem() {
        graph = new Graph(this);
        graph_algo = new GraphUpdate(this);
    }

    public void start() {
        System.err.println("IGEM Applet started");
        graph_algo.start();
        super.start();
    }

    public void stop() {
        System.err.println("IGEM Applet stopped");
        graph_algo.stop();
        super.stop();
    }

    public void destroy() {
        System.err.println("IGEM DESTROYED!");
        graph_algo.stop();
    }

    public synchronized void setMessage(String text) {
        message_label.setText(text);
    }

    public synchronized void setStatus(String text) {
        status_label.setText(text);
    }

    public synchronized void setStatus() {
        setStatus("("+graph.edges.size()+" edges, "+graph.vertices.size()+" vertices)");
    }

    public static void main(String args[])
    {
        Frame f = new Frame("IGem");
        IGem gm = new IGem();
        gm.init();
        gm.start();
        f.add("Center", gm);
        f.resize(500, 300);
        f.show();
    }

    static synchronized void resetGridBagConstraints(GridBagConstraints c)
    {
        c.gridx = c.gridy = GridBagConstraints.RELATIVE;
        c.gridwidth = c.gridheight = 1;
        c.fill = GridBagConstraints.BOTH;
        c.weightx = c.weighty = 0;
        c.ipadx = 0;
        c.ipady = 2;
    }

    protected synchronized void createStatusBar(Panel p)
    {
        GridBagLayout gridbag = new GridBagLayout();
        p.setLayout(gridbag);

        Button button;
        GridBagConstraints c = new GridBagConstraints();

        message_label = new Label("# IGem.");
        resetGridBagConstraints(c);
        c.weightx = 1;
        c.weighty = 0;
        c.gridheight = GridBagConstraints.REMAINDER;
        gridbag.setConstraints(message_label, c);
        p.add(message_label);

        status_label = new Label("(0 edges, 0 vertices)  ");
        resetGridBagConstraints(c);
        c.weighty = 0;
        c.gridheight = GridBagConstraints.REMAINDER;
        c.ipady = 2;
        gridbag.setConstraints(status_label, c);
        p.add(status_label);

        Choice grid_choice = new Choice();
        grid_choice.addItem("No Grid");
        grid_choice.addItem("10x10 Grid");
        grid_choice.addItem("5x5 Grid");
        grid_choice.addItem("2x2 Grid");
        grid_choice.addItem("1x1 Grid");
        resetGridBagConstraints(c);
        c.weighty = 0;
        c.fill = GridBagConstraints.NONE;
        c.gridheight = GridBagConstraints.REMAINDER;
        c.ipadx = 4;
        gridbag.setConstraints(grid_choice, c);
        p.add(grid_choice);

        button = new Button("-");
        resetGridBagConstraints(c);
        c.weightx = c.weighty = 0;
        c.gridy = 0;
        c.ipadx = 4;
        gridbag.setConstraints(button, c);
        p.add(button);

        button = new Button("+");
        resetGridBagConstraints(c);
        c.weightx = c.weighty = 0;
        c.gridy = 0;
        c.ipadx = 4;
        c.gridwidth = GridBagConstraints.REMAINDER;
        gridbag.setConstraints(button, c);
        p.add(button);
    }

    protected synchronized void createControlPanel(Panel p)
    {
        GridBagLayout layout = new GridBagLayout();
        p.setLayout(layout);

        GridBagConstraints c = new GridBagConstraints();

        resetGridBagConstraints(c);
        c.gridx = 0;

        Font bold_font = new Font("Helvetica", Font.BOLD, 12);
        Label lab = new Label("IGem");
        lab.setFont(bold_font);
        lab.setAlignment(Label.CENTER);
        c.ipady = 20;
        layout.setConstraints(lab, c);
        p.add(lab);

        resetGridBagConstraints(c);
        c.gridx = 0;

        randomize = new CheckButton("Randomize");
        randomize.init();
        layout.setConstraints(randomize, c);
        p.add(randomize);

        arrange = new CheckButton("Arrange");
        arrange.init();
        layout.setConstraints(arrange, c);
        p.add(arrange);

        optimize = new CheckButton("Optimize");
        optimize.init();
        layout.setConstraints(optimize, c);
        p.add(optimize);

        stop = new CheckButton("Stop",1);
        stop.init();
        layout.setConstraints(stop, c);
        p.add(stop);

        Button button = new Button("Clear");
        resetGridBagConstraints(c);
        c.gridx = 0;
        layout.setConstraints(button, c);
        p.add(button);

        button = new Button("Quit");
        resetGridBagConstraints(c);
        c.gridx = 0;
        layout.setConstraints(button, c);
        p.add(button);

        lab = new Label(" Samples");
        resetGridBagConstraints(c);
        c.gridx = 0;
        //lab.setFont(bold_font);
        //lab.setAlignment(Label.CENTER);
        layout.setConstraints(lab, c);
        p.add(lab);

        Choice samples = new Choice();
        for (int i=0;i<GraphEd.SAMPLE_NAMES.length;i++) {
            samples.addItem(GraphEd.SAMPLE_NAMES[i]);
        }
        resetGridBagConstraints(c);
        c.gridx = 0;
        layout.setConstraints(samples, c);
        p.add(samples);

        slider = new Scrollbar(Scrollbar.HORIZONTAL,50,10,10,500);
        slider.setPageIncrement(5);

        slider_label = new Label(" Edge length: "+slider.getValue());
        resetGridBagConstraints(c);
        c.gridx = 0;
        layout.setConstraints(slider_label, c);
        p.add(slider_label);

        resetGridBagConstraints(c);
        c.gridx = 0;
        layout.setConstraints(slider, c);
        p.add(slider);

        Label temp_label = new Label(" Temperature");
        resetGridBagConstraints(c);
        c.gridx = 0;
        layout.setConstraints(temp_label, c);
        p.add(temp_label);

        meter = new ProgressMeter();
        resetGridBagConstraints(c);
        c.gridx = 0;
        layout.setConstraints(meter, c);
        p.add(meter);

        Label dummy = new Label("");
        resetGridBagConstraints(c);
        c.gridx = 0;
        c.fill = GridBagConstraints.NONE;
        c.weighty = 1.0;
        c.gridheight = GridBagConstraints.REMAINDER;
        layout.setConstraints(dummy, c);
        p.add(dummy);
    }

    protected synchronized void createCanvasPanel(Panel p)
    {
        GridBagLayout gridbag = new GridBagLayout();
        p.setLayout(gridbag);

        GridBagConstraints c = new GridBagConstraints();
        Button button;

        button = new Button("(0,0)");
        resetGridBagConstraints(c);
        c.weighty = .05;
        c.weightx = .025;
        gridbag.setConstraints(button, c);
        p.add(button);

        horiz_rule = new Ruler(this,Ruler.HORIZONTAL);
        resetGridBagConstraints(c);
        c.weightx = 2;
        c.weighty = 0;
        c.gridwidth = GridBagConstraints.REMAINDER;
        c.gridheight = 100;
        gridbag.setConstraints(horiz_rule, c);
        p.add(horiz_rule);

        vertic_rule = new Ruler(this,Ruler.VERTICAL);
        resetGridBagConstraints(c);
        c.weighty = 2;
        gridbag.setConstraints(vertic_rule, c);
        p.add(vertic_rule);

        disp_area = new DisplayArea(this);
        resetGridBagConstraints(c);
        c.weightx = c.weighty = 2;
        c.gridwidth = GridBagConstraints.REMAINDER;
        gridbag.setConstraints(disp_area, c);
        p.add(disp_area);
    }

    public synchronized void init()
    {
        GridBagLayout gridbag = new GridBagLayout();
        setFont(new Font("Helvetica", Font.PLAIN, 11));
        setLayout(gridbag);

        GridBagConstraints c = new GridBagConstraints();
        Button button;

        Panel control_panel = new Panel();
        resetGridBagConstraints(c);
        c.weightx = 0;
        c.weighty = 1;
        c.gridheight = GridBagConstraints.REMAINDER;
        gridbag.setConstraints(control_panel, c);
        add(control_panel);
        createControlPanel(control_panel);

        Panel canvas_panel = new Panel();
        resetGridBagConstraints(c);
        c.weighty = 1;
        c.gridwidth = GridBagConstraints.REMAINDER;
        gridbag.setConstraints(canvas_panel, c);
        add(canvas_panel);
        createCanvasPanel(canvas_panel);

        Panel status_panel = new Panel();
        resetGridBagConstraints(c);
        c.weightx = 1;
        c.weighty = 0;
        c.gridwidth = c.gridheight = GridBagConstraints.REMAINDER;
        gridbag.setConstraints(status_panel, c);
        add(status_panel);
        createStatusBar(status_panel);

        URLInfo.getURLBASE(this);
        setMessage("IGem initialized ("+URLInfo.URLHOST+")");
    }

    public boolean handleEvent(Event e) {
        if (e.target instanceof Scrollbar) {
            slider_label.setText(" Edge length: "+slider.getValue());
            AlgoFRICK.setEdgeLength(slider.getValue());
        }
        return super.handleEvent(e);
    }

    public synchronized boolean action(Event e, Object arg)
    {
        boolean ok = false;
        if (e.target instanceof Scrollbar) {
            System.out.println("POIPOI");
        } else
        if (e.target instanceof Choice) {
            ok = true;
            if ("No Grid".equals(arg)) {
                disp_area.grid_mode = 0;
            } else
            if ("10x10 Grid".equals(arg)) {
                disp_area.grid_mode = 100;
            } else
            if ("5x5 Grid".equals(arg)) {
                disp_area.grid_mode = 50;
            } else
            if ("2x2 Grid".equals(arg)) {
                disp_area.grid_mode = 20;
            } else
            if ("1x1 Grid".equals(arg)) {
                disp_area.grid_mode = 10;
            } else {
                ok = false;
                clearAll();
                for (int i=0;i<GraphEd.SAMPLE_NAMES.length;i++) {
                    if (GraphEd.SAMPLE_NAMES[i].equals(arg)) {
                        message_label.repaint();
                        graph_algo.setAlgo(GraphUpdate.NONE);
                        setCheckButtonStopped();
                        if (GraphEd.read("samples/"+GraphEd.SAMPLE_NAMES[i],graph)==true)
                            setMessage("Loaded sample: "+GraphEd.SAMPLE_NAMES[i]);
                        else
                            setMessage("Can't load sample: "+GraphEd.SAMPLE_NAMES[i]);
                        ok = true;
                    }
                }
            }
            if (ok==true) disp_area.repaint();
        } else
        if ("(0,0)".equals(arg)) {
            disp_area.dc.reset();
            disp_area.repaint();
            ok = true;
        } else
        if ("+".equals(arg)) {
            disp_area.dc.incrScale();
            disp_area.repaint();
            ok = true;
        } else
        if ("-".equals(arg)) {
            disp_area.dc.decrScale();
            disp_area.repaint();
            ok = true;
        } else
        if ("Clear".equals(arg)) {
            clearAll();
            disp_area.repaint();
            ok = true;
            setMessage("All edges/vertices deleted.");
        } else
        if ("Repaint".equals(arg)) {
            disp_area.repaint();
            ok = true;
            setMessage("Repaint done.");
        } else
        if ("Quit".equals(arg)) {
            System.exit(0);
        } else
        if ("Randomize".equals(arg)) {
            Debug.println("Activated Randomize");
            clearCheckButtons();
            randomize.setStatus(1);
            graph_algo.setAlgo(GraphUpdate.RANDOMIZE);
            ok = true;
        } else
        if ("Arrange".equals(arg)) {
            Debug.println("Activated Arrange");
            clearCheckButtons();
            arrange.setStatus(1);
            graph_algo.setAlgo(GraphUpdate.ARRANGE);
            ok = true;
        } else
        if ("Optimize".equals(arg)) {
            Debug.println("Activated Optimize");
            clearCheckButtons();
            optimize.setStatus(1);
            graph_algo.setAlgo(GraphUpdate.OPTIMIZE);
            ok = true;
        } else
        if ("Stop".equals(arg)) {
            Debug.println("Activated Stop");
            graph_algo.setAlgo(GraphUpdate.NONE);
            setCheckButtonStopped();
            ok = true;
        }
        if (ok == false) setMessage("Not implemented.");
        return ok;
    }

    private void clearAll()
    {
        disp_area.op_mtx.wlock();
        disp_area.operation = DisplayArea.OP_NONE;
        disp_area.snap_item = disp_area.snap_item_to = -1;
        graph.deleteAll();
        disp_area.op_mtx.unlock();
    }

    public void setCheckButtonStopped()
    {
        clearCheckButtons();
        stop.setStatus(1);
    }

    public void clearCheckButtons()
    {
        stop.setStatus(0);
        randomize.setStatus(0);
        arrange.setStatus(0);
        optimize.setStatus(0);
    }
}

class ProgressMeter extends Panel
{
    public double val=0.0;
    final static int BORDER = 2;

    public void setValue(double i)
    {
        if (i<0.0) val=0;
        else if (i>1.0) val=1.0;
        else val=i;
        repaint();
    }

    public void paint(Graphics g)
    {
        Dimension d = size();

        g.setColor(getForeground());
        g.fill3DRect(0, 0, d.width - 1, d.height - 1, true);
                                                                                                           g.draw3DRect(3, 3, d.width - 7, d.height - 7, false);
        g.setColor(Color.blue);
        g.setPaintMode();

        int x_scaled = (int) ((d.width-1)*val);
        g.fillRclass ProgressMeter extends Panel
{
    public double val=0.0;
    final static int BORDER = 2;

    public void setValue(double i)
    {
        if (i<0.0) val=0;
        else if (i>1.0) val=1.0;
        else val=i;
        repaint();
    }

    public void paint(Graphics g)
    {
        Dimension d = size();

        g.setColor(getForeground());
        g.fill3DRect(0, 0, d.width - 1, d.height - 1, true);
                                                                                                           g.draw3DRect(3, 3, d.width - 7, d.height - 7, false);
        g.setColor(Color.blue);
        g.setPaintMode();

        int x_scaled = (int) ((d.width-1)*val);
        g.fillRect(BORDER,BORDER,x_scaled-2*BORDER-1,d.height-2*BORDER-1);
    }
}ect(BORDER,BORDER,x_scaled-2*BORDER-1,d.height-2*BORDER-1);
    }
}

class Ruler extends Panel
{
    final static int HORIZONTAL = 0;
    final static int VERTICAL = 1;
    final static int MINOR_STEP = 10;
    final static int MAJOR_STEP = 100;
    final static int MINOR_TICK = 4;
    final static int MAJOR_TICK = 8;
    final static int BORDER = 4;

    IGem igem;
    int type;

    public Ruler(IGem g,int type) {
        igem = g;
        this.type = type;
        this.setFont(new Font("Helvetica", Font.PLAIN, 8));
    }

    private int x2,y2,xl,yl;

    public boolean mouseDown(Event e, int x, int y)
    {
        x2 = x;
        y2 = y;
        return true;
    }

    public boolean mouseDrag(Event e, int x, int y)
    {
        xl = x2;
        yl = y2;
        x2 = x;
        y2 = y;
        DeviceCoord dc = igem.disp_area.dc;
        switch(type) {
            case HORIZONTAL:
                dc.moveX(xl-x);
                break;
            case VERTICAL:
                dc.moveY(yl-y);
                break;
        }
        igem.disp_area.repaint();
        return true;
    }

    public void paint(Graphics g)
    {
        Dimension d = size();

        g.setColor(getBackground());
        g.draw3DRect(0, 0, d.width - 1, d.height - 1, true);
                                                                                                           g.draw3DRect(3, 3, d.width - 7, d.height - 7, false);
        g.setColor(getForeground());
        g.setPaintMode();

        DeviceCoord dc = igem.disp_area.dc;

        if (type == HORIZONTAL)
        {
            int from_x = dc.toWorldX(0);
            int to_x = dc.toWorldX(d.width-1) - MINOR_STEP;
            int x = ((int)(from_x/MINOR_STEP)+1)*MINOR_STEP;
            int y_base = d.height-1-BORDER;
            int y_minor = d.height-1-MINOR_TICK-BORDER;
            int y_major = d.height-1-MAJOR_TICK-BORDER;
            int y_text = y_major-2;
            while (x < to_x)
            {
                int scrx = dc.toDeviceX(x);
                if (x%MAJOR_STEP == 0) {
                    g.drawString(""+x/MINOR_STEP,scrx-2,y_text);
                    g.drawLine(scrx,y_base,scrx,y_major);
                } else {
                    g.drawLine(scrx,y_base,scrx,y_minor);
                }
                x += MINOR_STEP;
            }
        } else
        if (type == VERTICAL)
        {
            int from_y = dc.toWorldY(0);
            int to_y = dc.toWorldY(d.height-1) - MINOR_STEP;
            int y = ((int)(from_y/MINOR_STEP)+1)*MINOR_STEP;
            int x_base = d.width-1-BORDER;
            int x_minor = d.width-1-MINOR_TICK-BORDER;
            int x_major = d.width-1-MAJOR_TICK-BORDER;
            int x_text = x_major-16;
            while (y < to_y)
            {
                int scry = dc.toDeviceY(y);
                if (y%MAJOR_STEP == 0) {
                    g.drawString(""+y/MINOR_STEP,x_text,scry+8);
                    g.drawLine(x_base,scry,x_major,scry);
                } else {
                    g.drawLine(x_base,scry,x_minor,scry);
                }
                y += MINOR_STEP;
            }
        }
    }
}

class DeviceCoord
{
    public double scale = 1.0;
    public Vec2d origin = new Vec2d(-20,-20);

    int curr_scale = 4;
    final static double SCALE_STEPS[] =
        { 0.1, 0.2, 0.3, 0.4, 0.5, 0.75, 1.0, 1.5, 2.0 };

    IGem igem;

    public DeviceCoord(IGem g) { igem=g; reset(); }

    public void reset() {
        curr_scale = 4;
        scale = SCALE_STEPS[curr_scale];
        origin.x = origin.y = -20;
        igem.horiz_rule.repaint();
        igem.vertic_rule.repaint();
    }

    public int toDeviceX(int x) {
        return (int) (x*scale - origin.x);
    }

    public int toDeviceY(int y) {
        return (int) (y*scale - origin.y);
    }

    public int toWorldX(int x) {
        return (int) ((x+origin.x)/scale);
    }

    public int toWorldY(int y) {
        return (int) ((y+origin.y)/scale);
    }

    public void incrScale() {
        curr_scale++;
        if (curr_scale>=SCALE_STEPS.length)
            curr_scale=SCALE_STEPS.length-1;
        scale = SCALE_STEPS[curr_scale];
        igem.horiz_rule.repaint();
        igem.vertic_rule.repaint();
    }

    public void decrScale() {
        curr_scale--;
        if (curr_scale<0) curr_scale=0;
        scale = SCALE_STEPS[curr_scale];
        igem.horiz_rule.repaint();
        igem.vertic_rule.repaint();
    }

    public void moveX(int x) {
        origin.x += x;
        igem.horiz_rule.repaint();
    }

    public void moveY(int y) {
        origin.y += y;
        igem.vertic_rule.repaint();
    }

    final static int MOVE_STEP = 25;
    public void moveUp() { moveY((int)(scale*MOVE_STEP)); }
    public void moveDown() { moveY(-(int)(scale*MOVE_STEP)); }
    public void moveLeft() { moveX((int)(scale*MOVE_STEP)); }
    public void moveRight() { moveX(-(int)(scale*MOVE_STEP)); }
}


class DisplayArea extends Panel
{
    private int x1,y1, x2,y2, xl,yl;

    public static final int OP_NONE = 0;
    public static final int OP_ADDEDGE = 1;
    public static final int OP_MOVEPOINT = 2;
    public static final int OP_ADDCHILDEDGE = 3;
    public static final int OP_SPLITEDGE = 4;

    RWLock op_mtx = new RWLock();
    int operation = OP_NONE;
    int snap_item = -1;
    int snap_item_to = -1;

    DeviceCoord dc;
    int grid_mode = 0;
    IGem igem;

    public DisplayArea(IGem g) {
        setBackground(Color.white);
        igem = g;
        dc = new DeviceCoord(igem);
        x2 = xl = -1;
    }

    public synchronized boolean mouseDown(Event e, int ex, int ey)
    {
        int x = dc.toWorldX(ex);
        int y = dc.toWorldY(ey);

        Graphics g = getGraphics();
        x2 = xl = -1;
        Vertex v;

        boolean do_repaint = false;
        op_mtx.wlock();

        if (e.metaDown()==true) {
            if (igem.graph_algo.algo_type == GraphUpdate.NONE) {
                if (operation==OP_MOVEPOINT) {
                    igem.graph.deleteVertex(snap_item);
                    operation = OP_NONE;
                    snap_item = -1;
                    do_repaint=true;
                } else
                if (operation==OP_SPLITEDGE) {
                    igem.graph.deleteEdge(snap_item);
                    operation = OP_NONE;
                    snap_item = -1;
                    do_repaint=true;
                }
            }
        } else switch(operation)
        {
            case OP_MOVEPOINT:
                igem.setMessage("Moving vertex "+snap_item+".");
                break;

            case OP_ADDCHILDEDGE:
                if (igem.graph_algo.algo_type != GraphUpdate.NONE) {
                    igem.setMessage("Can't add and iterate at the same time");
                    break;
                }
                igem.setMessage("Adding new child to vertex "+snap_item+".");
                v = (Vertex) igem.graph.vertices.elementAt(snap_item);
                x1 = v.x;
                y1 = v.y;
                x2 = x;
                y2 = y;
                break;

            case OP_SPLITEDGE:
                if (igem.graph_algo.algo_type != GraphUpdate.NONE) {
                    igem.setMessage("Can't add and iterate at the same time");
                    break;
                }
                int mid_vert = igem.graph.splitEdge(snap_item);
                operation = OP_MOVEPOINT;
                snap_item = mid_vert;
                v = (Vertex) igem.graph.vertices.elementAt(snap_item);
                v.setX( x );
                v.setY( y );
                x2 = x;
                y2 = y;
                do_repaint = true;
                break;

            case OP_ADDEDGE:
            case OP_NONE:
            default:
                if (igem.graph_algo.algo_type != GraphUpdate.NONE) {
                    igem.setMessage("Can't add and iterate at the same time");
                    break;
                }
                operation = OP_ADDEDGE;
                x1 = x;
                y1 = y;
                igem.setMessage("Adding new edge.");
                dragPaint(g);
                break;
        }
        op_mtx.unlock();
        if (do_repaint == true) repaint();
        return true;
    }

    public synchronized boolean mouseUp(Event e, int ex, int ey)
    {
        int x = dc.toWorldX(ex);
        int y = dc.toWorldY(ey);

        x2 = xl = -1;
        igem.setMessage("");

        int v1,v2;

        op_mtx.wlock();

        if (e.metaDown()==true) {
            // anything?
        } else switch (operation)
        {
            case OP_ADDCHILDEDGE:
                if (igem.graph_algo.algo_type != GraphUpdate.NONE) {
                    igem.setMessage("Can't add and iterate at the same time");
                    break;
                }
                v1 = snap_item;
                if (snap_item_to != -1) v2 = snap_item_to;
                else v2 = igem.graph.addVertex(x, y);
                igem.graph.addEdge(v1,v2);
                break;

            case OP_ADDEDGE:
                if (igem.graph_algo.algo_type != GraphUpdate.NONE) {
                    igem.setMessage("Can't add and iterate at the same time");
                    break;
                }
                v1 = igem.graph.addVertex(x1, y1);
                if ((Math.abs(x-x1) + Math.abs(y-y1)) < 10) {
                    break;
                }
                if (snap_item_to != -1) v2 = snap_item_to;
                else v2 = igem.graph.addVertex(x,y);
                igem.graph.addEdge(v1,v2);
                break;

            case OP_MOVEPOINT:
                if (snap_item_to != -1) {
                    // merge snap_item with snap_item_to
                    if (igem.graph.mergeVertex(snap_item,snap_item_to)==true) {
                        igem.setMessage("Vertices "+snap_item+" and "+snap_item_to+" merged.");
                    }
                }
                break;

            default:
                break;
        }

        operation = OP_NONE;
        snap_item = snap_item_to = -1;
        op_mtx.unlock();
        repaint();
        mouseMove(e,ex,ey);

        return true;
    }

    public synchronized boolean mouseDrag(Event e, int ex, int ey)
    {
        int x = dc.toWorldX(ex);
        int y = dc.toWorldY(ey);

        xl = x2;
        yl = y2;
        x2 = x;
        y2 = y;

        boolean do_repaint = false;
        op_mtx.wlock();
        snap_item_to = -1;

        int snap_radius = (int)(Graph.CIR_SIZE*Graph.CIR_SIZE*3/dc.scale);
        Vertex v;
        int nearest[];

        switch (operation)
        {
            case OP_MOVEPOINT:
                v = (Vertex) igem.graph.vertices.elementAt(snap_item);
                nearest = igem.graph.getNearestVertexExcept(x2,y2,snap_item);

                if (nearest[1]<snap_radius) {
                    igem.setMessage("Merge with "+nearest[0]);
                    snap_item_to = nearest[0];
                    Vertex v_to = (Vertex) igem.graph.vertices.elementAt(nearest[0]);
                    v.setX( x2 = v_to.x );
                    v.setY( y2 = v_to.y );
                } else {
                    igem.setMessage("");
                    v.setX(x2);
                    v.setY(y2);
                    snap_item_to = -1;
                }
                do_repaint=true;
                break;

            case OP_ADDCHILDEDGE:
            case OP_ADDEDGE:
                if (igem.graph_algo.algo_type != GraphUpdate.NONE) {
                    igem.setMessage("Can't add and iterate at the same time");
                    break;
                }
                nearest = igem.graph.getNearestVertexExcept(x2,y2,snap_item);
                if (nearest != null && nearest[1]<snap_radius) {
                    igem.setMessage("Merge with "+nearest[0]);
                    snap_item_to = nearest[0];
                    Vertex v_to = (Vertex) igem.graph.vertices.elementAt(nearest[0]);
                    x2 = v_to.x;
                    y2 = v_to.y;
                } else {
                    igem.setMessage("");
                    snap_item_to = -1;
                }
                dragPaint(getGraphics());
                break;

            case OP_NONE:
            default:
                break;
        }

        op_mtx.unlock();
        if (do_repaint) repaint();
        return true;
    }

    public synchronized boolean mouseMove(Event e, int ex, int ey)
    {
        int x = dc.toWorldX(ex);
        int y = dc.toWorldY(ey);

        xl = x2;
        yl = y2;
        x2 = x;
        y2 = y;

        // Undo previous snaps.
        requestFocus();

        op_mtx.wlock();

        int prev_snap_item = snap_item;
        snap_item = -1;

        Graphics g = getGraphics();
        if (prev_snap_item!=-1 && igem.graph_algo.algo_type==GraphUpdate.NONE) {
            switch(operation) {
                case OP_MOVEPOINT:
                    unhighlightVertex(g,prev_snap_item);
                    break;

                case OP_ADDCHILDEDGE:
                    g.setColor(Color.red);
                    g.setXORMode(getBackground());
                    eraseLastLine(g);
                    break;

                case OP_SPLITEDGE:
                    unhighlightEdge(g,prev_snap_item);
                    break;
            }
        }

        // Try snapping to vertices first.

        int nearest_vert[] = igem.graph.getNearestVertex(x,y);

        if (nearest_vert==null) {
            operation = OP_NONE;
            igem.setMessage("");
            op_mtx.unlock();
            return false;
        }

        double dc_scale_sqr = dc.scale*dc.scale;
        int snap_radius = (int)(Graph.CIR_SIZE*Graph.CIR_SIZE*2/dc_scale_sqr);
        int pull_radius = (int)(Graph.CIR_SIZE*Graph.CIR_SIZE*10/dc_scale_sqr);

        if (nearest_vert[1] < snap_radius) {
            operation = OP_MOVEPOINT;
            snap_item = nearest_vert[0];
            igem.setMessage("Click to move vertex " + snap_item + ".");
            highlightVertex(getGraphics(),snap_item);
            op_mtx.unlock();
            return true;
        }

        if (igem.graph_algo.algo_type != GraphUpdate.NONE) {
            operation = OP_NONE;
            op_mtx.unlock();
            return true;
        }

        Vertex v;
        if (nearest_vert[1] < pull_radius) {
            operation = OP_ADDCHILDEDGE;
            snap_item = nearest_vert[0];
            igem.setMessage("Click to add child to vertex " + snap_item);
            v = (Vertex) igem.graph.vertices.elementAt(snap_item);
            x1 = v.x;
            y1 = v.y;
            g.setColor(Color.red);
            g.setXORMode(getBackground());
            paintNewLine(g);
            op_mtx.unlock();
            return true;
        }

        // If vertex snap fails, try snapping to edges.

        int EDGE_SNAP_ANGLE = 35;

        int nearest_edge[] = igem.graph.getNearestEdge(x,y);
        if (nearest_edge != null) {
            igem.setMessage("Click to split edge "+nearest_edge[0]+".");
            if (nearest_edge[1] < EDGE_SNAP_ANGLE) {
                operation = OP_SPLITEDGE;
                snap_item = nearest_edge[0];
                highlightEdge(getGraphics(),snap_item);
                op_mtx.unlock();
                return true;
            }
        }

        // If all fails, there's nothing to do.

        operation = OP_NONE;
        igem.setMessage("");
        op_mtx.unlock();
        return true;
    }

    protected boolean deleteItemKey()
    {
        boolean retval;
        boolean do_repaint = false;
        op_mtx.wlock();
        switch (operation)
        {
            case OP_MOVEPOINT:
                retval = igem.graph.deleteVertex(snap_item);
                if (retval == true) {
                    igem.setMessage("Deleted vertex "+snap_item+".");
                    snap_item = -1;
                    operation = OP_NONE;
                    do_repaint = true;
                } else {
                    igem.setMessage("Can't delete vertex "+snap_item+", delete adjacent edges first.");
                }
                break;

            case OP_SPLITEDGE:
                retval = igem.graph.deleteEdge(snap_item);
                if (retval == true) {
                    igem.setMessage("Deleted edge "+snap_item+".");
                    snap_item = -1;
                    operation = OP_NONE;
                    do_repaint = true;
                } else {
                    igem.setMessage("Can't delete edge "+snap_item+"!");
                }
                break;

            case OP_ADDCHILDEDGE:
            case OP_ADDEDGE:
            case OP_NONE:
            default:
                break;
        }
        op_mtx.unlock();
        if (do_repaint) repaint();
        return true;
    }

    public synchronized boolean keyDown(Event e, int keyint)
    {
        char key = (char) keyint;
        switch (key) {
            case 'w':
                if (GraphEd.write("test.out",igem.graph)==false) {
                    igem.setMessage("#ERROR# Can't save to file test.out");
                } else {
                    igem.setMessage("Graph saved to file test.out");
                }
                break;

            case 'd':
            case 'D':
                deleteItemKey();
                break;

            case '+':
                dc.incrScale();
                repaint();
                break;

            case '-':
                dc.decrScale();
                repaint();
                break;

            case '*':
                dc.reset();
                repaint();
                break;

            case 'h':
                dc.moveLeft();
                repaint();
                break;

            case 'l':
                dc.moveRight();
                repaint();
                break;

            case 'j':
                dc.moveUp();
                repaint();
                break;

            case 'k':
                dc.moveDown();
                repaint();
                break;

            case ' ':
                if (operation == OP_MOVEPOINT) {
                    igem.graph.toggleFixVertex(snap_item);
                } else
                if (operation == OP_SPLITEDGE) {
                    igem.graph.toggleFixEdge(snap_item);
                }
                repaint();
                break;
        }
        return true;
    }

    public final static Color MinorGridColor = Color.lightGray;
    public final static Color MajorGridColor = Color.gray;

    protected void paintGrid(Graphics g)
    {
        Dimension d = size();
        g.setPaintMode();

        int from,to,coord,scr_coord;

        from = dc.toWorldX(0);
        to = dc.toWorldX(d.width-1);
        coord = ((int)(from/grid_mode))*grid_mode;
        while (coord < to) {
            if (coord%Ruler.MAJOR_STEP == 0) g.setColor(MajorGridColor);
            else g.setColor(MinorGridColor);
            scr_coord = dc.toDeviceX(coord);
            g.drawLine(scr_coord,0,scr_coord,d.height-1);
            coord += grid_mode;
        }

        from = dc.toWorldY(0);
        to = dc.toWorldY(d.height-1);
        coord = ((int)(from/grid_mode))*grid_mode;
        while (coord < to) {
            if (coord%Ruler.MAJOR_STEP == 0) g.setColor(MajorGridColor);
            else g.setColor(MinorGridColor);
            scr_coord = dc.toDeviceY(coord);
            g.drawLine(0,scr_coord,d.width-1,scr_coord);
            coord += grid_mode;
        }
    }

    Image offscreen;
    Dimension offscreensize;

    public synchronized void update(Graphics g)
    {
        Dimension d = size();
        if ((offscreen == null) || (d.width != offscreensize.width) || (d.height != offscreensize.height)) {
            offscreen = createImage(d.width, d.height);
            offscreensize = d;
        }

        Graphics offgraphics = offscreen.getGraphics();

        offgraphics.setColor(getBackground());
        offgraphics.fillRect(0, 0, d.width, d.height);

        paint(offgraphics);

        g.drawImage(offscreen, 0, 0, null);
    }

    public synchronized void paint(Graphics g)
    {
        if (grid_mode != 0) paintGrid(g);

        g.setColor(getForeground());
        g.setPaintMode();
        igem.graph.paint(g);

        op_mtx.rlock();
        if (operation == OP_MOVEPOINT) {
            highlightVertex(g,snap_item);
        }
        op_mtx.unlock();
    }

    protected void eraseLastLine(Graphics g)
    {
        if (xl != -1) {
            // erase the last line.
            igem.graph.drawGraphEdge(g, x1, y1, xl, yl);
        }
    }

    protected void paintNewLine(Graphics g)
    {
        if (x2 != -1) {
            igem.graph.drawGraphEdge(g, x1, y1, x2, y2);
        }
    }

    protected void dragPaint(Graphics g)
    {
        // Drags a highlighted edge in XOR mode.
        // Hence don't need to redraw the entire scene.
        g.setColor(Color.red);
        g.setXORMode(getBackground());
        eraseLastLine(g);
        paintNewLine(g);
    }

    protected void highlightVertex(Graphics g,int v_num)
    {
        // Highlights a vertex. (not in XOR mode!)

        Vertex v = (Vertex) igem.graph.vertices.elementAt(v_num);
        g.setColor(Color.red);
        g.setPaintMode();
        igem.graph.drawVertex(g,v.x,v.y,false);
    }

    protected void unhighlightVertex(Graphics g,int v_num)
    {
        // Undo effects of highlight.

        Vertex v = (Vertex) igem.graph.vertices.elementAt(v_num);
        g.setColor(getForeground());
        g.setPaintMode();
        igem.graph.drawVertex(g,v.x,v.y,false);
    }

    protected void highlightEdge(Graphics g,int v_num)
    {
        // Highlights an edge. (not in XOR mode!)
        Edge e = (Edge) igem.graph.edges.elementAt(v_num);
        g.setColor(Color.red);
        g.setPaintMode();
        igem.graph.drawEdge(g, e.v1.x, e.v1.y, e.v2.x, e.v2.y);
    }

    protected void unhighlightEdge(Graphics g,int v_num)
    {
        // Undo effects of highlight.
        Edge e = (Edge) igem.graph.edges.elementAt(v_num);
        g.setColor(getForeground());
        g.setPaintMode();
        igem.graph.drawEdge(g, e.v1.x, e.v1.y, e.v2.x, e.v2.y);
    }
}

class Debug
{
    static int debug_level = 0;
    static void print(int lvl,String str) {
        if (debug_level>=lvl) System.out.print(str);
    }
    static void println(String str) {
        print(1,str+"\n");
    }
    static void println(int lvl,String str) {
        print(lvl,str+"\n");
    }
}

class URLInfo
{
    static boolean URLINITIALIZED;
    static String URLPROTOCOL, URLHOST, URLFILE, URLBASEDOC, URLREF;
    static String URLPREFIX = "file:/u/acf/IGem";
//    static String URLPREFIX = "http://localhost/~acf/IGem";
    static int URLPORT;
    static URL URLBASE;

    static public void getURLBASE(Applet a)
    {
        try {
            URLBASE = a.getCodeBase();
            URLPROTOCOL = URLBASE.getProtocol();
            URLHOST = URLBASE.getHost();
            URLFILE = URLBASE.getFile();
            URLBASEDOC = URLBASE.toExternalForm();
            URLPORT = URLBASE.getPort();
            URLREF = URLBASE.getRef();
            URLINITIALIZED = true;
            int last_slash = URLBASEDOC.lastIndexOf('/');
            URLPREFIX = URLBASEDOC.substring(0,last_slash);
            System.err.println("# URLPROTOCOL = "+URLPROTOCOL);
            System.err.println("# URLHOST = "+URLHOST);
            System.err.println("# URLFILE = "+URLFILE);
            System.err.println("# URLBASEDOC = "+URLBASEDOC);
            System.err.println("# URLPORT = "+URLPORT);
            System.err.println("# URLREF = "+URLREF);
            System.err.println("# URLPREFIX = "+URLPREFIX);
        } catch (Exception ex) {
            System.err.println("# Can't obtain base addresses: "+ex);
        }
    }
}

