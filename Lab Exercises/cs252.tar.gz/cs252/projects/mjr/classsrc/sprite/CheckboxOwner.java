package sprite;

public interface CheckboxOwner {
    public void CheckboxChanged(CheckboxSprite checkbox, boolean newState);
}
