import Node;

class Edge {

public Node source;
public Node dest;

}
