/*
 * @(#)PolySprite.java	1.0 5/6/96 Michael John Radwin
 */

package mjr.pstree;

import sprite.*;
import java.awt.*;

/**
 * A simple polygon sprite.  Easy to write, but useful.
 *
 * @version 1.0 5/6/96
 * @author <A HREF="http://www.cs.brown.edu/people/mjr/">Michael John Radwin</A>
 */
public class PolySprite extends Sprite {
    Color pen;
    Polygon poly;

    public PolySprite(SpriteArea area, Polygon poly, Color pen)
    {
	super(area, poly.xpoints[0], poly.ypoints[0]);
	this.pen = pen;
	this.poly = poly;
    }
    
    public PolySprite(SpriteArea area, Polygon poly)
    {
	this(area, poly, Color.black);
    }

    
    public PolySprite(SpriteArea area,
		      int xPoints[], int yPoints[], int nPoints,
		      Color pen)
    {
	this(area, new Polygon(xPoints, yPoints, nPoints), pen);
    }


    public PolySprite(SpriteArea area,
		      int xPoints[], int yPoints[], int nPoints)
    {
	this(area, new Polygon(xPoints, yPoints, nPoints), Color.black);
    }


    public void setColor(Color pen)
    {
	this.pen = pen;
    }
    
    public boolean Inside(int x, int y)
    {
	return poly.inside(x, y);
    }

    public void Draw(Graphics g)
    {
	g.setColor(pen);
	g.fillPolygon(poly);
    }
    public static void mjr() { ; }
}
