package sprite.test;

import sprite.*;
import java.awt.*;

class DragText extends TextSprite {
    DragText(SpriteArea area, int x, int y, String text) {
	super(area, x, y, text);
    }
    
    public void handleEvent(Event e) {
        switch (e.id) {
        case Event.MOUSE_DOWN:
            Unanchor();
            ZToTop();
            break;
            
        case Event.MOUSE_DRAG:
            MoveTo(e.x, e.y);
            break;

        case Event.MOUSE_UP:
            Anchor();
            break;
        }
    }
}

class Flip extends ButtonSprite {
    ButtonSprite other_;
    
    public Flip(SpriteArea area, int x, int y, int width, int height,
		String title) {
        super(area, x, y, width, height, title);
        other_ = null;
    }
    
    public void Action() {
	Disable();
        other_.Enable();
    }

    public void SetOther(ButtonSprite other) {
        other_ = other;
    }
}

class Check extends CheckboxSprite {
    public Check(SpriteArea area, int x, int y, String title) {
        super(area, x, y, title);
    }
    
    public void Action(boolean state) {
	System.out.println(this + " = " + state);
    }
}

public class SubTest extends SpriteArea {
    int x1_, y1_;
    
    public SubTest(int width, int height) {
        super(width, height);
	Flip a = new Flip(this, 20, 20, 50, 20, "Flip");
	Flip b = new Flip(this, 72, 20, 50, 20, "Flop");
	a.SetOther(b);
	b.SetOther(a);	
	Check ca = new Check(this, 20, 60, "Check");
	Check cb = new Check(this, 20, 80, "Your Head");
    }

    public void HandleBackgroundEvent(Event e) {
	if (e.id == Event.MOUSE_DOWN) {
	    x1_ = e.x;
	    y1_ = e.y;      
	}
	else if (e.id == Event.MOUSE_UP) {
	    DragText s = new DragText(this, x1_, y1_, "gub");
	    s.SetColor(new Color(
		(int)(Math.round(Math.random() * 255)),
		(int)(Math.round(Math.random() * 255)),
		(int)(Math.round(Math.random() * 255))));
	    s.SlideTo(e.x, e.y, 20, 50, true, false);
	}
    }
    
    public static void main (String args[]) {
        Frame f = new Frame();
        
        f.setLayout(new FlowLayout());
        SubTest area = new SubTest(300, 300);
        f.add(area);
        f.resize(f.preferredSize());
        f.show();
        
        area.WaitForGraphics();
        Graphics back = area.GetBackgroundGraphics();

        for (int loop = 0; loop < 10; ++loop) {
            back.setColor(new Color(loop * 25, loop * 25, loop * 25));
            back.fillRect(0, loop * 30, 300, 30);
        }

        area.BackgroundDirty();
    }
}
