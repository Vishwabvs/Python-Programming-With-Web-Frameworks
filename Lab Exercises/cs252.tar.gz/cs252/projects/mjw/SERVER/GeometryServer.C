/* GeometryServer

   Implements a server using input and output streams that exposes
   algorithms written in LEDA
   (http://www.mpi-sb.mpg.de/LEDA/leda.html) .  Use a program like
   socket (Juergen Nickelsen <nickel@cs.tu-berlin.de>) to work as an
   actual server.

   An example startup of this server with socket is

   nohup socket -qlf -p GeometryServer -s 6006 &

   Note that the background option does not seem to work for the socket program.
   This will start a process for each connection and terminate upon the loss
   of the socket.

   The program will sit in a loop waiting for a candidate algorithm (in text,
   using direct translation to strings of the enum algorithms).  Upon a request,
   it will read additional input then emit the appropriate output, using
   native LEDA formats for both input and output.
   
   Author:      Mike Walczak
   Version:     April 1, 1996
*/

#include <LEDA/point.h>
#include <LEDA/d_array.h>

#include <fstream.h>
#include "RTRangeTree.H"
#include "RTEvent.H"
#include "RTLists.H"
#include "STSegmentTree.H"
#include "STSegmentList.H"
#include "STSegmentComposite.H"


enum algorithms { com_quit = 1,                  
		  alg_range_search,
		  alg_segment_intersection,
		  gen_range_tree,
		  gen_segment_tree,                 
               };

#define MAP_COMMAND(dict,alg) dict[#alg] = alg

int main ()
{
   d_array<string, algorithms> commandsD;
   RTRangeTree range_tree_;
   STSegmentTree segment_tree_;
   
   MAP_COMMAND(commandsD, com_quit);
   MAP_COMMAND(commandsD, alg_segment_intersection);
   MAP_COMMAND(commandsD, alg_range_search);
   MAP_COMMAND(commandsD, gen_range_tree);
   MAP_COMMAND(commandsD, gen_segment_tree);

   string choice;
   for (;;)
   {
      cin >> choice;
      if (!commandsD.defined(choice))
	  continue;
	  
      switch (commandsD[choice])
      {
       case com_quit:
        {
           exit (0);
        }
        break;  // not really necessary!
         
  
	case alg_range_search:
	{		
		if (range_tree_.isEmpty())
		{
			cout << "null";
			break;
		}
		point upper_left;
		cin >> upper_left;
		point lower_right;
		cin >> lower_right;
		RTEventList event_list;

		range_tree_.rangeSearch(upper_left,lower_right,event_list);	
		cout << event_list.length() << endl;
		RTEvent *evt;
		forall(evt, event_list)
			cout << *evt << endl;
	}
	break;
        case alg_segment_intersection:
	{
	  if (!segment_tree_.numNodes())
	  {
	    //cout << "null";
		break;
	  }
	  point qseg_begin;
	  point qseg_end;
	  cin >> qseg_begin;
	  cin >> qseg_end;
	  STSegment qseg(qseg_begin, qseg_end);
	  RTEventList event_list;
	  segment_tree_.intersection(qseg, event_list);
	  cout << event_list.length() << endl;
	  RTEvent *evt;
	  forall(evt, event_list)
	  {
		 cout << *evt << endl;		 
	  }
	}
        break;
	
	case gen_range_tree:
	{		
		list <point> points;
		points.read();
		if (range_tree_.build(points))
			range_tree_.write();
		//else
		//cout << "null";      
	}
	break;
        case gen_segment_tree:
	{	    
	    list<point> points;
	   
	    points.read();	   	    
	    if (segment_tree_.build(points))
	    	segment_tree_.write();
	    //else 	 
	      //cout <<"\nnull";	   
	}
	break;
      }
   }

   return 0;
}

