import java.lang.*;
import java.io.StreamTokenizer;
import geometry.*;
import ReversibleCommand;
import Prototype;
import java.awt.image.*;
import java.awt.*;
import TreeNode;
import Tree;
import TreeAccessible;
import GPoint;



public class RangeSearchAnimationCommand extends ReversibleCommand
						implements Prototype {
protected TreeNode	node_ =null;
protected GPoint 	point_=null;
protected GeometryPanel panel_=null;
protected Image		image_=null;
protected TreeAccessible tree_app_ = null;
protected Box		user_input_bounds_;
protected int begin_=0, median_=0, end_=0;
protected Segment 	segment_=null;
protected Color		range_color_=Color.lightGray;

	public RangeSearchAnimationCommand(Image	 im,
					   GeometryPanel p,
					   TreeAccessible treeApp,
					   Box		 input_area)
	{
		image_ = im;
		panel_ = p;
		tree_app_ = treeApp;
		user_input_bounds_ = input_area;
	}

	public void setNode(TreeNode node)
	{
		node_ = node;
	}

	public void setPoint(GeometryPoint pt)
	{	
		point_ = (GPoint) pt;
	}

	public void setSegment(Segment sg)
	{
		segment_ = sg;
	}

	public TreeNode getNode()
	{
		return node_;
	}

	public GeometryPoint getPoint()
	{
		return point_;
	}


	public Object clone()
	{
		return null;
	}

	public Object clone(StreamTokenizer st)
	{
		return null;
	}

	public void setBegin(int b)
	{
		begin_ = b;
	}

	public void setMedian(int m)
	{
		median_ = m;
	}

	public void setEnd(int e)
	{
		end_ = e;
	}

	public int getBegin()
	{
		return begin_;
	}	
	public int getMedian()
	{
		return median_;
	}
	public int getEnd()
	{
		return end_;
	}

        public void drawRange(int begin, int median, int end, Color color)
        {
		if (node_ != null)
		{			
			// draw range of this node (minX maxX)
			// get bounds of the range		     
			int x = begin;
			int y = user_input_bounds_.minY();
			int width = end - begin;
			int height = user_input_bounds_.maxY() - y;
			Dimension d =tree_app_.getTreeNodeImageDimension();
			x -= d.width/2; 
			width += d.width;

			//System.out.println("range= x:"+x+", y:"+y+", width:"+width+", height:"+height);
			Graphics g = image_.getGraphics();
			Color oldColor=g.getColor();
			g.setColor(color);
			g.fill3DRect(x,y,width,height,false);
			g.setColor(oldColor);
			tree_app_.drawPointSet(g);
			tree_app_.drawSegmentSet(g);
			tree_app_.drawQuerySegment(g);
			tree_app_.drawTree(g);
			
			panel_.getGraphics().drawImage(image_, 0, 0,(GeometryClient)tree_app_);
			reversible_ = true;
		}
        }
						  
};










