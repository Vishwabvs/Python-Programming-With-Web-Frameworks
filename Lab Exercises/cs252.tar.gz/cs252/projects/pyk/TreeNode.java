/*
 * TreeNode.java
 *
 * Description:
 *    This class contains the methods and variables for constructing
 *    and manipulating a binary tree node.
 */
import java.util.Vector;

class TreeNode
{
    protected TreeNode leftChild;   // the node's left child
    protected Object key;           // the node's key
    protected Object data;          // the data associated with the key
    protected TreeNode rightChild;  // the node's right child
    protected TreeNode parent;      // the node's parent
    protected int xPosition;        // the x position of the node, used
                                    // when showing the binary tree
    protected int yPosition;        // the y position of the node,
                                    // used when showing the binary tree
    protected int subTreeWidth;     // the width of the subtree
    protected int numberNodes;      // number of nodes
    protected Vector multHitList;   // hit list for nodes that have same key

    // constructor for tree node
    public TreeNode()
    {
       key = data = null;
       parent = leftChild = rightChild = null;
       multHitList = new Vector();
       numberNodes = 0;
       xPosition = yPosition = subTreeWidth = 0;
    }

    // constructor for key node, the data will be the same as the key
    public TreeNode(Object keyValue)
    {
       key = keyValue;
       data = null;
       multHitList = new Vector();
       parent = leftChild = rightChild = null;
    }

    // cosntructor for tree node, different values for key and data
    public TreeNode(Object keyValue, Object value)
    {
       key = keyValue;
       data = value;
       multHitList = new Vector();
       parent = leftChild = rightChild = null;
    }

    // return the data object
    Object getData()
    {
       return data;
    }

    // return the key value
    Object getKey()
    {
       return key;
    }

    // return the vector of multiple data objects for the same key
    Vector getMultHitList()
    {
       return multHitList;
    }

    // add a tree node to the multiple hit list for the current key
    public void addToMultHitList(TreeNode newNode)
    {
       multHitList.addElement(newNode);
    }

    // delete a tree node from the multiple hit list for the current key
    public TreeNode deleteFromMultHitList()
    {
       TreeNode tempTreeNode;

       if (multHitList.isEmpty() == false)
       {
          tempTreeNode = (TreeNode) (multHitList.firstElement());
          multHitList.removeElementAt(0);
       }
       else
       {
          tempTreeNode = null;
       }
       return tempTreeNode;
    }
};
