import java.awt.*;
import java.util.*;
import java.net.*;
import java.io.*;

import Node;
import Edge;
import PostOrderAlgorithm;
import CircleAlgorithm;
import MuratsAlgorithm;
import RandomAlgorithm;
import RandomColorAlgorithm;
import DepthColorAlgorithm;
import SiteColorAlgorithm;

import WebCrawler;
import HelpFrame;
import CrawlFrame;
import GetPageFrame;
import ErrorFrame;
import URLFrame;


public class WebTree extends java.applet.Applet implements Runnable {
   
   Thread application_;
  
   Image offscreenImage_;
   Graphics offscreenGraphics_;
   Canvas canvas_;
  
   // Constants
  
   final int CANVAS_WIDTH = 570;
   final int CANVAS_HEIGHT = 570;
   final int OFFSCREEN_WIDTH = 1710;
   final int OFFSCREEN_HEIGHT = 1710;
   final int RADIUS = 10;
   final boolean DEBUG = false;

   Vector edgeList_;
   Vector nodeList_;
   Vector temp_;
   Node selectedNode_;
  
   int graphWidth_;
   int graphHeight_;
  
   // Algorithms

   PostOrderAlgorithm postOrder_;
   CircleAlgorithm circle_;
   boolean isCircle_;
   MuratsAlgorithm murats_;
   RandomAlgorithm random_;
   RandomColorAlgorithm randomColor_;
   DepthColorAlgorithm depthColor_;
   SiteColorAlgorithm siteColor_;
   boolean edge_;
   boolean change_ = false;
   boolean reCalculate_ =true;

   // Window
  
   CrawlFrame window_;
   GetPageFrame getPage_;
   HelpFrame helpWindow_;
   ErrorFrame error_;
   URLFrame URLFrame_;
   
   // Scroll Bars
  
   Scrollbar hor_, ver_;
  
   GridBagLayout layout_;
   GridBagConstraints cons_;
   Button btn1, btn2, btn3, btn4, btn5;
   Button helpButton_, refreshButton_, deleteButton_;

   CheckboxGroup edgeOnOff_, animation_, layoutAlgorithms_, colorAlgorithms_;
   Label edgeOnOffLabel_, animationLabel_;
   boolean laidOut_ = false;
   Checkbox animationYes_, animationNo_, edgeOnOffYes_, edgeOnOffNo_;
   Checkbox lANone_, lACircle_, lACentered_, lACompressed_, lARandom_;
   Checkbox cANone_ , cADepth_, cARandom_, cASite_;
   
   Label btnLabel1_, btnLabel2_, btnLabel3_; // Edit, Layout, Color...
   
   Checkbox lACurrent_, cACurrent_, edgeOnOffCurrent_;

   // WebCrawler...
   
   WebCrawler webCrawler_;
   int crawlDepth_;
   int crawlMaxNodes_;
   URL rootURL_;
   boolean isCrawl_ = false;
  
   // Threads...
   
   FirstThread thread1_;

   // Dialog boxes...
   
   Button crawlerDialogButton_;
   TextField crawlerDialogText_;

   boolean addExisting_ = false;


// GET OFFSCREEN WIDTH //////////////////////////////////////////////////
  
public int getOffScreenWidth () { return OFFSCREEN_WIDTH; }


// GET OFFSCREEN HEIGHT ////////////////////////////////////////////////

public int getOffScreenHeight () { return OFFSCREEN_HEIGHT; }


// GET WIDTH //////////////////////////////////////////////////////////

public int getWidth () { return CANVAS_WIDTH; }

   
// GET HEIGHT /////////////////////////////////////////////////////////

public int getHeight () { return CANVAS_HEIGHT; }
  

// START /////////////////////////////////////////////////////////////
    
public void start ()
   {
      
      if (application_ == null); {
         application_ = new Thread(this);
         application_.start();
      }
      
   }


// SNAP TO ///////////////////////////////////////////////////////////
   
public void snapTo (Point point)
   {
      
      int x = point.x - CANVAS_WIDTH / 2;
      int y = point.y - CANVAS_HEIGHT / 2;
   
      hor_.setValue((int)(x / 12.67)); // What is this constant, Murat?
      ver_.setValue((int)(y / 12.67));
  
      change_ = true;
      
   }
  

// STOP /////////////////////////////////////////////////////////////
   
public void stop ()
   {
      
      if (application_ != null) {
         application_.stop();
         application_ = null;
      }
      
   }


// RUN /////////////////////////////////////////////////////////////   
  
public void run ()
   {
      
      while (true) {
         repaint();
         try {Thread.sleep(100); }
         catch(InterruptedException e) {}
      }
      
   }


// INIT ////////////////////////////////////////////////////////////
   
public void init ()
   {

      webCrawler_ = new WebCrawler(this);
      setLayout(null);

      if (DEBUG) System.out.println("Initializing applet...");

      getAppletContext().showStatus("Initializing applet...");
     
      isCircle_ = false;
      edge_ = true;
      selectedNode_ = null;
      
      edgeList_ = new Vector();
      nodeList_ = new Vector();
      
      offscreenImage_ = createImage(OFFSCREEN_WIDTH, OFFSCREEN_HEIGHT);
      offscreenGraphics_ = offscreenImage_.getGraphics();

      canvas_= new Canvas();
      canvas_.resize(CANVAS_WIDTH, CANVAS_HEIGHT);
      canvas_.setBackground(Color.white);
      createButtons();
     
      add(canvas_);
 
      ver_ = new Scrollbar(Scrollbar.VERTICAL, 1, 0, 0, OFFSCREEN_WIDTH/10);
      hor_ = new Scrollbar(Scrollbar.HORIZONTAL, 1, 0, 0, OFFSCREEN_HEIGHT/10);
      add(ver_);   
      add(hor_);
      
      graphWidth_ = size().width;
      graphHeight_ = size().height;
      
      // Initialize algorithms.
      
      postOrder_ = new PostOrderAlgorithm(this);
      circle_ = new CircleAlgorithm(this);
      murats_ = new MuratsAlgorithm(this);
      random_ = new RandomAlgorithm(this);
      randomColor_ = new RandomColorAlgorithm(this);
      depthColor_ = new DepthColorAlgorithm(this);
      siteColor_ = new SiteColorAlgorithm(this);

      // Different windows needed by the applet.
      
      window_ = new CrawlFrame("Crawler", this);
      window_.resize(200, 200);

      getPage_ = new GetPageFrame("Text from URL", this);
      getPage_.resize(200, 200);

      helpWindow_ = new HelpFrame("Help", this);
      helpWindow_.resize(200, 200);
   
      error_ = new ErrorFrame("Error!", this);
      error_.resize(200, 200);

      URLFrame_ = new URLFrame("URLs", this);
      URLFrame_.resize(200, 200);

      getAppletContext().showStatus("");

   }


// GO TO PAGE //////////////////////////////////////////////////////////
   
public void goToPage (URL theURL)
   {
      
      if (theURL != null) getAppletContext().showDocument(theURL);
      
   }


// GET PAGE ///////////////////////////////////////////////////////
   
public void getPage (URL theURL)
   {
  
      getPage_.show();
      if (theURL != null) getPage_.get(theURL);
      
   }


// MOUSE DOWN ////////////////////////////////////////////////////
   
public boolean myMouseDown (Event evt, int x, int y)
   {
      
      if (!isCrawl_) {
         
         if(evt.shiftDown()) {
            
            if (DEBUG) System.out.println("SHIFT DOWN");
            
         } else if (evt.controlDown())
            
            if (DEBUG) System.out.println("CONTROL DOWN");

         x -= canvas_.bounds().x - hor_.getValue() * 12.67;
         y -= canvas_.bounds().y - ver_.getValue() * 12.67;
  
         if (evt.target instanceof Canvas) {
    
            // special case the first node (the root)

            if (nodeList_.size() == 0) {
      
               addNode(x, y);
               return true;

            }

            // check to see if the mouse hit a node
         
            for (int i = 0; i < nodeList_.size(); i++) {

               Node temp = (Node)nodeList_.elementAt(i);

               Point currPos = temp.getPosition(); 

               if ((currPos.x + RADIUS > x && currPos.x - RADIUS < x) &&
                   (currPos.y + RADIUS > y && currPos.y - RADIUS < y)) {

                  // select the node
               
                  if (selectedNode_ == null || selectedNode_ != temp) {

                     if (DEBUG) System.out.println("selecting node");
                     
                     if (evt.shiftDown()) goToPage(temp.getURL());
                     
                     else if (evt.controlDown()) getPage(temp.getURL());
                     
                     else selectNode(temp);
                  
                     return true;
                     
                  }

                  // deselect the node
               
                  else if (selectedNode_ == temp) {

                     if (DEBUG) System.out.println("deselecting node");
		 
                     if (evt.shiftDown()) goToPage(temp.getURL());

                     else if (evt.controlDown()) getPage(temp.getURL());
                     else deselectNode();
                     
                     return true;
                     
                  }                  
	
               }
               
            }

            // if there's no selected node do nothing
         
            if (selectedNode_ == null) {

               // if (DEBUG) System.out.println("doing nothing");

               return true;
               
            } else {

               if (DEBUG) System.out.println("adding node");

               addNode(x, y);
               
            }

         }
         
      }
      
      return true;

   }
  

// MOUSE DRAG /////////////////////////////////////////////////
   
public boolean myMouseDrag (Event evt, int x, int y)
   {
     
      if (!isCrawl_) {
         
         if (evt.target instanceof Canvas) {
	 
            x -= canvas_.bounds().x - hor_.getValue() * 12.67;
            y -= canvas_.bounds().y - ver_.getValue() * 12.67;
	 
            if (DEBUG) System.out.println("canvas x = " + canvas_.bounds().x +
                                          " hor = " + hor_.getValue() +
                                          " canvas y = " + canvas_.bounds().y +
                                          " ver = " + ver_.getValue());
	 
            if (selectedNode_ != null) {
               
               selectedNode_.setPosition(new Point(x, y));
	   
               // Adjust the scrollbars
               
               double horizontal = hor_.getValue() * 12.67;
               double vertical = ver_.getValue() * 12.67;

               if (x  < horizontal + RADIUS) {

                  if (hor_.getValue() > 0) hor_.setValue(hor_.getValue() - 1);

               } else if (x > CANVAS_WIDTH + horizontal - RADIUS)
                  
                  if (hor_.getValue() < 90) hor_.setValue(hor_.getValue() + 1);

               if (y < vertical + RADIUS) {
                  
                  if (ver_.getValue() > 0) ver_.setValue(ver_.getValue() - 1);

               } else if (y > CANVAS_HEIGHT + vertical - RADIUS)

                  if (ver_.getValue() < 90) ver_.setValue(ver_.getValue() + 1);

               change_ = true;
               
            }
            
         }
         
      }
      
      return true;
     
   }
  

// MY MOUSE UP ////////////////////////////////////////////////////////
   
public final boolean myMouseUp (Event evt, int x, int y) { return true; }

   public boolean myMouseMove (Event evt, int x, int y)  {  return true; }

   public boolean myMouseEnter (Event evt, int x, int y) { 
     if (DEBUG) System.out.println("MOUSE ENTER");
     change_ = true;
     return true; }

   public boolean myMouseExit (Event evt, int x, int y) { 
     if(DEBUG) System.out.println("MOUSE EXIT");
     change_ = true;
     return true; }
   
  
// ACTION /////////////////////////////////////////////////////////
   
public boolean handleEvent(Event evt)
   {
      
      switch (evt.id) {
         
       case Event.MOUSE_DOWN:
         return myMouseDown(evt, evt.x, evt.y);
         
       case Event.MOUSE_DRAG:
         return myMouseDrag(evt, evt.x, evt.y);
         
       case Event.MOUSE_UP:
         return myMouseUp(evt, evt.x, evt.y);
         
       case Event.MOUSE_MOVE:
         return myMouseMove(evt, evt.x, evt.y);
         
       case Event.MOUSE_ENTER:
         return myMouseEnter(evt, evt.x, evt.y);
         
       case Event.MOUSE_EXIT:
         return myMouseExit(evt, evt.x, evt.y);
         
      }
    
      if (evt.target instanceof Button) button((String)evt.arg);
      else if (evt.target instanceof Scrollbar)	change_= true;

      return true;
      
   }


// BUTTON /////////////////////////////////////////////////////////
   
public final void button (String s)
  {
     
     // Parse the string.
     
     if (s.equals("Clear")) clear();
    
     else if (s.equals("Crawl")) {

        if (selectedNode_ != null) {
           
           if (selectedNode_.getURL() == null)
              error_.setError("Selected node does not have a valid URL.", 
                              "Select another node.");
           else {
              
              window_.tf_.setText(selectedNode_.getURL().toString());
              window_.tf_.setEditable(false);
              window_.show();
              
           }
           
      } else {
         
         window_.tf_.setText("http://");
         window_.tf_.setEditable(true);
         window_.show();
         
      }
        
     } else if (s.equals("MakeRoot")) makeRoot();

     else if (s.equals("Stop")) {
        
	if (thread1_!= null) thread1_.stop();
	crawlDone();
        
     } else if (s.equals("Refresh")) change_ = true;

     else if (s.equals("Help")) {
        
	helpWindow_.show();
	if (DEBUG) System.out.println("Help");
        
     } else if (s.equals("Delete")) deleteNode();

     else if (s.equals("URLs")) displayURLs();
  }


// DISPLAY URLS ///////////////////////////////////////////////////

public final void displayURLs ()
   {

      System.out.println("displaying URLs...");
      URLFrame_.show();
      
   }

   
// CLEAR /////////////////////////////////////////////////////

public final void clear ()
   {

      nodeList_.removeAllElements();
      edgeList_.removeAllElements();
      selectedNode_ = null;
      change_ = true;
      
      URLFrame_.update(nodeList_);

   }

   
// UPDATE ////////////////////////////////////////////////////
   
   public void update (Graphics g) { paint(g); }


// PAINT /////////////////////////////////////////////////////

public void paint (Graphics g)
   {
    
      if (!laidOut_) setLayout();
    

      if (lACurrent_ != layoutAlgorithms_.getCurrent()) {
         
         lACurrent_ = layoutAlgorithms_.getCurrent();
         change_ = true;
         reCalculate_ = true;
         
      }

      if (cACurrent_ != colorAlgorithms_.getCurrent()) {
         
         cACurrent_ = colorAlgorithms_.getCurrent();
         change_ = true;
         reCalculate_ = true;

      }
    
      if (edgeOnOffCurrent_ != edgeOnOff_.getCurrent()) {
         
         change_ = true;
         edgeOnOffCurrent_ = edgeOnOff_.getCurrent();
         if (edgeOnOffCurrent_== edgeOnOffYes_) edge_= true;
         else edge_ = false;
         
      }

      if (DEBUG) System.out.println("painting");

      if (change_) { 

         offscreenGraphics_.setColor(canvas_.getBackground());
         offscreenGraphics_.fillRect((int)(hor_.getValue() * 12.67),
                                     (int)(ver_.getValue() * 12.67),
                                     graphWidth_, graphHeight_);
         
         if (reCalculate_) {
            
            reCalculate_ = false;
            
            if (lACurrent_ != lANone_) {
               
               if (lACurrent_ == lACircle_) {
                  
                  circle_.execute(nodeList_);
                  isCircle_ = true;
                  
               } else if (lACurrent_ == lACentered_)
                  murats_.execute(nodeList_);
               
               else if (lACurrent_ == lACompressed_)
                  postOrder_.execute(nodeList_);
               
               else if (lACurrent_ == lARandom_) {
                  
                  random_.execute(nodeList_);
                  layoutAlgorithms_.setCurrent(lANone_);
                  
               }
            }
    
            if (cACurrent_ != cANone_) {
               
               if (cACurrent_ == cARandom_) {
                  
                  randomColor_.execute(nodeList_);
                  colorAlgorithms_.setCurrent(cANone_);
                  
               } else if (cACurrent_ == cADepth_)
                  depthColor_.execute(nodeList_);
               
               else if (cACurrent_ == cASite_) siteColor_.execute(nodeList_);

            }
            
         }
         
         if (lACurrent_ == lACircle_) isCircle_ =true;

         if (isCircle_) {
            
            drawCircles();
            isCircle_ = false;
            
         }
         
         if (edge_) drawEdges();
         
         drawNodes();

         Graphics temp = canvas_.getGraphics();
         
         temp.drawImage(offscreenImage_, (int)(-hor_.getValue() * 12.67),
                        (int)(-ver_.getValue() * 12.67), this);
         
         change_ = false;
      }
      
  }


// DRAW CIRCLES ///////////////////////////////////////////////
   
public final void drawCircles ()
   {
      
     int prev_rad = 0;
      if (nodeList_.size() == 0) return;
         
      Vector interval = circle_.getInterval();
    
      if (interval == null) System.out.println("EMPTY LIST");
      else{
      for (int i = 0; i < interval.size(); i++) {
	int temp = ((Integer)interval.elementAt(i)).intValue() * 2;
	offscreenGraphics_.setColor(Color.blue);
	offscreenGraphics_.drawOval(OFFSCREEN_WIDTH/2 -(prev_rad+temp)/2  
				    , OFFSCREEN_HEIGHT/2 -(prev_rad+temp)/2 ,
				    temp+prev_rad, temp+prev_rad);
	prev_rad += temp;

      }
      }
   }



// DRAW NODES ////////////////////////////////////////////////

public final void drawNodes ()
   {

      if (DEBUG) System.out.println("drawing Nodes");
  
      for (int i = 0; i < nodeList_.size(); i++) {

         Node temp;
         temp = (Node)nodeList_.elementAt(i);

         int posX = temp.getPosition().x;
         int posY = temp.getPosition().y;
         
         offscreenGraphics_.setColor(temp.getColor());
         offscreenGraphics_.drawOval(posX - RADIUS, 
                                     posY - RADIUS,
                                     2 * RADIUS, 2 * RADIUS);
            
         if (temp != selectedNode_)
            offscreenGraphics_.setColor(temp.getColor());
         else
            offscreenGraphics_.setColor(Color.white);
         
         offscreenGraphics_.fillOval(posX - RADIUS + 2, 
                                     posY - RADIUS + 2,
                                     2 * (RADIUS - 2), 2 * (RADIUS - 2));
            
         if (temp != selectedNode_)
            offscreenGraphics_.setColor(Color.white);
         else
            offscreenGraphics_.setColor(Color.black);
               
         if (temp.getId() > 99) {
            
            offscreenGraphics_.setFont( new Font("TimesRoman", Font.PLAIN,10));
            offscreenGraphics_.drawString((new Integer(temp.getId())).toString(),
               posX - 6,
               posY + 3);
	    offscreenGraphics_.setFont( new Font("TimesRoman", Font.PLAIN,12));
            
         } else if (temp.getId() < 10) {
            
            offscreenGraphics_.drawString((new Integer(temp.getId())).toString(),
                                          posX - 2,
                                          posY + 4);
	    
         } else {
            
            offscreenGraphics_.drawString((new Integer(temp.getId())).toString(),
                                          posX - 5,
                                          posY + 4);
         }
	 
            
      }
      
   }


// DRAW EDGES ////////////////////////////////////////////////////////
   
public final void drawEdges ()
   {

      if (DEBUG) System.out.println("drawing Edges.." + edgeList_.size());
  
      for (int i = 0; i < edgeList_.size(); i++) {

         Edge temp = (Edge)edgeList_.elementAt(i);
         Point vertex1 = temp.dest.getPosition();
         Point vertex2 = temp.source.getPosition();

         offscreenGraphics_.setColor(Color.black);
         offscreenGraphics_.drawLine(vertex1.x, vertex1.y,
                                     vertex2.x, vertex2.y);

         // Create the arrowheads
         
         Polygon arrow = new Polygon();
         double theta = Math.atan(((double)Math.abs(vertex1.y - vertex2.y)) /
                                  ((double)Math.abs(vertex1.x - vertex2.x))); 

         if (DEBUG) System.out.println(theta);
      
         double r_cos = RADIUS * Math.cos(theta);
         double r_sin = RADIUS * Math.sin(theta);
         
         double circle_radius = 1.3 * RADIUS / 2.0;
         int SIZE = 2;

         double angle1 = theta + (2.0 * Math.PI / 3.0);
         double angle2 = theta + (4.0 * Math.PI / 3.0);
         
         if (vertex1.y <= vertex2.y && vertex1.x >= vertex2.x) {

            int intersectx = (int)(vertex1.x - r_cos);
            int intersecty = (int)(vertex1.y + r_sin);
            
            arrow.addPoint(intersectx, intersecty);
            
            int intersectx2 = (int)(vertex1.x - SIZE * r_cos);
            int intersecty2 = (int)(vertex1.y + SIZE * r_sin);		

            int intersectx3 = (int)(intersectx2 - Math.cos(angle1) *
                                    circle_radius);
            int intersecty3 = (int)(intersecty2 + Math.sin(angle1) *
                                    circle_radius);
            
            arrow.addPoint(intersectx3, intersecty3);
            
            int intersectx4 = (int)(intersectx2 - Math.cos(angle2) *
                                    circle_radius);
            int intersecty4 = (int)(intersecty2 + Math.sin(angle2) *
                                    circle_radius);
            
            arrow.addPoint(intersectx4, intersecty4);

         } else if (vertex1.y >= vertex2.y && vertex1.x >= vertex2.x) {
            
            int intersectx = (int)(vertex1.x - r_cos);
            int intersecty = (int)(vertex1.y - r_sin);
            
            arrow.addPoint(intersectx, intersecty);
            
            int intersectx2 = (int)(vertex1.x - SIZE * r_cos);
            int intersecty2 = (int)(vertex1.y - SIZE * r_sin);		

            int intersectx3 = (int)(intersectx2 - Math.cos(angle1) *
                                    circle_radius);
            int intersecty3 = (int)(intersecty2 - Math.sin(angle1) *
                                    circle_radius);
            
            arrow.addPoint(intersectx3, intersecty3);
            
            int intersectx4 = (int)(intersectx2 - Math.cos(angle2) *
                                    circle_radius);
            int intersecty4 = (int)(intersecty2 - Math.sin(angle2) *
                                    circle_radius);
            
            arrow.addPoint(intersectx4, intersecty4);

         } else if (vertex1.y > vertex2.y && vertex1.x < vertex2.x) {
            
            int intersectx = (int)(vertex1.x + r_cos);
            int intersecty = (int)(vertex1.y - r_sin);
            
            arrow.addPoint(intersectx, intersecty);
            
            int intersectx2 = (int)(vertex1.x + SIZE * r_cos);
            int intersecty2 = (int)(vertex1.y - SIZE * r_sin);
            
            int intersectx3 = (int)(intersectx2 + Math.cos(angle1) *
                                    circle_radius);
            int intersecty3 = (int)(intersecty2 - Math.sin(angle1) *
                                    circle_radius);
            
            arrow.addPoint(intersectx3, intersecty3);
            
            int intersectx4 = (int)(intersectx2 + Math.cos(angle2) *
                                    circle_radius);
            int intersecty4 = (int)(intersecty2 - Math.sin(angle2) *
                                    circle_radius);
          
            arrow.addPoint(intersectx4, intersecty4);
          
	} else {
           
           int intersectx = (int)(vertex1.x + r_cos);
           int intersecty = (int)(vertex1.y + r_sin);

           arrow.addPoint(intersectx, intersecty);

           int intersectx2 = (int)(vertex1.x + SIZE * r_cos);
           int intersecty2 = (int)(vertex1.y + SIZE * r_sin);
           
           int intersectx3 = (int)(intersectx2 + Math.cos(angle1) *
                                   circle_radius);
           int intersecty3 = (int)(intersecty2 + Math.sin(angle1) *
                                   circle_radius);
           
           arrow.addPoint(intersectx3, intersecty3);
          
           int intersectx4 = (int)(intersectx2 + Math.cos(angle2) *
                                   circle_radius);
           int intersecty4 = (int)(intersecty2 + Math.sin(angle2) *
                                   circle_radius);
           
           arrow.addPoint(intersectx4, intersecty4);
          
	}

         if (DEBUG) System.out.println("adding polygon");
         offscreenGraphics_.fillPolygon(arrow);
         
      }

   }


// MAKE ROOT////////////////////////////////////////////////////////////

public void makeRoot() {

   temp_ = new Vector();
  
   if (selectedNode_ == null) {
      
      error_.setError("You have to select"," a node first!");
      return;
      
   } else {
      
      selectedNode_.setParent(null);
      selectedNode_.setSibling(null);
      int newDepth = selectedNode_.getDepth();
      traverse(selectedNode_);
      nodeList_.removeAllElements();
      
      for (int i = 0; i < temp_.size(); i++){
         
	nodeList_.addElement((Node)temp_.elementAt(i));
	Node tempNode = ((Node)nodeList_.elementAt(i)); 
	tempNode.setDepth(tempNode.getDepth()- newDepth);

      }
    
      // Update edge list
      
      int i = edgeList_.size() - 1;
      
      while (i >= 0) {
         
         if (!nodeList_.contains(((Edge)edgeList_.elementAt(i)).source) || 
             !nodeList_.contains(((Edge)edgeList_.elementAt(i)).dest))

            edgeList_.removeElementAt(i);
         
         i--;
         
      }
      
      reCalculate_ = true;
      change_ = true;

   }

   URLFrame_.update(nodeList_);

}


// TRAVERSE ///////////////////////////////////////////////////////////

public void traverse (Node node)
   {
  
      temp_.addElement(node);
      Node firstChild = node.getFirstChild();
      Node sibling = node.getSibling();
       
      if (firstChild != null) traverse(firstChild);
      if (sibling != null) traverse(sibling);
    
}


// DELETE NODE ////////////////////////////////////////////////////////
  
private void deleteNode()
   {
      
      reCalculate_ = true;

      if (DEBUG) System.out.println("Deleting node...");

      if (selectedNode_ == null) {
         
	error_.setError("No selected node!");
	return; // nothing to delete
        
      }
      
      removeAllReferencesToSelectedNode();

      deselectNode();

      URLFrame_.update(nodeList_);
      
   }


// REMOVE ALL REFERENCES TO A NODE ////////////////////////////////////

private void removeAllReferencesToSelectedNode()
   {

      // Climb up the tree.

      Node child;
      
      if (!selectedNode_.isRoot()) {
      
         Node parent = selectedNode_.getParent();

         child = parent.getFirstChild();
         
         if (child == selectedNode_)

            parent.setFirstChild(selectedNode_.getSibling());
         
         else for (; child != null;
                   child = child.getSibling()) {

            if (child.getSibling() == selectedNode_) {

               child.setSibling((child.getSibling()).getSibling());
               break;
               
            }

         }
                  
         // Now remove the edge going to it.

         for (int i = 0; i < edgeList_.size(); i++) {

            Edge tempEdge = (Edge)edgeList_.elementAt(i);

            if (tempEdge.dest == selectedNode_) {

               edgeList_.removeElement(tempEdge);
               break;

            }
         }

      }

      nodeList_.removeElement(selectedNode_); // safe to remove now

      // Climb down the tree.
      
      for (child = selectedNode_.getFirstChild(); child != null;
           child = child.getSibling()) {
      
         selectNode(child);

         removeAllReferencesToSelectedNode();

      }

   }
   
   
// FIND MAX ID ///////////////////////////////////////////////////////
  
final public int getMaxId ()
   {
      
   int temp = 0;
   
   for (int i = 0; i < nodeList_.size(); i++) {
      
      if (((Node)(nodeList_.elementAt(i))).getId() > temp) {

         temp = ((Node)(nodeList_.elementAt(i))).getId();

      }
   }
   
   return temp;
   
  }

  
// ADD NODE ////////////////////////////////////////////////////////////

final public void addNode (int x, int y)
   {
    
      // Create the new Node
      
      Node temp = new Node();
     
      temp.setPosition(new Point(x, y));
     
      int id;
     
      if (nodeList_.isEmpty()) id = 0;
      else id = getMaxId()+ 1;
     
      temp.setId(id);
     
      temp.setColor(Color.red);

      if (selectedNode_ != null) {
         
         // Add it as the first child of the selected Node
         
         Node swap = selectedNode_.getFirstChild();
         
         if (swap != null)  swap.setRank(1);

	 temp.setSibling(swap);
	 selectedNode_.setFirstChild(temp);
	 temp.setRank(1);
         temp.setFirstChild(null);
         temp.setParent(selectedNode_);
         temp.setDepth(selectedNode_.getDepth() + 1);
     
   
	 nodeList_.addElement(temp);

         URLFrame_.update(temp); // update the URL window

         Edge temp2 = new Edge();
         
         temp2.source = selectedNode_;
         temp2.dest = temp;
         edgeList_.addElement(temp2);


         while (temp.getSibling() != null){
            temp = temp.getSibling();
	    temp.setRank(temp.getRank() + 1);
         }

         change_ = true;
	 reCalculate_ = true;
	 deselectNode();
         
         return; // no need to repaint twice...
         
      }

      // Root
      
      temp.setSibling(null);
      temp.setFirstChild(null);
      temp.setParent(null);
      temp.setRank(0);
      
      nodeList_.addElement(temp);

      URLFrame_.update(temp); // update the URL window
      
      change_ = true;
      reCalculate_ = true;

}


// ADD NODE /////////////////////////////////////////////////////////////

public void addNode (Node temp)
   {

      Date date = new Date();
      Random random = new Random();

      // random.setSeed(date.getTime());
  
      int randomX =
         (int)(random.nextDouble() * (CANVAS_WIDTH - 2 * RADIUS) + RADIUS);
      
      int randomY =
         (int)(random.nextDouble() * (CANVAS_HEIGHT - 2 * RADIUS) + RADIUS);

      randomX += OFFSCREEN_WIDTH / 2 - CANVAS_WIDTH / 2;
      randomY += OFFSCREEN_HEIGHT / 2 - CANVAS_HEIGHT / 2;
  
      temp.setPosition(new Point(randomX, randomY));
      temp.setColor(Color.red);

      selectedNode_ = temp.getParent(); 

      if (DEBUG) temp.print();

      if(selectedNode_ == null) { // first node on a graph

         temp.setId(0);
         nodeList_.addElement(temp);

         URLFrame_.update(temp);
         
         change_ = true;
         reCalculate_ = true;
         deselectNode();

      } else {

         temp.setId(getMaxId() + 1);
  
         // Add it as the first child of the selected Node
         Node swap = selectedNode_.getFirstChild();
    
         if (swap != null)  swap.setRank(1);
    
         temp.setSibling(swap);

         selectedNode_.setFirstChild(temp);

         temp.setRank(1);

         nodeList_.addElement(temp);

         URLFrame_.update(temp);

         Edge temp2 = new Edge();
         temp2.source = selectedNode_;
         temp2.dest = temp;
         edgeList_.addElement(temp2);

         while (temp.getSibling() != null) {
            temp = temp.getSibling();
            temp.setRank(temp.getRank() + 1);
         }
         
         change_ = true;
         reCalculate_ = true;
         deselectNode();

    }

      snapTo(new Point(OFFSCREEN_WIDTH / 2, OFFSCREEN_HEIGHT / 2));
  
}

   
// DESELECT NODE /////////////////////////////////////////////////
   
final public void deselectNode ()
   {
     
      getAppletContext().showStatus("");
      selectedNode_ = null;
      change_ = true;


   }


// SELECT NODE //////////////////////////////////////////////////////
   
final public void selectNode (Node temp)
   {

      Node parent = temp.getParent();
      Node firstChild = temp.getFirstChild();
      Node sibling = temp.getSibling();

      URL url = temp.getURL();

      if (DEBUG) {

         String status = new String(
            "URL: " + ((url != null) ? (url.toString()) : ("none")) +
            
            "; rank: " + temp.getRank() + "; parent: " +

            ((parent != null) ?
             (new Integer(parent.getId()).toString()) :
             "null") + ", first: " +
            
            ((firstChild != null) ?
             (new Integer(firstChild.getId()).toString()) :
             "null") + ", sibling: " +
                                    
            ((sibling != null) ?
             (new Integer(sibling.getId()).toString()) :
             "null"));

         getAppletContext().showStatus(status);
         
      } else {
         
         getAppletContext().showStatus("URL: " + ((url != null) ?
                                                  (url.toString()) :
                                                  ("none")));

      }
      
      selectedNode_ = temp;
      change_ = true;

   }


// CREATE BUTTONS //////////////////////////////////////////////////////

final public void createButtons ()
   {
   
    btnLabel1_ = new Label("Edit");
    add(btnLabel1_);
    
    btnLabel2_ = new Label("Layout Algorithms");
    add(btnLabel2_);
    
    btnLabel3_ = new Label("Coloring Algorithms");
    add(btnLabel3_);

    // Layout algorithms
    
    layoutAlgorithms_ = new CheckboxGroup();
    
    lANone_ = new Checkbox("None", layoutAlgorithms_, true);
    add(lANone_);
    
    lACircle_ = new  Checkbox("Circle", layoutAlgorithms_, false);
    add(lACircle_);
    
    lACentered_ = new  Checkbox("Centered", layoutAlgorithms_, false);
    add(lACentered_);

    lACompressed_ = new  Checkbox("Compressed", layoutAlgorithms_, false);
    add(lACompressed_);
    
    lARandom_ = new  Checkbox("Random", layoutAlgorithms_, false);
    add(lARandom_);

    // Coloring algorithms
    
    colorAlgorithms_ = new CheckboxGroup();
    
    cANone_ =  new Checkbox("None", colorAlgorithms_, true);
    add(cANone_);
    
    cADepth_ =  new Checkbox("Depth", colorAlgorithms_, false);
    add(cADepth_);
    
    cARandom_ =  new Checkbox("Random", colorAlgorithms_, false);
    add(cARandom_);
    
    cASite_ =  new Checkbox("Site", colorAlgorithms_, false); add(cASite_);

    // Editing buttons
    
    btn1 = new Button("Crawl");
    add(btn1);
    
    btn2 = new Button("MakeRoot");
    add(btn2);
    
    btn3 = new Button("Stop");
    add(btn3);
    
    btn4 = new Button("Clear");
    add(btn4);

    btn5 = new Button("URLs");
    add(btn5);
    
    deleteButton_ = new Button("Delete");
    add(deleteButton_);

    // Miscellaneous Buttons
    
    helpButton_ = new Button("Help");
    add(helpButton_);
    
    refreshButton_ = new Button("Refresh");
    add(refreshButton_);

    // Animation
    
    animation_ = new CheckboxGroup();
    animationLabel_ = new Label("Animation");
    add(animationLabel_);

    animationYes_ = new Checkbox("Yes", animation_, false);
    add(animationYes_);

    animationNo_ = new Checkbox("No", animation_, true);
    add(animationNo_);

    // Edges
    
    edgeOnOffLabel_ = new Label ("Edges");
    add(edgeOnOffLabel_);
    edgeOnOff_ = new CheckboxGroup();
    edgeOnOffYes_ = new Checkbox("Yes", edgeOnOff_, true);
    edgeOnOffNo_ = new Checkbox("No", edgeOnOff_, false);
    add(edgeOnOffYes_);
    add(edgeOnOffNo_);
    
  }
  

// SET LAYOUT /////////////////////////////////////////////////
   
   final public void setLayout ()
   {
      
      laidOut_ = true;

      Insets insets = insets();
      insets = insets();
      
      int tempx = 75;
      int tempy = 75;
      int templeft = 2;
      
      Font f = new Font("TimesRoman", Font.BOLD, 14);
      
      btnLabel1_.reshape(insets.left + templeft + tempx - 15, insets.top,
                         tempx * 2, tempy / 3);
      
      btnLabel1_.setFont(f);
      
      btnLabel2_.reshape(insets.left + templeft + tempx * 2,
                         insets.top, tempx * 3, tempy / 3);
      
      btnLabel2_.setFont(f);
      
      btnLabel3_.reshape(insets.left + templeft + tempx * 4,
                         insets.top, tempx * 2, tempy / 3);
      
      btnLabel3_.setFont(f);
      
      btn1.reshape(insets.left + templeft, insets.top + tempy / 3,
                   tempx, tempy / 3);
      
      btn3.reshape(insets.left + templeft, insets.top + 2 * tempy / 3,
                   tempx, tempy / 3);
      
      btn2.reshape(insets.left + templeft, insets.top + tempy,
                   tempx, tempy / 3);
      
      btn4.reshape(insets.left + templeft + tempx, insets.top + tempy / 3,
                   tempx, tempy / 3);

      btn5.reshape(insets.left + templeft + tempx, insets.top + 2 * tempy / 3,
                   tempx, tempy / 3);
      
      deleteButton_.reshape(insets.left + templeft + tempx, insets.top +
                            tempy, tempx, tempy / 3);

      lANone_.reshape(insets.left + templeft + tempx * 2, insets.top +
                      tempy / 3  , tempx, tempy / 3);
      
      lACircle_.reshape(insets.left + templeft + tempx * 2, insets.top + 2 *
                        tempy / 3, tempx, tempy / 3);
      
      lACentered_.reshape(insets.left + templeft + tempx * 2, insets.top +
                          tempy    , tempx, tempy / 3);
      
      lACompressed_.reshape(insets.left - 13 + templeft + tempx * 3,
                            insets.top + tempy / 3  , tempx + 25, tempy / 3);
      
      lARandom_.reshape(insets.left - 13 + templeft + tempx * 3,
                        insets.top + 2 * tempy / 3, tempx, tempy / 3);
      
      cANone_.reshape(insets.left + 10 + templeft + tempx * 4, insets.top +
                      tempy / 3  , tempx, tempy / 3);
      
      cADepth_.reshape(insets.left + 10 + templeft + tempx * 4, insets.top +
                       2 * tempy / 3, tempx, tempy / 3);
      
      cARandom_.reshape(insets.left + 10 + templeft + tempx * 4, insets.top +
                        tempy, tempx, tempy / 3);
      
      cASite_.reshape(insets.left + templeft + tempx * 5, insets.top +
                      tempy / 3  , tempx, tempy / 3);

      animationLabel_.reshape(insets.left + templeft + tempx * 6, insets.top,
                              tempx, tempy / 3);
      
      animationLabel_.setFont(f);
      animationYes_.reshape(insets.left + templeft + tempx * 6, insets.top +
                            tempy / 3, tempx, tempy / 3);
      
      animationNo_.reshape(insets.left + templeft + tempx * 6, insets.top +
                           2 * tempy / 3, tempx, tempy / 3);

      edgeOnOffLabel_.reshape(insets.left + templeft + tempx * 7, insets.top,
                              tempx, tempy / 3);
      
      edgeOnOffLabel_.setFont(f);
      edgeOnOffYes_.reshape(insets.left + templeft + tempx * 7, insets.top +
                            tempy / 3, tempx,tempy / 3);
      
      edgeOnOffNo_.reshape(insets.left + templeft + tempx * 7, insets.top +
                           2 * tempy / 3, tempx, tempy / 3);
      
      refreshButton_.reshape(insets.left - 15 + templeft + tempx * 6,
                             insets.top + tempy, tempx, tempy / 3);
      
      helpButton_.reshape(insets.left - 15 + templeft + tempx * 7,
                          insets.top + tempy, tempx, tempy / 3);

      canvas_.reshape(insets.left + templeft, insets.top +  tempy  * 3 / 2,
                      CANVAS_WIDTH, CANVAS_HEIGHT);
      
      ver_.reshape(insets.left + CANVAS_WIDTH + templeft, insets.top + tempy *
                   3 / 2, 20, CANVAS_HEIGHT);
      
      hor_.reshape(insets.left + templeft, CANVAS_HEIGHT + tempy * 3 / 2 +
                   insets.top, CANVAS_WIDTH, 20);

      window_.reshape(insets.left + 75, insets.top + 100, 400, 200);

      getPage_.reshape(insets.left + 75, insets.top + 100, 600, 550);
  
      helpWindow_.reshape(insets.left + 75, insets.top + 100, 600, 550);

      URLFrame_.reshape(insets.left + 75, insets.top + 100, 400, 525);      
  
      error_.reshape(insets.left + 75, insets.top + 100, 400, 200);
     
  }

   
// CRAWL DONE ////////////////////////////////////////////////////////
   
public void crawlDone ()
   {
      
      isCrawl_ = false;
      btn1.enable();
      btn4.enable();
      deleteButton_.enable();

   }       

}


  
