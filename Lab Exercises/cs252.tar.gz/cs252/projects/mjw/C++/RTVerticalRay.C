#include "RTVerticalRay.H"
