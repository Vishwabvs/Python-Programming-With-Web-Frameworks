package graph;

import java.awt.*;

public class ArrowHead extends Canvas {
    private final static int DIVISIONS = 90;
    private final static double ANGLE = 0.8;
    private final static double LENGTH = 7.0;

    private final static int TOTAL = 4 * DIVISIONS;
    private final static int HALF = 2 * DIVISIONS;
    private final static double MIN = LENGTH * LENGTH + 5;
    private final static double HALF_PI = Math.PI / 2.0;

    public final static int TEST_SIZE = 300;

    static int addX_[], addY_[], addX2_[], addY2_[];
    static int xPoints_[], yPoints_[];
    int x_, y_;
    
    static {
	addX_ = new int[DIVISIONS * 4];
	addY_ = new int[DIVISIONS * 4];
	addX2_ = new int[DIVISIONS * 4];
	addY2_ = new int[DIVISIONS * 4];
	
	xPoints_ = new int[3];
	yPoints_ = new int[3];
	
	for (int loop = 0; loop < DIVISIONS; ++loop) {
	    double angle = -((double)loop / (double)DIVISIONS) * HALF_PI;
	    angle += Math.PI;

	    addX_[loop] = (int)Math.round(Math.cos(angle + ANGLE) * LENGTH);
	    addY_[loop] = (int)-Math.round(Math.sin(angle + ANGLE) * LENGTH);
	    addX2_[loop] = (int)Math.round(Math.cos(angle - ANGLE) * LENGTH);
	    addY2_[loop] = (int)-Math.round(Math.sin(angle - ANGLE) * LENGTH);

	    // from first to second
	    addX_[loop + DIVISIONS] = -addY_[loop];
	    addY_[loop + DIVISIONS] = addX_[loop];
	    addX2_[loop + DIVISIONS] = -addY2_[loop];
	    addY2_[loop + DIVISIONS] = addX2_[loop];

	    // from first to third
	    addX_[loop + DIVISIONS * 2] = -addX_[loop];
	    addY_[loop + DIVISIONS * 2] = -addY_[loop];
	    addX2_[loop + DIVISIONS * 2] = -addX2_[loop];
	    addY2_[loop + DIVISIONS * 2] = -addY2_[loop];

	    // from first to fourth
	    addX_[loop + DIVISIONS * 3] = addY_[loop];
	    addY_[loop + DIVISIONS * 3] = -addX_[loop];
	    addX2_[loop + DIVISIONS * 3] = addY2_[loop];
	    addY2_[loop + DIVISIONS * 3] = -addX2_[loop];
	}
    }

    static void FillHead(Graphics graphics, int x1, int y1, int x2, int y2) {
	double dX = x2 - x1; double dY = y2 - y1;
	if (dX * dX + dY * dY > MIN) {
	    double angle = Math.atan(dY / dX);
	    int index = (int)Math.round((angle / HALF_PI) * (double)DIVISIONS);
	    if (dX < 0)
		index += HALF;
	    if (index < 0)
		index += TOTAL;
	    
	    xPoints_[0] = x2; yPoints_[0] = y2;
	    xPoints_[1] = x2 + addX_[index]; yPoints_[1] = y2 + addY_[index];
	    xPoints_[2] = x2 + addX2_[index]; yPoints_[2] = y2 + addY2_[index];
	    
	    graphics.fillPolygon(xPoints_, yPoints_, 3);
//	    graphics.drawLine(x2, y2, x2 + addX_[index], y2 + addY_[index]);
//	    graphics.drawLine(x2, y2, x2 + addX2_[index], y2 + addY2_[index]);
	}
    }

    static void DrawHead(Graphics graphics, int x1, int y1, int x2, int y2) {
	double dX = x2 - x1; double dY = y2 - y1;
	if (dX * dX + dY * dY > MIN) {
	    double angle = Math.atan(dY / dX);
	    int index = (int)Math.round((angle / HALF_PI) * (double)DIVISIONS);
	    if (dX < 0)
		index += HALF;
	    if (index < 0)
		index += TOTAL;
	    
	    graphics.drawLine(x2, y2, x2 + addX_[index], y2 + addY_[index]);
	    graphics.drawLine(x2, y2, x2 + addX2_[index], y2 + addY2_[index]);
	}
    }

    public ArrowHead() {
	resize(TEST_SIZE, TEST_SIZE);
	x_ = -1;
	y_ = -1;
    }
    
    public boolean mouseDown(Event e, int x, int y) {
	return mouseDrag(e, x, y);
    }

    public boolean mouseDrag(Event e, int x, int y) {
	x_ = x;
	y_ = y;
	repaint();
	return true;
    }

    public boolean mouseUp(Event e, int x, int y) {
	return mouseDrag(e, x, y);
    }

    public void paint(Graphics g) {
	g.drawRect(TEST_SIZE / 2 - RADIUS, TEST_SIZE / 2 - RADIUS,
		   RADIUS * 2, RADIUS * 2);
	if (!(x_ == -1 && y_ == -1)) {
	    int aX = x_; int aY = y_;
	    int bX = TEST_SIZE / 2; int bY = TEST_SIZE / 2;

	    double dX = bX - aX;
	    double dY = bY - aY;
	    int rX, rY;
	    if (dX * dX > dY * dY) {
		rX = RADIUS;
		rY = (int)Math.round(dY / dX * (double)RADIUS);
		if (dX > 0) {
		    rX *= -1;
		    rY *= -1;
		}
	    }
	    else {
		rX = (int)Math.round(dX / dY * (double)RADIUS);
		rY = RADIUS;
		if (dY > 0) {
		    rX *= -1;
		    rY *= -1;
		}
	    }
// 	    int rX, rY;
// 	    double d = (int)Math.abs(dY / dX);
// 	    if (dX * dX > dY * dY) {
// 		rX = RADIUS;
// 		rY = (int)Math.round((double)RADIUS * d);
// 	    }
// 	    else {
// 		rX = (int)Math.round((double)RADIUS / d);
// 		rY = RADIUS;
// 	    }
// 	    if (dX > 0) rX *= -1;
// 	    if (dY > 0) rY *= -1;
	    g.drawLine(aX, aY, bX, bY);
	    g.drawLine(aX, aY, bX + rX, bY + rY);
	    DrawHead(g, aX, aY, bX + rX, bY + rY);
	}
    }
    
    public static void main (String args[]) {
	Frame frame = new Frame();
	frame.add(new ArrowHead());
	frame.resize(TEST_SIZE + 10, TEST_SIZE + 30);
	frame.show();
    }

    public final static int RADIUS = 30;
}
