import java.util.*;
import java.awt.Component;

class WV_StringVector extends Vector {

  public WV_String getString(int index)
  {return (WV_String) elementAt(index);}

}
