package sprite;

public interface ButtonOwner {
    public void ButtonClicked(ButtonSprite button);
}
