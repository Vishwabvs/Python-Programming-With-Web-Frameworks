/*
 *  GRDialog_SA - controls the simulated annealing convergence method 
 *  4/14/96 
 *  by Daniel Spirn 
 *
 */
package graphrender;

import java.awt.*;
import java.applet.*;

public class GRDialog_SA extends Frame {

    // Different controlling sliders 
    GRSlider 		sc1,sc2,sc3;

    // Default button
    Button 		button;

    // message area to keep user updated on state of animation
    Label		update_message_;

    // reference to the graph area 
    GRGraphArea 	ga_;

    public GRDialog_SA(String title, GRGraphArea ga) {
	super(title);
	this.setResizable(false);
	ga_ = ga;
    }

    public void addNotify() {
	super.addNotify();
	
	GridBagLayout gridbag = new GridBagLayout();
	GridBagConstraints c = new GridBagConstraints();
	c.fill = GridBagConstraints.BOTH;
	
	setLayout(gridbag);

        // builds the sliders to control constants of animation
	sc1 = new GRSlider("Annealing Constant",0.001,0.1,0.001);
	sc2 = new GRSlider("Initial Temperature",0,0.1,0.001);
	sc3 = new GRSlider("Iterations",0,20,1);

        // build rest of components
	button = new Button("default");
	button.setForeground(new Color(122,36,95));
	Label warning_message_ = new Label("Alert: this method is very slow");
	warning_message_.setForeground(Color.red);
	warning_message_.setBackground(Color.white);
	warning_message_.setAlignment(Label.CENTER);
	update_message_ = new Label("stable");
	update_message_.setBackground(new Color(34,133,144));
	update_message_.setForeground(new Color(255,255,255));

	sc1.setValue(ga_.animator.annealing_constant_);
	sc2.setValue(ga_.animator.initial_temperature_);
	sc3.setValue(ga_.iterations_);

	c.weightx = 1.0;
	c.weighty = 1.0;
	c.gridwidth = GridBagConstraints.REMAINDER;
	gridbag.setConstraints(warning_message_,c);
	add(warning_message_);
	c.weightx = 1.0;
	c.weighty = 1.0;
	c.gridwidth = GridBagConstraints.RELATIVE;
	gridbag.setConstraints(sc1,c);
	add(sc1);
	c.weightx = 1.0;
	c.weighty = 1.0;
	c.gridwidth = GridBagConstraints.REMAINDER;
	gridbag.setConstraints(sc2,c);
	add(sc2);
	c.weightx = 1.0;
	c.weighty = 1.0;
	c.gridwidth = GridBagConstraints.REMAINDER;
	gridbag.setConstraints(sc3,c);
	add(sc3);
	c.weightx = 1.0;
	c.weighty = 2.0;
	c.gridwidth = GridBagConstraints.REMAINDER;
	gridbag.setConstraints(button,c);
	add(button);
	c.weightx = 1.0;
	c.weighty = 2.0;
	c.gridwidth = GridBagConstraints.REMAINDER;
	gridbag.setConstraints(update_message_,c);
	add(update_message_);

	pack();
//	positionOnScreen();
	show();
    }

    // moves frame to specific location on screen
    private void positionOnScreen() {
	Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
	this.move(((screen.width / 2)), (screen.height / 3) - (this.size().height));
    }

    public void show(){
	super.show();
	sc1.setValue(ga_.animator.annealing_constant_);
	sc2.setValue(ga_.animator.initial_temperature_);
	sc3.setValue(ga_.iterations_);
    }

    // gets update message and puts to message board.
    public void setUpdateMessage(String string) 
    {
	update_message_.setText(string);
    }

    /** Respond to user actions. */
    public boolean handleEvent(Event e) {
	boolean handled = false;

	if (e.target instanceof GRSlider) {
		boolean a = sc1.handleEvent(e);
		boolean b = sc2.handleEvent(e);
		boolean c = sc3.handleEvent(e);
		ga_.animator.annealing_constant_ = Double.valueOf(sc1.textField.getText()).doubleValue();
		ga_.animator.initial_temperature_ = Double.valueOf(sc2.textField.getText()).doubleValue();
		ga_.iterations_ = Integer.parseInt(sc3.textField.getText()); 
		return (a || b || c);
	} else if (e.id == Event.ACTION_EVENT) {
		if (e.arg.equals("default")) {
			ga_.animator.annealing_constant_ = ga_.animator.default_annealing_constant_;
			sc1.setValue(ga_.animator.annealing_constant_);
			ga_.animator.initial_temperature_ = ga_.animator.default_initial_temperature_;
			sc2.setValue(ga_.animator.initial_temperature_);
			ga_.iterations_ = ga_.default_iterations_;
			sc3.setValue(ga_.iterations_);
		}
	} else if (e.id == Event.WINDOW_DESTROY) {
		this.hide();
		this.dispose();
	}
	return(handled);
    }
}

