import java.awt.*;
import java.util.*;
import java.net.*;

import WebTree;
import Node;

public class URLFrame extends Frame {

   Label l;
   WebTree webtree_;
   List URLList_;
   Button closeButton_;

   private final boolean DEBUG = true;

   
   URLFrame (String title, WebTree webtree)
   {
      
      super(title);
      GridBagLayout layout = new GridBagLayout();
      GridBagConstraints gbc = new GridBagConstraints();

      gbc.gridx = 0;
      gbc.gridy = 0;
      gbc.gridwidth = 1;
      gbc.gridheight = 1;
      gbc.weightx = 1;
      gbc.weighty = 1;
      gbc.fill = gbc.BOTH;
      
      setLayout(layout);
      URLList_ = new List(25, false);

      
      webtree_ = webtree;

      layout.setConstraints(URLList_, gbc);
      add(URLList_);

      gbc.gridx = 0;
      gbc.gridy = 1;
      gbc.gridwidth = 0;
      gbc.gridheight = 0;
      gbc.fill = gbc.NONE;
      gbc.weightx = 0;
      gbc.weighty = 0;
      closeButton_ = (new Button("Close"));
      layout.setConstraints(closeButton_, gbc);

      add(closeButton_);

      pack();
      
   }

   
public boolean action (Event evt, Object arg)
   {

      if (evt.target instanceof Button) {

         String label = (String)arg;

         if (label.equals("Close")) this.hide();

         return true;
         
      } else if (evt.target instanceof List) {

         if (evt.target == URLList_) {

            if (DEBUG) System.out.println("URL list item \"" +
                                          (String)arg + "\" was clicked on");

         }

         return true;
      }

      else return false;
      
   }

public boolean handleEvent (Event e)
   {

      if (e.target instanceof List) {

         switch (e.id) {

          case Event.LIST_SELECT:

            int sIndex = ((Integer)e.arg).intValue();

            String listItem = URLList_.getItem(sIndex);

            if (DEBUG) System.out.println("Select event occured on item #" +
                                          sIndex + " (\"" + listItem + "\")");

            int idIndex = listItem.indexOf(" ");

            String tempId = listItem.substring(0, idIndex);

            int id = new Integer(tempId).intValue();

            // Find the node with the corresponding id.
            
            Node tempNode;
            
            for (int i = 0; i < webtree_.nodeList_.size(); i++) {

               tempNode = (Node)webtree_.nodeList_.elementAt(i);

               if (tempNode.getId() == id) {
                  
                  webtree_.selectNode(tempNode); // select the node
                  break;

               }

            }
            
            break;

          case Event.LIST_DESELECT:

            int dIndex = ((Integer)e.arg).intValue();
            
            if (DEBUG) System.out.println("Deselect event occured on item #" +
                                          dIndex + " (\"" +
                                          URLList_.getItem(dIndex) + "\")");

            webtree_.deselectNode(); // deselect the node
            
            break;
            
         }
         
      }

      return super.handleEvent(e);
      
   }
   
   
public void update (Node node)
   {

      // This method gets called whenever a node is added to the graph.
      
      URL tempURL;
      String tempString;
      
      tempURL = node.getURL();

      if (tempURL != null) tempString = tempURL.toString();
      else tempString = new String("none");

      // A list item is a combination of the node's id and URL.
      
      URLList_.addItem(new String(new Integer(node.getId()).toString() +
                           " " + tempString));
      
   }

   
public void update (Vector nodelist)
   {

      // This method gets called whenever there is a deletion.
      
      URLList_.clear();

      Node tempNode;
      
      for (int i = 0; i < nodelist.size(); i++) {

         tempNode = (Node)nodelist.elementAt(i);
         update(tempNode);

      }
      
   }
   
}




