import java.util.*;

public abstract class LayoutAlgorithm {

public abstract void execute (Vector nodeList);

}
