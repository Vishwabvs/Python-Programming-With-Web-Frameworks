/*
 * @(#)SearchBoxSprite.java	1.0 5/6/96 Michael John Radwin
 */

package mjr.pstree;

import sprite.*;
import java.awt.*;

/**
 * The draggable box that lets the user specify a range to search in.
 *
 * @version 1.0 5/6/96
 * @author <A HREF="http://www.cs.brown.edu/people/mjr/">Michael John Radwin</A>
 */
public class SearchBoxSprite extends Sprite {
    protected int sides[];
    protected int drag_side = -1;
    public static final int left = 0, right = 1, bottom = 2;
    public static final int bot_left = 3, bot_right = 4;
    public static final int BORDER = 40;
    public static final int FUDGE = 3;
    protected PSTGraph pstgraph;

    public int x0() { return sides[left]; }
    public int x1() { return sides[right]; }
    public int y0() { return sides[bottom]; }
    
    public SearchBoxSprite(PSTGraph area)
    {
	super(area, 0, 0);
	pstgraph = area;
	sides = new int[3];
	sides[left] = 20;
	sides[right] = 100;
	sides[bottom] = 80;
    }

    boolean insideLeft(int x, int y)
    {
	return ((y < sides[bottom] + (2 * FUDGE)) &&
		(x < sides[left] + (2 * FUDGE) && x > sides[left] - (2 * FUDGE)));
    }

    boolean insideRight(int x, int y)
    {
	return ((y < sides[bottom] + (2 * FUDGE)) &&
		(x < sides[right] + (2 * FUDGE) && x > sides[right] - (2 * FUDGE)));
    }
    
    boolean insideBottom(int x, int y)
    {
	return ((y < sides[bottom] + (2 * FUDGE) && y > sides[bottom] - (2 * FUDGE)) &&
		(x > sides[left] - (2 * FUDGE) && x < sides[right] + (2 * FUDGE)));
    }

    public boolean Inside(int x, int y)
    {
	return insideLeft(x, y) || insideRight(x, y) || insideBottom(x, y);
    }

    public void handleEvent(Event e) {
	switch (e.id) {
	case Event.MOUSE_DOWN:
	    if (insideLeft(e.x, e.y))
		if (insideBottom(e.x, e.y))
		    drag_side = bot_left;
		else
		    drag_side = left;

	    else if (insideRight(e.x, e.y))
		if (insideBottom(e.x, e.y))
		    drag_side = bot_right;
		else
		    drag_side = right;

	    else
		drag_side = bottom;
	    break;
		    
	case Event.MOUSE_DRAG:
//	    System.err.println("MOUSE_DRAG event at " + e.x + "," + e.y);
//	    System.err.println("drag_side is " + drag_side);
	    switch (drag_side) {
	    case bot_left:
		if (e.y > area_.size().height - BORDER)
		    sides[bottom] = area_.size().height - BORDER;
		else if (e.y < FUDGE * 2)
		    sides[bottom] = FUDGE * 2;
		else
		    sides[bottom] = e.y;
		// there is purposely no break here
		
	    case left:
		if (e.x > sides[right]) {
//		    System.err.println("left has just passed right");
		    drag_side = (drag_side == bot_left) ? bot_right : right;
		    sides[left] = sides[right];
		    if (e.x < area_.size().width - FUDGE)
			sides[right] = e.x;
		    else
			sides[right] = area_.size().width - FUDGE;
		}
		else if (e.x < FUDGE)
		    sides[left] = FUDGE;
		else
		    sides[left] = e.x;
		break;

	    case bot_right:
		if (e.y > area_.size().height - BORDER)
		    sides[bottom] = area_.size().height - BORDER;
		else if (e.y < FUDGE * 2)
		    sides[bottom] = FUDGE * 2;
		else
		    sides[bottom] = e.y;
		// there is purposely no break here
		
	    case right:
		if (e.x < sides[left]) {
//		    System.err.println("right has just passed left");
		    drag_side = (drag_side == bot_right) ? bot_left : left;
		    sides[right] = sides[left];
		    if (e.x > FUDGE)
			sides[left] = e.x;
		    else
			sides[left] = FUDGE;
		}
		else if (e.x > area_.size().width - FUDGE)
		    sides[right] = area_.size().width - FUDGE;
		else
		    sides[right] = e.x;
		break;

	    case bottom:
		if (e.y > area_.size().height - BORDER)
		    sides[bottom] = area_.size().height - BORDER;
		else if (e.y < FUDGE * 2)
		    sides[bottom] = FUDGE * 2;
		else
		    sides[bottom] = e.y;
		break;
	    }

	    Redraw();
	    break;
	case Event.MOUSE_UP:
//	    drag_side = -1;
	    pstgraph.rangeQuery(sides[left], sides[right], sides[bottom]);
	    break;
	}
    }
    
    public void Draw(Graphics g)
    {
	g.setColor(Color.darkGray);

	// vertical lines
	g.drawLine(sides[left], 0,
		   sides[left], sides[bottom]);
	g.drawLine(sides[right], 0,
		   sides[right], sides[bottom]);

	// horizontal line
	g.drawLine(sides[left], sides[bottom],
		   sides[right], sides[bottom]);

	// arrowheads
	int xPoints[] = new int[3];
	int yPoints[] = new int[3];
	xPoints[0] = sides[left];
	xPoints[1] = sides[left] - 3;
	xPoints[2] = sides[left] + 3;
	yPoints[0] = 0;
	yPoints[1] = 8;
	yPoints[2] = 8;
	g.fillPolygon(xPoints, yPoints, 3);
	xPoints[0] = sides[right];
	xPoints[1] = sides[right] - 3;
	xPoints[2] = sides[right] + 3;
	g.fillPolygon(xPoints, yPoints, 3);
    }
    public static void mjr() { ; }
}
