/*
 * @(#)TreeGraphics.java	1.0 1/18/96 Michael John Radwin
 */

package mjr.treegraphics;

/**
 * A generic TreeGraphics interface.
 *
 * This code was ported by
 * <A HREF="http://www.cs.brown.edu/people/mjr/">mjr</A>
 * from the pascal source written by
 * <A HREF="http://www.cs.brown.edu/people/bmc/">bmc</A>.
 *
 * @see ASCIITreeGraphics
 * @version 1.0 1/18/96
 * @author <A HREF="http://www.cs.brown.edu/people/mjr/">Michael John Radwin</A>
 * @author <A HREF="http://www.cs.brown.edu/people/bmc/">Bryan Cantrill</A>
 */

public
abstract class TreeGraphics {
    public TreeGraphics() { ; }
    
    abstract public void DrawInternal(String nodeLabel, String color);
    abstract public void DrawLeaf(String color);

    public TreeGraphics GTreeGraphics = null;
}
