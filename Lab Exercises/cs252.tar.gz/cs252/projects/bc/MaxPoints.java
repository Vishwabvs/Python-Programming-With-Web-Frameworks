import java.util.*;
import java.awt.*;
import java.applet.Applet;
import java.lang.*; 

class DrawingMethod extends Panel implements Runnable {
    	private int linePosition;
    	private boolean forth;
    	private boolean lineDrag;
    	private boolean pointDrag;
	private MaxPoints maxp;
   	private MaxPointStructure mp;
       	private Node pick;
        private Node lastPick;
	Thread	demoer;
	public  long flashTime=200;	
	public  long demoSpeed=5;

   
	public MaxPointStructure getMPS(){
		return mp;
	}

	public Thread getDemoer() {
		return demoer;
	}

	DrawingMethod(MaxPoints maxp) {
		this.maxp = maxp;
		mp = new MaxPointStructure();
		forth=true;
		linePosition=8;
		lineDrag=false;
		pointDrag=false;
       		pick = null;
        	lastPick = null;
    	}

        private Image offscreen;
    	private Dimension offscreensize;
    	private Graphics offgraphics;
    

    	final Color selectedColor = Color.pink;
    	final Color begroundColor1 = new Color(250,240,140);
    	final Color begroundColor2 = Color.white;
    	final Color nodeColor = Color.blue;
    	final Color lineColor = Color.darkGray;
    	final Color maxColor = Color.red;
    

    	public void paintPoint(Graphics g, int x, int y) {
		g.fillOval(x - 3, y - 3, 7, 7);
	}

	public void paintLine(Graphics g, int i) {
		Dimension d = size();
		g.drawLine(i, 0, i, d.height);
	}

	private int x_tmp, y_tmp;
	private Node n;

    	public synchronized void update(Graphics g) {
		Dimension d = size();
		if ((offscreen == null) || (d.width != offscreensize.width) || 				(d.height != offscreensize.height)) {
	    		offscreen = createImage(d.width, d.height);
	    		offscreensize = d;
	    		offgraphics = offscreen.getGraphics();
		}

		offgraphics.setColor(begroundColor1);
		offgraphics.fillRect(0, 0, linePosition, d.height);
		offgraphics.setColor(begroundColor2);
		offgraphics.fillRect(linePosition+1, 0, d.width, d.height);


		if (mp.getRangeTree().getRoot()!=null) {
			Vector v = mp.getRangeTree().allNodes();
			if (v!=null){
				offgraphics.setColor(nodeColor);
				for (int i = 0 ; i < v.size() ; i++) {
					n = (Node)v.elementAt(i);
					x_tmp = n.getKey().getX();
					y_tmp = n.getKey().getY();
    					paintPoint(offgraphics, x_tmp, y_tmp);
				}
			}
		}

		if (mp.getMaxTree().getRoot()!=null) {
			Vector v = mp.getMaxTree().allNodes();
			if (v!=null) {
				for (int i = 0 ; i < v.size() ; i++) {
					n = (Node)v.elementAt(i);
					x_tmp = n.getKey().getY();
					y_tmp = n.getKey().getX();
					offgraphics.setColor(maxColor);	
  					paintPoint(offgraphics, x_tmp,y_tmp);
					if (i-1>=0){
						Node n1 = (Node)v.elementAt(i-1);
						int x1 = n1.getKey().getY();
						int y1 = n1.getKey().getX();
						offgraphics.drawLine(x1,y1,x_tmp,y_tmp);
					}
				}
			}
		}

		offgraphics.setColor((lineDrag)? selectedColor: lineColor);
		paintLine(offgraphics,linePosition);
			
  		if (pick!=null) {  
			Color c = (pointDrag==true)? selectedColor : nodeColor;
			offgraphics.setColor(c);
			x_tmp = pick.getKey().getX();
			y_tmp = pick.getKey().getY();
	  		paintPoint(offgraphics, x_tmp, y_tmp);
		}

		g.drawImage(offscreen, 0, 0, null);
	}

	public synchronized boolean mouseDown(Event evt, int x, int y) {
		Dimension d=size();
		int x1=x-1;
		int y1=d.height-y-1;
	        maxp.mouseLabel.setText("[" + x1 + ", " + y1 + "]");
		if (maxp.demo==true) return true; 
		if ( x < linePosition) 
			return true;

		if ( x>=linePosition-1 && x<=linePosition+1)  {
			linePosition=x;
			lineDrag=true;
			repaint();
			return true;
		}

		if (pick==null) {
			pick = new Node(x,y);
		}

		if (mp.getRangeTree().getRoot()!=null) {
			Vector v = mp.getRangeTree().allNodes();
			if (v!=null){
				for (int i = 0 ; i < v.size(); i++) {
		    			n = (Node)v.elementAt(i);
					int dx= (n.getKey().getX() - x);
					int dy= (n.getKey().getY() - y);
	    				if ((dx*dx + dy*dy) < 9) {
						pick.setKey(x,y);
						mp.deletePoint(n);
						pointDrag = true;
						repaint();
						return true;
	    				}	
				}
			}
		} 
		
		pick.setKey(x,y);
		pointDrag=true;
		repaint();
		return true;
	}  	

    	public synchronized boolean mouseDrag(Event evt, int x, int y) {
		Dimension d=size();
		int x1=x-1;
		int y1=d.height-y-1;
	        maxp.mouseLabel.setText("[" + x1 + ", " + y1 + "]"); 
		if (maxp.demo==true) return true;
		if (lineDrag == true && maxp.demo!=true) { 
			if ( x<8 || x>= d.width) return true;
			linePosition=x;
			if ( mp.getRangeTree().getRoot()!=null) {
				if (linePosition > mp.getRightMark())
					mp.rightSweep();
				if (linePosition < mp.getCurMark())
					mp.leftSweep();
			}
		}
		else if (pointDrag == true) {
			if (x<=linePosition) return true;
			pick.setKey(x,y);
		}	
		repaint();
		return true;
    	}

	private long lastTime=0;

    	public synchronized boolean mouseUp(Event evt, int x, int y) {
		Dimension d=size();
		int x1=x-1;
		int y1=d.height-y-1;
	        maxp.mouseLabel.setText("[" + x1 + ", " + y1 + "]");
		if (maxp.demo==true) return true;
		Date curTime = new Date(); 
        	if (lineDrag == true) {
			if (x>=8 && x < d.width) 
				linePosition = x;
			lineDrag = false;
		}

		if (pointDrag==true) {
			if (x>linePosition && x<d.width)
				pick.setKey(x,y);

			if ( lastPick!=null) 
				if(pick.getKey().equals(lastPick.getKey())  
					&& curTime.getTime()-lastTime<500) {
					lastPick=null;
					pointDrag = false;
					pick = null;
					lastTime=curTime.getTime();
					repaint();			
					return true;
				}

			mp.addPoint(pick);	
			lastPick = pick;
			pointDrag = false;
			pick = null;	
		}
		lastTime=curTime.getTime();
		if ( x>=linePosition)
			repaint();			
		return true;
    	}

	public synchronized boolean mouseMove(Event evt, int x, int y){
		Dimension d=size();
		int x1=x-1;
		int y1=d.height-y-1;
	        maxp.mouseLabel.setText("[" + x1 + ", "+ y1 + "]"); 
		if (maxp.demo==true) return true;
		if (x>=linePosition-1 && x<=linePosition+1) {
			lineDrag=true;
			repaint();
		} else if (lineDrag==true) {
			lineDrag=false;
			repaint();
		}
		return true;	
	}
	
	public void reSet() {	
		mp = new MaxPointStructure();
		linePosition=8;
		pick=null;
		lastPick=null;
		lastTime=0;
		lineDrag=false;
		pointDrag=false;
		maxp.demo = false;
		forth=true;
	}

	public void reStart(){	
		mp.getMaxTree().setRoot(null);
		mp.getRangeTree().resetCurMark();
		linePosition=8;
		pick=null;
		lastPick=null;
		lastTime=0;
		lineDrag=false;
		pointDrag=false;
		maxp.demo = false;
		forth=true;
	}

	public void run() {
		while(true){			 
			Dimension d = size();
			if (linePosition<d.width-1){
				linePosition++; 
				if ( mp.getRangeTree().getRoot()!=null) {
					if (linePosition>mp.getRightMark()) {
						mp.rightSweep();
						Node node=(Node)mp.getCurMarkNode();
						Key k=node.getKey().exchange();
						Node n=mp.getMaxTree().treeSearch(k);
						Graphics g=getGraphics();
						if (g!=null) {	
							flashNode(g, node);
							if (n.getTrash().size()>0)
								flashVector(g, n.getTrash());
						}
					}
				}
				repaint();
				try {
					Thread.sleep(demoSpeed);
				} 
				catch (InterruptedException e);
			}
			else {
				maxp.demo=false;
				maxp.setDemo("Demo On");
				repaint();
				break;
			}
		}
	}

	private void flashNode(Graphics g, Node n) {
		g.setColor(Color.blue);
		for (int i=0; i<9; i++){
			g.setColor(g.getColor()==Color.red? Color.blue:Color.red);
			paintPoint(g, n.getKey().getX(),n.getKey().getY());
			try {
				Thread.sleep(flashTime);
			} 
			catch (InterruptedException e);
		}
	}

	private void flashVector(Graphics g, Vector v) {
		g.setColor(Color.blue);
		int x,y, x_old, y_old;
		for (int i=0; i<9; i++){
			g.setColor(g.getColor()==Color.red?Color.blue:Color.red);
			for (int j=0; j<v.size(); j++) {
				Node n = (Node)v.elementAt(j);
				x=n.getKey().getY();
				y=n.getKey().getX();
				paintPoint(g,x,y);
				if ( j>=1) {
					n = (Node)v.elementAt(j-1);
					x_old=n.getKey().getY();
					y_old=n.getKey().getX();
					g.drawLine(x_old,y_old,x,y);
				}
			}				
			try {
				Thread.sleep(flashTime);
			} 
			catch (InterruptedException e);
		}
	}

	public void start() {
		demoer = new Thread(this);
		demoer.start();
	}
	
	public void stop() {
		if ( demoer!=null) demoer.stop();
	}
	
}

public class MaxPoints extends Applet{
    	DrawingMethod panel;
	public Label mouseLabel;
	private Button demoButton;
	public boolean demo=false;

	public void setDemo(String str) { 
		demoButton.setLabel(str);
	}

    	public void init() {
		GridBagLayout gridBag = new GridBagLayout(); 
		GridBagConstraints c = new GridBagConstraints(); 

		setLayout(gridBag); 

		c.fill = GridBagConstraints.BOTH; 
		c.insets = new Insets(0, 0, 0, 0); 
		c.weightx = 0.0; 
		c.weighty = 0.0; 
		c.gridwidth = GridBagConstraints.REMAINDER; 
   
		Panel p = new Panel(); 
		p.setLayout(gridBag); 

		c.gridx = 0;  c.gridy = 0; 
		Label label = new Label("Mouse:"); 
		gridBag.setConstraints(label, c); 
		p.add(label); 

		c.gridx = 0;  c.gridy = 1;
		mouseLabel = new Label ("[100, 100]"); 
		gridBag.setConstraints(mouseLabel, c); 
		p.add(mouseLabel); 

		c.gridx = 0;  c.gridy = 4; 
		Button button = new Button("Restart"); 
		gridBag.setConstraints(button, c); 
		p.add(button); 

		c.gridx = 0;  c.gridy = 5; 
		button = new Button("Clear"); 
		gridBag.setConstraints(button, c); 
		p.add(button); 

		c.gridx = 0;  c.gridy = 6; 
		demoButton = new Button("Demo Off"); 
		gridBag.setConstraints(demoButton, c); 
		p.add(demoButton);
		demoButton.setLabel("Demo On");
/*
		c.gridx = 0;  c.gridy = 7; 
		button = new Button("Help"); 
		gridBag.setConstraints(button, c); 
		p.add(button);
*/
		c.gridx = 0;  c.gridy = 1; 
		c.gridwidth = 1;  c.gridheight = 1; 
		c.fill = GridBagConstraints.VERTICAL; 
		c.anchor = GridBagConstraints.WEST; 
		c.weightx = 0.0;  c.weighty = 1.0; 
		c.insets = new Insets(10, 10, 8, 8); 
		gridBag.setConstraints(p, c); 
		add(p); 


		panel = new DrawingMethod(this);
		panel.setLayout(gridBag); 

		c.gridx = 1;  c.gridy = 1; 
		c.gridwidth = 1;  c.gridheight = 2; 
		c.fill = GridBagConstraints.BOTH; 
		c.anchor = GridBagConstraints.CENTER; 
		c.weightx = 1.0;  c.weighty = 1.0; 
		c.insets = new Insets(10, 10, 5, 10); 
		gridBag.setConstraints(panel, c); 
		add(panel);
		
		panel.repaint();
   	}

	public synchronized boolean mouseEnter(Event evt, int x, int y) {
		if (demo==false)
			panel.repaint();
		return true;
	}

    	public boolean action(Event evt, Object arg) {
		if ("Clear".equals(arg)) {
			demoButton.setLabel("Demo On");
			panel.stop();
			panel.reSet();
			panel.repaint();
			
		}

		if ("Restart".equals(arg)) {
			demoButton.setLabel("Demo On");
			panel.stop();
			panel.reStart();
			panel.repaint();
		}

		if (evt.target==demoButton){
			if (demoButton.getLabel()=="Demo On") {
				demoButton.setLabel("Demo Off");
				demo = true;
				panel.start();
			} 
			else {
				demoButton.setLabel("Demo On");
				panel.stop();
				demo = false;
			} 
			return true;
		}
		return true;
    	}
}


















