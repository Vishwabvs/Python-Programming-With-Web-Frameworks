/** Brian Rogers
    cs252
    spring 1996
    Final Project */

import java.awt.*;


/** ThreeDEdge
    This is an edge in three dimensions.  It has a color and references to
    the two vertices it connects, so it knows where to draw. */
    
public class ThreeDEdge {
     public static final int CANVAS_DIMENSION = ThreeDCanvas.CANVAS_DIMENSION;

     ThreeDVertex vert_1;
     ThreeDVertex vert_2;

     Color _color;

     public ThreeDEdge (ThreeDVertex vert1, ThreeDVertex vert2, Color color) {
          vert_1 = vert1;
	  vert_2 = vert2;
	  _color = color;
     }

     /** This just draws the edge by finding the apparent (modified with
         perspective) coordinates of the two vertices, and drawing a line
	 between them. */
     public void draw (Graphics grafix) {
          grafix.setColor(_color);

	  ThreeDVector app1 = vert_1.apparent();
	  ThreeDVector app2 = vert_2.apparent();

	  int appz1 = app1.zCoord();
	  int appz2 = app2.zCoord();

	  int drawx1 = app1.xCoord() + CANVAS_DIMENSION/2;
          int drawy1 = CANVAS_DIMENSION/2 - app1.yCoord();
          int drawx2 = app2.xCoord() + CANVAS_DIMENSION/2;
	  int drawy2 = CANVAS_DIMENSION/2 - app2.yCoord();

          grafix.drawLine(drawx1, drawy1, drawx2, drawy2);     
     }
     
     public void setColor (Color color)  {_color = color;}
}
