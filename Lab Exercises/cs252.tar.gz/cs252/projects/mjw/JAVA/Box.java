import geometry.*;
import java.awt.*;
import java.util.Vector;


class TickMark {
protected int position_=0, height_=4, width_=2;

  public TickMark(int position){
    position_ = position;
  }
  public TickMark(int position, int height, int width){
    position_ = position;
    height_ = height;
    width_ = width;
  }

  public void setPosition(int position){
    position_ = position;
  }

  public void setHeight(int height){
    height_ = height;
  }

  public void setWidth(int width){
    width_ = width;
  }

  public int getPosition(){
    return position_;
  }
  public int getHeight(){
    return height_;
  }
  public int getWidth(){
    return width_;
  }
};



public class Box extends boundingBox {
protected Color   boundary_color_=Color.blue, tick_color_=Color.blue;
protected int     tick_height_=4, tick_width_=2;
protected Vector  top_ticks_, bottom_ticks_, right_ticks_, left_ticks_;
protected boolean ticks_enabled_= false;
final static int TOP=1;
final static int BOTTOM=2;
final static int RIGHT=3;
final static int LEFT=4;

  
	public Box(){
		this(0,0,0,0);
	}

	public Box(int x, int y, int width, int height)
	{
	        super();
		setOrigPt(x,y);
		setPt(x+width,y+height);
		disableTickMarks();
	}

	public void setColor(Color color)
	{
		boundary_color_ = color;
	}

	public void draw(Graphics g)
	{
		Color oldColor=g.getColor();
		g.setColor(boundary_color_);
		g.drawRect(minX(),minY(),maxX()-minX(),maxY()-minY());
		g.setColor(oldColor);
		if (ticks_enabled_)
		  {
		    //if (top_ticks_.size()>0)
		      drawTickMarks(g, top_ticks_, TOP);
		    if (bottom_ticks_.size()>0)
		      drawTickMarks(g, bottom_ticks_, BOTTOM);
		    if (right_ticks_.size()>0)
		      drawTickMarks(g, right_ticks_, RIGHT);
		    if (left_ticks_.size()>0)
		      drawTickMarks(g, left_ticks_, LEFT);
		  }
	}

        protected void drawTickMarks(Graphics g, Vector ticks, int side)
        {
	  int num = ticks.size();
	  int x,y;
	  TickMark t;
	  for (int i=0; i < num; i++)
	    {
	      t = (TickMark) ticks.elementAt(i);
	      switch (side) {
	      case TOP:
	      case BOTTOM:
		x = t.getPosition();
		if (side == TOP)
		  y = minY();
		else y = maxY();
		GeometryLine.draw(g, x, y-(t.getHeight()/2),
				     x, y+(t.getHeight()/2),
				     tick_width_, tick_color_);
		break;
	      case LEFT:
	      case RIGHT:
		if (side == RIGHT)
		  x = minX();
		else x = maxY();
		y = t.getPosition();
		GeometryLine.draw(g, x-(t.getHeight()/2), y,
				     x+(t.getHeight()/2), y,
				     tick_width_, tick_color_);
		break;
	      default:;
	      }
	    }
        }  

  
	public void setActive(boolean b)
	{
		boxOn = b;
	}

	public boolean inside(int x, int y)
	{
		return ((x > minX()) && (x < maxX()) && (y > minY()) &&(y<maxY()));
	}

        public void setTickMark(int side, int position)
        {
	  if (ticks_enabled_)
	    {
	      switch (side) {
	      case TOP:
		top_ticks_.addElement(new TickMark(position, tick_height_,tick_width_));
		break;
	      case BOTTOM:
		bottom_ticks_.addElement(new TickMark(position, tick_height_,tick_width_));
		break;
	      case LEFT:
		left_ticks_.addElement(new TickMark(position, tick_height_,tick_width_));
		break;
	      case RIGHT:
		right_ticks_.addElement(new TickMark(position, tick_height_,tick_width_));
		break;
	      default:;
	      }
	    }
	}

        public void setTickMarkHeight(int height)
        {
	  tick_height_ = height; 
        }

        public void setTickMarkWidth(int width)
        {
	  tick_width_ = width;
        }

        public void setTickColor(Color c)
        {
	  tick_color_ = c;
        }

        public void enableTickMarks()
        {
	  ticks_enabled_ = true;
	  top_ticks_ 	= new Vector();
	  bottom_ticks_ = new Vector();
	  right_ticks_	= new Vector();
	  left_ticks_ 	= new Vector();
        }	

        public void disableTickMarks()
        {
	  ticks_enabled_ = false;
	  top_ticks_ 	= null;
	  bottom_ticks_ = null;
	  right_ticks_	= null;
	  left_ticks_ 	= null;
        }

	public void clearAllTickMarks()
	{
	  if (ticks_enabled_)
	    {	
	 	top_ticks_.removeAllElements();
	  	bottom_ticks_.removeAllElements();
	  	right_ticks_.removeAllElements();
	  	left_ticks_.removeAllElements();
	    }
	}

	public void clearTickMarks(int side)
	{
	    if (ticks_enabled_)
	    {
	      switch (side) {
	      case TOP:
		top_ticks_.removeAllElements();
		break;
	      case BOTTOM:
		bottom_ticks_.removeAllElements();
		break;
	      case LEFT:
		left_ticks_.removeAllElements();
		break;
	      case RIGHT:
		right_ticks_.removeAllElements();
		break;
	      default:;
	      }
	    }
	}
};
