import java.util.*;
import java.awt.*;
import LayoutAlgorithm;
import Node;
import WebTree;

public class DepthColorAlgorithm extends LayoutAlgorithm {

  final boolean DEBUG = false;

  final int INITIAL_BLUE = 55;

  WebTree webtree_;

DepthColorAlgorithm(WebTree webtree){
  webtree_ = webtree;
}

public void execute (Vector nodeList)
  {

    if (DEBUG) System.out.println("depth color algorithm execute called");

    int total = nodeList.size();
    
    if (DEBUG) System.out.println("total nodes: " + total);
    
    if (total == 0) return; // make sure there is a graph

    // Sort the list by depth.

    InsertionSort(nodeList);

    // The maximum depth is the depth of the last element in the sorted list.

    int maxDepth = getMaxDepth(nodeList);

    if (DEBUG) System.out.println("max depth: " + maxDepth);

    Vector depthList = new Vector();

    int currentDepth = 0; // the depth of the root is zero
    int nodeCount = 0;

    for (int j = 0; j < total; j++) {

      Node tempNode = (Node)nodeList.elementAt(j);

      int depth = tempNode.getDepth();

      if (depth == currentDepth) nodeCount++;

      else { // do this only if we down (or up?!) a level

        depthList.addElement(new Integer(nodeCount));
        nodeCount = 1;
        currentDepth++;

      }

    }

    depthList.addElement(new Integer(nodeCount)); // add the last count

    if (DEBUG) {

      // Print out the depth list.

        for (int j = 0; j < depthList.size(); j++) {
          int count = ((Integer)(depthList.elementAt(j))).intValue();
          System.out.print(count + " ");
        }
      System.out.println();

    }

    int red = 0, green = 0, blue = INITIAL_BLUE;

    double increment = (255 - INITIAL_BLUE) / (double)maxDepth;

    int depthCounter = -1;
    int nodeCounter = -1;

    while (++nodeCounter < total) {

      Node tempNode = (Node)nodeList.elementAt(nodeCounter);

      depthCounter++;

      int numNodes = ((Integer)(depthList.elementAt(depthCounter))).intValue();

      // For each page on the current level.

      int counter = 0;

      while (counter < numNodes) {

        tempNode.setColor(red, green, blue);

        counter++;
        
        if (counter < numNodes) {
          nodeCounter++;
          tempNode = (Node)nodeList.elementAt(nodeCounter);
        }

      }

      // red += increment;
      // green += increment;
      blue += increment;

    }
      
  }


// This method takes in a list of nodes and sorts them by depth.

public final void InsertionSort (Vector list)
  {

    int k, j, n;
    Node itemToInsert;
    boolean stillLooking;

    n = list.size();

    for (k = 1; k < n; k++) {

      itemToInsert = (Node)list.elementAt(k);
      j = k - 1;
      stillLooking = true;
      
      while (j >= 1 && stillLooking)

        if (itemToInsert.getDepth() < ((Node)(list.elementAt(j))).getDepth()) {

          list.setElementAt(list.elementAt(j), j + 1);
          j--;

        } else stillLooking = false;

        list.setElementAt(itemToInsert, j + 1);
    }
  }

public final int getMaxDepth(Vector nodeList){
  int temp =0;
  for (int i=0; i<nodeList.size(); i++){
    if (((Node)nodeList.elementAt(i)).getDepth() >  temp)
      temp =((Node)nodeList.elementAt(i)).getDepth(); 
  }
  return temp;


}

}
