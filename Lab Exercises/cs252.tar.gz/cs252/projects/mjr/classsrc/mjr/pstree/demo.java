/*
 * @(#)demo.java	1.0 5/2/96 Michael John Radwin
 */

package mjr.pstree;

import java.applet.*;
import java.awt.*;
import leda.*;

/**
 * an interactive priority search tree applet
 *
 * @version 1.0 5/2/96
 * @author <A HREF="http://www.cs.brown.edu/people/mjr/">Michael John Radwin</A>
 */
public class demo extends Applet {
    PSTGraph area = null;
    final public static int CANVAS_WIDTH = 570;
    final public static int CANVAS_HEIGHT = 400;
    
    public void init()
    {
	ParameterInfo info = new ParameterInfo(this);
	setLayout(new BorderLayout());
	area = new PSTGraph(this, CANVAS_WIDTH, CANVAS_HEIGHT, info);
	mjr();
    }

    public String[][] getParameterInfo()
    {
	return ParameterInfo.pinfo;
    }

    public String getAppletInfo()
    {
	return "Priority Search Tree demo by Michael John Radwin";
    }

    /**
     * hack to get netscape to load classfiles
     */
    public static void mjr()
    {
	int mjr = ps_item.left;
	PSTree.mjr();
	DrawTreeCommand.mjr();
	GIFNode.mjr();
	LineSprite.mjr();
	NullCommand.mjr();
	PSTNode.mjr();
	PolySprite.mjr();
	SearchBoxSprite.mjr();
    }
}
