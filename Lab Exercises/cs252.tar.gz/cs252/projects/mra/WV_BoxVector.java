import java.util.*;

class WV_BoxVector extends Vector {

  public WV_Box getBox(int index) {return (WV_Box) elementAt(index);}

}
