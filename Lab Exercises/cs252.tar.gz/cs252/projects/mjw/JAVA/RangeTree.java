import java.awt.*;
import geometry.*;
import java.util.Enumeration;
import Tree;
import CommandList;
import AbstractPrototypeFactory;
import RangeSearchAnimationCommand;
import java.io.StreamTokenizer;
import EventCheckOverlapCommand;
import EventGoLeftCommand;
import EventGoRightCommand;
import EventNoChildrenCommand;
import EventOverlapCommand;
import EventVisitPointCommand;
import TreeAccessible;
import SegmentSet;
import VCR;

/**
 * Implements an applet that enables the user to input a point set
 * visualize the range tree resulting from the entered points
 * and perform range search queries.
 * @author 	Mike Walczak (mjw@cs.brown.edu)
 * @version 	
 */

 
public class RangeTree extends AnimatorGeometryClient implements TreeAccessible
{
   /*
    * Instance data 
    */

   PointSet ptsetInput_;
   Tree rangeTree_; 
   boolean dragging_ = false;
   GeometryPoint drag_from_pt_;
   GeometryPoint drag_to_pt_;
   GeometryPoint edited_pt_; 
   boolean errored = false;
   AbstractPrototypeFactory command_factory_;
   CommandList		    command_list_;
   EventCheckOverlapCommand node_range_;
   Image 	leaf_node_image_, allocation_node_image_, user_point_query_selected_image_;
   Image        unselected_node_image_, selected_node_image_;   
   Color 	selected_tree_color_, unselected_tree_color_;
   Color        rangetree_color_;
   Color        range_color_;

/****************************************************************/
/*                                                              */
/* Function Name: init                                          */
/* Parameters:                                                  */
/* Returns:                                                     */
/* Effects:  Create an empty input point set and a Range Tree   */  
/*           graph.                                             */
/*                                                              */
/****************************************************************/

   /**
    * Create an empty input point set and a Range Tree graph.
    */

  //selected_tree_color ="yellow"
  //unselected_tree_color ="black"
  //allocation_node ="../images/pr_ball.gif"
  //selected_query_point ="../images/yl_ball.gif"

  public void init() {
	super.init();
	/* init geometry */

	drag_from_pt_ = new GeometryPoint(0,0);
	drag_to_pt_ = new GeometryPoint(0,0);
	edited_pt_ = null;
	ptsetInput_ = new PointSet();
	ptsetInput_.setLimits(0, 0, myGeometryPanel.size().width,
 	  			 myGeometryPanel.size().height);
	
	// stuff that can be set from the html page
	range_color_ = attribute("range_color",Color.gray);
	selected_tree_color_ = attribute ("selected_tree_color", Color.red);
	unselected_tree_color_ = attribute ("unselected_tree_color", Color.blue);
	allocation_node_image_ =  getImage (getCodeBase(), attribute("allocation_node", "../images/pr_ball.gif"));
	user_point_query_selected_image_ =
	  getImage(getCodeBase(),attribute("selected_query_point","../images/yl_ball.gif"));
	leaf_node_image_ = getImage (getCodeBase(),
				attribute ("leaf_node","../images/redball.gif"));
	unselected_node_image_ = getImage (getCodeBase(),
				attribute ("unselected_node","../images/blueball.gif"));
        selected_node_image_ = getImage (getCodeBase(),
				attribute ("selected_node","../images/redball.gif"));
	tracker.addImage(unselected_node_image_, 0);
	tracker.addImage(selected_node_image_, 0);
      	tracker.addImage(allocation_node_image_, 0);
	tracker.addImage(user_point_query_selected_image_,0);
	tracker.addImage(leaf_node_image_,0);
	// end
	
	rangeTree_ = new Tree();
	initTreeColors();


	command_factory_ = new AbstractPrototypeFactory();
	command_list_    = new CommandList();

	EventVisitPointCommand c1 = new
			EventVisitPointCommand( imOffscreen,
						myGeometryPanel,
						this,
						user_input_area_);
	
	command_factory_.registerType(c1.toString(),c1);

	EventCheckOverlapCommand c2 = new
			EventCheckOverlapCommand( imOffscreen,
						  myGeometryPanel,
						  this,
						  user_input_area_);
	command_factory_.registerType(c2.toString(),c2);

	EventVisitPointCommand c3 = new
			EventVisitPointCommand(	  imOffscreen,
						  myGeometryPanel,
						  this,
						  user_input_area_);
	command_factory_.registerType(c3.toString() ,c3);

	
	EventGoLeftCommand c4 = new
			EventGoLeftCommand(	 imOffscreen,
						 myGeometryPanel,
						 this,
						 user_input_area_);
	command_factory_.registerType(c4.toString() ,c4);

	EventGoRightCommand c5 = new
			EventGoRightCommand(	 imOffscreen,
						 myGeometryPanel,
						 this,
						 user_input_area_);
	command_factory_.registerType(c5.toString(),c5);

	EventNoChildrenCommand c6 = new
			EventNoChildrenCommand(	 imOffscreen,
						 myGeometryPanel,
						 this,
						 user_input_area_);
	command_factory_.registerType(c6.toString() ,c6);

	EventOverlapCommand c7 = new
			EventOverlapCommand(	 imOffscreen,
						 myGeometryPanel,
						 this,
						 user_input_area_);

	command_factory_.registerType(c7.toString() ,c7);


	node_range_ = new
			EventCheckOverlapCommand( imOffscreen,
						  myGeometryPanel,
						  this,
						  user_input_area_);
   }


/****************************************************************/
/*                                                              */
/* Function Name: asyncRecalculate                              */
/* Parameters:                                                  */
/* Returns:                                                     */
/* Effects:                                                     */
/*                                                              */
/****************************************************************/

public void asyncRecalculate ()
{
      if (ptsetInput_.size() > 1)
      {
	 
	// System.out.println("sending 'gen_range_tree' to server"+server.getInetAddress().getHostName()+" "+server.getPort());
         pstrmServerOut.print("gen_range_tree  ");
         ptsetInput_.print(pstrmServerOut);
	 try {
            rangeTree_ = new Tree(stknServerIn);
	    initTreeColors();

	 } catch (GeometryException e) {
		System.out.println(e.getMessage());
		System.out.println("Could not read the tree data from stream.");
  	 }
      }
      else
      {
		rangeTree_ =new Tree();
		initTreeColors();
      }
      super.asyncRecalculate();
   }

  public void initTreeColors()
  {
	    setUnselectedNodeImage(unselected_node_image_);
	    setSelectedNodeImage(selected_node_image_);
	    setAllocationNodeImage(allocation_node_image_);
	    setLeafNodeImage(leaf_node_image_);
	    rangeTree_.setUnselectedColor(unselected_tree_color_);
	    rangeTree_.setSelectedColor(selected_tree_color_);
  } 



   public GeometryPoint addPoint (int x, int y) {
      GeometryPoint p = ptsetInput_.add(new GPoint(x,y));
      recalc ();
      super.addPoint (x, y);
      return p;
   }

   public GeometryPoint findPoint (int x, int y) {
      return (ptsetInput_.findPoint (x, y, imRedDot.getWidth(this), imRedDot.getHeight(this)));
   }

   public void movePoint (GeometryPoint p, int x, int y) {
      ptsetInput_.movePoint (p, x, y);
      recalc();
      super.movePoint (p, x, y);
   }
   
   public void removePoint(GeometryPoint p)
   {
      ptsetInput_.removePoint(p);
      recalc();
      super.removePoint(p);
   }   

  public void removePointsNotOnGrid(int grid_spacing)
  {
    /*int num = ptsetInput_.size();
    for (int i=0; i<num; i++)
      {
	GeometryPoint pt = ptsetInput_.elementAt(i);
	if ((pt.x % grid_spacing) !=0 || (pt.y % grid_spacing) != 0)
	  ptsetInput_.removePoint(pt);
      }
      */
  }

public void gridSpacingChanged(int old_grid_spacing,
			       int new_grid_spacing)
{
  GeometryPoint pt;
  int x, y, num = ptsetInput_.size();
  for (int i=0; i<num; i++)
    {
      pt = ptsetInput_.elementAt(i);
             
      int ratio_x = pt.x / old_grid_spacing;
      int ratio_y = pt.y / old_grid_spacing;
      
      pt.x = ratio_x * new_grid_spacing;
      pt.y = ratio_y * new_grid_spacing;
    }
  recalc();
}
  
   public void clearPoints()
   {
	vcr_.eject();
	ptsetInput_= new PointSet();
        ptsetInput_.setLimits(0, 0, myGeometryPanel.size().width,
				   myGeometryPanel.size().height);

        rangeTree_=new Tree();
	initTreeColors();
	super.clearPoints();
   }   

   public void removeSelectedPts()
   {
	ptsetInput_.removeSelectedPts();
	vcr_.eject();
	recalc();
	super.removeSelectedPts();
   }

   public void moveSelectedPts(int offx, int offy)
   {
	ptsetInput_.moveSelectedPts(offx, offy);
	vcr_.eject();
	recalc();
	super.moveSelectedPts(offx,offy);
   }

   public void unSelectPts()
   {
     //ptsetInput_.unSelectPts();
	for (Enumeration e = ptsetInput_.points.elements(); e.hasMoreElements();)
      	{
         	GPoint p = (GPoint) e.nextElement();
	 	p.setQuerySelected(false);
      	}
	vcr_.eject();
	super.unSelectPts();
	ptsetInput_.unSelectPts();
   }

   public int numSelectedPts()
   {
      return ptsetInput_.numSelectedPts();
   }

   public void selectBoxPts()
   {
	int x0=bBox.minX(), y0=bBox.minY();
	int x1=bBox.maxX(), y1=bBox.maxY();

	ptsetInput_.selectBoxPts(x0, y0, x1, y1);
	super.selectBoxPts();
	// send the query to the server
	if ((x0!=x1)&&(y0!=y1))
		sendRangeQuery(x0, y0, x1, y1);
   }

   /**
    * Draws the user's input point set and the computed range tree
    */
   public void draw(Graphics g) {
      super.draw (g);
      bBox.draw(g);
      drawPointSet(g); 
      drawTree(g);
   }

   public void drawQueryRange(Graphics g)
   { 
   }


   public void sendRangeQuery(int x0, int y0, int x1, int y1)
   {
	if (ptsetInput_.size() > 1)
        {
		rangeTree_.resetAttributes();

		//System.out.println("sending 'alg_range_search' to server"+server.getInetAddress().getHostName()+" "+server.getPort());
		//System.out.println("query: x0="+x0+" y0="+y0+" x1="+x1+" y1="+y1);
		pstrmServerOut.print("alg_range_search ");
		pstrmServerOut.print(x0+" "+y0+" "+x1+" "+y1);
		pstrmServerOut.println();


		
		//String marker = st.nextString();
		//if (marker == null || marker.compareTo("GRAPH.EVENTS") != 0)
		//	throw new GeometryException
		//	("Geometry server did not return events in proper format :" + marker);
            
		//stknServerIn.nextEOL();
		int num_events = stknServerIn.nextInt();
		stknServerIn.nextEOL();
		command_list_ = new CommandList();
		for (int i=0; i < num_events; i++)
		{
			RangeSearchAnimationCommand c =(RangeSearchAnimationCommand)
				command_factory_.create(stknServerIn);
			stknServerIn.nextEOL();
			if (c==null)
			{
				//System.out.println("factory returned null");
				break;
			}
			command_list_.addCommand(c);
			//System.out.println(c.toString());
		}
		if (command_list_.numElements() != 0)
			vcr_.insert(command_list_);
	}
    }
  
    public Tree getTree()
    {
	return rangeTree_;
    }

    public PointSet getPointSet()
    {
	return ptsetInput_;
    }


    public boolean action(Event evt, Object arg)
    {
	vcr_.eject();
	rangeTree_.resetAttributes();
	return super.action(evt, arg);
    }



    public void drawTree(Graphics g)
    {
	rangeTree_.draw (g, this);
    }

    public void drawPointSet(Graphics g)
    {
	Image dot;
      	for (Enumeration e = ptsetInput_.points.elements(); e.hasMoreElements();)
      	{
         	GPoint p = (GPoint) e.nextElement();
	 	if (p.isQuerySelected())
			dot = user_point_query_selected_image_;
		else	dot = imRedDot;

		p.draw(g,dot,this);
      	}
	bBox.draw(g);
    }

    public Dimension getTreeNodeImageDimension()
    {
	return new Dimension(imBlueDot.getWidth(this),imBlueDot.getHeight(this));
    }

    public Dimension getPointImageDimension()
    {
	return new Dimension(imRedDot.getWidth(this),imRedDot.getHeight(this));
    }

    public SegmentSet getSegmentSet()
    {
	return null;
    }

    public void drawSegmentSet(Graphics g)
    {
    }



	public Image getUnselectedNodeImage()
	{
		return rangeTree_.getUnselectedNodeImage();
	}
	public Image getSelectedNodeImage()
	{
		return rangeTree_.getSelectedNodeImage();	
	}
	public Image getAllocationNodeImage()
	{
		return rangeTree_.getAllocationNodeImage();
	}
	public void setUnselectedNodeImage(Image im)
	{
		rangeTree_.setUnselectedNodeImage(im);	
	}
	public void setSelectedNodeImage(Image im)
	{
		rangeTree_.setSelectedNodeImage(im);
	}
	public void setAllocationNodeImage(Image im)
	{
		rangeTree_.setAllocationNodeImage(im);
	}
  public void setLeafNodeImage(Image im)
  {
        rangeTree_.setLeafNodeImage(im);
  }

  public Image getLeafNodeImage()
  {
        return leaf_node_image_;
  }


        public boolean mouseDown(Event e, int x, int y)
        {	  
	  if (!user_input_area_.inside(x,y))
	    {
	      TreeNode node = rangeTree_.findNode(x, y, this);
	      if (node != null)
		{		  
		  Graphics g = myGeometryPanel.getGraphics();      
		  g.clipRect (0, 0, size().width, size().height);
		  draw(grOffscreen);
		  g.drawImage(imOffscreen, 0, 0, this);
		  node_range_.setNode(node);
		  node_range_.setReversible(true);
		  node_range_.undo();
		}
	      return true;
	    }
	  unSelectPts();
	  return super.mouseDown(e, x, y);
        }


        public Color getRangeColor()
        {
	  return range_color_;
        }   

        public void drawQuerySegment(Graphics g)
        {}
};



