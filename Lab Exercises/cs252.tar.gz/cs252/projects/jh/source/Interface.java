import java.awt.Graphics;
import java.awt.*;
import java.awt.Event;
import java.awt.Point;
import java.lang.Boolean;
import java.util.Vector;
import java.applet.AudioClip;

public class Interface extends java.applet.Applet{

  //some constants used to control the mode of mouse
  public static final int STATE_NORMAL=1;
  public static final int STATE_DELETE=2;
  public static final int STATE_MOVE=3;
  public static final int STATE_RESIZE=4;
  public static final int STATE_SWEEP=5;
  public int state;

  
  public Vector rectangles;
  public ResultArea resultArea;
  public AudioClip beep;
  public AudioClip whoopy;
  public Image bg1;
  public Image bg2;
  public boolean show_dim=true;
  

  Ruler hori_ruler, verti_ruler;

  DrawingArea drawArea;
  TreeAreaHolder treeAreaHolder;
  TreeArea treeArea;

  //win is an editor to add rectangles by hand
  MyFrame win;

  //win2 is used for demostrating  algorithm
  MyFrame2 win2;

  //
  //Demo demo;


  AAlgo runner;
  MouseControl mouse_control;
  ChoiceMenu choice_menu;
  //DemoMenu demo_menu;

  Vector flash_intervals;
  Vector flash_rects;
  Color  flash_color=Color.red;

  public void init(){
    state=STATE_NORMAL;
    GridBagLayout gridbag = new GridBagLayout();
    GridBagConstraints c = new GridBagConstraints();
    setFont(new Font("Helvetica", Font.PLAIN, 14));
    setLayout(gridbag);
    
    GridBagLayout gridbag1=new GridBagLayout();
    Panel mid_panel=new Panel();
    mid_panel.setLayout(gridbag1);
    //add the "mid_panel", which will contain all the 
    //useful applets.
    resetGridBagConstraints(c);
    c.weightx=1.0;
    c.weighty=1.0;
    c.gridwidth=GridBagConstraints.RELATIVE;
    gridbag.setConstraints(mid_panel,c);
    add(mid_panel);

    //add a righ hand side margin, just make it looks better.
    Label label=new Label();
    c.weightx=0.01;
    c.weighty=1;
    c.gridwidth=GridBagConstraints.REMAINDER;
    gridbag.setConstraints(label,c); 
    add(label);


    //add the tree area:
    resetGridBagConstraints(c);
    c.fill=GridBagConstraints.BOTH;
    c.weighty=5.0;
    c.weightx=1.0;
    c.gridwidth=1;
    treeAreaHolder=new TreeAreaHolder(this);
    gridbag1.setConstraints(treeAreaHolder,c);
    mid_panel.add(treeAreaHolder);


    //add drawing area, including rulers, scroll bar and
    //the real display area.
    Panel draw_area_container=new Panel();
    resetGridBagConstraints(c);
    c.fill=GridBagConstraints.BOTH;
    c.weighty=5.0;
    c.weightx=1.0;
    c.gridwidth = GridBagConstraints.REMAINDER;
    gridbag1.setConstraints(draw_area_container,c);
    mid_panel.add(draw_area_container);
    createDrawArea(draw_area_container);

    //add the text area, which show result: sweep height and
    //sweeped area.
    resetGridBagConstraints(c);
    c.gridwidth = 1;
    Panel text_area = new Panel();     
    c.weighty=0.0;
    gridbag1.setConstraints(text_area,c);
    mid_panel.add(text_area);
    createTextArea(text_area);

    //add the control panal(inside mid_panel); 
    Panel control_panel = new Panel();
    resetGridBagConstraints(c);
    c.fill=GridBagConstraints.BOTH;
    c.weightx = 0.0;
    c.weighty = 0.0;
    c.gridheight=1;
    c.gridwidth=1;
    c.gridwidth=GridBagConstraints.REMAINDER;
    gridbag1.setConstraints(control_panel, c);
    mid_panel.add(control_panel);
    createControlPanel(control_panel);

    //create the popup window for the editor.
    win=new MyFrame("Editor",this);

    //initilize the sound clip, which will be used in
    //editor for warning.
    whoopy=getAudioClip(getCodeBase(),"audio/whoopy.au");
    bg1=getImage(getCodeBase(),"video/bgw2.gif");
    bg2=getImage(getCodeBase(),"video/swirl.gif");
  }


  public void createControlPanel(Panel control_panel){

    GridBagLayout gridbag=new GridBagLayout();
    control_panel.setLayout(gridbag);
    GridBagConstraints c = new GridBagConstraints();
    
    //add  radio buttons to control the mode of Mouse
    mouse_control=new MouseControl(this);
    resetGridBagConstraints(c);
    c.fill=GridBagConstraints.BOTH;
    c.weightx=1;
    c.weighty=1;
    c.gridwidth=1;
    gridbag.setConstraints(mouse_control,c);
    control_panel.add(mouse_control);   

    //add a "Clear" button, used to clear the display area.
    Clear clear_ap=new Clear(this);
    c.weighty=0.0;
    c.weightx=0.0;
    gridbag.setConstraints(clear_ap,c); 
    control_panel.add(clear_ap);

    //add a button to control whether or not show
    //coordinates of vertice of rectangles
    ShowNumber show_number=new ShowNumber(this);
    gridbag.setConstraints(show_number,c);
    control_panel.add(show_number);

    //add a button for poping out the editor window
    choice_menu=new ChoiceMenu(this);
    resetGridBagConstraints(c);
    c.weightx=1;
    c.gridwidth=GridBagConstraints.REMAINDER;
    gridbag.setConstraints(choice_menu,c);
    control_panel.add(choice_menu);
  }

  public void createTextArea(Panel text_area){
    GridBagLayout gridbag=new GridBagLayout();
    text_area.setLayout(gridbag);
    GridBagConstraints c = new GridBagConstraints();

    //add the result showing area
    resultArea=new ResultArea(this);
    c.weightx=1;
    gridbag.setConstraints(resultArea,c);
    text_area.add(resultArea);
  }

  //createDrawArea creates the display area and rulers.
  public void createDrawArea(Panel container){
    GridBagLayout gridbag=new GridBagLayout();
    container.setLayout(gridbag);
    GridBagConstraints c = new GridBagConstraints();
   
    //add the origin label
    Button orig=new Button(" 0 ");
    resetGridBagConstraints(c);
    c.weighty=0.0;
    c.weightx=0.0;
    gridbag.setConstraints(orig,c);
    container.add(orig);

    //add horizatal and vertical rulers
    hori_ruler= new Ruler(Ruler.HORIZONTAL);
    resetGridBagConstraints(c);
    c.weightx = 2;
    c.weighty = 1;
    c.gridwidth = GridBagConstraints.REMAINDER;
    c.gridheight = 2;
    gridbag.setConstraints(hori_ruler, c);
    container.add(hori_ruler);
                
    verti_ruler = new Ruler(Ruler.VERTICAL);
    resetGridBagConstraints(c);
    c.weighty = 2;
    gridbag.setConstraints(verti_ruler, c);
    container.add(verti_ruler);


    //add display area
    resetGridBagConstraints(c);
    c.fill=GridBagConstraints.BOTH;
    c.weighty=c.weightx=2.0;
    c.gridwidth = GridBagConstraints.REMAINDER;
    drawArea=new DrawingArea(this);

    gridbag.setConstraints(drawArea,c);
    container.add(drawArea);

    //add a slider
    resetGridBagConstraints(c);
    c.gridwidth = GridBagConstraints.REMAINDER;
    c.weightx=1.0;
    Slider slider=new Slider(this);
    gridbag.setConstraints(slider,c);
    container.add(slider);

  }

  public void call_repaint(){
    drawArea.repaint();
  }

  
  static synchronized void resetGridBagConstraints(
    GridBagConstraints c){
      c.gridx = c.gridy = GridBagConstraints.RELATIVE;
      c.gridwidth = c.gridheight = 1;
      c.fill = GridBagConstraints.BOTH;
      c.weightx = c.weighty = 0;
      c.ipadx = c.ipady = 0;
  }

  //this function will be called whenever a sweep
  //begins.
  public void set_rectangles(){
    rectangles=drawArea.rectangles; 
    runner=new AAlgo(this);
    runner.start(); 
  }

  public void add_new_rec(float a, float b, float c, float d){
    int x=(int)a*50;
    int y=(int)b*50;
    int w=(int)c*50;
    int h=(int)d*50;
    RecTangle rec=new RecTangle(x,y,w,h);
    drawArea.rectangles.addElement(rec);
    repaint();
  }

  public void sweep_line_flash(Vector intervals, Vector rects){
    flash_intervals=intervals;
    flash_rects=rects;
    drawArea.repaint();
  }

  public void sweep_line_switch_color(){
    if(flash_color==Color.red)
      flash_color=Color.green;
    else
      flash_color=Color.red;
  } 
  public void reset_flash_color(){
      flash_color=Color.green;
      drawArea.repaint();
  }
  public void slide(int cur_pos){
    float rate;
    rate=(float)(cur_pos/90.0);
    int k=(int)(rate*drawArea.size().width);
    drawArea.sweep(k); 
    runner.reset_cur_pos(k); 
  }

}


class Slider extends java.applet.Applet{
  Interface inf;
  Scrollbar scrollbal;
  int scro_val;
  public Slider(Interface inter) {
    inf=inter;
    scrollbal= new Scrollbar(Scrollbar.HORIZONTAL,
       1,0,0,500);
    GridBagLayout gridbag=new GridBagLayout();
    setLayout(gridbag);
    GridBagConstraints c = new GridBagConstraints();
    c.fill=GridBagConstraints.BOTH;
    c.weighty=1.0;
    c.weightx=1.0;
    c.gridwidth=GridBagConstraints.REMAINDER;
    gridbag.setConstraints(scrollbal,c);
    add(scrollbal);
  }
 
  public boolean handleEvent(Event evt){
    if(!(evt.target instanceof Scrollbar))
      return true;
    if(inf.state!=Interface.STATE_SWEEP){
      inf.mouse_control.setState("sweep"); 
    } 

    scro_val=((Scrollbar)evt.target).getValue();
    inf.slide(scro_val);
    return true;

  }

}

class Clear extends java.applet.Applet{
  Button button;
  Interface inf;
  public Clear(Interface a){
    inf=a;
    setLayout(new GridLayout(1,1));
    button=new Button("clear");
    add(button);
  }
  public boolean handleEvent(Event evt){
    if(evt.target==button){
      inf.drawArea.rectangles=new Vector();
      inf.drawArea.no_recs=true;
      inf.mouse_control.setState("add");
      inf.drawArea.repaint();
    }
    return true;
  }
} 

//this class is used to control the showing
//of coordinates.
class ShowNumber extends java.applet.Applet{
  Choice choice;
  Interface inf;
  CheckboxGroup cbg;
  Checkbox pop_box;
  Checkbox cancel_box;
  public ShowNumber(Interface a){
   inf=a;
   GridBagLayout gridbag=new GridBagLayout();
   setLayout(gridbag);
   GridBagConstraints c=new GridBagConstraints();
   cbg=new CheckboxGroup();
  
   Label label=new Label("Vertices");
   label.setFont(new Font("Helvetica",Font.BOLD,14));
   c.gridwidth=GridBagConstraints.REMAINDER;
   gridbag.setConstraints(label,c);
   add(label);
   
   pop_box=new Checkbox("show",cbg, true);
   gridbag.setConstraints(pop_box,c);
   add(pop_box);

   cancel_box=new Checkbox("not show",cbg, false);
   gridbag.setConstraints(cancel_box,c);
   add(cancel_box);
   
  }

  public boolean action(Event evt,Object arg){
    if(evt.target instanceof Checkbox){
      String str=(String)(cbg.getCurrent().getLabel());
      if(str.equals("show"))
        inf.show_dim=true;
      else if(str.equals("not show"))
        inf.show_dim=false;
    }
    inf.drawArea.repaint();
    return true;
  }

}

//this class is used for poping out editor window.
class ChoiceMenu extends java.applet.Applet{
    Interface inf;
    Choice choice;
    public ChoiceMenu(Interface a){
      inf=a;
      choice=new Choice();
      choice.addItem("Editor Off");
      choice.addItem("Editor On");
      add(choice); 
    }
    public boolean action(Event evt,Object arg){
      if(evt.target instanceof Choice)
        doJob(choice.getSelectedItem());
      return true;
    }
    void doJob(String str){
      Point d=inf.location();
      inf.win.move(d.x+50,d.y+50);
      inf.win.resize(400,300);
      if(str.equals("Editor On")){
        inf.win.show();
        choice.select(str);
      }
      else if(str.equals("Editor Off")){
        inf.win.hide();
        choice.select(str);
      }
    }
}


class MouseControl extends java.applet.Applet{
    Interface inf;
    CheckboxGroup cbg;
    Checkbox add_box;
    Checkbox sweep_box;

    public MouseControl(Interface a){
      inf=a;
      GridBagLayout gridbag=new GridBagLayout();
      setLayout(gridbag);
      GridBagConstraints c = new GridBagConstraints();
      cbg=new CheckboxGroup();
      Checkbox box;
      Label label=new Label("Mouse Control");
      label.setFont(new Font("Helvetica",Font.BOLD,14));
      c.gridwidth=GridBagConstraints.REMAINDER;
      gridbag.setConstraints(label,c);
      add(label);

      c.gridwidth=1;
      add_box=new Checkbox("add",cbg,true);
      gridbag.setConstraints(add_box,c);
      add(add_box);
      box=new Checkbox("delete",cbg,false);
      c.gridwidth=GridBagConstraints.REMAINDER;
      gridbag.setConstraints(box,c);
      add(box);
      box=new Checkbox("move",cbg,false);
      c.gridwidth=1;
      gridbag.setConstraints(box,c);
      add(box);

/*
      box=new Checkbox("resize",cbg, false);
      c.gridwidth=GridBagConstraints.REMAINDER;
      gridbag.setConstraints(box,c);
      add(box); 
*/
    }

    public boolean action(Event evt,Object arg){
      if(evt.target instanceof Checkbox)
        setState((String)(cbg.getCurrent().getLabel()));
      inf.call_repaint();
      return true;
    }  

    void setState(String str){
      //inf.beep.play();
      if(str.equals("delete"))
        inf.state=Interface.STATE_DELETE;
      else if(str.equals("move"))
        inf.state=Interface.STATE_MOVE;
      else if(str.equals("resize"))
        inf.state=Interface.STATE_RESIZE;
      else if(str.equals("sweep")){
        inf.state=Interface.STATE_SWEEP;
        inf.set_rectangles();
        //cbg.setCurrent(sweep_box);
        cbg.setCurrent(add_box);
        //inf.thread_start();
      }
      else{ 
        inf.state=Interface.STATE_NORMAL;
        inf.treeArea.reset_tree(null);
        inf.drawArea.currentpoint=null;
        cbg.setCurrent(add_box);
      }
      if(!str.equals("sweep"))
        inf.runner.stop();
    }

}

class ResultArea extends java.applet.Applet{
    Interface inf;
    TextField sweep_height_f;
    TextField area_f;
    public ResultArea(Interface a){
      Label label;
      TextField text_field;
      GridBagLayout gridbag=new GridBagLayout();
      setLayout(gridbag);
      GridBagConstraints c=new GridBagConstraints();
      inf=a;

      c.gridwidth=1;
      label=new Label("current sweep height: ");
      gridbag.setConstraints(label,c);
      add(label);

      c.gridwidth=GridBagConstraints.REMAINDER;
      sweep_height_f=new TextField(20);
      gridbag.setConstraints(sweep_height_f,c);
      add(sweep_height_f);

      c.gridwidth=1;
      label=new Label("area of highlighted part: ");
      gridbag.setConstraints(label,c);
      add(label);

      c.gridwidth=GridBagConstraints.REMAINDER;
      area_f=new TextField(20);
      gridbag.setConstraints(area_f,c);
      add(area_f);
    }

   public void set_result(float area, float sweep_h){
     area_f.setText(String.valueOf(area));
     sweep_height_f.setText(String.valueOf(sweep_h));
   }
}

//class used for showing sweeping heights and 
//sweeped area.
class DataArea extends java.applet.Applet{
    Interface inf;
    TextField left_upp_x;
    TextField left_upp_y;
    TextField width;
    TextField height;
    Button o_k;
    public float x;
    public float y;
    public float w;
    public float h;
    public DataArea(Interface a){
      Label label;
      TextField text_field;
      GridBagLayout gridbag=new GridBagLayout();
      setLayout(gridbag);
      GridBagConstraints c=new GridBagConstraints();
      inf=a;
 
      c.gridwidth=GridBagConstraints.REMAINDER;
      label=new Label("ADD REC BY HAND");
      gridbag.setConstraints(label,c);
      add(label);
 
      //for upp_left_x
      c.gridwidth=1;
      label=new Label("left_upper.x ");
      gridbag.setConstraints(label,c);
      add(label);
      left_upp_x=new TextField(8);
      gridbag.setConstraints(left_upp_x,c);
      add(left_upp_x);
 
      //for upp_left_y
      c.gridwidth=1;
      label=new Label("left_upper.y ");
      gridbag.setConstraints(label,c);
      add(label);
      c.gridwidth=GridBagConstraints.REMAINDER; 
      left_upp_y=new TextField(8);
      gridbag.setConstraints(left_upp_y,c);
      add(left_upp_y);

      //for width
      c.gridwidth=1;
      label=new Label("width");
      gridbag.setConstraints(label,c);
      add(label);
      width=new TextField(8);
      gridbag.setConstraints(width,c);
      add(width);
 
      //for height
      c.gridwidth=1;
      label=new Label("height");
      gridbag.setConstraints(label,c);
      add(label);
      c.gridwidth=GridBagConstraints.REMAINDER;
      height=new TextField(8);
      gridbag.setConstraints(height,c);
      add(height);

      //OK button
      o_k=new Button("OK");
      add(o_k);
    }

    public boolean HandleEvent(Event evt){
      if((evt.target == o_k)){
        String v1=left_upp_x.getText();
        String v2=left_upp_x.getText();
	String v3=width.getText();
	String v4=height.getText();
	x=(new Float(v1)).floatValue();
	y=(new Float(v2)).floatValue();
	w=(new Float(v3)).floatValue();
	h=(new Float(v4)).floatValue();
	if(w<=0 || h<=0)
	  System.out.println("[PANIC] width or height should be positive");
        else
	  inf.add_new_rec(x,y,w,h);
      }
      return true;
    } 
}


class Ruler extends Panel
{
    final static int HORIZONTAL = 0;
    final static int VERTICAL = 1;
    final static int MINOR_STEP = 5;
    final static int MAJOR_STEP = 50;
    final static int MINOR_TICK = 4;
    final static int MAJOR_TICK = 8;
    final static int BORDER = 4;
    
    int type;

    public Ruler(int type) { 
        this.type = type; 
        this.setFont(new Font("Helvetica", Font.PLAIN, 10));
    }

    private int x2,y2,xl,yl;
    
    public void paint(Graphics g) 
    {
        Dimension d = size();
        g.setColor(Color.black);
        g.draw3DRect(0, 0, d.width - 1, d.height - 1, true);
        g.setColor(Color.black);
        g.setPaintMode();


        if (type == HORIZONTAL) 
        {
            int from_x = 0;
            int to_x = d.width;
            int x = MINOR_STEP;
            int y_base = d.height;
            int y_minor = d.height-1-MINOR_TICK-BORDER;
            int y_major = d.height-1-MAJOR_TICK-BORDER;
            int y_text = y_major-2;
            while (x < to_x)
            {
                int scrx = x;
                if (x%MAJOR_STEP == 0) {
                    g.drawString(""+(x/MINOR_STEP)/10.0,scrx-2,
                      y_text);
                    g.drawLine(scrx,y_base,scrx,y_major);
                } else {
                    g.drawLine(scrx,y_base,scrx,y_minor);
                }
                x += MINOR_STEP;
            }
        } else
        if (type == VERTICAL) 
        {
            int from_y = 0;
            int to_y = d.height;
            int y = MINOR_STEP;
            int x_base = d.width;
            int x_minor = d.width-1-MINOR_TICK-BORDER;
            int x_major = d.width-1-MAJOR_TICK-BORDER;
            int x_text = x_major-5;
            while (y < to_y)
            {
                int scry = y;
                if (y%MAJOR_STEP == 0) {
                    g.drawString(""+(y/MINOR_STEP)/10.0,x_text,scry+8);
                    g.drawLine(x_base,scry,x_major,scry);
                } else {
                    g.drawLine(x_base,scry,x_minor,scry);
                }
                y += MINOR_STEP;
            }
        }
    }

}


class RecTangle{
  int x,y,w,h;
  public RecTangle(int a, int b, int c, int d){
    x=a;
    y=b;
    w=c;
    h=d;
  }
}

class DrawingArea extends Canvas{
  boolean no_recs=true;
  int pre_pos;
  final int MAXREC=50;
  boolean MouseIsDown=false;
  int slide_pos;
  Image offscreenImage;
  Dimension old_dim;
  Graphics offscreenGraphics;
  Interface inf;
  int cur_picked_rec_ind;
  RecTangle cur_rec;
  
  Point starts[]=new Point[MAXREC];
  Point dimensions[]=new Point[MAXREC];
  Vector rectangles=new Vector();
  AAlgo algo;

  Point anchor;
  Point currentpoint;
  Point moving_ptr;
  Point left_upp;
  int width;
  int height;
  int cur_rec_num=0;
  
  public DrawingArea(Interface inter){
    inf=inter;
  }

  public DrawingArea(){;}

  //caculate the left upper conner and the 
  //height and width of a recangle from
  //the anchor point and current point.
  public void set_corner(){
    int x1;
    int x2;
    int y1;
    int y2;
    int w;
    int h;
    if(anchor.x<currentpoint.x){
      x1=anchor.x;
      x2=currentpoint.x;
    }else{
      x1=currentpoint.x;
      x2=anchor.x;
    };
    if(anchor.y<currentpoint.y){
      y1=anchor.y;
      y2=currentpoint.y;
    }else{
      y1=currentpoint.y;
      y2=anchor.y;
    };
    left_upp=new Point(x1,y1); 
    width=x2-x1;
    height=y2-y1;
  }
 
  public boolean mouseDown(Event evt,int x,int y){
   MouseIsDown=true;
   switch(inf.state){
     case Interface.STATE_NORMAL:{
       anchor = new Point(x,y);
       set_corner();
       break;
     }
     case Interface.STATE_DELETE:{
       if(cur_picked_rec_ind!=-1){
         rectangles.removeElementAt(cur_picked_rec_ind);
       }
       cur_picked_rec_ind=get_nearest_rec_index(currentpoint);
       if(cur_picked_rec_ind==-1)
         inf.drawArea.no_recs=true;
       repaint();
       break;
     }
     case Interface.STATE_MOVE:{
       if(inf.drawArea.no_recs)
         return true;
       cur_rec=(RecTangle)rectangles.
         elementAt(cur_picked_rec_ind);
       width=cur_rec.w;
       height=cur_rec.h; 
       cur_rec=new RecTangle(cur_rec.x,cur_rec.y,cur_rec.w,
         cur_rec.h);
       rectangles.removeElementAt(cur_picked_rec_ind);
       //anchor = new Point(cur_rec.x, cur_rec.y);
       anchor = new Point(x,y);
       left_upp.x=cur_rec.x;
       left_upp.y=cur_rec.y;
       repaint();
       break;
     }
    case Interface.STATE_RESIZE:{
       if(inf.drawArea.no_recs) return true;
       cur_rec=(RecTangle)rectangles.elementAt(cur_picked_rec_ind);
       anchor = new Point(cur_rec.x, cur_rec.y);
       currentpoint=moving_ptr;
       set_corner();
       rectangles.removeElementAt(cur_picked_rec_ind);
       repaint();
       break;
    }
    case Interface.STATE_SWEEP:{
      inf.mouse_control.setState("add");
      anchor = new Point(x,y);
      set_corner();
      break;
    }
   }//end of switch
   return true;
 }

  public boolean mouseUp(Event evt, int x, int y){
   MouseIsDown=false;
   currentpoint=new Point(x,y);
   switch(inf.state){
     case Interface.STATE_NORMAL:{
         inf.drawArea.no_recs=false;
         set_corner();
         addrec();
         break;
     }
     case Interface.STATE_RESIZE:{
         if(inf.drawArea.no_recs)
           return true;
         set_corner();
         addrec();
         break;
     }
     case Interface.STATE_MOVE: 
     {
         if(inf.drawArea.no_recs)
           return true;
         if(rectangles.size()==0) return true;
         left_upp.x=cur_rec.x+currentpoint.x-anchor.x;
         left_upp.y=cur_rec.y+currentpoint.y-anchor.y;
         addrec();
         currentpoint=new Point(x,y);
         cur_picked_rec_ind=get_nearest_rec_index(currentpoint);
         break;
    }
   }//end of switch.
   repaint();
   return true;
  }

 public boolean mouseDrag(Event evt, int x, int y){
  switch(inf.state){
    case Interface.STATE_NORMAL:{
     currentpoint=new Point(x,y);
     set_corner();
     repaint();
     break;
    }
    case Interface.STATE_RESIZE:{
     if(inf.drawArea.no_recs)
       return true;
     currentpoint=new Point(x,y);
     set_corner();
     repaint();
     break;
    }
    case Interface.STATE_MOVE:{
     if(inf.drawArea.no_recs) return true;
     currentpoint=new Point(x,y);
     left_upp.x=cur_rec.x+currentpoint.x-anchor.x;
     left_upp.y=cur_rec.y+currentpoint.y-anchor.y; 
     repaint();
     break;
    } 
  }
  return true;
 }

 public boolean mouseMove(Event evt,int x, int y){
  if(inf.state!=Interface.STATE_NORMAL){
    moving_ptr=new Point(x,y);
    cur_picked_rec_ind=get_nearest_rec_index(moving_ptr); 
    repaint();
  }
  return true;
 }

 void addrec(){
  RecTangle rec=new RecTangle(left_upp.x, left_upp.y, width, 
    height); 
  rectangles.addElement(rec);
  cur_rec_num++;
  currentpoint = null;
  repaint();
 }

 
 public void paint(Graphics g){
  Dimension d=size();
  int k,l;
  RecTangle rec;
  if(offscreenImage==null || d.width!=old_dim.width || 
     d.height!=old_dim.height){
    offscreenImage=createImage(this.size().width,
      this.size().height);
    offscreenGraphics = offscreenImage.getGraphics();
    old_dim=d;
  }
  offscreenGraphics.setColor(Color.blue);
/*
  offscreenGraphics.fillRect(0,0,this.size().width,
    this.size().height);
*/
  offscreenGraphics.drawImage(inf.bg2,
    0,0,this.size().width,this.size().height,null);
  offscreenGraphics.setColor(Color.white);
  k=rectangles.size();
  for(int i=0; i<k; i++){
    rec=(RecTangle)rectangles.elementAt(i);
    offscreenGraphics.drawRect(rec.x,rec.y, rec.w, rec.h);
    if(inf.show_dim){
      String s1=String.valueOf(rec.x/50.0);
      String s2=String.valueOf(rec.y/50.0);
      String s3=String.valueOf((rec.x+rec.w)/50.0);
      String s4=String.valueOf((rec.y+rec.h)/50.0);
      //offscreenGraphics.setColor(Color.white);
      offscreenGraphics.drawString("("+s1+" , "+s2+")", rec.x-40, 
        rec.y-2);
      offscreenGraphics.drawString("("+s3+" , "+s4+")",
        rec.x+rec.w-40, rec.y+rec.h+10);
    }

  }
  offscreenGraphics.setColor(Color.red);
  switch(inf.state){
    case Interface.STATE_NORMAL:{
      if(currentpoint !=null)
        offscreenGraphics.drawRect(left_upp.x,left_upp.y,width, 
          height);
      if(inf.show_dim && MouseIsDown)
        drawDim(left_upp.x,left_upp.y,left_upp.x+width,
                left_upp.y+height, offscreenGraphics);
      break;
    }
    case Interface.STATE_MOVE:{ 
      if(currentpoint!=null && MouseIsDown){
        offscreenGraphics.drawRect(left_upp.x,left_upp.y,
          cur_rec.w, cur_rec.h);
        if(inf.show_dim){
          drawDim(left_upp.x,left_upp.y,left_upp.x+width,
                  left_upp.y+height, offscreenGraphics);
        }
      }
      else if(cur_picked_rec_ind!=-1){
        rec=(RecTangle)rectangles.elementAt(cur_picked_rec_ind);
        offscreenGraphics.drawRect(rec.x,rec.y,rec.w, rec.h);
      } 
      break;
    }
    case Interface.STATE_DELETE:{
      if(!MouseIsDown && cur_picked_rec_ind!=-1){
        rec=(RecTangle)rectangles.elementAt(cur_picked_rec_ind);
        offscreenGraphics.drawRect(rec.x,rec.y,rec.w, rec.h);
      }
      break;
    }
    case Interface.STATE_RESIZE:{
     if(currentpoint!=null && MouseIsDown){
       offscreenGraphics.drawRect(left_upp.x,left_upp.y,width,
         height);
        if(inf.show_dim){
          drawDim(left_upp.x,left_upp.y,left_upp.x+width,
                  left_upp.y+height, offscreenGraphics);
        }
     }
     else if(cur_picked_rec_ind!=-1){
      rec=(RecTangle)rectangles.elementAt(cur_picked_rec_ind);
      offscreenGraphics.drawRect(rec.x,rec.y,rec.w, rec.h);
     }
     break;
    }
    case Interface.STATE_SWEEP:{
      offscreenGraphics.drawLine(slide_pos,0,slide_pos,
        this.size().height);

      offscreenGraphics.setColor(Color.yellow);
      for(int i=0; i<k; i++){
        rec=(RecTangle)rectangles.elementAt(i);
        if(rec.x<slide_pos){
          if(rec.x+rec.w>slide_pos) 
            offscreenGraphics.fillRect(rec.x,rec.y,slide_pos-rec.x
             ,rec.h);
          else
            offscreenGraphics.fillRect(rec.x,rec.y,rec.w, rec.h);
        }
      }

      //flashing picked part:
      if(inf.flash_intervals!=null && inf.flash_color==Color.red){
        int s=inf.flash_intervals.size();
        offscreenGraphics.setColor(inf.flash_color);
        Interval temp;
        for(int j=0; j<s; j++){
          temp=(Interval)inf.flash_intervals.elementAt(j); 
          offscreenGraphics.fillRect(slide_pos-2, temp.left,
            4, temp.right-temp.left);
        }
        if(inf.flash_rects!=null){
        s=inf.flash_rects.size();
          RecTangle rect;
          for(int j=0; j<s; j++){
            rect=(RecTangle)inf.flash_rects.elementAt(j);
            offscreenGraphics.drawRect(rect.x, rect.y, 
              rect.w, rect.h);
          }
        }
      }

      break;
    }
    default:{
      if(cur_picked_rec_ind!=-1){
        rec=(RecTangle)rectangles.elementAt(cur_picked_rec_ind);
        offscreenGraphics.drawRect(rec.x,rec.y,rec.w, rec.h);
      }
      break;
    }
  }//end of switch

  g.drawImage(offscreenImage, 0, 0, this); 
 }
 
 //show the coordinates of vertice of rectangles.
 void drawDim(int a, int b, int c, int d, Graphics graphic){
      int margin1=40;
      int margin2=2;
      int margin3=10;
      String s1=String.valueOf(a/50.0);
      String s2=String.valueOf(b/50.0);
      String s3=String.valueOf(c/50.0);
      String s4=String.valueOf(d/50.0);
      graphic.setColor(Color.yellow);
      graphic.drawString("("+s1+" , "+s2+")", a-margin1, b-margin2);
      graphic.drawString("("+s3+" , "+s4+")", c-margin1, d+margin3);
      graphic.setColor(Color.blue);
 }

 int get_nearest_rec_index(Point ptr){
  int k=rectangles.size();
  int ind=-1;
  int temp=10000;
  int temp1;
  int temp2;
  int temp3;
  RecTangle rec;
  
  for(int i=0; i<k; i++){
    rec=(RecTangle)rectangles.elementAt(i);
    temp1=Math.min(Math.abs(rec.x-ptr.x), Math.abs(rec.y-ptr.y));
    temp2=Math.min(Math.abs(rec.x+rec.w-ptr.x),
      Math.abs(rec.y+rec.h-ptr.y));
    temp3=Math.max(temp1, temp2);
    temp1=Math.min(temp1, temp2);
    if(temp1>10)
      temp1=temp3;
    if(temp1<temp){
      ind=i;
      temp=temp1;
    }
  }
  return ind;
 }

 public void sweep(int cur_pos){
   slide_pos=cur_pos;
   repaint();
 }

 public void update(Graphics g){
    paint(g);
 }

}

//a pop up window for editor.
class MyFrame extends Frame{
  Editor editor;
  public MyFrame(String title, Interface a){
    super(title);
    setLayout(new GridLayout(1,1));
    editor=new Editor(a);
    add(editor);
  }
}

//a pop up window for demostration.
class MyFrame2 extends Frame{
  public MyFrame2(Interface a){
    setLayout(new GridLayout(1,1));
/*
    a.demo=new Demo(a,a.drawArea.offscreenGraphics, 
      a.drawArea.rectangles);
    add(a.demo);
*/
  }
  public void run(){
 //   a.demo.start(); 
  }
}

//class used to add rectangles by hand.
class Editor extends java.applet.Applet implements Runnable{
  Interface inf;
  Label l_x;
  Label l_y;
  Label l_w;
  Label l_h;
  float x;
  float y;
  float h;
  float w;
  TextField t_x;
  TextField t_y;
  TextField t_w;
  TextField t_h;
  Button o_k;
  Button clear;
  Button quit_b;
  Panel panel;
  Label label;
 
  public Editor(Interface a){
    inf=a;
    GridBagLayout gridbag=new GridBagLayout();
    GridBagConstraints c=new GridBagConstraints();
    setLayout(gridbag);

    l_x=new Label("x_cordiate of the left upper conner");
    l_y=new Label("y_cordiate of the left upper conner");
    l_w=new Label("width");
    l_h=new Label("height");
    t_x=new TextField(6);
    t_y=new TextField(6);
    t_w=new TextField(6);
    t_h=new TextField(6);
    o_k=new Button("add");
    panel=new Panel();
    quit_b=new Button("quit");
    clear=new Button("clear");
    label=new Label("                                          ");

    c.fill=GridBagConstraints.BOTH;
    c.weightx=1.0;
    c.gridwidth=3;

    gridbag.setConstraints(l_x,c);
    add(l_x);

    c.gridwidth=GridBagConstraints.REMAINDER;
    gridbag.setConstraints(t_x,c);
    add(t_x);

    c.gridwidth=3;
    gridbag.setConstraints(l_y,c);
    add(l_y);

    c.gridwidth=GridBagConstraints.REMAINDER;
    gridbag.setConstraints(t_y,c);
    add(t_y);

    c.gridwidth=3;
    gridbag.setConstraints(l_w,c);
    add(l_w);

    c.gridwidth=GridBagConstraints.REMAINDER;
    gridbag.setConstraints(t_w,c);
    add(t_w);

    c.gridwidth=3;
    gridbag.setConstraints(l_h,c);
    add(l_h);

    c.gridwidth=GridBagConstraints.REMAINDER;
    gridbag.setConstraints(t_h,c);
    add(t_h);

    c.gridwidth=GridBagConstraints.REMAINDER;
    gridbag.setConstraints(panel,c);
    add(panel);

    panel.setLayout(new FlowLayout());
    panel.add(o_k);
    panel.add(clear);
    panel.add(quit_b);

    c.gridwidth=GridBagConstraints.REMAINDER;
    gridbag.setConstraints(label,c);
    label.setFont(new Font("Helvetica",Font.BOLD,14));
    add(label);
  }

  public void run(){
  }

  public boolean action(Event e, Object arg){
   label.setText(" ");
   if(e.target==o_k){
        String v1=t_x.getText();
        String v2=t_y.getText();
        String v3=t_w.getText();
        String v4=t_h.getText();
        x=(new Float(v1)).floatValue();
        y=(new Float(v2)).floatValue();
        w=(new Float(v3)).floatValue();
        h=(new Float(v4)).floatValue();
        if(w<=0 || h<=0){
          inf.whoopy.play();
          label.setText ("width or height should be positive");
        }
       else{
        inf.add_new_rec(x,y,w,h);
        inf.drawArea.repaint();
       }


   } 
   else if(e.target==clear){
     t_x.setText(String.valueOf(0.0));
     t_y.setText(String.valueOf(0.0));
     t_h.setText(String.valueOf(0.0));
     t_w.setText(String.valueOf(0.0));
   }
   else if(e.target==quit_b){
     inf.choice_menu.doJob("Editor Off"); 
   }
   return true;
  }
}
