/*
 *  SliderControl - basic slider widget for arbitrary values 
 *  4/14/96 
 *  by Daniel Spirn based on example from Sun Microsystems, inc.
 *  (see http://java.sun.com/./tutorial/ui/overview/
 *		example/Converter.java.html)
 *				
 */
package graphrender;

import java.awt.*;

// Builds a slider widget
//
class GRSlider extends Panel {
    // Title of the particular slider widget
    String title;

    // Displays the value of the slider
    TextField textField;

    // Actual Slider 
    Scrollbar slider;

    // Min, max value of slider and the increment value
    double min_, max_, delta_;

    // Corresponding min, max integer value for slider
    int slidermin_ = 0;
    int slidermax_;

    GRSlider(String myTitle, double min, double max, double delta){
	super();

	setLayout(new BorderLayout());

	title = myTitle;
	min_ = min;
	max_ = max;
	delta_ = delta;
	slidermax_ = (int) ((max - min) / delta);	

	//Add the label
	Label label = new Label(title, Label.CENTER);
	label.setBackground(new Color(34,133,144));
	label.setForeground(new Color(255,255,255));
	add("North",label);

	//Add the text field
	textField = new TextField("0", 10);
	add("Center",textField);

	//Add the slider
	slider = new Scrollbar(Scrollbar.HORIZONTAL, 0, 100, slidermin_, slidermax_);
	add("South",slider);
    }

    /** Draws a box around this panel. */
    public void paint(Graphics g) {
	Dimension d = size();
	g.drawRect(0,0, d.width - 1, d.height - 1);
    }
               
    /** Gets the current value in the text field.
     * That's guaranteed to be the same as the value
     * in the scroller (subject to rounding, of course).
     */
    double getValue() {
	double f;
	try {
		f = Double.valueOf(textField.getText()).doubleValue(); 
	} catch (java.lang.NumberFormatException e) {
		f = 0.0;
	}
	f *= delta_;
	f += min_;
	return f;
    }

    /** Respond to user actions. */
    public boolean handleEvent(Event e) {
	if (e.target instanceof Scrollbar) {
		double f = slider.getValue();
		f *= delta_;
		f += min_;
		textField.setText(String.valueOf(f));
	} else if ((e.target instanceof TextField) 
		&& (e.id == Event.ACTION_EVENT)) {
		setSliderValue(getValue());
	} else if ((e.target instanceof Choice) 
		&& (e.id == Event.ACTION_EVENT)) {
	} 
	return false;
    }

    /** Set the values in the slider and text field. */
    void setValue(double f) {
	setSliderValue(f);
	textField.setText(String.valueOf(f));
    }

    /** Set the slider value. */
    void setSliderValue(double f) {

	f -= min_;
	f /= delta_;

	int sliderValue = (int)f;


	if (sliderValue > slidermax_)
		sliderValue = slidermax_;
	if (sliderValue < slidermin_)
		sliderValue = slidermin_;
	slider.setValue(sliderValue);
    }
}








