/****************************************************************/
/*    NAME:                                                     */
/*    ACCT: mjw                                                 */
/*    FILE: RTPoint.C                                           */
/*    ASGN:                                                     */
/*    DATE: Wed Apr 10 16:27:59 1996                            */
/****************************************************************/



#include "RTPoint.H"

// does not print \n char
ostream& operator<<(ostream& out, const RTPoint& pt)
{
	out <<pt.id_<<"("<<pt.x_ <<","<< pt.y_<<")";
	return out;
}


// this is needs a bit more...
istream& operator>>(istream& in, RTPoint& pt)
{
	in >> pt.x_;
	in >> pt.y_;
	return in;
}



