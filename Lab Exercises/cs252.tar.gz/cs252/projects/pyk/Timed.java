/*
 * Timed.java
 *
 * Description:
 *    This is the interface for a tick used by the timer class.
 */
interface Timed
{
   public void tick(Timer t);
}