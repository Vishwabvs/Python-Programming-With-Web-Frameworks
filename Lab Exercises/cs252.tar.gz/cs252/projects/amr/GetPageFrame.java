import java.awt.*;
import java.net.*;
import WebTree;

class GetPageFrame extends Frame {
  
   Label l;
   WebTree webtree_;
   TextArea ta = new TextArea("Getting Text...", 30, 70);
   
   TextField tf_, tf1_;
   Button clear_, close_;

// CONSTRUCTOR ////////////////////////////////////////////////////
   
   GetPageFrame (String title, WebTree webtree)
   {

      super(title);
      setLayout(new FlowLayout());
      webtree_ = webtree;
      ta.setEditable(false);
      ta.setBackground(Color.white);
      add(ta);
      clear_ = new Button("Clear"); add(clear_);
      close_ = new Button("Close");add(close_);

  }


// GET ////////////////////////////////////////////////////////////
   
public void get (URL theURL)
   {
      
      String buf = webtree_.webCrawler_.getSource(theURL);
      ta.setText(buf);
      
   }


// ACTION ////////////////////////////////////////////////////////

public boolean action (Event evt, Object arg)
   {
      
      if (evt.target instanceof Button) {

         String label = (String) arg;

         if (label.equals("Clear")) {
            ta.setText(" ");
         } else if (label.equals("Close")) this.hide();

         return true;
         
      } else  return false;
      
   }
   
}