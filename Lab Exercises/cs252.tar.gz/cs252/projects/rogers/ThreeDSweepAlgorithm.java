/** Brian Rogers
    cs252
    spring 1996
    Final Project */

import java.awt.*;



/** This is the abstract class that all sweep plane algorithms extend.  It's
    job is to keep track of the sweep plane, and control the thread that will
    just call the step method on the subclass to run it's particular 
    algorithm. */
    
public abstract class ThreeDSweepAlgorithm extends Thread {
     public static final int CANVAS_DIMENSION = ThreeDCanvas.CANVAS_DIMENSION;
     
     int move_step = 10;
     int calc_step = 300;

     ThreeDSweepPlane _plane;

     ThreeDSpace _space;        // We need these to draw what is happening,
     ThreeDCanvas _canvas;     // and to communicate when we are done 
     ThreeD _applet;          // running the algorithm.

     ThreeDVertex _verts[];  // The vertices in space sorted by x coordinate
     int num_verts;
     int vert_index = 0;
     ThreeDVertex current_vert;

     Image off_screen;  // An off screen image for double buffering.



     public ThreeDSweepAlgorithm (ThreeDSpace space, ThreeDCanvas canvas,
                                  ThreeD applet, Color planecolor,
                                  ThreeDVertex verts[], int numverts) {
          _plane = new ThreeDSweepPlane(space, planecolor);

          _space = space; 
	  _canvas = canvas;
	  _applet = applet;
	  
          _verts = verts;

	  num_verts = numverts;

	  if (num_verts > 0) current_vert = _verts[0];
	  else current_vert = null;

	  _plane.draw(_canvas.getGraphics());
	  
	  off_screen = _canvas.createImage(CANVAS_DIMENSION, CANVAS_DIMENSION);
     }


     /** This moves the plane one step to the left if there is space for it.
         It uses double buffering to reduce flickering */
     public boolean movePlane () {
          if (off_screen == null)
               off_screen = _canvas.createImage(CANVAS_DIMENSION, 
	                                        CANVAS_DIMENSION);
          else off_screen.flush();

          Graphics grafix = off_screen.getGraphics();
	  grafix.setColor(Color.black);
	  grafix.fillRect(0, 0, CANVAS_DIMENSION, CANVAS_DIMENSION);

	  if (_plane.move() == true) {
	       _plane.draw(grafix);
	       grafix = _canvas.getGraphics();
	       grafix.drawImage(off_screen, 0, 0, _canvas);
	       return true;
	  }
	  else {
	       _space.drawFrame(grafix);
	       _space.drawSpace(grafix);
	       grafix = _canvas.getGraphics();
	       grafix.drawImage(off_screen, 0, 0, _canvas);
	       return false;
	  }
     }



     /** This is the body of the thread that runs the algorithm.  It basically
         just moves the plane from left to right, and calls step() when it 
	 sees it is at a vertex.  The subclasses define what step() does. */
     public void run () {
          try {
	       while (true) {
	            /* If there are no more vertices to check */
	            if (current_vert == null) {
		         /* If the plane is all the way to the right */
	                 if (movePlane() == false) {
			      _applet.finishedSweep();
			      stop();
			 }
	                 else sleep(move_step);
	            }

		    /* If the plane is at the current_vert's x coordinate */
                    else if (current_vert.xCoord() == _plane.xValue()) {
	                 step(); // Call step() on the subclass.
			 
			 /* get the next vertex if there is another */
	                 if (vert_index < num_verts-1) 
	                             current_vert = _verts[++vert_index];
	                 else current_vert = null;

                         /* give the user a chance to see what is going on */ 
	                 sleep(calc_step);
	            }

	            else {
	                 movePlane();
	                 sleep(move_step);
	            }
	       }
	  }
	  
	  catch (InterruptedException e) System.out.println(e);
     }

     public abstract void step ();
     
     
     public void setMoveStep (int step) {move_step = step;}
     
     public void setCalcStep (int step) {calc_step = step;}
}
