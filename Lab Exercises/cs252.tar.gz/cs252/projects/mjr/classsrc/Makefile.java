all:
	javac *.java

clean:
	/bin/rm -f *.class
