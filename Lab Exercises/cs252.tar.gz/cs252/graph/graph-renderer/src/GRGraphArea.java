/*
 *  GRGraphArea - graph display area 
 *  4/14/96 
 *  by Daniel Spirn 
 *
 */
package graphrender;

import java.net.*;
import java.io.*;
import java.awt.*;
import java.applet.*;
import java.util.*;

public class GRGraphArea extends Canvas implements Runnable
{
    // Animator Object - controls iteration updates
    static GRAnimator 	animator;
	
    // Animation Thread - needed to get regular time intervals for animation
    static Thread 	animatorThread;

    // Controls File IO (mostly loading graphs from a library)
    static GRFileIO	fileio;

    // Access to the graph control panel 
    static GRGraphControl gc;

    // The actual graph
    static GRGraph 	graph;

    //  These are coordinatees of 
    int 		prevx, prevy;
    int 		bx0,by0,bx1,by1;

    final static int	default_iterations_ = 50;		
    int 		iterations_;

    final static double default_energy_delta_ = 0.001;
    double		energy_delta_;
    double 		gamma_ = 0.5;

    static int		iteration_count;

    final static int 	fps = 10;
    int 		delay;
    final static double SCREEN_DIMENSION = 500.0;

    // These temporary, needed to do node/edge moving.  They are needed to keep track of 
    // mouse clicks and events
    Node 		temp1_node;
    Edge		temp1_edge;

    // whether first node in edge is filled (when drawing edges)
    boolean 		filled = false;

    // Mode that the program is in (selecting node or edge / adding nodes)
    boolean 		selectnode = false;  
    boolean 		selectedge = false;
    boolean 		addnode = false;

    // whether the program should center the graph next time around
    boolean 		centered = true;

    // These are needed for double-buffering
    Dimension		offDimension;
    Graphics		offGraphics;
    Image		offImage;

    GRGraphArea(GRGraphControl t, Container container, Applet applet) 
    {
	graph = new GRGraph(this);
	gc = t;
	setBackground(Color.white);
	
        // calculates the default delay during animations
	delay = (fps > 0) ? (1000 / fps) : 100;
	
	animator = new GRAnimator();
	fileio = new GRFileIO(applet);

	// add GRGraphArea to the parent
	container.add("Center", this);

	// set the iteration constants
	iterations_ = default_iterations_;
	energy_delta_ = default_energy_delta_;
    }

    public GRGraph graph() {
	return graph;
    }

    public void newGraph(){
	graph = new GRGraph(this);
    }
    
    //  Loads filename from the models/ directory (figure library) 
    //
    public boolean load(String filename) {
	GRGraph temp;

	try {
		temp = fileio.readInGraph(filename, this);
	} catch (GRFileFormatException e) {
		System.err.println(e.toString());
		return false;
	} catch (java.io.IOException ioe) {
		System.err.println(ioe.toString());
		return false;
 	}

	// No file loaded (io problem)	
	if (temp == null)
		return false;

	graph = temp;
	graph.centerGraph();
	repaint();
	return true;
    }

    //  Projects the graph onto the viewing plane
    //
    public void project() {
	graph.view.project(graph);
	graph.calculateView();
	repaint();
    }

    // Perturbs the graph in random ways (gaussian distribution on nodes)
    //
    public void perturbGraph() {
	animator.perturbGraph(graph);
    }

    // Builds a random graph with numnodes number of edges.  There can be 
    // random edges between the nodes
    //
    public void newRandomGraph(boolean addedges, int numnodes){
	int i,j;
	Random rand = new Random();

	// prints out old graph to system
	for (i = 0 ; i<graph.numnodes() ; i++)
		System.out.println("v "+graph.nodes()[i].x()+" "+graph.nodes()[i].y()+" "+graph.nodes()[i].z());
	Edge edge = graph.edges();
	while(edge != null) {
		j = 0;
		while(j < graph.numnodes()) {
			if (graph.nodes()[j] == edge.node1())
				break;
			else j++;
		}
		int k = 0;
		while(k < graph.numnodes()) {
			if (graph.nodes()[k] == edge.node2())
				break;
			else k++;
		}
		System.out.println("l "+(j+1)+" "+(k+1));
		edge = edge.next();
	}


	// Build NEW GRAPH
	graph = new GRGraph(this);
	
	// Put random location for each node
	for (i = 0 ; i < numnodes ; i++) {
		double x = (200.0 * rand.nextDouble()) - 100.0;
		double y = (200.0 * rand.nextDouble()) - 100.0;
		double z = (200.0 * rand.nextDouble()) - 100.0;
		graph.addNode(x,y,z);
	}
	
	if (addedges == false) return;

	int nextnode;
	Edge tedge;
	boolean add_new_edge = true;

	// Add random edges between nodes
	for (i = 0 ; i < numnodes ; i++) {
	
		// On average 3 edges from each node
		for ( j = 0 ; j < 2 ; j++ ) {
			nextnode = (int) ((double)(numnodes) * 
						rand.nextDouble());
			if (nextnode != i) {
				tedge = graph.edges();

				// Make sure edge doesn't exist already
				while (tedge != null) {
					if (((tedge.node1() == graph.nodes()[i]) && 
					     (tedge.node2() == graph.nodes()[nextnode])) ||
					    ((tedge.node1() == graph.nodes()[nextnode]) && 
					     (tedge.node2() == graph.nodes()[i])))
						add_new_edge = false;
					tedge = tedge.next();
				}
				if (add_new_edge == true)
					graph.addEdge(graph.nodes()[i],graph.nodes()[nextnode]);

			}
			add_new_edge = true;
		}
	}
    }
	 
    public void startAnimation() {
	gc.setUpdateMessage("animation started");
	repaint();
  	if (animatorThread == null) {
		animatorThread = new Thread(this);
		animatorThread.start();
	}
    }

    public void stopAnimation(){
  	animatorThread = null;
	gc.animating_ = false;
	gc.animate_.setSelected(false);
	gc.animate_.repaint();
	gc.energy_graph_.repaint();
    }

    // Animation SEQUENCE
    //
    public void run() {
 	// Start time of animation
	long startTime = System.currentTimeMillis();

	// Energy at particular iteration
	double average_energy = 10, previous_energy = 0, cost = 10;	

	// Iterations
	iteration_count = -1;

	// Set simulated annealing constants to default
	animator.resetSAConstants();

	if (iterations_ == 0) iteration_count = 0;

	while ((Thread.currentThread() == animatorThread) &&
	       (iteration_count < iterations_)) {
		iteration_count++;

		// Call the appropiate convergence method
		if (gc.method() == gc.SPRING_METHOD) {
			average_energy = animator.SpringUpdate(graph);
			gc.setUpdateMessage((new String("energy = ")).concat(Double.toString(average_energy)));	
			if (Math.abs(average_energy - previous_energy) < energy_delta_) {
				gc.setUpdateMessage((new String("[threshold reached] = ")).concat(
						     Double.toString(average_energy - previous_energy)));
				break;
			}
		}
		else if (gc.method() == gc.FORCE_DIRECTED_METHOD) {			
			average_energy = animator.ForceDirectedUpdate(graph);
			gc.setUpdateMessage((new String("energy = ")).concat(Double.toString(average_energy)));	
			if (Math.abs(average_energy - previous_energy) < energy_delta_) {
				gc.setUpdateMessage((new String("[threshold reached] = ")).concat(
						     Double.toString(average_energy - previous_energy)));
				break;
			}
		}
		else if (gc.method() == gc.SIMULATED_ANNEALING_METHOD) {
			average_energy = animator.SimulatedAnnealingUpdate(graph);
			gc.setUpdateMessage((new String("cost = ")).concat(Double.toString(average_energy)));
			recenter();
		}

		// Set the energy for the iteration step
		gc.energy_graph_.SetNextEnergyStep(average_energy);		
		graph.calculateView();
		repaint();
		gc.updateEnergyGraph();
		previous_energy = average_energy;

		// Let thread sleep to give time to repaint the graph
		try {
			startTime += delay;
			animatorThread.sleep(Math.max(0,startTime-System.currentTimeMillis()));
		} catch (InterruptedException e) {
		 break;
		}
		
	}
	if (iteration_count == iterations_)
			gc.setUpdateMessage((new String("stopped after ")).concat(Integer.toString(iterations_)).concat(" iterations"));
	stopAnimation();
	gc.energy_graph_.DrawGraph();
	gc.energy_graph_.repaint();
    }

    public double screenDimension()
    {
	return SCREEN_DIMENSION;
    }

    public boolean autoscaling()
    {
	return gc.autoscale();
    }

    // DOUBLE BUFFERED CODE
/*
    public void update(Graphics g) {
	Dimension d = size();

	Rectangle r = bounds();
	if ((r.width != SCREEN_DIMENSION) || (r.height != SCREEN_DIMENSION)) 
		reshape(r.x, r.y, (int) SCREEN_DIMENSION, (int) SCREEN_DIMENSION);

	if ( (offGraphics == null)
	   || (d.width != offDimension.width)
	   || (d.height != offDimension.height)) {	
		offDimension = d;
		offImage = createImage(d.width, d.height);
		offGraphics = offImage.getGraphics();
	}
	
	offGraphics.setColor(getBackground());
	offGraphics.fillRect(0,0,d.width,d.height);
	offGraphics = graph.draw(offGraphics);

	g.drawImage(offImage, 0,0 ,this);
    }

    public void paint(Graphics g) 
    {
	if (offImage != null) 
		g.drawImage(offImage, 0, 0, this);
    }
*/
    // SINGLE BUFFERED CODE
    //
    public void paint(Graphics g) 
    {
	Rectangle r = bounds();
	if ((r.width != SCREEN_DIMENSION) || (r.height != SCREEN_DIMENSION)) 
		reshape(r.x, r.y, (int) SCREEN_DIMENSION, (int) SCREEN_DIMENSION);
	g = graph.draw(g);
    }

    // RECENTER GRAPH
    //
    public void recenter()
    {
	graph.centerGraph();
    }

    // RESIZE VIEWING PORT
    //
    public void resize()
    {
	graph.calculateView();
    }

    //
    //  Mouse event -> does the appropiate action depending on which mode the program is in:
    //			Rotate, Select, Delete, Add Node/Edge, Lock
    //
    public boolean mouseDown(Event e,int x,int y)
    { 
	// Suspend animation & do event to graph
	if (gc.animate() == true) {
		animatorThread.suspend();
	}

	// Rotate Graph
	if (gc.status()==0)
	{
		prevx = x;
		prevy = y;
		if (centered == false) { 
			graph.centerGraph();
			centered = true;
		}
	}

      	// Add Node
	if (gc.status()==1)
	{
		graph.addNode(x,y);
		temp1_node = graph.selectNode(x,y);
		addnode = true;
		temp1_node.setSelectColor();
		centered = false;
	}

 	// Add Edge
	if (gc.status()==2) 
	{
		if (filled == false) 
		{
			temp1_node = graph.selectNode(x,y);
			if (temp1_node == null) 
				filled = false;
			else
				filled = true;
		}
		else 
			filled = false;					
	}

	// Select Node/Edge
	if (gc.status()==3)
	{
	  	temp1_node = graph.selectNode(x,y);
		if (temp1_node == null) { 
			temp1_edge = graph.selectEdge(x,y,gamma_);
			if (temp1_edge == null) 
				return false;
			temp1_edge.setSelected();
			centered = false;
			selectedge = true;
			return true;
		}
		temp1_node.setSelectColor();
		selectnode = true;
		centered = false;
		temp1_node.setviewx(x);
		temp1_node.setviewy(y);
	}

	// Delete Node/Edge
	if (gc.status()==4)
	{	
		temp1_node = graph.selectNode(x,y);
		if (temp1_node != null) {
			graph.deleteNode(temp1_node);
			centered = false;
		}
		else {
			Edge tedge = graph.selectEdge(x,y,gamma_);
			if (tedge == null)
				return false;
			graph.deleteEdge(tedge);
		}
	}

	// Lock Node
	if (gc.status() == 5)
	{
		temp1_node = graph.selectNode(x,y);
		if (temp1_node == null) {
			return false;
		}
		if (temp1_node.isLocked() == false)
			temp1_node.lock();
		else
			temp1_node.unlock();
	}
	repaint();
	return(true);
    }

    public boolean mouseDrag(Event e,int x,int y)
    {
	// Rotate Graph
	if (gc.status() == 0) 
	{		
		double xtheta = ((double) (y - prevy))*360.0f /SCREEN_DIMENSION;
		double ytheta = ((double) (x - prevx))*360.0f /SCREEN_DIMENSION;
		graph.view().xrot(xtheta);
		graph.view().yrot(ytheta);
		prevx = x;
		prevy = y;
		graph.calculateView(); 
	}

	// Move New Node
	if ((gc.status() == 1) && (addnode==true)) 
	{
		temp1_node.setviewx(x);
		temp1_node.setviewy(y);
	}

	// Drag out Edge
	if ((gc.status() == 2) && (filled == true))
		graph.tempedge((int) temp1_node.viewx(), (int) temp1_node.viewy(),x,y,true);

	// Move Selected Node
	if ((gc.status() == 3) && (selectnode == true))
	{
		temp1_node.setviewx(x);
		temp1_node.setviewy(y);
	}

	// Move Selected Edge
	if ((gc.status() == 3) && (selectedge == true))
	{
		double lengthx = (double) (temp1_edge.node2().viewx() - temp1_edge.node1().viewx());
		double lengthy = (double) (temp1_edge.node2().viewy() - temp1_edge.node1().viewy());

		int dx2 = (int) (lengthx*(1.0-gamma_));
		int dx1 = (int) (-lengthx*(gamma_));
		int dy2 = (int) (lengthy*(1.0-gamma_));
		int dy1 = (int) (-lengthy*(gamma_));

		temp1_edge.node2().setviewx(x+dx2);
		temp1_edge.node1().setviewx(x+dx1);
		temp1_edge.node2().setviewy(y+dy2);
		temp1_edge.node1().setviewy(y+dy1);	
	}
	repaint();
	return(true);
    }

    public boolean mouseUp(Event e,int x,int y)
    {
	// End Rotation sequence
	if (gc.status() == 0) 
		graph.calculateView();

	// Set final position of new Node
	if ((gc.status() == 1) && (addnode == true))
	{
		temp1_node.setviewx(x);
		temp1_node.setviewy(y);
		double tx = ((double) x - (SCREEN_DIMENSION/2.0))/graph.viewfactor();
		double ty = ((double) y - (SCREEN_DIMENSION/2.0))/graph.viewfactor();
		graph.view().setNodePosition(temp1_node, tx, ty);
		temp1_node.setUnselectColor();
		addnode = false;
	}	

	// Set in New Edge (if release of mouse on a second node)
	if (gc.status()==2) 
	{
		if (filled == true) 
		{
			filled = false;
			graph.tempedge(0,0,0,0,false);
			Node temp2_node = graph.selectNode(x,y);
			if ((temp2_node == null) || (temp2_node == temp1_node)) {
				repaint();
				return(true);
			}
			graph.addEdge(temp1_node,temp2_node);
		}
	}

	// Set final position of Selected Node
	if ((gc.status() == 3) && (selectnode==true)) 
	{
		temp1_node.setviewx(x);
		temp1_node.setviewy(y);
		double tx = ((double) x - (SCREEN_DIMENSION/2.0))/graph.viewfactor();
		double ty = ((double) y - (SCREEN_DIMENSION/2.0))/graph.viewfactor();
		graph.view().setNodePosition(temp1_node, tx, ty);
		temp1_node.setUnselectColor();	
		selectnode = false;
	}

	// Set final position of Selected Edge
	if ((gc.status() == 3) && (selectedge == true))
	{
		double lengthx = (double) (temp1_edge.node2().viewx() - temp1_edge.node1().viewx());
		double lengthy = (double) (temp1_edge.node2().viewy() - temp1_edge.node1().viewy());

		int dx2 = (int) (lengthx*(1.0-gamma_));
		int dx1 = (int) (-lengthx*(gamma_));
		int dy2 = (int) (lengthy*(1.0-gamma_));
		int dy1 = (int) (-lengthy*(gamma_));

		temp1_edge.node2().setviewx(x+dx2);
		temp1_edge.node1().setviewx(x+dx1);
		temp1_edge.node2().setviewy(y+dy2);
		temp1_edge.node1().setviewy(y+dy1);	

		double tx1 = ((double) (x+dx1) - SCREEN_DIMENSION/2.0)/graph.viewfactor();
		double tx2 = ((double) (x+dx2) - SCREEN_DIMENSION/2.0)/graph.viewfactor();
		double ty1 = ((double) (y+dy1) - SCREEN_DIMENSION/2.0)/graph.viewfactor();
		double ty2 = ((double) (y+dy2) - SCREEN_DIMENSION/2.0)/graph.viewfactor();

		graph.view().setNodePosition(temp1_edge.node1(), tx1,ty1);
		graph.view().setNodePosition(temp1_edge.node2(), tx2,ty2);
		temp1_edge.setUnselected();
		selectedge = false;
	}
	repaint();

	// Resume animation thread
	if (gc.animate() == true) {
		animatorThread.resume();
	}

	return(true);
    }
}
