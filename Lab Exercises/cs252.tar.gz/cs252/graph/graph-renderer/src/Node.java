/*
 *  Node - node object 
 *  4/14/96 
 *  by Daniel Spirn 
 *
 */
package graphrender;

import java.awt.*;
import java.applet.*;

class Node extends Object
{
    // Universal Coordinates
    double x_, y_, z_;

    // Transformed Coordinates (relative to the viewing angle)
    double tx_, ty_, tz_;

    // X, Y in the viewing port (integer translated)
    double viewx_, viewy_;

    // Delta x, y, z for force/velocity vector calculations
    double changex_, changey_, changez_;

    // Whether or not the node is locked
    boolean locked = false;

    // Default color
    Color nodecolor = new Color(12,54,254);

    Node(double x, double y, double z)
    { 
	x_ = x;
	y_ = y;
	z_ = z;
    }

    Node(double x, double y, double z, int viewu, int viewv)
    { 
	x_ = x;
	y_ = y;
	z_ = z;
	viewx_ = viewu;
	viewy_ = viewv;
    }

    Node(Node oldnode)
    { 
	x_ = oldnode.x();
	y_ = oldnode.y();
	z_ = oldnode.z();
	viewx_ = oldnode.viewx();
	viewy_ = oldnode.viewy();
    }

    public Node copy()
    {
	Node temp = new Node(x_, y_, z_);
	temp.setviewx(viewx_);
	temp.setviewy(viewy_);
	return(temp);
    } 

    // Draws Node to the graphic with radius vcolor
    //
    public Graphics draw(int vcolor, Graphics g)
    {
	g.setColor(nodecolor);
	g.fillOval(((int) viewx_)-(4+vcolor),((int) viewy_)-(4+vcolor),7+2*vcolor,7+2*vcolor);
	return g;
    }
	
    private Color basicColor() {
	return new Color(12,54,254);
    }

    private Color selectColor() {
	return new Color(102,129,58);
    }

    private Color lockedColor() {
	return new Color(199,21,133);
    }

    public void setchangex(double x)
    {
	changex_ = x;
	return;
    } 

    public void setchangey(double y)
    {
	changey_ = y;
	return;
    } 

    public void setchangez(double z)
    {
	changez_ = z;
	return;
    } 

    public void settx(double x)
    {
	tx_ = x;
	return;
    } 

    public void setty(double y)
    {
	ty_ = y;
	return;
    } 

    public void settz(double z)
    {
	tz_ = z;
	return;
    } 

    public void setviewx(double x)
    {
	viewx_ = x;
	return;
    } 

    public void setviewy(double y)
    {
	viewy_ = y;
	return;
    } 

    public void setx(double x)
    {
	x_ = x;
	return;
    } 

    public void sety(double y)
    {
	y_ = y;
	return;
    } 

    public void setz(double z)
    {
	z_ = z;
	return;
    } 

    public double changex()
    {
	return changex_;
    } 

    public double changey()
    {
	return changey_;
    } 

    public double changez()
    {
	return changez_;
    } 

    public double tx()
    {
	return tx_;
    } 

    public double ty()
    {
	return ty_;
    } 

    public double tz()
    {
	return tz_;
    } 

    public double x()
    {
	return x_;
    } 

    public double y()
    {
	return y_;
    } 

    public double z()
    {
	return z_;
    } 

    public double viewx()
    {
	return viewx_;
    } 

    public double viewy()
    {
	return viewy_;
    } 
    public boolean isLocked(){
	return locked;
    }

    public void lock(){
	locked = true;
	nodecolor = lockedColor();
    }

    public void unlock(){
	locked = false;
	nodecolor = basicColor();
    }

    public void setSelectColor() {
	nodecolor = selectColor();
    }

    public void setUnselectColor() {
	if (locked == false)
		nodecolor = basicColor();
	else
	 	nodecolor = lockedColor();
    }

    public Color getColor()
    {	
	return nodecolor; 
    }			

    public void setColor(Color newcol)
    {
	nodecolor = newcol;
	return;
    }

}

