/*
 * @(#)TGNodeCommand.java 1.0 1/13/96 Michael John Radwin
 */
 
package mjr.pstree;

import mjr.treegraphics.TreeGraphics;
import leda.*;
 
public class TGNodeCommand extends PSTCommand {
    TreeGraphics tg;
    
    public TGNodeCommand(TreeGraphics tg)
    {
	this.tg = tg;
    }
    
    public Object _execute(ps_item p)
    {
	String label = "(" + String.valueOf(p.split_value_x()) +
	    "," + String.valueOf(p.split_value_y()) +
	    "):(" + String.valueOf(p.x_value()) +
	    "," + String.valueOf(p.y_value()) + ")";
	
//	System.err.println("node: " + label);
	tg.DrawInternal(label, "red");
	return null;
    }
    public static void mjr() { ; }
}
