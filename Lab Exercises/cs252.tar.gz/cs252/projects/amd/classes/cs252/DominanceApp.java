package cs252;

import java.awt.*;
import java.applet.*;

public class DominanceApp extends Applet {
    public void init() {
        setLayout(new FlowLayout());
        DominanceGraph area = new DominanceGraph(this);
    }
}
