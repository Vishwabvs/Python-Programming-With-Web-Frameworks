import java.awt.*;
import java.util.*; 
import java.lang.*; 

class Amination extends Thread {
   static final int INFTY = ClosestPairDiagram.INFTY; 
   static final int RIGHT = ClosestPairDiagram.RIGHT; 
   static final int LEFT = ClosestPairDiagram.LEFT; 
   static final int PRIOR = ClosestPairDiagram.PRIOR; 
   static final int POST = ClosestPairDiagram.POST; 
   static final Color queryBoxColor = ClosestPairDiagram.queryBoxColor; 

   private int R;     
   private ClosestPairDiagram controller; 
   private FunctionSet tools; 
   private DrawingArea drawArea; 
   private ClosestPair cp; 
   private Color sweepLineColor = ClosestPairDiagram.sweepLineColor; 

   // An important Double-buffering technique needs an offcreen Image object
   // cf. <Java In A Nutshell> p.151-155
   Image offscreen; 
   int imagewidth, imageheight; 

   Amination(ClosestPairDiagram c) {
      controller = c; 
      tools = c.tools; 
      drawArea = c.getDrawingArea(); 
      cp = c.getClosestPair(); 
      R = controller.NODERADIUS; 
   } 

   public void run() {
      int r = cp.getTail().next().getKey().getX(); 
      //Make sure the offscreen image is created and is the right size
      Dimension d = drawArea.size(); 
      if((offscreen==null) ||
        ((imagewidth!=d.width)||(imageheight!=d.height))) {
         offscreen = controller.createImage(d.width, d.height); 
         imagewidth = d.width; 
         imageheight = d.height; 
      } 
      if(r < INFTY) 
         demo(cp); 
   }
  
   void demo(ClosestPair cp) {
      Vector fiber;
      QueryNode head = cp.getHead(), tail = cp.getTail(); 
      BRTree nodeTree, bandTree; 
      double min_distance;
      int line = controller.getLinePosition(); 
      // The x coordinate of the next node. 
      int rightTarget = tail.next().getKey().getX(); 
      controller.setLinePosition(rightTarget); 

      fiber = cp.fiberAt(tail.next()); 
      nodeTree = cp.getNodeTree(); 
      bandTree = cp.getBandTree(); 
      QueryNode fiberHead = (QueryNode) fiber.firstElement(); 
      while(tail.next().getKey().getX()==rightTarget) {
         // Update the line.
         int old_line = line; 
         line = rightTarget; 
         min_distance = tail.getMinDistance(); 

         // Update the tail; 
         tail=tail.next();
         cp.setTail(tail); 

         tools.drawSweep(cp, old_line, line, min_distance);  
         double old_min = min_distance; 
         tools.setBandWidth(min_distance); 
         tools.drawClosestPair(drawArea.getGraphics(), cp, Color.green); 
         tail.setClosestPair(tail.prev().getClosestPair()); 
         tail.setMinDistance(min_distance); 

         // Update the tree of nodes which fall into the band 
         BRNode band_tail_=new BRNode(tail.getKey().exchange());
         bandTree.treeInsert(band_tail_); 
         while(head.getKey().getX()<rightTarget-min_distance) {
            Key key_ = head.getKey().exchange(); 
            bandTree.treeDelete(bandTree.treeSearch(key_));
            Key k = head.getKey(); 
            DrawingMethods.drawCircleAt(drawArea, k.getX(), k.getY(), 
              Color.blue); 
            if(head == cp.getClosestPairFirstNode())
               DrawingMethods.drawCircleAt(drawArea, k.getX(), k.getY(), 
                 Color.green); 
            if(head == cp.getClosestPairSecondNode())
               DrawingMethods.drawCircleAt(drawArea, k.getX(), k.getY(), 
                 Color.green); 
            head=head.next();
         }
         cp.setHead(head); 
         rest(300); 
  
         //Find the nodes in the band that lie in the "querry box".
         int y_coord_ = tail.getKey().getY();
         double low = y_coord_- min_distance;
         double up = y_coord_+ min_distance;
         Vector b_section_=bandTree.nodesBetween(low, up);

         //Draw the box
         flashBox(tail.getKey(), min_distance, b_section_);
         rest(300); 
         //Flash all the nodes in the box.
         flash(tail.getKey(), min_distance, b_section_); 
         rest(300); 
                                         
         int x_tail_ = tail.getKey().getX();
         int y_tail_ = tail.getKey().getY();
         for(int i=0; i<b_section_.size(); i++) {
            BRNode b_node_ = (BRNode)b_section_.elementAt(i); 
            Key q_key_ = b_node_.getKey().exchange();
            QueryNode q_node_ = (QueryNode)nodeTree.treeSearch(q_key_);
            double td_=min_distance; 
            if(!q_node_.getKey().equals(tail.getKey())) {
               //Flash the two nodes;
               flash(tail, q_node_, old_min, b_section_); 
               rest(200); 
               int x_node_ = q_node_.getKey().getX(); 
               int y_node_=q_node_.getKey().getY();
               double dx_ = x_node_-x_tail_;
               double dy_ = y_node_-y_tail_;
               td_=Math.sqrt(dx_*dx_ + dy_*dy_);
                    
               QueryNode n = cp.getClosestPairFirstNode();
               Key k = n.getKey(); 
               if(k.lessThan(head.getKey())) {
                  DrawingMethods.drawCircleAt(drawArea, k.getX(), 
                    k.getY(), Color.blue); 
               } else {
                  DrawingMethods.drawCircleAt(drawArea, k.getX(), 
                    k.getY(), Color.black); 
               } 
               n = cp.getClosestPairSecondNode();
               k = n.getKey(); 
               if(k.lessThan(head.getKey())) {
                  DrawingMethods.drawCircleAt(drawArea, k.getX(), 
                    k.getY(), Color.blue); 
               } else {
                  DrawingMethods.drawCircleAt(drawArea, k.getX(), 
                    k.getY(), Color.black); 
               } 
               // if the distance is really smaller, saved d and the nodes
               // in fiber_node
               if(td_<min_distance) {
                  min_distance = td_;
                  //System.out.println("min_distance = "+min_distance); 
                  tail.setMinDistance(td_);
                  Vector data_=new Vector();
                  data_.addElement(q_node_);
                  data_.addElement(tail);
                  tail.setClosestPair(data_);
               }
               cp.upDateClosestPair(); 
               tools.drawClosestPair(drawArea, cp, Color.green); 
               controller.showMinD(); 
               rest(150); 
            }   
         }   
         if(b_section_.size()<1) {
            cp.upDateClosestPair(); 
            tools.drawClosestPair(drawArea, cp, Color.green); 
            controller.showMinD(); 
         }                
         //Directly remove the box without animation 
         drawBox(tail.getKey(), old_min, b_section_, Color.yellow, false,
                 false); 
         rest(150); 
         DrawingMethods.drawSweepLine(drawArea, line, Color.red);  
         rest(100); 
      }   
   } 
   
   void rest(int t)  {
      try Thread.sleep(t); 
      catch(InterruptedException e); 
   } 
  
   //Draw a box counterclockwise with k as the mid point of the right 
   //side, height 2d and width d  
   void conclockDrawBox(Key k, double d, Color c) {
      int x = k.getX(); 
      int y = k.getY(); 
      int up, below, left; 
      int w = drawArea.size().width, h = drawArea.size().height; 
      int bw = (int)d; 

      if(x<0||x>w) return; 
      if(y<0||y>h) return; 
      if(y+1<d) {
         up = 0; 
      } else {
         up = y-bw+1; 
      }
      if(y+d>h-1) {
         below = h-1; 
      } else {
         below = y+bw; 
      }
      if(x+1<d) {
         left = 0;
      } else {
         left = x-bw+1; 
      }         

      w = x - left+1; 
      h = below - up+1; 

      aminatedDrawLine(x, y, x, up, c, DrawingMethods.COUNTER, 
                       x-d, x, 0, h, Color.black); 
      aminatedDrawLine(x, up, left, up, c, DrawingMethods.COUNTER,
                       x-d, x, 0, h, Color.black); 
      aminatedDrawLine(left, up, left, below, c, DrawingMethods.COUNTER,
                       x-d, x, 0, h, Color.black); 
      aminatedDrawLine(left, below, x, below, c, DrawingMethods.COUNTER,
                       x-d, x, 0, h, Color.black); 
      aminatedDrawLine(x, below, x, y, c, DrawingMethods.COUNTER,
                       x-d, x, 0, h, Color.black); 
   }
   
   //Draw a box counterclockwise with k as the mid point of the right 
   //side, height 2d and width d  
   void clockDrawBox(Key k, double d, Color c) { 
      int x = k.getX(); 
      int y = k.getY(); 
      int up, below, left; 
      int w = drawArea.size().width, h = drawArea.size().height; 
      int bw = (int)d; 

      if(x<0||x>w) return; 
      if(y<0||y>h) return; 
      if(y+1<d) {
         up = 0; 
      } else {
         up = y-bw+1; 
      }
      if(y+d>h-1) {
         below = h-1; 
      } else {
         below = y+bw; 
      }
      if(x+1<d) {
         left = 0;
      } else {
         left = x-bw+1; 
      }         

      w = x - left+1; 
      h = below - up+1; 
      
      // objects other than this can also call getBackground() method!  
      aminatedDrawLine(x, y, x, below, c, DrawingMethods.CLOCK,
                       x-d, x, 0, h, Color.black); 
      aminatedDrawLine(x, below, left, below, c, DrawingMethods.CLOCK,
                       x-d, x, 0, h, Color.black); 
      aminatedDrawLine(left, below, left, up, c, DrawingMethods.CLOCK,
                       x-d, x, 0, h, Color.black); 
      aminatedDrawLine(left, up, x, up, c, DrawingMethods.CLOCK,
                       x-d, x, 0, h, Color.black); 
      aminatedDrawLine(x, up, x, y, c, DrawingMethods.CLOCK,
                       x-d, x, 0, h, Color.black); 
   }

   // Draw the line and fix the adjacent node's color, with nodes in 
   // the regine (a_1, a_2)x(b_1, b_2) having special color nodecolor 
   void aminatedDrawLine(int x_1, int y_1, int x_2, int y_2, 
                Color linecolor, int direction, 
                double a_1, double a_2, double b_1, double b_2, 
                Color nodecolor) {
      int numsteps = 10; 
      int dx, dy; 
      int Dx, Dy; 

      if(x_1<=x_2) {
         Dx = x_2 - x_1; 
         dx = Dx/numsteps; 
         if(dx < 5) dx = 5; 
      } else {
         Dx = x_1 - x_2; 
         dx = Dx/numsteps; 
         if(dx < 5) dx = 5; 
         dx = -dx; 
      }

      if(y_1<=y_2) {
         Dy = y_2 - y_1; 
         dy = Dy/numsteps; 
         if(dy < 5) dy = 5; 
      } else {
         Dy = y_1 - y_2; 
         dy = Dy/numsteps; 
         if(dy < 5) dy = 5; 
         dy = -dy; 
      }
 
      int x = x_1; 
      int y = y_1; 
      while(Dx!=0 || Dy!=0) {
         if(dx<0) {
            if(Dx< -2*dx) dx = -Dx; 
            Dx = Dx+dx; 
         } else {
            if(Dx < 2*dx) dx = Dx; 
            Dx = Dx - dx; 
         } 
         if(dy<0) {
            if(Dy< -2*dy) dy = -Dy; 
            Dy = Dy+dy; 
         } else {
            if(Dy < 2*dy) dy = Dy; 
            Dy = Dy - dy; 
         } 

         tools.drawLine(cp, x, y, x+dx, y+dy, linecolor, direction, 
                        a_1, a_2, b_1, b_2, nodecolor); 
         x = x+dx;  y = y+dy; 
         rest(100);
      }
   }
   
   // Only flash the box
   void flashBox(Key k, double d, Vector bandv) {
      //for(int i=0; i<2; i++) {
      //   drawBox(k, d, bandv, queryBoxColor, false, true); 
      //   rest(200); 
      //   drawBox(k, d, bandv, queryBoxColor, false, false); 
      //   rest(200); 
      //} 
      drawBox(k, d, bandv, queryBoxColor, false, true); 
   }  

   // Flash all the nodes in the box
   void flash(Key k, double d, Vector bandv) {
      for(int i=0; i<3; i++) {
         drawBox(k, d, bandv, queryBoxColor, true, true); 
         rest(200); 
         drawBox(k, d, bandv, queryBoxColor, false, true); 
         rest(200); 
      } 
   }  
  
   // Only flash two specified nodes. 
   void flash(QueryNode a, QueryNode b, double d, Vector bandv) {
      if(a==null) return; 
      if(b==null) return; 
      Key k = a.getKey(); 
      for(int i=0; i<3; i++) {
         drawBox(k, d, bandv, a, b, queryBoxColor, false, true, true); 
         rest(200); 
         drawBox(k, d, bandv, a, b, queryBoxColor, false, false, true); 
         rest(200); 
      } 
   }

   void drawBox(Key k, double d, Vector bandv, Color color, 
                boolean all, boolean drawbox) {
      QueryNode a = null; 
      QueryNode b = null; 
      drawBox(k, d, bandv, a, b, color, all, false, drawbox); 
   }

   // If all is true, turn all nodes in the box red.  If pair is 
   // true, turn the specified pair into red.  The boundary of the 
   // box is painted with the specified color. 
   // d is the width of the box.  The box has height 2d
   void drawBox(Key k, double d, 
                Vector bandv, QueryNode n1, QueryNode n2, 
                Color color, boolean all, boolean pair, boolean drawbox) {
      BRTree nodeTree = cp.getNodeTree(); 
      int x = k.getX(); 
      int y = k.getY(); 
      int up, below, left; 
      int w = drawArea.size().width, h = drawArea.size().height; 
      int bw = (int)d; 

      if(x<0||x>w) return; 
      if(y<0||y>h) return; 
      if(y+1<bw) {
         up = 0; 
      } else {
         up = y-bw+1; 
      }
      if(y+bw>h-1) {
         below = h-1; 
      } else {
         below = y+bw; 
      }
      if(x+1<bw) {
         left = 0;
      } else {
         left = x-bw+1; 
      }         

      w = x - left+1; 
      h = below - up+1; 
      
      DrawingMethods.drawBackground(offscreen, drawArea, 
             left-2*R, up-2*R, w+4*R, h+4*R); 
      DrawingMethods.drawQueryBand(offscreen, x, w, Color.yellow, 
             drawArea, left-2*R, up-2*R, w+4*R, h+4*R); 
      if(controller.getGridChoice()) {
         tools.drawGrid(offscreen.getGraphics(), drawArea.size().width,
                        drawArea.size().height, Color.black); 
      } 
      DrawingMethods.drawSweepLine(offscreen, x, sweepLineColor, drawArea, 
             left-2*R, up-2*R, w+4*R, h+4*R); 
      if(drawbox) {
         DrawingMethods.drawLine(offscreen, x, y, x, up, color,  
             DrawingMethods.COUNTER, left-2*R, up-2*R, w+4*R, h+4*R); 
         DrawingMethods.drawLine(offscreen, x, up, left, up, color,  
             DrawingMethods.COUNTER, left-2*R, up-2*R, w+4*R, h+4*R); 
         DrawingMethods.drawLine(offscreen, left, up, left, below, color,  
             DrawingMethods.COUNTER, left-2*R, up-2*R, w+4*R, h+4*R); 
         DrawingMethods.drawLine(offscreen, left, below, x, below, color,  
             DrawingMethods.COUNTER, left-2*R, up-2*R, w+4*R, h+4*R); 
         DrawingMethods.drawLine(offscreen, x, below, x, y, color,  
             DrawingMethods.COUNTER, left-2*R, up-2*R, w+4*R, h+4*R); 
      }

      Vector nv = nodeTree.nodesBetween(left-3*R, left+w+5*R);
      if(nv!=null) {
         for(int i=0; i<nv.size(); i++) {
            QueryNode n = (QueryNode)nv.elementAt(i); 
            Key key = n.getKey(); 
            int cx = key.getX(); 
            int cy = key.getY(); 
            if(n == cp.getClosestPairFirstNode()) {
               DrawingMethods.drawCircleAt(offscreen, cx, cy, Color.green); 
            } else if(n == cp.getClosestPairSecondNode()) {
               DrawingMethods.drawCircleAt(offscreen, cx, cy, Color.green); 
            } else if(n == cp.getTail()) { 
               DrawingMethods.drawCircleAt(offscreen, cx, cy, 
                    FunctionSet.tailColor); 
            } else if(cx>=x-d&&cx<=x) {
               DrawingMethods.drawCircleAt(offscreen, cx, cy, Color.black); 
            } else {
               DrawingMethods.drawCircleAt(offscreen, cx, cy, Color.blue); 
            } 
         }
      }
      if(all) { 
         if(bandv!=null) {
            for(int i=0; i<bandv.size(); i++) {
               BRNode n = (BRNode)bandv.elementAt(i); 
               Key key = n.getKey().exchange(); 
               int cx = key.getX(); 
               int cy = key.getY(); 
               DrawingMethods.drawCircleAt(offscreen, cx, cy, Color.red); 
            }
         }
      }    
      if(pair) {
         if(n1!=null&&n2!=null&&
            n1.getKey().getX()<INFTY&&n2.getKey().getX()<INFTY&&
            n1.getKey().getX()>-INFTY&&n2.getKey().getX()>-INFTY) {
            Key key = n1.getKey();
            int x_1 = key.getX(); 
            int y_1 = key.getY(); 
            key = n2.getKey(); 
            int x_2 = key.getX(); 
            int y_2 = key.getY(); 
            DrawingMethods.drawLine(offscreen, x_1, y_1, x_2, y_2, 
                                    Color.red);
            DrawingMethods.drawCircleAt(offscreen, x_1, y_1, Color.red); 
            DrawingMethods.drawCircleAt(offscreen, x_2, y_2, Color.red); 
         }
      } 
      Graphics g=drawArea.getGraphics(); 
      g.clipRect(left-2*R, up-2*R, w+4*R, h+4*R); 
      g.drawImage(offscreen, 0, 0, drawArea); 
   }

   void movearrow(QueryNode s, QueryNode e, QueryNode o) { 
   } 
   
   void arrow(QueryNode a, QueryNode b) { 
   } 
}
