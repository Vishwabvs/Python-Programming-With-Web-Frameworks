/*
 * RectangleNode.java
 *
 * Description:
 *    This class contains the methods and variables for the bounding boxes.
 */
import java.awt.Graphics;
import java.awt.Color;

class RectangleNode
{
     int xPosition;        // x coordinate of the bounding box
     int yPosition;        // y coordinate of the bounding box
     int zPosition;        // z coordiante of the bounding box
     int colorUnit;        // red component of the color of the bounding box
     int height;           // height of the bounding box
     int width;            // width of the bounding box
     int rectID;           // unique identifier of the bounding box
     String rectIDString;  // string representation of the identifier

     // cosntructor of the bounding box
     RectangleNode(int x, int y, int ID)
     {
        Integer tempInt = new Integer(ID);

        xPosition = x;
        yPosition = y;
        zPosition = 0;
        colorUnit = 150;
        rectID = ID;
        rectIDString = new String(tempInt.toString());
     }

     // set the position of the bounding box
     public void setXYZ(int x, int y, int z)
     {
        xPosition = x;
        yPosition = y;
        zPosition = z;
     }

     // return the identifier of the bounding box
     public int getID()
     {
        return rectID;
     }

     // return the string identifier of the bounding box
     public String getRectIDString()
     {
        return rectIDString;
     }

     // set the height and width
     public void setHeightWidth(int x, int y)
     {
        if (x > xPosition)
        {
           width = x - xPosition;
        }
        else
        {
           width = xPosition - x;
           xPosition = x;
        }
        if (y > yPosition)
        {
           height = y - yPosition;
        }
        else
        {
           height = yPosition - y;
           yPosition = y;
        }
     }

     // reposition the bounding box, the color gets darker as it moves towards the
     // viewer, gets lighter as it moves away from the viewer
     public void reposition(int x, int y, int z)
     {
        xPosition = xPosition + width / 2;
        yPosition = yPosition + height / 2;
        width = width + (4 * z);
        height = height + (4 * z);
        xPosition = xPosition + (4 * x);
        yPosition = yPosition - (4 * y);
        zPosition = zPosition + (4 * z);
        xPosition = xPosition - width / 2;
        yPosition = yPosition - height / 2;
        if (z < 0)
        {
           colorUnit = colorUnit + 5;
           if (colorUnit > 200)
           {
              colorUnit = 200;
           }
        }
        else
        {
           colorUnit = colorUnit - 5;
           if (colorUnit < 0)
           {
              colorUnit = 0;
           }
        }
     }

     // return the x ccordinate
     public int getXPosition()
     {
        return xPosition;
     }

     // return the y coordinate
     public int getYPosition()
     {
        return yPosition;
     }

     // return the z coordinate
     public int getZPosition()
     {
        return zPosition;
     }

     // return the width
     public int getWidth()
     {
        return width;
     }

     // return the height
     public int getHeight()
     {
        return height;
     }

     // return the red component of the color
     public int getColorUnit()
     {
        return colorUnit;
     }

     // draw the bounding box at the current position with the desired color
     public void drawRectangleNode(Graphics g, boolean useObjectColor)
     {
        Color savedColor = g.getColor();
        if (useObjectColor)
        {
           g.setColor(new Color(colorUnit, colorUnit, colorUnit));
        }
        g.drawRect(xPosition, yPosition, width, height);
        g.setColor(savedColor);
     }

     // determine if the specified location is contained within the bounding box
     public boolean contains(int x, int y)
     {
        boolean isContainedIn = false;

        if ((x >= xPosition) && (x <= xPosition + width)  && (y >= yPosition) &&
            (y <= yPosition + height))
        {
           isContainedIn = true;
        }
        return isContainedIn;
     }
}
