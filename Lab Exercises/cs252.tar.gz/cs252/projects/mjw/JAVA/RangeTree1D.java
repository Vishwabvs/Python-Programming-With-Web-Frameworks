import java.awt.*;
import geometry.*;
import Tree;
import AbstractPrototypeFactory;
import java.io.StreamTokenizer;
import TreeAccessible;

import VCR;

/**
 * Implements an applet that enables the user to input a point set
 * visualize the range tree resulting from the entered points
 * and perform range search queries.
 * @author 	Mike Walczak (mjw@cs.brown.edu)
 * @version 	
 */

 
public class RangeTree1D extends RangeTree {

	protected Color		interval_color_, query_range_color_;  
	protected GeometryLine  interval_;
        protected int query_range_thickness_;

/****************************************************************/
/*                                                              */
/* Function Name: init                                          */
/* Parameters:                                                  */
/* Returns:                                                     */
/* Effects:  Create an empty input point set and a Range Tree   */  
/*           graph.                                             */
/*                                                              */
/****************************************************************/

   /**
    * Create an empty input point set and a Range Tree graph.
    */

   public void init() {
	super.init();
	
	interval_color_ = attribute ("interval_color", Color.blue);
	query_range_color_ = attribute("query_range_color", Color.cyan);
        query_range_thickness_ = attribute("query_range_thickness",7);
	int x0 = user_input_area_.minX();
	int y0 = user_input_area_.minY()+ (user_input_area_.maxY() - user_input_area_.minY())/2;
	int x1 = user_input_area_.maxX();
	int y1 = y0;
	int width = 2;
	interval_ = new GeometryLine(x0, y0, x1, y1, width, interval_color_); 
   }


   public GeometryPoint addPoint (int x, int y) {
      Point pt = interval_.getFrom();
      return super.addPoint (x, pt.y);
   }

   public GeometryPoint findPoint (int x, int y)
   {
      Point pt = interval_.getFrom();
      return (ptsetInput_.findPoint (x, pt.y, imRedDot.getWidth(this), imRedDot.getHeight(this)));
   }

   public void movePoint (GeometryPoint p, int x, int y) {
      Point pt = interval_.getFrom();
      super.movePoint(p, x, pt.y);
   }

   public void moveSelectedPts(int offx, int offy) {
	super.moveSelectedPts(offx, 0);  // move only in x
   }

    public void drawPointSet(Graphics g)
    {
	interval_.draw(g);
	drawQueryRange(g);
	super.drawPointSet(g);
    }



public void drawQueryRange(Graphics g)
{
      if (bBox.minX() != bBox.maxX())
      {
            Point pt = interval_.getFrom();
            GeometryLine.draw(g, bBox.minX(), pt.y, bBox.maxX(), pt.y,
                                  query_range_thickness_, query_range_color_); 
      }
}

public void gridSpacingChanged(int old_grid_spacing,
			       int new_grid_spacing)
{
  GeometryPoint pt;
  int x, y, num = ptsetInput_.size();
  for (int i=0; i<num; i++)
    {
      pt = ptsetInput_.elementAt(i);             
      int ratio_x = pt.x / old_grid_spacing;      
      pt.x = ratio_x * new_grid_spacing;
    }
  recalc();
}


public boolean mouseDown(Event evt, int x, int y)
{
	if (user_input_area_.inside(x,y))
	{
		Point pt = interval_.getFrom();
		y = pt.y;
		if(evt.metaDown())
		{
			unSelectPts();
			resetSelectionRectangle(x,y);
		}
	}
	return super.mouseDown(evt, x, y);
}



/** Adds a point upon a mouseUp.
 */
public boolean mouseUp(Event evt, int x, int y)
{
	if (user_input_area_.inside(x,y))
	{
		Point pt = interval_.getFrom();
		return super.mouseUp(evt, x, pt.y);
	}
	return false;
}

public boolean mouseDrag(Event evt, int x, int y)
{
	// actually we should check all selected points
	if (user_input_area_.inside(x,y))
	{
		Point pt = interval_.getFrom();
		return super.mouseDrag(evt, x, pt.y);
	}
	return false;
}

//public void sendRangeQuery(int x0, int y0, int x1, int y1)
//{
//	super.sendRangeQuery(x0, y0-10, x1, y1+10);
//}


  public void selectBoxPts()
   {
	super.selectBoxPts();

	Point pt = interval_.getFrom();
	
	int x0=bBox.minX(), y0=pt.y-10;
	int x1=bBox.maxX(), y1=pt.y+10;

	// send the query to the server
	sendRangeQuery(x0, y0, x1, y1);
   }


};



