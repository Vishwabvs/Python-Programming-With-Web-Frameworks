import TreeAccessible;
import java.lang.*;
import java.io.StreamTokenizer;
import geometry.*;
import ReversibleCommand;
import Prototype;
import java.awt.Image;
import java.awt.Color;
import java.awt.image.*;
import RangeSearchAnimationCommand;
import GPoint;

/****************************************************************/
/* CLASS NAME :  EventVisitPointCommand                         */
/*                                                              */
/*                                                              */
/*                                                              */
/*                                                              */
/*                                                              */
/*                                                              */
/****************************************************************/


public class EventVisitPointCommand extends RangeSearchAnimationCommand  {

	public EventVisitPointCommand(	Image		im,
					GeometryPanel	p,
					TreeAccessible	treeApp,
					Box		input_area)
	{
		super(im, p, treeApp, input_area);
		range_color_ = Color.blue;
	}

	public EventVisitPointCommand(	Image		im,
					GeometryPanel	p,
					TreeAccessible	treeApp,
					Box		input_area,
					GPoint		 pt)
	{
		super(im, p, treeApp, input_area);
		setPoint(pt);
		range_color_ = Color.blue;
	}

	public void execute()
	{
		if ((point_ != null) && (node_ != null))
		{
			point_.setQuerySelected(true);
			//drawRange(node_.getBegin(), -1, node_.getEnd(), range_color_);
			panel_.repaint();
			reversible_ = true;
		}
		else reversible_ = false;
	}

	public void undo()
	{
		if (reversible_)
		{
			point_.setQuerySelected(false);
			panel_.repaint();
		}
	}


	public Object clone()
	{
		EventVisitPointCommand c = new
			EventVisitPointCommand( image_,
						panel_,
						tree_app_,
						user_input_bounds_,
						point_);
		c.setBegin(begin_);
		c.setMedian(median_);
		c.setEnd(end_);
		return c;
	}

	public Object clone(StreamTokenizer st)
	{
		// get point x,y
		TreeNode n= new TreeNode((GeometryStreamTokenizer)st);
		begin_ = ((GeometryStreamTokenizer)st).nextInt();
		median_ = ((GeometryStreamTokenizer)st).nextInt();
		end_ = ((GeometryStreamTokenizer)st).nextInt();
		Tree tree = tree_app_.getTree();
		if (tree == null)  return null;

		n = tree.findNode(n.getID());
		GeometryPoint pt = new GeometryPoint((GeometryStreamTokenizer)st);
		PointSet point_set = tree_app_.getPointSet();

		GPoint p = (GPoint) point_set.findPoint(pt.x, pt.y, 5, 5);
					// we don't width and height
					// know the actual values 
					// at this point
		EventVisitPointCommand c = new
			EventVisitPointCommand( image_,
						panel_,
						tree_app_,
						user_input_bounds_,
						p);
		c.setNode(n);
		c.setReversible(reversible_);
		c.setBegin(begin_);
		c.setMedian(median_);
		c.setEnd(end_);
		return c;
	}

	public String toString()
	{
		return new String("RTEVENTVISITPT");
	}

};
