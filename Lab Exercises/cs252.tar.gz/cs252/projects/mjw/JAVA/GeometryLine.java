import java.awt.*;
import java.util.*;
import java.io.*;
import java.awt.image.ImageObserver;
import geometry.*;
import Segment;


// I got the drawLine method off the web
// http://www.digitalfocus.com/digitalfocus/faq/VR.html#GR_35



/****************************************************************/
/* CLASS NAME :  GeometryLine                                   */
/*               This class allows setting thickness on lines   */
/*               (as far as I know, the awt does not allow you  */
/*                to do that just yet).                         */
/*                                                              */
/****************************************************************/





public class GeometryLine {
protected int startX_=0, startY_=0;
protected int endX_=0, endY_=0;
protected Color color_=Color.blue;
protected int thickness_=1;


public GeometryLine(int x0, int y0, int x1, int y1, int thickness)
{
	startX_ = x0;
	startY_ = y0;
	endX_   = x1;
	endY_   = y1;
	thickness_ = thickness;
}

public GeometryLine(int x0, int y0, int x1, int y1, int thickness, Color color)
{
	startX_ = x0;
	startY_ = y0;
	endX_   = x1;
	endY_   = y1;
	thickness_  = thickness;
	color_  = color;
}

public GeometryLine()
{
        startX_ = 0;
	startY_ = 0;
	endX_   = 0;
	endY_   = 0;
	thickness_  = 1;
}

public GeometryLine(Point pt1, Point pt2, int thickness)
{
        this(pt1.x,pt1.y,pt2.x,pt2.y,thickness); 
}

public GeometryLine(Point pt1, Point pt2, int thickness, Color color)
{
        startX_ = pt1.x;
	startY_ = pt1.y;
	endX_   = pt2.x;
	endY_   = pt2.y;
	thickness_  = thickness;
	color_ 	= color; 
}

public void setThickness(int w)
{
	thickness_ = w;
}

public int getThickness()
{
	return thickness_;
}

public void setFrom(int x, int y)
{
	startX_ = x;
	startY_ = y;
}

public void setFrom(Point pt)
{
        startX_ = pt.x;
	startY_ = pt.y;
}

public void setTo(int x, int y)
{
	endX_ = x;
	endY_ = y;
}

public void setTo(Point pt)
{
	endX_ = pt.x;
	endY_ = pt.y;
}

public Point getFrom()
{
	return new Point(startX_, startY_);
}

public Point getTo()
{
	return new Point(endX_, endY_);
}	

public void setColor(Color color)
{
	color_ = color;
}

public Color getColor()
{
	return color_;
}


public void moveByOffset (int offsetx, int offsety) 
{
        startX_ += offsetx;
	endX_   += offsetx;
	startY_ += offsety;
	endY_   += offsety;
}


public boolean equals(GeometryLine line)
{
	Point s = line.getFrom();
	Point e = line.getTo();

	return (s.x == startX_ && s.y == startY_ &&
		e.x == endX_   && e.y == endY_);
}



public void print (PrintStream out)
{
 // out.print("[(" + startX_ + ", " + startY_ + ")===");
 // out.print("(" + endX_ + ", " + endY_ + ")]");
 out.print("(" + startX_ + ", " + startY_ + ")");
 out.print("(" + endX_ + ", " + endY_ + ")");
}



public void draw(Graphics g)
{
	if (startX_ == endX_ && startY_==endY_)
		return;
	draw(g, startX_, startY_, endX_, endY_, thickness_, color_);
	
}


static public void draw(
   Graphics g, int startX, int startY, int endX, int endY, int wid, Color col)
       {
               // Make this reflect the current width and color...
               g.setColor(col);

               //
               // We draw a thick line by computing the four corners of an equivalent
               // diagonal rectangle, and filling it.

               //
               // Compute the corner points of the rectangle to fill
               //

               // The x and y deltas from the start to the end of the line...
               int dX = endX - startX;
               int dY = endY - startY;

               // The length of the line...
               double D = Math.sqrt(dX * dX + dY * dY);

               // The ratio of half the line thickness to the length of the line...
               double scale = (double)(wid) / (2 * D);

               // The x and y increments from an endpoint needed to create a rectangle...
               double ddx = -scale * (double)dY;
               double ddy = scale * (double)dX;
               if (ddx > 0) ddx += 0.5; else ddx -= 0.5;               // round off
               if (ddy > 0) ddy += 0.5; else ddy -= 0.5;               //  "
               int dx = (int)ddx;
               int dy = (int)ddy;

               // Now we can compute the corner points...

               int xPoints[] = new int[4];
               int yPoints[] = new int[4];

               xPoints[0] = startX + dx;
               yPoints[0] = startY + dy;

               xPoints[1] = startX - dx;
               yPoints[1] = startY - dy;

               xPoints[2] = endX - dx;
               yPoints[2] = endY - dy;

               xPoints[3] = endX + dx;
               yPoints[3] = endY + dy;

               // Fill the rectangle, effectively drawing a thick line
               g.fillPolygon(xPoints, yPoints, 4);
       }
		     
};
