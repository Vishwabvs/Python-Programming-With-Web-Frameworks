/** Brian Rogers
    cs252
    spring 1996
    Final Project */


/**                              ThreeDVector
    A 3 dimensional Vector to keep track of the x, y, and z coordinates of a
    point in 3 space.  Not much more explanation to give. */

public class ThreeDVector {

     int x_coord;
     int y_coord;
     int z_coord;
     
     public ThreeDVector () {
          x_coord = 0;
          y_coord = 0;
          x_coord = 0;
     }

     public ThreeDVector (int x, int y, int z) {
          x_coord = x;
          y_coord = y;
          z_coord = z;
     }

     public void setX (int x) {x_coord = x;}
     public void setY (int y) {y_coord = y;}
     public void setZ (int z) {z_coord = z;}

     public int xCoord () {return x_coord;}
     public int yCoord () {return y_coord;}
     public int zCoord () {return z_coord;}
}
