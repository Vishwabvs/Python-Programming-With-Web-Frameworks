/*
 *  GRAnimator - calculates the changes in the graph during animations
 * 		 depending on the convergence method 
 *  4/14/96 
 *  by Daniel Spirn 
 *
 */
package graphrender;

import java.awt.*;
import java.applet.*;
import java.util.*;

public class GRAnimator
{
    // Spring constant
    //
    final static double  	default_spring_constant_ = 0.00001;
    double 			spring_constant_;
    final static double		default_spring_length_ = 100; 
    double 			spring_length_;

    //  Force-Directed constants
    //
    final static double		default_f_d_attractive_force_constant_ = 0.00001;
    double			f_d_attractive_force_constant_;
    final static double		default_f_d_repulsive_force_constant_ = 0.00001;
    double			f_d_repulsive_force_constant_;

    //  Annealing constants
    //
    final static double 	default_annealing_constant_ = 0.001;
    double			annealing_constant_;

    //  Perturbation constants
    //
    double			perturbation_radius_;

    //  Old Cost value (for last iteration)
    //  
    double			old_cost;

    // Various Temperature constants
    //
    final static double         default_initial_temperature_ = 0.001;
    double			initial_temperature_;
    double 			temperature_;
    final static double		temperature_factor_ = 0.75;

    //  Iteration total
    //
    final static int 		total_iteration_limit_ = 40;
    final static int		successful_iteration_limit_ = 5;
 
    public GRAnimator()
    {
	spring_constant_ = default_spring_constant_;
	spring_length_ = default_spring_length_;
	annealing_constant_ = default_annealing_constant_;
	initial_temperature_ = default_initial_temperature_;
	f_d_attractive_force_constant_ = default_f_d_attractive_force_constant_;
	f_d_repulsive_force_constant_ = default_f_d_repulsive_force_constant_;
    }

    public void setDefaultSpringLength()
    {	
	spring_length_ = default_spring_length_;
    }

    public void setDefaultSpringConstant()
    {	
	spring_constant_ = default_spring_constant_;
    }

    public void setSpringLength(double length)
    {
	spring_length_ = length;
    }

    public double springLength()
    {
   	return spring_length_;
    }

    public void setSpringConstant(double constant)
    {
	spring_constant_ = constant;
    }

    public double springConstant()
    {
  	return spring_constant_;
    }

    // Calculates the "Energy" of a graph by checking what the average positional change 
    // is in all of the nodes
    //
    private double Energy(GRGraph graph_)
    {
	if (graph_.numnodes() <= 1) return 0;
	double energy = 0;

	for (int i = 0 ; i < graph_.numnodes() ; i++ ) {
		energy += Math.abs(graph_.nodes()[i].changex());
		energy += Math.abs(graph_.nodes()[i].changey());
		energy += Math.abs(graph_.nodes()[i].changez());
	}			
	energy /= (double) graph_.numnodes();
	return energy;
    }

    // Updates the graph through one iteration
    //
    public double SpringUpdate(GRGraph graph_)
    {
	boolean continue_ = false;
	double dx,dy,dz;
	double length, force;
	Node node1,node2;

 	// Reset changes
        //
	for (int i = 0 ; i < graph_.numnodes() ; i++) {
		graph_.nodes()[i].setchangex(0);
		graph_.nodes()[i].setchangey(0);
		graph_.nodes()[i].setchangez(0);
	}

 	// Give and edge attractive force
   	//
	Edge currentedge = graph_.edges();	
	while (currentedge != null) {	
		node1 = currentedge.node1();
		node2 = currentedge.node2();		
		dx = node2.x() - node1.x();
		dy = node2.y() - node1.y();
		dz = node2.z() - node1.z();

	//  Divide length by two since nodes moving in towards each other
	//  When Node locked, divide by 1.0   
		if (node1.isLocked() || node2.isLocked())
			length = Math.sqrt(dx*dx + dy*dy + dz*dz);	
		else
			length = Math.sqrt(dx*dx + dy*dy + dz*dz)/2.0;	

		force = (spring_length_ - length)*spring_constant_;
		force = (force/Math.abs(force))*Math.sqrt(Math.abs(force));

		node1.setchangex(node1.changex() - force*dx);
		node1.setchangey(node1.changey() - force*dy);
		node1.setchangez(node1.changez() - force*dz);

		node2.setchangex(node2.changex() + force*dx);
		node2.setchangey(node2.changey() + force*dy);
		node2.setchangez(node2.changez() + force*dz);
	
		currentedge = currentedge.next();
	}

	// Add changes to the graph's position -> if the node is not locked
  	//
	for (int i = 0 ; i < graph_.numnodes() ; i++) {
		if (graph_.nodes()[i].isLocked() == false) {
			graph_.nodes()[i].setx(graph_.nodes()[i].x() + 
				graph_.nodes()[i].changex());
			graph_.nodes()[i].sety(graph_.nodes()[i].y() + 
				graph_.nodes()[i].changey());
			graph_.nodes()[i].setz(graph_.nodes()[i].z() + 
				graph_.nodes()[i].changez());
		}
	}
	return Energy(graph_);
    }

    // Updates the graph through one force-directed iteration
    //
    public double ForceDirectedUpdate(GRGraph graph_) 
    {
	boolean continue_ = false;
	double dx,dy,dz;
	double length, force;
	Node node1,node2;
	int i,j;

	// Reset all changes
	//
	for (i = 0 ; i < graph_.numnodes() ; i++) {
		graph_.nodes()[i].setchangex(0);
		graph_.nodes()[i].setchangey(0);
		graph_.nodes()[i].setchangez(0);
	}

	// Give a resistive "push" between all nodes proportional to 1/(distance)
	//
	for (i = 0 ; i < graph_.numnodes() ; i++) {
		for (j = 0 ; j < graph_.numnodes() ; j++) {
		 if (i != j) {

				dx = graph_.nodes()[j].x() - graph_.nodes()[i].x();
				dy = graph_.nodes()[j].y() - graph_.nodes()[i].y();
				dz = graph_.nodes()[j].z() - graph_.nodes()[i].z();

	//  Divide length by two since nodes moving in towards each other
	//  When Node locked, divide by 1.0 
	
				if (graph_.nodes()[i].isLocked() || graph_.nodes[j].isLocked())
					length = Math.sqrt(dx*dx + dy*dy + dz*dz);	
				else
					length = Math.sqrt(dx*dx + dy*dy + dz*dz)/2.0;	

				length *= 0.01;
				force = ((1/length) * Math.sqrt(f_d_repulsive_force_constant_));

				graph_.nodes()[i].setchangex(graph_.nodes()[i].changex() - force*dx);
				graph_.nodes()[i].setchangey(graph_.nodes()[i].changey() - force*dy);
				graph_.nodes()[i].setchangez(graph_.nodes()[i].changez() - force*dz);
		
				graph_.nodes()[j].setchangex(graph_.nodes()[j].changex() + force*dx);
				graph_.nodes()[j].setchangey(graph_.nodes()[j].changey() + force*dy);
				graph_.nodes()[j].setchangez(graph_.nodes()[j].changez() + force*dz);
			}
		}
	}

	// Give an attractive "pull" between nodes with edges between them 
	// proportional to (distance)^2
	//
	Edge currentedge = graph_.edges();	
	while (currentedge != null) {	
		node1 = currentedge.node1();
		node2 = currentedge.node2();		
		
		dx = node2.x() - node1.x();
		dy = node2.y() - node1.y();
		dz = node2.z() - node1.z();

		if (node1.isLocked() || node2.isLocked())
			length = Math.sqrt(dx*dx + dy*dy + dz*dz);	
		else
			length = Math.sqrt(dx*dx + dy*dy + dz*dz)/2.0;	

		force = (spring_length_ - length)*f_d_attractive_force_constant_;
		force = (force/Math.abs(force))*Math.sqrt(Math.abs(force));

		node1.setchangex(node1.changex() - force*dx);
		node1.setchangey(node1.changey() - force*dy);
		node1.setchangez(node1.changez() - force*dz);
		
		node2.setchangex(node2.changex() + force*dx);
		node2.setchangey(node2.changey() + force*dy);
		node2.setchangez(node2.changez() + force*dz);

		currentedge = currentedge.next();
	}

	// Add changes to the graph's position -> if the node is not locked
  	//
	for (i = 0 ; i < graph_.numnodes() ; i++) {
		if (graph_.nodes()[i].isLocked() == false) {
			graph_.nodes()[i].setx(graph_.nodes()[i].x() + 
				graph_.nodes()[i].changex());
			graph_.nodes()[i].sety(graph_.nodes()[i].y() + 
				graph_.nodes()[i].changey());
			graph_.nodes()[i].setz(graph_.nodes()[i].z() + 
				graph_.nodes()[i].changez());
		}
	}
	return Energy(graph_);
    }

    // Slightly perturbs the position of the nodes of the graph using a gaussian distribution set
    // randomly over the nodes, the maximum distance of the perturbation can be 
    // sqrt(3)*(graph bounding box)
    //
    public void perturbGraph(GRGraph graph){
	double 	bounding_box = graph.findMaxDimension();
	double 	x,y,z,dist;
	int 	temp;
	Random  rand = new Random();
	int 	numnodes = graph.numnodes();
	int 	halfnumnodes = (int)(((double)graph.numnodes())/2.0);
	double  exponent = Math.exp(0);
	int[]	perturbation_array;

	// Get a permutation of the node numbers from 1 to number of graph nodes
	//
	perturbation_array = new int[numnodes];
	for (int i = 0 ; i < numnodes ; i++)
		perturbation_array[i] = i;

	for (int i = 0 ; i < numnodes ; i++) {
		int j = (int) (rand.nextDouble()*(double) numnodes);
		int k = (int) (rand.nextDouble()*(double) numnodes);
		temp = perturbation_array[j];
		perturbation_array[j] = perturbation_array[k];
		perturbation_array[k] = temp;
	}

	// Do a gaussian curve on changes
 	//
	for (int i = 0 ; i < numnodes ; i++){
		dist = 2.0*bounding_box*(Math.exp(-(double)((i-halfnumnodes)*(i-halfnumnodes))/3.0)/exponent);
		x = (rand.nextDouble() - 0.5)*dist;
		y = (rand.nextDouble() - 0.5)*dist;
		z = (rand.nextDouble() - 0.5)*dist;
		graph.nodes()[perturbation_array[i]].setx(graph.nodes()[perturbation_array[i]].x()+x);
		graph.nodes()[perturbation_array[i]].sety(graph.nodes()[perturbation_array[i]].y()+y);
		graph.nodes()[perturbation_array[i]].setz(graph.nodes()[perturbation_array[i]].z()+z);
	}
    }

    // Updates the graph through one simulated annealing iteration
    //
    public double SimulatedAnnealingUpdate(GRGraph graph) 
    {
	Random rand = new Random();	

	double 	cost, random, cooling;
	int 	total_iterations = 0;
	int 	successful_iterations = 0;
	int 	iteration_limit_ = total_iteration_limit_ * graph.numnodes();
	int 	successful_limit_ = successful_iteration_limit_ * graph.numnodes();

	// Run until equilibrium reached
	do {
		SARandomPerturbation(graph,rand.nextLong());
		cost = SACost(graph);
		random = rand.nextDouble();
		cooling = Math.exp((old_cost - cost)/temperature_);

		if ((cost < old_cost) || (random < cooling)) {
			if (random < cooling)
				System.out.println("RANDOM");
			else
				System.out.println();
			SASetGraph(graph);
			old_cost = cost;
			successful_iterations++;
			if (successful_iterations == successful_limit_) {
				successful_iterations = 0;
				break;
			}
		}

		total_iterations++;
	} while (total_iterations < iteration_limit_);

	SALowerTemp();
	return old_cost;
    }

    public void resetSAConstants() {
	old_cost = 99999999;	
	temperature_ = initial_temperature_;
    }

    private void SALowerTemp() {
	temperature_ *= temperature_factor_;
    }

    // sets the changed location of the nodes in the graph to the actual location
    //
    private void SASetGraph(GRGraph graph) 
    {
	for (int i = 0 ; i < graph.numnodes() ; i++) {
		if (graph.nodes()[i].isLocked() == false) {
			graph.nodes()[i].setx(graph.nodes()[i].x() + 
				graph.nodes()[i].changex());
			graph.nodes()[i].sety(graph.nodes()[i].y() + 
				graph.nodes()[i].changey());
			graph.nodes()[i].setz(graph.nodes()[i].z() + 
				graph.nodes()[i].changez());
		}
	}
    }
 
    // perturb a single node randomly within the perturbation radius
    //
    public void SARandomPerturbation(GRGraph graph,long seed)
    {
	Random rand = new Random(seed);
	double dx,dy,dz;
	perturbation_radius_ = 2.0*graph.findMaxDimension()*(temperature_/initial_temperature_);

	for (int i = 0 ; i < graph.numnodes() ; i++) {
		graph.nodes()[i].setchangex(0);
		graph.nodes()[i].setchangey(0);
		graph.nodes()[i].setchangez(0);
	}

	int node = (int) ((double) graph.numnodes() * rand.nextDouble());

	dx = (perturbation_radius_ * (rand.nextDouble() - 0.5));	
	dy = (perturbation_radius_ * (rand.nextDouble() - 0.5));		
	dz = (perturbation_radius_ * (rand.nextDouble() - 0.5));		
	graph.nodes()[node].setchangex(dx);
	graph.nodes()[node].setchangey(dy);
	graph.nodes()[node].setchangez(dz);
    }

    // Calculates the cost of the movement of a node in the graph, same as the cost for 
    // the force-directed method
    //
    public double SACost(GRGraph graph) 
    {
	boolean 	continue_ = false;
	double 		cost = 0;
	double 		dx,dy,dz;
	double 		length, force;
	Node 		node1,node2;

	for (int i = 0 ; i < graph.numnodes() ; i++) {
		for (int j = 0 ; j < graph.numnodes() ; j++) {
		 if (i != j) {
				
			dx = (graph.nodes()[j].x() + graph.nodes()[j].changex()) - 
			     (graph.nodes()[i].x() + graph.nodes()[i].changex());
			dy = (graph.nodes()[j].y() + graph.nodes()[j].changey()) - 
			     (graph.nodes()[i].y() + graph.nodes()[i].changey());
			dz = (graph.nodes()[j].z() + graph.nodes()[j].changez()) - 
			     (graph.nodes()[i].z() + graph.nodes()[i].changez());

			length = Math.sqrt(dx*dx + dy*dy + dz*dz);	
			length *= 0.01;
			force = (1/length) * Math.sqrt(annealing_constant_);
			cost += force;
		 }
		}
	}

	Edge currentedge = graph.edges();	
	while (currentedge != null) {	
		node1 = currentedge.node1();
		node2 = currentedge.node2();		
		
		dx = (node2.x() + node2.changex()) - (node1.x() + node1.changex());
		dy = (node2.y() + node2.changey()) - (node1.y() + node1.changey());
		dz = (node2.z() + node2.changez()) - (node1.z() + node1.changez());

		length = Math.sqrt(dx*dx + dy*dy + dz*dz);	

		force = (Math.abs(spring_length_ - length) * annealing_constant_);
		cost += force;

		currentedge = currentedge.next();
	}
	return cost;
  }
}
