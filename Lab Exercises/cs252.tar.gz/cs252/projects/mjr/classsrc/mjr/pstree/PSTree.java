/*
 * @(#)PSTree.java	1.0 5/16/96 Michael John Radwin
 */

package mjr.pstree;

import leda.*;
import java.util.Vector;

/**
 * Augmented priority search tree for the java demo
 *
 * @version 1.0 5/16/96
 * @author <A HREF="http://www.cs.brown.edu/people/mjr/">Michael John Radwin</A>
 */
public class PSTree extends ps_tree {
    /**
     * mjr: returns success and failure vectors for range queries
     */
    protected void enumerate(int x1,int x2,int y0,ps_item p,
			     Vector success, Vector failure)
    {
	if (p == null) return;
	
	if (cmp(y0,p.y_value())>=0) {
	    if (cmp(x1,p.split_value_x())<=0 && cmp(p.split_value_x(),x2)<=0) {
		if (cmp(x1,p.x_value())<=0 && cmp(p.x_value(),x2)<=0)
		    success.addElement(p);
		else if (p.y_value() > 0)
		    failure.addElement(p);
		enumerate(x1,x2,y0,p.left_child(), success, failure); 
		enumerate(x1,x2,y0,p.right_child(), success, failure); 
	    } else if (cmp(p.split_value_x(),x1)<=0) {
		if(cmp(x1,p.x_value())<=0 && cmp(p.x_value(),x2)<=0)
		    success.addElement(p);
		else if (p.y_value() > 0)
		    failure.addElement(p);
		enumerate(x1,x2,y0,p.right_child(), success, failure);
	    } else if (cmp(x2,p.split_value_x())<=0) {
		if(cmp(x1,p.x_value())<=0 && cmp(p.x_value(),x2)<=0)
		    success.addElement(p);
		else if (p.y_value() > 0)
		    failure.addElement(p);
		enumerate(x1,x2,y0,p.left_child(), success, failure);
	    } else if (p.y_value() > 0) {
		failure.addElement(p);
	    }
	} else if (p.y_value() > 0) {
	    failure.addElement(p);
	}
    }

    /**
     * mjr: just like enumerate, but returns a vector of results.
     * The first element is found nodes, the second is nodes
     * that were visited by the search but not found
     */
    public Vector[] range_query(int x1,int x2,int y0)
    {
	Vector result[] = new Vector[2];
	result[0] = new Vector();  // found points
	result[1] = new Vector();  // visited but failure points
	
	enumerate(x1,x2,y0,root,result[0],result[1]);
	return result;
    }

    /**
     * mjr: traverse the tree preorder using these silly command objects.
     */
    public void preorder(PSTCommand nodeCommand,
			 PSTCommand leafCommand) throws Throwable
    {
	preorder(nodeCommand, leafCommand, root);
    }
    
    protected void preorder(PSTCommand nodeCommand,
			    PSTCommand leafCommand, ps_item p) throws Throwable
    {
	if (p == null) {
	    leafCommand.execute(p);
	    return;
	}

	nodeCommand.execute(p);
	preorder(nodeCommand, leafCommand, p.left_child());
	preorder(nodeCommand, leafCommand, p.right_child());
    }

    
    /**
     * mjr: traverse the tree postorder using these silly command objects.
     */
    public void postorder(PSTCommand nodeCommand,
			 PSTCommand leafCommand) throws Throwable
    {
	postorder(nodeCommand, leafCommand, root);
    }
    
    protected void postorder(PSTCommand nodeCommand,
			    PSTCommand leafCommand, ps_item p) throws Throwable
    {
	if (p == null) {
	    leafCommand.execute(p);
	    return;
	}

	postorder(nodeCommand, leafCommand, p.left_child());
	postorder(nodeCommand, leafCommand, p.right_child());
	nodeCommand.execute(p);
    }

    
    /**
     * mjr: traverse the tree inorder using these silly command objects.
     */
    public void inorder(PSTCommand nodeCommand,
			 PSTCommand leafCommand) throws Throwable
    {
	inorder(nodeCommand, leafCommand, root);
    }
    
    protected void inorder(PSTCommand nodeCommand,
			    PSTCommand leafCommand, ps_item p) throws Throwable
    {
	if (p == null) {
	    leafCommand.execute(p);
	    return;
	}

	inorder(nodeCommand, leafCommand, p.left_child());
	nodeCommand.execute(p);
	inorder(nodeCommand, leafCommand, p.right_child());
    }

    public static void mjr() { ; }
}
