import java.awt.*;
import WebTree;


class ErrorFrame extends Frame {

   Label l_,l2_;
   WebTree webtree_;
   Button btn2_;


// CONSTRUCTOR ////////////////////////////////////////////////////
   
   ErrorFrame(String title, WebTree webtree)
   {
      
      super(title);
      setLayout(new GridLayout(3,1));
      Font f = new Font("TimesRoman", Font.BOLD, 14); 
      l_ = new Label();
      l_.setFont(f);
      add(l_);
      webtree_ = webtree;
      l2_ = new Label();
      l2_.setFont(f);
      add(l2_);
      btn2_ = (new Button("Close"));
      add(btn2_);
  }


// ACTION ///////////////////////////////////////////////////////   
   
public boolean action (Event evt, Object arg)
   {
      
      if (evt.target instanceof Button) {

         String label = (String) arg;

         if (label.equals("Close")) {
            webtree_.change_ = true;
            this.hide();
         }

         return true;
         
      } else  return false;
      
} 


// SET ERROR ////////////////////////////////////////////////////   
   
public void setError (String s)
   {

      l_.setText(s);
      l2_.setText("");
      this.show();
      
   }

// SET ERROR /////////////////////////////////////////////////////
   
public void setError (String s1, String s2)
   {
      
      l_.setText(s1);
      l2_.setText(s2);
      this.show();
      
   }
 
}

  
