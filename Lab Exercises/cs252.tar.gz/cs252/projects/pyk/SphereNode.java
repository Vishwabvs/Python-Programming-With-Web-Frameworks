/*
 * SphereNode.java
 *
 * Description:
 *    This class contains the methods and variables for the sphere used in the
 *    3D positioning tool.  The sphere will be drawn in shades of red to give a
 *    3D illusion.
 */
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

class SphereNode
{
   Color fillColor;         // the base color of the sphere
   int resetX;              // initial x position of the sphere
   int resetY;              // initial y position of the sphere
   int resetZ;              // initial z position of the sphere
   int resetWidth;          // initial width of the sphere
   int resetHeight;         // initial height of the sphere
   int relativeX;           // relative x movement
   int relativeY;           // relative y movement
   int relativeZ;           // relative z movement
   int relativeWidth;       // relative change in width
   int relativeHeight;      // relative change in height
   int stoppedZPosition;    // location where sphere stopped shrinking
   boolean stoppedZ;        // flag which is set when z can't shrink further

   // cosntructor for sphere ndoe
   SphereNode(int x, int y, int width)
   {
      fillColor = new Color(116, 1, 38);
      resetX = x;
      resetY = y;
      resetZ = 0;
      resetWidth = width;
      resetHeight = width;
      relativeX = x;
      relativeY = y;
      relativeZ = 0;
      relativeWidth = width;
      relativeHeight = width;
      stoppedZ = false;
   }

   // reset the sphere to the initial settings
   public void reset()
   {
      relativeX = resetX;
      relativeY = resetY;
      relativeZ = resetZ;
      relativeWidth = resetWidth;
      relativeHeight = resetHeight;
   }

   // draw the sphere at the specified location, use different shades of red to
   // give the illusion of 3D depth
   public void sphereDraw(Graphics g)
   {
      Color savedColor = g.getColor();
      int tempWidth;
      int width;
      int numberColors = 0;
      float redStep;
      float greenStep;
      float blueStep;
      int redComponent;
      int greenComponent;
      int blueComponent;
      int index;

      g.setColor(fillColor);
      g.fillOval(relativeX - (relativeWidth / 2),
                 relativeY - (relativeWidth / 2), relativeWidth,
                 relativeHeight);
      for (tempWidth = relativeWidth / 2; tempWidth > 2; tempWidth = tempWidth / 2)
      {
          numberColors++;
      }
      redStep = ((float) 135) / numberColors;
      greenStep = ((float) 1) / numberColors;
      blueStep = ((float) 45) / numberColors;
      for (index = 0; index < numberColors; index++)
      {
         redComponent = 116 + (int) (redStep * (index + 1));
         greenComponent = 1 + (int) (greenStep * (index + 1));
         blueComponent = 38 + (int) (blueStep * (index + 1));
         Color newColor = new Color(redComponent, greenComponent, blueComponent);
         g.setColor(newColor);
         g.fillOval(relativeX - (relativeWidth / 2) + ((relativeWidth / 2) * (index + 1)) /
                       numberColors,
                    relativeY - (relativeWidth / 2) + ((relativeWidth / 2) * (index + 1)) /
                       numberColors,
                    relativeWidth - (relativeWidth / 2) * (index + 1) / numberColors -
                       2 * (index + 1),
                    relativeWidth - (relativeWidth / 2) * (index + 1) / numberColors -
                       2 * (index + 1));
      }
      g.setColor(savedColor);
   }

   // erase the sphere
   public void sphereClear(Graphics g)
   {
      Color savedColor = g.getColor();
      g.setColor(Color.black);
      g.fillRect(relativeX - (relativeWidth / 2),
                 relativeY - (relativeWidth / 2), relativeWidth,
                 relativeHeight);
      g.setColor(savedColor);
   }

   // move the sphere
   public void sphereMove(int x, int y, int z)
   {
      relativeX = relativeX + x;
      relativeY = relativeY - y;
      if (z < 0)
      {
         relativeZ = relativeZ + z;
         if (relativeWidth > 1)
         {
            relativeWidth = relativeWidth - 1;
            relativeHeight = relativeHeight - 1;
            relativeX = relativeX;
            relativeY = relativeY;
         }
         else
         {
            if (stoppedZ == false)
            {
               stoppedZ = true;
               stoppedZPosition = relativeZ;
            }
         }
      }
      else if (z > 0)
      {
         relativeZ = relativeZ + z;
         if (stoppedZ)
         {
            if (relativeZ == stoppedZPosition)
            {
               stoppedZ = false;
            }
         }
         else
         {
            relativeWidth = relativeWidth + 1;
            relativeHeight = relativeHeight + 1;
            relativeX = relativeX;
            relativeY = relativeY;
         }
      }
   }

   // get bounding box of sphere
   public Rectangle getBoundingBox()
   {
      Rectangle boundingBox = new Rectangle(
                 relativeX - (relativeWidth / 2),
                 relativeY - (relativeWidth / 2), relativeWidth,
                 relativeHeight);
      return boundingBox;
   }

   // return the relative x displacement
   public int getRelativeX()
   {
      return relativeX;
   }

   // return the relative y displacement
   public int getRelativeY()
   {
      return relativeY;
   }

   // return the relative z displacement
   public int getRelativeZ()
   {
      return relativeZ;
   }

   // return the relative width change
   public int getRelativeWidth()
   {
      return relativeWidth;
   }

}