import java.util.*;
import java.io.*;
import java.net.*;
import java.awt.*;

import Node;
import Queue;
import WebTree;


public class WebCrawler {

   final private boolean DEBUG = true;

   final private int MAX_TAG_SIZE = 512;
   final private int MAX_ATTR_SIZE = 512;
   final private int MAX_URL_SIZE = 512;

   private Queue pages_;    // holds all nodes pending parsing

   private Vector urls_;    // stores all the urls found on the crawl

   
   // Begin HTML tags

   final private int TAG_A = 0;
   final private int TAG_ADDRESS = 1;

   final private int TAG_B = 2;
   final private int TAG_BASE = 3;
   final private int TAG_BLOCKQUOTE = 4;
   final private int TAG_BODY = 5;
   final private int TAG_BR = 6;
   
   final private int TAG_CITE = 7;
   final private int TAG_CODE = 8;
   
   final private int TAG_DD = 9;
   final private int TAG_DIR = 10;
   final private int TAG_DL = 11;
   final private int TAG_DT = 12;
   
   final private int TAG_EM = 13;
   
   final private int TAG_H1 = 14;
   final private int TAG_H2 = 15;
   final private int TAG_H3 = 16;
   final private int TAG_H4 = 17;
   final private int TAG_H5 = 18;
   final private int TAG_H6 = 19;
   final private int TAG_HEAD = 20;
   final private int TAG_HR = 21;
   final private int TAG_HTML = 22;
   
   final private int TAG_I = 23;
   final private int TAG_IMG = 24;
   final private int TAG_INPUT = 25;
   final private int TAG_ISINDEX = 26;
   
   final private int TAG_KBD = 27;
   
   final private int TAG_LI = 28;
   final private int TAG_LINK = 29;
   final private int TAG_LISTING = 30;
   
   final private int TAG_MENU = 31;
   final private int TAG_META = 32;
   
   final private int TAG_NEXTID = 33;
   
   final private int TAG_OL = 34;
   final private int TAG_OPTION = 35;
   
   final private int TAG_P = 36;
   final private int TAG_PLAINTEXT = 37;
   final private int TAG_PRE = 38;
   
   final private int TAG_SAMP = 39;
   final private int TAG_SELECT = 40;
   final private int TAG_STRONG = 41;
   
   final private int TAG_TEXTAREA = 42;
   final private int TAG_TITLE = 43;
   final private int TAG_TT = 44;
   
   final private int TAG_UL = 45;
   
   final private int TAG_VAR = 46;
   
   final private int TAG_XMP = 47;

   final private int TAG_SITE = 48;
   final private int TAG_FORM = 49;
   final private int TAG_IMGMAP = 50;
   final private int TAG_WORDS = 51;

   final private int TAG_APPLET = 52;

   final private int TAG_UNKNOWN = 53;

   // End HTML tags

   private WebTree wt_; // points back to the main application
   
   private URL url_; // the current page's URL

   private Node currentPage_; // the current page (node)

   private Node selectedNode_; // the selected node (for adding on to trees)

   private int maxDepth_, maxNodes_;
   

// CONSTRUCTOR /////////////////////////////////////////////////////
   
   WebCrawler (WebTree wt) { wt_ = wt; }


// START CRAWL /////////////////////////////////////////////////////
   
public void startCrawl (URL url, Node selectedNode,
                        int maxDepth, int maxNodes)
   {

      // Set the global url.

      url_ = url;

      // Set the maximum depth of the crawl.

      maxDepth_ = maxDepth;

      if (DEBUG)
         System.out.println("Starting crawl until depth " + maxDepth_);

      maxNodes_ = maxNodes;

      if (DEBUG) System.out.println("Maximum number of nodes: " + maxNodes_);


      selectedNode_ = selectedNode;
      
      // Initialize the vectors.

      pages_ = new Queue();

      // Save old URLs if continuing a crawl.

      urls_ = new Vector(); // clear the URL vector

      int size = wt_.nodeList_.size();
         
      for (int i = 0; i < size; i++) {

         Node tempNode = (Node)wt_.nodeList_.elementAt(i);

         URL tempURL = tempNode.getURL();

         if (tempURL != null && !urls_.contains(tempURL))
            urls_.addElement(tempURL);

      }

      if (DEBUG) System.out.println("Building vector containing " +
                                    urls_.size() + " unique URLs.");

      currentPage_ = selectedNode_;

      if (currentPage_ != null) {

	url_ = currentPage_.getURL(); // set the current URL

	// Filter out non-HTML documents based on filename suffixes.

	if (analyzeURL(url_.toString())) {
            
	  // Connect to the URL and retrieve the page.
      
	  String page = getPage(url_);

	  parsePage(page);

	}

      } else {
      
      addURL(url.toString());  // for detecting cycles to the root

      }
      
      // Begin the breadth-first search.

      BFS();

   }


// GET SOURCE ///////////////////////////////////////////////////////
   
public String getSource (URL url)
   {

      if (DEBUG) System.out.println("Getting source at " + url.toString());
      
      String page = getPage(url);
      return page;
   }


// BREADTH-FIRST SEARCH /////////////////////////////////////////////
   
private void BFS ()
   {

      int pageCount = 0;
      
      while (!pages_.isEmpty()) {

         // Make sure that we haven't gone over our node quota.
         
         if (pageCount >= maxNodes_) {

            if (DEBUG) System.out.println("Maximum number of nodes exceeded!");

            break;

         }
         
         currentPage_ = (Node)pages_.remove(); // take the first one off

         int depth = currentPage_.getDepth();

         if (depth < maxDepth_) {
            
            url_ = currentPage_.getURL(); // set the current URL

            // Filter out non-HTML documents based on filename suffixes.

            if (analyzeURL(url_.toString())) {
            
               // Connect to the URL and retrieve the page.
      
               String page = getPage(url_);

               parsePage(page);

            }

         }

	 wt_.addNode(currentPage_);

         pageCount++;
         
         if (DEBUG) System.out.println("<PAGES: " + pageCount + ">");
      }

      if (DEBUG) System.out.println("Done.");

      // Signal to the main application that we're done.
      
      wt_.crawlDone();
      
   }

 
// GET NODES ////////////////////////////////////////////////////////

public Vector getNodes () { return pages_;  }


// PARSE PAGE ///////////////////////////////////////////////////////
   
private void parsePage (String page)
   {

      char ch;
      char[] tag_name = new char[MAX_TAG_SIZE];
      char[] attr_name = new char[MAX_ATTR_SIZE];
      
      if (DEBUG) System.out.println("Parsing page...");
      
      if (DEBUG) System.out.println("Length: " + page.length() + " bytes.");

      int index = 0;
      
      while (true) {

         try { ch = page.charAt(index); }
         catch (StringIndexOutOfBoundsException e) {
            if (DEBUG) System.out.println("String index out of bounds: " +
                                          index);
            break;
         }
         index++;
         
         if (ch == '<') { // we've got a potential tag

            for (int n = 0; n < MAX_TAG_SIZE; n++)
               tag_name[n] = '\0';

            int i = 0;

            while (true) {

               try { ch = page.charAt(index); }
               catch (StringIndexOutOfBoundsException e) {
                  if (DEBUG) System.out.println("String index out of " +
                                                "bounds: " + index);
                  break;
               }
               index++;

               if (ch == '/') break;

               if (ch == '\n') break;
               else if (ch == '\t') break;
               else if (ch == '\r') break;
               else if (ch == '>') break;

               else {

                  if (new Character(ch).isSpace(ch)) break;
                  
                  else {
                     
                     tag_name[i] = ch;
                     i++;

                  }

               }
            }

            tag_name[i] = '\0';

            int comment_count = 0;
            
            if (tag_name[0] == '\0') continue;

            else if (((new String(tag_name)).trim()).equals(new String("!--"))) {

               while (true) {

                  try { ch = page.charAt(index); }
                  catch (StringIndexOutOfBoundsException e) {
                     if (DEBUG) System.out.println("String index out of " +
                                                   "bounds: " + index);
                     break;
                  }
                  index++;
                     
                  if (new Character(ch).isSpace(ch)) continue;

                  else if (ch == '-') {

                     try { ch = page.charAt(index); }
                     catch (StringIndexOutOfBoundsException e) {
                        if (DEBUG) System.out.println("String index out " +
                                                      "of bounds: " + index);
                        break;
                     }
                     index++;

                     if (ch == '-') {

                        while (true) {
                              
                           try { ch = page.charAt(index); }
                           catch (StringIndexOutOfBoundsException e) {
                              if (DEBUG) System.out.println("String index " +
                                                            "out of bounds: " +
                                                            index);
                              break;
                           }
                           index++;

                           if (new Character(ch).isSpace(ch)) continue;

                           else break;
                        }

                        if (ch == '>') break;

                     }

                  }
               }

               continue;
                  
            } // done with eating up comments (?)

            // System.out.print("TAG: " + new String(tag_name));


               
            int tag_ID = getTagID(new String(tag_name));


            // System.out.println(" -> (" + tag_ID + ")");
               
            switch (tag_ID) {

            case TAG_A:

              while (true) {

                try { ch = page.charAt(index); }
                catch (StringIndexOutOfBoundsException e) {
                  if (DEBUG) System.out.println("String index out of " +
                                                "bounds: " + index);
                  break;
                }
                index++;

                if (ch == '>') break;

                // Fill the character array with \0's.

                for (int n = 0; n < MAX_ATTR_SIZE; n++)
                  attr_name[n] = '\0';

                int j = 0;

                // modified code....

                while (true) {

                     if (ch == '=') break;

                     else if (!(new Character(ch).isSpace(ch))) {

                        attr_name[j] = ch;
                        j++;
                        
                     }

                     try { ch = page.charAt(index); }
                     catch (StringIndexOutOfBoundsException e) {
                        
                        if (DEBUG) System.out.println("String index out of " +
                                                      "bounds: " + index);
                        break;
                     }
                     index++;

                  }
                  

                  // Construct a string from the attribute character array.
                  
                  String attrString = new String(attr_name);

                  // if (DEBUG) System.out.print("ATTR: " + attrString);
                  
                  attrString = attrString.toUpperCase();

                  attrString = attrString.trim();

                  // if (DEBUG)
                  //   System.out.println(" " + attrString + " [" +
                  //                      attrString.length() + "]");
                  
                  if (attrString.equals("HREF")) {

                     i = 0;
                     int count_quote = 0;
                        
                     char[] link_url = new char[MAX_URL_SIZE];

                     for (int n = 0; n < MAX_URL_SIZE; n++)
                        link_url[n] = '\0';
                     
                     while (true) {

                        try { ch = page.charAt(index); }
                        catch (StringIndexOutOfBoundsException e) {
                           if (DEBUG) System.out.println("String index out " +
                                              "of bounds: " + index);
                           break;
                        }
                        index++;

                        if (ch == '=') continue;

                        else if (new Character(ch).isSpace(ch))
                           continue;

                        else if (ch != '"' && count_quote < 1 &&
                                 ch != '>') {

                           link_url[i] = ch;
                           i++;
                                 
                        }

                        else if (ch == '"' && count_quote < 1) {

                           count_quote++;
                           continue;

                        }

                        else if (count_quote == 1 && ch != '"') {

                           link_url[i] = ch;
                           i++;
                                 
                        }

                        else break;

                     }

                     link_url[i] = '\0';



                     
                     String URL = new String(link_url);
                           
                     if (DEBUG) System.out.print("URL: " + URL);

                     URL = URL.trim();

                     if (DEBUG) System.out.println(" [" + URL.length() + "]");

                     // Check the string.
                              
                     if (URL.length() > 0) parseURL(URL);

                     break;


                     

                  }

                  else {

                     while (true) {

                        try { ch = page.charAt(index); }
                        catch (StringIndexOutOfBoundsException e) {
                           
                           if (DEBUG) System.out.println("String index out " +
                                                         "of bounds: " +
                                                         index);
                           break;
                        }
                        index++;

                        if (!(new Character(ch).isSpace(ch))) break;
                        
                     }

                     if (ch != '"') {

                        do {

                           if (new Character(ch).isSpace(ch) ||
                               ch == '>') break;

                           try { ch = page.charAt(index); }
                           catch (StringIndexOutOfBoundsException e) {
                              
                              if (DEBUG) System.out.println("String index " +
                                                            "out of bounds: " +
                                                            index);
                              break;
                           }
                           index++;
                              
                        } while (true);

                        if (ch == '>') break;

                        else continue;

                     }

                     else {

                        while (true) {
                           
                           try { ch = page.charAt(index); }
                           catch (StringIndexOutOfBoundsException e) {
                              
                              if (DEBUG) System.out.println("String index " +
                                                            "out of " +
                                                            "bounds: " +
                                                            index);
                              break;
                           }
                           index++;

                           if (ch == '"') break;

                        }

                        continue;

                     }

                  }

               }

               break;

             case TAG_ADDRESS: break;

             case TAG_B: break;

             case TAG_BASE: break;
                  
             case TAG_BLOCKQUOTE: break;

             case TAG_BODY: break;

             case TAG_BR: break;
                  
             case TAG_CITE: break;

             case TAG_CODE: break;

             case TAG_DD: break;
                  
             case TAG_DIR: break;

             case TAG_DL: break;

             case TAG_DT: break;
                  
             case TAG_EM: break;

             case TAG_H1: break;

             case TAG_H2: break;
                  
             case TAG_H3: break;

             case TAG_H4: break;

             case TAG_H5: break;
                  
             case TAG_H6: break;

             case TAG_HEAD: break;

             case TAG_HR: break;
               
             case TAG_HTML: break;

             case TAG_I: break;

             case TAG_IMG: break;
                  
             case TAG_INPUT: break;

             case TAG_ISINDEX: break;

             case TAG_KBD: break;
                  
             case TAG_LI: break;

             case TAG_LINK: break;

             case TAG_LISTING: break;
                  
             case TAG_MENU: break;

             case TAG_META: break;

             case TAG_NEXTID: break;
               
             case TAG_OL: break;
               
             case TAG_OPTION: break;

             case TAG_P: break;
                  
             case TAG_PLAINTEXT: break;

             case TAG_PRE: break;

             case TAG_SAMP: break;
                  
             case TAG_SELECT: break;

             case TAG_STRONG: break;

             case TAG_TEXTAREA: break;
                  
             case TAG_TITLE: break;

             case TAG_TT: break;
               
             case TAG_UL: break;
                  
             case TAG_VAR: break;

             case TAG_XMP: break;

             case TAG_SITE: break;
                  
             case TAG_FORM: break;

             case TAG_IMGMAP: break;

             case TAG_WORDS: break;

             case TAG_APPLET: break;

             case TAG_UNKNOWN: break;

            }

         }

         else {

            if (new Character(ch).isSpace(ch)) {

               continue;
                  
            }
               
         }
            
      }
                  
   }                       


// GET TAG ID ////////////////////////////////////////////////////////////
   
private int getTagID (String tag)
   {

      // Convert the tag string to uppercase
      
      tag = tag.toUpperCase();

      // Be sure to remove extra whitespace!!!
      
      tag = tag.trim();

      // if (DEBUG) System.out.print(" " + tag + " [" + tag.length() + "]");

      
      // These tags should be sorted by ubiquity.
      
      if (tag.equals("A")) return TAG_A;

      else if (tag.equals("ADDRESS")) return TAG_ADDRESS;

      else if (tag.equals("B")) return TAG_B;

      else if (tag.equals("BASE")) return TAG_BASE;

      else if (tag.equals("BLOCKQUOTE")) return TAG_BLOCKQUOTE;

      else if (tag.equals("BODY")) return TAG_BODY;      

      else if (tag.equals("BR")) return TAG_BR;

      else if (tag.equals("CITE")) return TAG_CITE;

      else if (tag.equals("CODE")) return TAG_CODE;

      else if (tag.equals("DD")) return TAG_DD;

      else if (tag.equals("DIR")) return TAG_DIR; 

      else if (tag.equals("DL")) return TAG_DL;

      else if (tag.equals("DT")) return TAG_DT;

      else if (tag.equals("EM")) return TAG_EM;

      else if (tag.equals("H1")) return TAG_H1;

      else if (tag.equals("H2")) return TAG_H2;  

      else if (tag.equals("H3")) return TAG_H3;

      else if (tag.equals("H4")) return TAG_H4;

      else if (tag.equals("H5")) return TAG_H5;

      else if (tag.equals("H6")) return TAG_H6;

      else if (tag.equals("HEAD")) return TAG_HEAD;
      
      else if (tag.equals("HR")) return TAG_HR;

      else if (tag.equals("HTML")) return TAG_HTML;

      else if (tag.equals("I")) return TAG_I;

      else if (tag.equals("IMG")) return TAG_IMG;

      else if (tag.equals("INPUT")) return TAG_INPUT;
   
      else if (tag.equals("ISINDEX")) return TAG_ISINDEX;

      else if (tag.equals("KBD")) return TAG_KBD;

      else if (tag.equals("LI")) return TAG_LI;

      else if (tag.equals("LINK")) return TAG_LINK;

      else if (tag.equals("LISTING")) return TAG_LISTING;
      
      else if (tag.equals("MENU")) return TAG_MENU;

      else if (tag.equals("META")) return TAG_META;

      else if (tag.equals("NEXTID")) return TAG_NEXTID;

      else if (tag.equals("OL")) return TAG_OL;

      else if (tag.equals("OPTION")) return TAG_OPTION;
      
      else if (tag.equals("P")) return TAG_P;

      else if (tag.equals("PLAINTEXT")) return TAG_PLAINTEXT;

      else if (tag.equals("PRE")) return TAG_PRE;

      else if (tag.equals("SAMP")) return TAG_SAMP;

      else if (tag.equals("SELECT")) return TAG_SELECT;
      
      else if (tag.equals("STRONG")) return TAG_STRONG;

      else if (tag.equals("TEXTAREA")) return TAG_TEXTAREA;

      else if (tag.equals("TITLE")) return TAG_TITLE;

      else if (tag.equals("TT")) return TAG_TT;

      else if (tag.equals("UL")) return TAG_UL;
      
      else if (tag.equals("VAR")) return TAG_VAR;

      else if (tag.equals("XMP")) return TAG_XMP;

      else if (tag.equals("FORM")) return TAG_FORM;

      else if (tag.equals("APPLET")) return TAG_APPLET;

      else return TAG_UNKNOWN;

   }


   // PARSE URL ////////////////////////////////////////////////////////
   
private void parseURL (String url)
   {
      
      if (DEBUG) System.out.println("Parsing url...");
      
      if (url.charAt(0) == '#') return; // ignore internal anchors

      int index = url.indexOf(':'); // find the index of the first colon

      if (index != -1) {
      
         String protocol = url.substring(0, index + 1);
         
         if (DEBUG) System.out.println("protocol: " + protocol);
            
         if (protocol.equalsIgnoreCase("http:")) {
                  
            // Got an http link (trival accept).
            
            addURL(url);

         }

         else if (protocol.equalsIgnoreCase("ftp:")) {

            // Got an ftp link.

         }

         else if (protocol.equalsIgnoreCase("gopher:")) {

            // Got a gopher link.

         }

         else if (protocol.equalsIgnoreCase("mailto:")) {

            // Got an email link.

         }

         else if (protocol.equalsIgnoreCase("news:")) {

            // Got a USENET link.

         }

         else if (protocol.equalsIgnoreCase("telnet:")) {

            // Got a telnet link.

         }

         else {

            // Got an unknown link.

         }

      } else { // no colon found in the URL

         // Get the hostname from the URL of the current HTML page.
         
         String currentHost = url_.getHost();

         // Get the filename from the URL of the current HTML page.
         
         String currentFile = url_.getFile();

         if (DEBUG) System.out.println("currentHost: " + currentHost + 
                                       ", currentFile: " + currentFile);

         // <A HREF ="/pathname/filename.*"

         if (url.charAt(0) == '/') {
                        
            String absURL = new String("http://" + currentHost + url);

            if (DEBUG) System.out.println("absURL: " + absURL);

            addURL(absURL);

         }

         // <A HREF="../../filename.*"

         else if (url.charAt(0) == '.') {

            String absURL;
            
            if (!currentFile.endsWith("/")) {

               // Remove the filename from the end of the URL.

               int lastSlashIndex = currentFile.lastIndexOf("/");
               
               String path = currentFile.substring(0, lastSlashIndex + 1);

               if (DEBUG) System.out.println("path: " + path);

               absURL = new String("http://" + currentHost + path + url);

               // Test the newly created URL.
               
               try {
                  
                  URL testURL = new URL(absURL);
                  URLConnection urlConnection = testURL.openConnection();
                  urlConnection.connect();

                  // If the file does not exist then the following will
                  // throw an exception.
                  
                  InputStream is = urlConnection.getInputStream();

                  int foo = is.read();
                  
               } catch (Exception e) {
                  
                  if (DEBUG) System.out.println(e.getMessage());

                  // Guess that the "filename" was actually a directory.

                  absURL = new String(url_ + "/" + url);
                  
               }
               
            } else {

               absURL = new String(url_ + url); // append link to URL

            }

               if (DEBUG) System.out.println("absURL: " + absURL);

               addURL(absURL);
         }

         // <A HREF = "pathname/filename.*"

         else {

            String absURL;
            
            if (!currentFile.endsWith("/")) {

               // Remove the filename from the end of the URL.

               int lastSlashIndex = currentFile.lastIndexOf("/");
               
               String path = currentFile.substring(0, lastSlashIndex + 1);

               if (DEBUG) System.out.println("path: " + path);

               absURL = new String("http://" + currentHost + path + url);

               // Test the newly created URL.
               
               try {
                  
                  URL testURL = new URL(absURL);
                  URLConnection urlConnection = testURL.openConnection();
                  urlConnection.connect();

                  // If the file does not exist then the following will
                  // throw an exception.
                  
                  InputStream is = urlConnection.getInputStream();

                  int foo = is.read();
                  
               } catch (Exception e) {
                  
                  if (DEBUG) System.out.println(e.getMessage());

                  // Guess that the "filename" was actually a directory.

                  absURL = new String(url_ + "/" + url);
                  
               }

            } else {

               absURL = new String(url_ + url); // append link to URL

            }

            if (DEBUG) System.out.println("absURL: " + absURL);

            addURL(absURL);

         }

      }

   }


   // ADD URL ///////////////////////////////////////////////////////////

private void addURL(String url)
   {

     if (DEBUG) System.out.print("Adding URL...");

     int depth;

     if (currentPage_ == null) depth = -1;
     else depth = currentPage_.getDepth();

     if (DEBUG) System.out.print(" (" + depth + ")");
     
     if (depth >= maxDepth_) {

        if (DEBUG) System.out.println(" MAX DEPTH EXCEEDED");
        return;

     }
     
     URL newURL;

     try { 

        newURL = new URL(url); // construct the URL out of the string
        
        if (urls_.contains(newURL)) {

           if (DEBUG) System.out.println(" DUPLICATE");
           return;

        } else {

           urls_.addElement(newURL);

           Node tempNode = new Node();

           tempNode.setURL(newURL);

           tempNode.setParent(currentPage_);

           tempNode.setDepth(depth + 1);
           
           pages_.insert(tempNode); // put it on the queue to be parsed

        }
        
     } catch (MalformedURLException e) {

        if (DEBUG) System.out.println(" MALFORMED URL: " + e.getMessage());
        return;

     }

     if (DEBUG) System.out.println(" DONE");
     
  }


// ANALYZE URL ///////////////////////////////////////////////////////

final private boolean analyzeURL (String url)
   {

      int index = url.lastIndexOf('.');

      if (index == -1) return true; // no period? go for it...
      
      String suffix = url.substring(index);

      if (DEBUG) System.out.println("suffix: " + suffix);

      if (suffix.equalsIgnoreCase(".gif") ||
          suffix.equalsIgnoreCase(".jpg") ||
          suffix.equalsIgnoreCase(".jpeg") ||
          suffix.equalsIgnoreCase(".mpg") ||
          suffix.equalsIgnoreCase(".mpeg") ||
          suffix.equalsIgnoreCase(".au") ||
          suffix.equalsIgnoreCase(".wav") ||
          suffix.equalsIgnoreCase(".txt")) {

         if (DEBUG) System.out.println("Rejecting URL!");
         return false;

      }

      else return true;
          
      
   }
   

// GET PAGE ///////////////////////////////////////////////////////////
   
private String getPage (URL url)
   {
      
      InputStream conn;
      DataInputStream data;
      String line;
      StringBuffer buf = new StringBuffer();

      if (DEBUG) System.out.println("Attempting to read URL: " + url);
      
      try {
         conn = url.openStream();
         data = new DataInputStream(new BufferedInputStream(conn));

         while ((line = data.readLine()) != null) {
            buf.append(line + "\n");
         }

      } catch (IOException e) {
      
         System.out.println("IO Error:" + e.getMessage());
         
      } catch (SecurityException e) {

         System.out.println("Security Exception: " + e.getMessage());
         
      }
      
      return buf.toString();

   }
   
}
