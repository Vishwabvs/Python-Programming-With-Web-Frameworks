package cs252;

import java.awt.*;
import sprite.*;
import graph.*;
import java.applet.Applet;
import java.util.Vector;

public class SpanGraph extends GraphArea {
    boolean left_;
    
    public SpanGraph(Container container, boolean left) {
	super(true, WIDTH, HEIGHT, false);
	left_ = left;
	
        SetUpdateMode(NO_UPDATING);
	TextSprite title = new TextSprite(
	    this, 0, TITLE_Y, (left ? "Left" : "Right") + " Spanning Tree");
	title.MoveTo((WIDTH - title.GetWidth()) / 2, title.y_);
	title.SetColor(Color.blue);
	title.Add();

	SetUpdateMode(DELAYED_UPDATING);

	container.add(this);
        container.resize(container.preferredSize());
        WaitForGraphics();
        
	Graphics back = GetBackgroundGraphics();
	back.setColor(Color.white);
	back.fillRect(0, 0, WIDTH, HEIGHT);

	if (left)
	    DrawXAxis(back);
	else
	    DrawYAxis(back);
	
	BackgroundDirty();
    }

    public void CopyGraph(Edge edges[]) {
	int index = left_ ? 0 : 1;
	for (int loop = 0; loop < edges.length; ++loop) {
	    OrderNode a = (OrderNode)edges[loop].GetA();
	    if (a.mirrors_[index] == null) {
		OrderNode newNode = new OrderNode(this, a);
		newNode.SetColor(Color.lightGray);
		a.mirrors_[index] = newNode;
	    }		
	    a = a.mirrors_[index];
	    
	    OrderNode b = (OrderNode)edges[loop].GetB();	    
	    if (b.mirrors_[index] == null) {
		OrderNode newNode = new OrderNode(this, b);
		newNode.SetColor(Color.lightGray);
		b.mirrors_[index] = newNode;
	    }
	    b = b.mirrors_[index];
	    Edge e = new Edge(this, a, b);
	    e.SetColor(Color.lightGray);
	}
    }
    
    public void CopySingleNode(OrderNode node) {
	OrderNode newNode = new OrderNode(this, node);
	newNode.SetColor(Color.lightGray);
	node.mirrors_[left_ ? 0 : 1] = newNode;
    }

    public void AddEdge(OrderNode from, OrderNode to) {
	int index = left_ ? 0 : 1;
	OrderNode newNode = to.mirrors_[index];
	if (left_)
	    newNode.SetLeft(to.GetLeft(), false);
	else
	    newNode.SetRight(to.GetRight(), false);
	newNode.SetColor(Color.blue);
	if (from != null) {
	    from = from.mirrors_[index];
	    from.ConnectingEdge(newNode).SetColor(Color.black);
	}
    }

    public void DrawXAxis(Graphics g) {
	Font font = new Font("Helvetica", Font.PLAIN, 10);
	FontMetrics m = getFontMetrics(font);

	int bottom = m.getAscent() + BUFFER + BOTTOM;
	int max = (WIDTH - LEFT) / BETWEEN;
	g.setColor(Color.black);
	g.drawLine(LEFT, BOTTOM, LEFT + BETWEEN * max, BOTTOM);
	g.setFont(font);
	for (int loop = 0; loop <= max; ++loop) {
	    String label = "" + loop;
	    int x = LEFT + BETWEEN * loop;
	    int xAdd = m.stringWidth(label) / 2;
	    g.setColor(Color.black);
	    g.drawLine(x, BOTTOM, x, BOTTOM + BUFFER);
	    g.setColor(Color.red);
	    g.drawString(label, x - xAdd, bottom);
	}
    }

    public void DrawYAxis(Graphics g) {
	Font font = new Font("Helvetica", Font.PLAIN, 10);
	FontMetrics m = getFontMetrics(font);

	int max = BOTTOM / BETWEEN;
	int yAdd = (m.getAscent() - m.getDescent()) / 2;
	g.setColor(Color.black);
	g.drawLine(LEFT, BOTTOM, LEFT, BOTTOM - BETWEEN * max);
	g.setFont(font);
	for (int loop = 0; loop <= max; ++loop) {
	    String label = "" + loop;
	    int xAdd = m.stringWidth(label) + BUFFER + 1;
	    int y = BOTTOM - BETWEEN * loop;
	    g.setColor(Color.black);
	    g.drawLine(LEFT, y, LEFT - BUFFER, y);
	    g.setColor(Color.red);
	    g.drawString(label, LEFT - xAdd, y + yAdd);
	}
    }
    
    final public static int TITLE_Y = 10;
    
    final public static int WIDTH = DominanceGraph.WIDTH;
    final public static int HEIGHT = DominanceGraph.HEIGHT;

    final public static int LEFT = DominanceGraph.LEFT;
    final public static int BOTTOM = DominanceGraph.BOTTOM;
    final public static int BETWEEN = DominanceGraph.BETWEEN;

    final public static int BUFFER = 3;
    
//    final public static double START_GRAY = 0.5;
//    final public static int GRADATIONS = 20;
}
