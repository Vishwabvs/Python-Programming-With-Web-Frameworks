import java.util.*;
import java.awt.*;
import java.net.*;

import LayoutAlgorithm;
import Node;
import WebTree;

public class SiteColorAlgorithm extends LayoutAlgorithm {

WebTree webtree_;

final private boolean DEBUG = true;
final private int MAX_DUPLICATES = 10;
   
private Vector hostnames_ = new Vector(); // holds strings
private Vector colors_ = new Vector(); // holds colors

private Random randomNumberGenerator_ = new Random();
   
SiteColorAlgorithm(WebTree webtree){
  webtree_ = webtree;
}


public void execute (Vector nodeList)
   {
     
      if (DEBUG) System.out.println("site color algorithm execute called");
      
      int total = nodeList.size();
     
      if (DEBUG) System.out.println("total nodes: " + total);

      if (total == 0) return;

     
      // Seed the random number generator.
     
      Date date = new Date();

      randomNumberGenerator_.setSeed(date.getTime());

     
      for (int i = 0; i < total; i++) {

         Node tempNode = (Node)nodeList.elementAt(i);

         URL tempURL = tempNode.getURL();

         String hostname;
        
         if (tempURL != null) hostname = tempURL.getHost();
         else hostname = new String("none");
        
         if (DEBUG) System.out.println(tempNode.getId() + "'s host: " +
                                      hostname);

         
         // Check to see if the hostname is unique.
        
         if (!hostnames_.contains(hostname)) {

            hostnames_.addElement(hostname);

            colors_.addElement(pickColor());
         }

         
         int index = hostnames_.indexOf(hostname); // find the index

         if (index != -1) {

            tempNode.setColor((Color)colors_.elementAt(index));
           
         } else { // how could this ever happen?

            if (DEBUG) System.out.println("WARNING: Unknown hostname!");

         }
        
      }

      if (DEBUG) {
         
         if (hostnames_.size() != colors_.size()) {

            System.out.println("WARNING: Color vector size does not match " +
                               "hostname vector size!");
         }

      }
      
   }


   // PICK COLOR //////////////////////////////////////////////////////////
   
final private Color pickColor()
   {

      // Pick a unique color.

      int randomR, randomG, randomB;

      boolean isUnique = false;

      int duplicates = 0;

      Color newColor = new Color(0, 0, 0); // must initialize
      
      while (!isUnique) {
         
         randomR = (int)(randomNumberGenerator_.nextDouble() * 256);
         randomG = (int)(randomNumberGenerator_.nextDouble() * 256);
         randomB = (int)(randomNumberGenerator_.nextDouble() * 256);
      
         if (DEBUG) System.out.println("color: [" + randomR + ", " +
                                       randomG + ", " + randomB + "]");
        
         newColor = new Color(randomR, randomG, randomB);

         if (!colors_.contains(newColor)) {
            
            isUnique = true;
           
         } else {

            duplicates++;
            
            if (DEBUG) System.out.println("Generated a duplicate color!");

            if (duplicates >= MAX_DUPLICATES) {

               if (DEBUG) System.out.println("WARNING: maximum number of " +
                                             "duplicate colors exceeded!");
               
               break;

            }

         }

      }

      return newColor;
      
   }


   // RESET ///////////////////////////////////////////////////////////

public void reset ()
   {

      // Erase the old vectors and start again.
      
      colors_ = new Vector();
      hostnames_ = new Vector();

   }

}

