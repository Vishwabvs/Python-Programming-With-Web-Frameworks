
import java.awt.*;
import java.applet.*;
import java.io.*;
import java.net.*;
import java.util.Vector;

class Queue extends Vector
{
    public void enqueue(Object obj) {
        addElement(obj);
    }
    public Object dequeue() {
        Object obj=firstElement();
        removeElementAt(0);
        return obj;
    }
}

class Stack extends Vector
{
    public void push(Object obj) {
        addElement(obj);
    }
    public Object pop() {
        Object obj=lastElement();
        removeElement(obj);
        return obj;
    }
}

class Edge
{
    public Vertex v1,v2;
    final static int PROXIMITY_FACTOR = 1000;

    public Edge(Vertex w1,Vertex w2) {
        v1=w1; v2=w2;
        v1.adjedges.addElement(this);
        v2.adjedges.addElement(this);
    }

    public void V1(Vertex v) {
        v1.adjedges.removeElement(this);
        v1=v;
        v1.adjedges.addElement(this);
    }

    public void V2(Vertex v) {
        v2.adjedges.removeElement(this);
        v2=v;
        v2.adjedges.addElement(this);
    }

    public void removeAdjEdges() {
        v1.adjedges.removeElement(this);
        v2.adjedges.removeElement(this);
    }

    public Vertex otherVertex(Vertex v)
    {
        if (v==v1) return v2;
        else return v1;
    }

    public int proximity(int x,int y)
    {
        // Returns a proximity measure: dot product of the edge and
        // an edge formed with the given vertex and one of the vertex.
        double vec1_x = v2.x - v1.x;
        double vec1_y = v2.y - v1.y;
        double len1 = Math.sqrt(vec1_x*vec1_x + vec1_y*vec1_y);
        vec1_x /= len1;
        vec1_y /= len1;

        double vec2_x = x - v1.x;
        double vec2_y = y - v1.y;
        double len2 = Math.sqrt(vec2_x*vec2_x + vec2_y*vec2_y);
        vec2_x /= len2;
        vec2_y /= len2;
        double dot2 = vec1_x*vec2_x + vec1_y*vec2_y;
        double cos2 = Math.abs(Math.acos(dot2));

        double vec3_x = x - v2.x;
        double vec3_y = y - v2.y;
        double len3 = Math.sqrt(vec3_x*vec3_x + vec3_y*vec3_y);
        vec3_x /= len3;
        vec3_y /= len3;
        double dot3 = - vec1_x*vec3_x - vec1_y*vec3_y;
        double cos3 = Math.abs(Math.acos(dot3));

        return (int)((cos2 + cos3)*90);
    }
}

class Graph
{
    Vector vertices;
    Vector edges;
    final static int CIR_SIZE = 4;
    IGem igem;
    String graph_name;

    RWLock lock;

    public Graph(IGem g) {
        vertices = new Vector();
        edges = new Vector();
        igem = g;
        graph_name = "unnamed";
    }

    public synchronized Edge addEdge(Vertex v1,Vertex v2)
    {
        // Adds an edge to the graph and returns the edge added.
        Edge e = new Edge(v1,v2);
        edges.addElement(e);
        igem.setStatus();
        return e;
    }

    public synchronized int addEdge(int v1,int v2)
    {
        // Adds an edge to the graph by vertex indices.
        Edge e = addEdge((Vertex)vertices.elementAt(v1),(Vertex)vertices.elementAt(v2));
        return edges.indexOf(e);
    }

    public synchronized int addEdge(int v1,Vertex v2)
    {
        // Adds an edge to the graph by vertex indices.
        Edge e = addEdge((Vertex)vertices.elementAt(v1),v2);
        return edges.indexOf(e);
    }

    public synchronized int addEdge(Vertex v1,int v2)
    {
        // Adds an edge to the graph by vertex indices.
        Edge e = addEdge(v1,(Vertex)vertices.elementAt(v2));
        return edges.indexOf(e);
    }

    public synchronized int addVertex(int x,int y)
    {
        // Adds a vertex to the graph and return the index
        // of the vertex added.

        Vertex v = new Vertex(x,y);
        vertices.addElement(v);
        igem.setStatus();
        return vertices.indexOf(v);
    }

    public synchronized boolean mergeVertex(int v_from,int v_to)
    {
        // Merge two vertices and delete one of them. If any edge
        // becomes redundant (two cases: degenerate edges, or duplicated
        // edges) then delete that edge too.

        Vertex vert_from = (Vertex) vertices.elementAt(v_from);
        Vertex vert_to = (Vertex) vertices.elementAt(v_to);

        for (int i=0;i<vert_from.adjedges.size();i++) {
            Edge e = (Edge) vert_from.adjedges.elementAt(i);
            if (e.v1 == vert_from) { e.V1(vert_to); i--; }
            if (e.v2 == vert_from) { e.V2(vert_to); i--; }
            if (e.v1 == e.v2 || findDuplicateEdge(e)!=null) { deleteEdge(e); }
        }
        deleteVertex(v_from);
        igem.setStatus();
        return true;
    }

    public synchronized void setFixVertex(int v_num,boolean b)
    {
        Vertex v = (Vertex) vertices.elementAt(v_num);
        v.fixed = b;
    }

    public synchronized void toggleFixVertex(int v_num)
    {
        Vertex v = (Vertex) vertices.elementAt(v_num);
        v.fixed = (v.fixed==true)?false:true;
    }

    public synchronized boolean deleteVertex(int v_num)
    {
        return deleteVertex( (Vertex) vertices.elementAt(v_num) );
    }

    public synchronized boolean deleteVertex(Vertex v)
    {
        for (int i=v.adjedges.size()-1;i>=0;i--) {
            Edge e = (Edge) v.adjedges.elementAt(i);
            deleteEdge(e);
        }
        vertices.removeElement(v);
        igem.setStatus();
        return true;
    }

    public synchronized void setFixEdge(int e_num,boolean b)
    {
        Edge e = (Edge) edges.elementAt(e_num);
        e.v1.fixed = b;
        e.v2.fixed = b;
    }

    public synchronized void toggleFixEdge(int e_num)
    {
        Edge e = (Edge) edges.elementAt(e_num);
        boolean b = true;
        if (e.v1.fixed || e.v2.fixed) b=false;
        setFixEdge(e_num,b);
    }

    public synchronized boolean deleteEdge(int e_num)
    {
        // Deletes an edge, all edges with greater edge numbers
        // shifts up by one automatically.
        Edge e = (Edge) edges.elementAt(e_num);
        e.removeAdjEdges();
        edges.removeElementAt(e_num);
        igem.setStatus();
        return true;
    }

    public synchronized boolean deleteEdge(Edge e)
    {
        e.removeAdjEdges();
        edges.removeElement(e);
        igem.setStatus();
        return true;
    }

    public synchronized int splitEdge(int e_num)
    {
        // Splits an edge into two, and return the new middle vertex
        Edge e = (Edge) edges.elementAt(e_num);
        int new_vert_num = addVertex(0,0);
        Vertex new_vert = (Vertex) vertices.elementAt(new_vert_num);
        Edge new_edge = addEdge(new_vert,e.v2);
        e.V2( new_vert );
        return new_vert_num;
    }

    public synchronized boolean deleteAllEdges()
    {
        for (int i=edges.size()-1;i>=0;i--) {
            Edge e = (Edge) edges.elementAt(i);
            if (e!=null) deleteEdge(e);
        }
        return true;
    }

    public synchronized boolean deleteAllVertices()
    {
        for (int i=vertices.size()-1;i>=0;i--) {
            Vertex v = (Vertex) vertices.elementAt(i);
            if (v!=null) deleteVertex(v);
            else vertices.removeElementAt(i);
        }
        return true;
    }

    public synchronized boolean deleteAll()
    {
        return deleteAllEdges() && deleteAllVertices();
    }

    public synchronized int[] getNearestVertexExcept(int x,int y,int except)
    {
        // Find the nearest vertex to the given point excluding
        // the given "except" vertex number. "Except" is useful
        // because we may want to find the nearest point to a point
        // already in the graph.

        if (vertices.size()==0) return null;
        int nearest[] = { -1,2<<16 };
        for (int i=0;i<vertices.size();i++)
        {
            if (i==except) continue;
            Vertex v = (Vertex) vertices.elementAt(i);
            if (v==null) continue;
            int len = v.proximity(x,y);
            if (len < nearest[1]) {
                nearest[0] = i;
                nearest[1] = len;
            }
        }
        return nearest;
    }

    public synchronized int[] getNearestVertex(int x,int y)
    {
        // Find the nearest vertex to the given point.
        // Returns null array only when there is no vertex in the
        // graph.

        return getNearestVertexExcept(x,y,-1);
    }

    public synchronized int[] getNearestEdge(int x,int y)
    {
        if (edges.size()==0) return null;
        int nearest[] = { -1,2<<16 };
        for (int i=0;i<edges.size();i++)
        {
            Edge e = (Edge) edges.elementAt(i);
            if (e==null) continue;
            int len = e.proximity(x,y);
            if (len < nearest[1]) {
                nearest[0] = i;
                nearest[1] = len;
            }
        }
        return nearest;
    }

    protected synchronized Edge findDuplicateEdge(Edge e)
    {
        Vertex v1 = e.v1;
        Vertex v2 = e.v2;
        for (int i=0; i < v1.adjedges.size(); i++) {
            Edge e_match = (Edge) v1.adjedges.elementAt(i);
            if (e_match == e) continue;
            if (e_match.v1==v2 || e_match.v2==v2)
                return e_match;
        }
        for (int i=0; i < v2.adjedges.size(); i++) {
            Edge e_match = (Edge) v2.adjedges.elementAt(i);
            if (e_match == e) continue;
            if (e_match.v1==v1 || e_match.v2==v1)
                return e_match;
        }
        return null;
    }

    public synchronized void paint(Graphics g)
    {
        // Draw the graph.
        for (int i=0; i < edges.size(); i++) {
            Edge edge = (Edge) edges.elementAt(i);
            if (edge==null) continue;
            drawEdge(g, edge.v1.x, edge.v1.y, edge.v2.x, edge.v2.y);
        }
        for (int i=0; i < vertices.size(); i++) {
            Vertex vert = (Vertex) vertices.elementAt(i);
            if (vert==null) continue;
            drawVertex(g, vert.x, vert.y, vert.fixed);
        }
    }

    public synchronized void paintAdjacentEdges(Graphics g)
    {
        // Draw the graph using adjacency lists, for testing only.
        for (int i=0; i < vertices.size(); i++) {
            Vertex vert = (Vertex) vertices.elementAt(i);
            if (vert==null) continue;
            drawVertex(g, vert.x, vert.y, vert.fixed);
            for (int j=0; j < vert.adjedges.size(); j++) {
                Edge e = (Edge) vert.adjedges.elementAt(j);
                drawEdge(g, e.v1.x, e.v1.y, e.v2.x, e.v2.y);
            }
        }
    }

    public void drawGraphEdge(Graphics g,int x1,int y1,int x2,int y2)
    {
        // Draws an edge.
        drawEdge(g,x1, y1, x2, y2);
        drawVertex(g,x1,y1,false);
        drawVertex(g,x2,y2,false);
    }

    public void drawEdge(Graphics g,int x1,int y1,int x2,int y2)
    {
        // Draws an edge.
        DeviceCoord dc = igem.disp_area.dc;
        g.drawLine(dc.toDeviceX(x1), dc.toDeviceY(y1), dc.toDeviceX(x2), dc.toDeviceY(y2));
    }

    public void drawVertex(Graphics g,int x,int y,boolean fixed)
    {
        // Draws a filled circle vertex.
        DeviceCoord dc = igem.disp_area.dc;
        if (fixed==false) {
            g.fillArc(dc.toDeviceX(x)-CIR_SIZE,dc.toDeviceY(y)-CIR_SIZE,2*CIR_SIZE,2*CIR_SIZE,0,360);
        } else {
            g.fillRect(dc.toDeviceX(x)-CIR_SIZE,dc.toDeviceY(y)-CIR_SIZE,2*CIR_SIZE,2*CIR_SIZE);
        }
    }

    static Queue queue = new Queue();

    public Vertex bfs (Vertex root)
    {
        Vertex v;
        if (root != null) {   // pass in a non-null root to start new search
            queue.removeAllElements();
            for (int i=0; i < vertices.size(); i++) {
                v = (Vertex) vertices.elementAt(i);
                v.in = 0;
            }
            queue.enqueue(root);
            root.in = 1;
        }
        if (queue.isEmpty()) return null;
        v = (Vertex) queue.dequeue();
        for (int e_num=0; e_num<v.adjedges.size();e_num++) {
            Edge e = (Edge) v.adjedges.elementAt(e_num);
            Vertex u = e.otherVertex(v);
            if (u.in==0) {
                queue.enqueue(u);
                u.in = v.in + 1;
            }
        }
        return v;
    }

    static Stack stack = new Stack();

    public Vertex dfs (Vertex root)
    {
        Vertex v;
        if (root != null) {
            stack.removeAllElements();
            for (int i=0; i < vertices.size(); i++) {
                v = (Vertex) vertices.elementAt(i);
                v.in = 0;
            }
            stack.push(root);
            root.in = 1;
        }
        if (stack.isEmpty()) return null;
        v = (Vertex) stack.pop();
        for (int e_num=0; e_num<v.adjedges.size();e_num++) {
            Edge e = (Edge) v.adjedges.elementAt(e_num);
            Vertex u = e.otherVertex(v);
            if (u.in==0) {
                stack.push(u);
                u.in = v.in + 1;
            }
        }
        return v;
    }

    public Vertex findCenterVertex()
    {
        Vertex c=null, u=null;
        int h = vertices.size() + 1;
        for (int i=0; i < vertices.size(); i++) {
            Vertex w = (Vertex) vertices.elementAt(i);
            Vertex v = bfs(w);
            while (v!=null && v.in<h) {
                u = v;
                v = bfs(null);
            }
            if (u.in < h) {
                h = u.in;
                c = w;
            }
        }
        return c;
    }
}

