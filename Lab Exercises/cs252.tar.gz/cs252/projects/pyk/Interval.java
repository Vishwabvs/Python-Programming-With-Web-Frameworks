/*
 * Interval.java
 *
 * Description:
 *    This class is the Interval class and has all methods and variables
 *    for creating an Interval node and setting and retrieving values
 */
import java.util.Vector;

class Interval
{
    private int lowValue;     // the low value in a range
    private int highValue;    // the high value in a range
    private int id;           // the unique id for the interval node
    public Vector otherIds;   // vector used to store node ids have
                              // nodes with same range

    // constructor for Interval node
    Interval(int low, int identifier)
    {
       lowValue = low;
       id = identifier;
       highValue = -1;
       otherIds = new Vector();
    }

    // set the high value of the interval
    public void setHighValue(int high)
    {
       highValue = high;
    }

    // return the low value of the interval
    public int getLowValue()
    {
       return lowValue;
    }

    // return the high value of the interval
    public int getHighValue()
    {
       return highValue;
    }

    // return the id of the interval
    public int getId()
    {
       return id;
    }

    // return the vector of multiple hits
    public Vector getOtherIds()
    {
        return otherIds;
    }

    // add the id to the multiple hit vector
    public void addId(int id)
    {
        otherIds.addElement(new Integer(id));
    }
};