package cs252;

import java.applet.*;
import java.awt.*;
import graph.*;
import sprite.*;
import java.util.Vector;

public class SourceSink extends Enforcer {
    Vector added_;
    OrderNode source_;

    public SourceSink(DominanceGraph area, int id) {
	super(area, id);
    }
    
    public void Enforce(Vector graph, Vector edges, OrderNode lowest) {
	added_ = new Vector();
	
	Node nodes[] = new Node[graph.size()];
	graph.copyInto(nodes);

	// sort nodes by y, < first
        for (int i = nodes.length - 1; i > 0; --i)
            for (int j = 0; j < i; ++j)
                if (!(nodes[j + 1].y_ > nodes[j].y_)) {
                    Node temp = nodes[j];
                    nodes[j] = nodes[j + 1];
                    nodes[j + 1] = temp;
                }
	source_ = (OrderNode)(nodes[nodes.length - 1]);

	Vector edgeL = new Vector();
	Vector bestL = new Vector();
	bestL.addElement(nodes[0]);
	for (int loop = 0; loop < nodes.length; ++loop) {
	    Node current = nodes[loop];
	    Edge all[] = current.GetAllArray();
	    
//	    System.out.println(current);
	    if (loop != 0 && current.GetOutgoingEdges().size() == 0) {
		int pos = FindPosition(edgeL, current);
		Node best = (Node)bestL.elementAt(pos);
		bestL.setElementAt(current, pos);
//		System.out.println(
//		    "  " + current + " has no outgoing edges. Best = " + best);
                Edge added = new Edge(area_, current, best);
		added_.addElement(added);
		area_.AddDelay();
	    }
	    
	    for (int eLoop = 0; eLoop < all.length; ++eLoop) {
		// moving down, so if end node add to status
		// incoming edge
		if (all[eLoop].GetB() == current) {
//		    System.out.println("  Inserting edge " + all[eLoop]);
		    InsertEdge(edgeL, bestL, current, all[eLoop]);
		}
	        // outgoing edge
		else {
//		    System.out.println("  Removing edge " + all[eLoop]);
		    RemoveEdge(edgeL, bestL, current, all[eLoop]);
		}
//		System.out.println("  Edge list is: " + edgeL);
//		System.out.println("  Best list is: " + bestL);
//		System.out.println();
	    }
	}

//	System.out.println();
//	System.out.println("Incoming edges");
//	System.out.println();		

	edgeL = new Vector();
	bestL = new Vector();
	bestL.addElement(source_);
	int max = nodes.length - 1;
	for (int loop = max; loop >= 0; --loop) {
	    Node current = nodes[loop];
	    Edge all[] = current.GetAllArray();
	    
//	    System.out.println(current);
	    if (loop != max && current.GetIncomingEdges().size() == 0) {
		int pos = FindPosition(edgeL, current);
		Node best = (Node)bestL.elementAt(pos);
//		System.out.println(
//		    "  " + current + " has no incoming edges. Best = " + best);
                Edge added = new Edge(area_, best, current);
		added_.addElement(added);
		area_.AddDelay();
	    }
	    
	    for (int eLoop = 0; eLoop < all.length; ++eLoop) {
		// moving up, so if start node add to status
		// outgoing edge
		if (all[eLoop].GetA() == current) {
//		    System.out.println("  Inserting edge " + all[eLoop]);
		    InsertEdge(edgeL, bestL, current, all[eLoop]);
		}
	        // incoming edge
		else {
//		    System.out.println("  Removing edge " + all[eLoop]);
		    RemoveEdge(edgeL, bestL, current, all[eLoop]);
		}
//		System.out.println("  Edge list is: " + edgeL);
//		System.out.println("  Best list is: " + bestL);
//		System.out.println();
	    }
	}
    }

    public void InsertEdge(Vector edges, Vector extreme,
			   Node owner, Edge newEdge) {
	int pos = FindPosition(edges, owner);
	extreme.setElementAt(owner, pos);
	extreme.insertElementAt(owner, pos);
	edges.insertElementAt(newEdge, pos);
    }

    public void RemoveEdge(Vector edges, Vector extreme,
			   Node owner, Edge edge) {
	int pos = edges.indexOf(edge);
	extreme.removeElementAt(pos);
	extreme.setElementAt(owner, pos);	
	edges.removeElementAt(pos);
    }
    
    public int FindPosition(Vector edges, Node node) {
	int xP = node.x_; int yP = node.y_;
	int loop;
	for (loop = 0; loop < edges.size(); ++loop)
	    if (FindSide((Edge)edges.elementAt(loop), xP, yP))
		return loop;
//	    else
//		System.out.println("  " + edges.elementAt(loop) +
//				   " is on the left.");
	return loop;
    }

    public boolean FindSide(Edge e, int xP, int yP) {
	Node nodeA = e.GetA(); Node nodeB = e.GetB();
	int x1 = nodeA.x_; int y1 = nodeA.y_;
	int x2 = nodeB.x_; int y2 = nodeB.y_;
	
	int dX = x2 - x1; int dY = y2 - y1;
	return (dY * (xP - x1) + (y1 - yP) * dX) > 0;
    }
	
    public boolean DidAnything() {
	return added_.size() > 0;
    }
    
    public void InformSplit(Edge e, Edge a, Node c, Edge b) {
	if (added_.contains(e)) {
	    added_.removeElement(e);
	    added_.addElement(c);
	    added_.addElement(a);
	    added_.addElement(b);	    
	}
    }
    
    public void Restore() {
 	for (int loop = 0; loop < added_.size(); ++loop) {
	    Sprite current = (Sprite)added_.elementAt(loop);
	    current.Hide();
	    area_.RemoveDelay();
 	}
    }

    public void Undo() { ; }

    public OrderNode GetSource() {
	return source_;
    }
}
