import java.awt.*;
import java.applet.*;

public class NameTile extends Canvas {
    final private static int OFFSET = 5;
    final private static String FONT_NAME = "TimesRoman";
    final private static int FONT_STYLE = 1;
    final private static int FONT_SIZE = 14;
    
    String name_;
    Font font_;
    int y_;
    
    NameTile (String name, int width, int height) {
	name_ = name;
	resize(width, height);
	font_ = new Font(FONT_NAME, FONT_STYLE, FONT_SIZE);
	y_ = -1;
    }

    public void paint(Graphics g) {
	g.setFont(font_);
	
	if (y_ == -1)
	    y_ = (int)((size().height +
			getFontMetrics(font_).getHeight()) / 2);

        g.drawString(name_, OFFSET, y_);
    }
}
