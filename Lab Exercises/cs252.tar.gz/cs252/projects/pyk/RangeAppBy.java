/*
 * RangeAppBy.java
 *
 * Description:
 *    This class is the animation applet class for the byline.  It cycles through
 *    41 GIF images.  When a user clicks within the applet the order of the
 *    animation will reverse.  The first time the animation is run it will not appear to be smooth
 *    this is because the frames are being enlarged (if they are not within 5
 *    pixels of the largest frame).  Further experimentation using mediatracker
 *    could probably smooth out even the first pass through the animation.
 *    However, this wasn't really woth spending more time on.  The frames are different
 *    sizes due to poor cropping on my part (this is where the 5 pixel difference
 *    comes in) and the fact that some images were produced in a zoom in mode
 *    within photo-paint.  This resulted in much different dimensions than the
 *    images that were not produced in zoom mode.
 */
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Color;
import java.awt.Event;
import java.awt.MediaTracker;
import java.awt.Dimension;

public class RangeAppBy extends java.applet.Applet implements Runnable
{
   Image frames[] = new Image[41];              // space to hold the images
   Dimension frameSizes[] = new Dimension[41];  // dimensions of the images, used
                                                // to determine the max dimensions
   Dimension currentSize = null;                // current largest dimensions
   Image firstImage = null;                     // the first image
   Image currentImage = null;                   // the current image
   MediaTracker tracker = null;                 // the media tracker, used so that
                                                // no image will be shown until
                                                // the image is within memory
   String gifFiles[] = new String[41];          // string used for name of gif file
   Image offScreenImage = null;                 // offscreen image
   Graphics offScreenGraphics = null;           // graphics context for offscreen
                                                // image
   Thread running;                              // running thread
   boolean forward = true;                      // direction of animation
   boolean firstTime = true;                    // flag which indicates whether the
                                                // animation has been run previously
   boolean mouseClicked = false;                // has the mouse been clicked
                                                // within the animation
   private boolean loaded = false;              // have all the frames been loaded
   private int maxWidth = 0;                    // maximum width of all the frames
   private int maxHeight = 0;                   // maximum height of all the frames
   int pauseValue = 75;                         // sleep time between the display
                                                // of sequential frames

   // the initialization method, create the media tracker
   public void init()
   {
      tracker = new MediaTracker(this);
   }

   // the start method, start the running thread and get the frames of the animation
   public void start()
   {
      if (running == null)
      {
         running = new Thread(this);
         getAnimationFrames();
         running.start();
      }
   }

   // given the dimensions of the current frame, update the maximum values if
   // appropriate
   private void updateMaxDimensions(Dimension dimension)
   {
      maxWidth = Math.max(dimension.width, maxWidth);
      maxHeight = Math.max(dimension.height, maxHeight);
   }

   // get the dimensions of the image
   synchronized Dimension getImageDimensions(Image image)
   {
      int width;
      int height;

      while ((width = image.getWidth(this)) < 0)
      {
         try
         {
            wait();
         } catch (InterruptedException e)
         {
         }
      }
      while ((height = image.getHeight(this)) < 0)
      {
         try
         {
            wait();
         } catch (InterruptedException e)
         {
         }
      }
      return new Dimension(width, height);
   }

   // get the animation frames and determine the maximum dimensions, use media
   // tracker to ensure that all frames are within memory before trying to display
   // any of them
   private boolean getAnimationFrames()
   {
      int index;
      int gifNumber;

      try
      {
/*
       firstImage = getImage(getCodeBase(), "image/RangeAppBy1.gif");
*/
       firstImage = getImage(getDocumentBase(),
                      "image/RangeAppBy1.gif");
      }
      catch(Exception e1)
      {
         System.out.println(e1);
      }
      for (index = 0; index < 41; index++)
      {
         try
         {
            gifNumber = index + 1;
            gifFiles[index] = new String("image/RangeAppBy" + gifNumber + ".gif");
//            frames[index] = getImage(getCodeBase(), gifFiles[index]);
            frames[index] = getImage(getDocumentBase(), gifFiles[index]);
         } catch(Exception e2)
         {
           System.out.println(e2);
         }
         tracker.addImage(frames[index], index);
         try
         {
            tracker.checkID(index, true);
            tracker.waitForID(index);
//            showStatus("Loading image " + getCodeBase() + gifFiles[index]);
            showStatus("Loading image " + getDocumentBase() + gifFiles[index]);
         } catch(Exception e3)
         {
           System.out.println(e3);
         }
         updateMaxDimensions(frameSizes[index] = getImageDimensions(frames[index]));
         if (index == 0)
         {
            currentImage = firstImage;
            repaint();
         }
      }
      resize(maxWidth, maxHeight);
      offScreenImage = createImage(maxWidth, maxHeight);
      offScreenGraphics = offScreenImage.getGraphics();
      return true;
   }

   // the stop method will stop the running thread
   public void stop()
   {
      if (running != null)
      {
         running.stop();
         running = null;
         if (offScreenGraphics != null)
         {
            offScreenGraphics.dispose();
         }
      }
      loaded =false;
   }

   // sleep for the desired time
   public void pause(int time)
   {
      try
      {
         Thread.sleep(time);
      }
      catch (InterruptedException e)
      {
      }
   }

   // the run method, will run the application reversing direction every time
   // the mouse is clicked, all frames in the current direction will be displayed
   // before the change of direction will occur
   public void run()
   {
      int index;
      Thread thisThread = Thread.currentThread();
      thisThread.setPriority(Thread.MIN_PRIORITY);
      currentImage = firstImage;
      repaint();
      while(running == thisThread)
      {
         if ((firstTime == true) || (mouseClicked == true))
         {
            if (mouseClicked == true)
            {
               mouseClicked = false;
            }
            runAnimation();
            if (firstTime == true)
            {
               firstTime = false;
            }
            pause(pauseValue);
         }
      }
   }

   // run the animation either forwards or backwards
   private void runAnimation()
   {
      int index;

      loaded = true;
      if (forward == true)
      {
         showStatus("Running animation forwards");
         for (index = 0; index < 41; index++)
         {
            pause(pauseValue);
            currentImage = frames[index];
            currentSize = frameSizes[index];
            repaint();
         }
         showStatus("");
         forward = false;
      }
      else
      {
         showStatus("Running animation backwards");
         for (index = 40; index >= 0; index--)
         {
            pause(pauseValue);
            currentImage = frames[index];
            currentSize = frameSizes[index];
            repaint();
         }
         showStatus("");
         forward = true;
      }
   }

   // set the mouse clicked flag whenever the mouse button is released
   public boolean mouseUp(Event evt, int x, int y)
   {
      mouseClicked = true;
      return true;
   }

   // update the screen
   public void update(Graphics g)
   {
      paint(g);
   }

   // draw the current offscreen image to the screen, any image which is not
   // within 5 pixels of the maximum will be enlarged to the maximum dimensions
   public void paint(Graphics g)
   {
      if ((loaded == true) && (currentImage != null) &&
          (offScreenGraphics != null) && (offScreenImage != null))
      {
/*
         offScreenGraphics.clearRect(0, 0, size().width, size().height);
*/
         if ((currentSize != null) && ((currentSize.width < maxWidth - 5) ||
             (currentSize.height < maxHeight - 5)))
         {
            offScreenGraphics.drawImage(currentImage, 0, 0, maxWidth, maxHeight,
                                        this);
         }
         else
         {
            offScreenGraphics.drawImage(currentImage, 0, 0, this);
         }
         g.drawImage(offScreenImage, 0, 0, this);
      }
      else if ((firstImage != null) && (tracker != null))
      {
         g.drawImage(firstImage, 0, 0, this);
         if (tracker.checkID(40))
         {
            showStatus("");
         }
      }
   }
}