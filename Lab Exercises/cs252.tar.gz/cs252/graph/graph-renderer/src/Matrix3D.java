/*
 *  Matrix3D - matrix package 
 *  4/14/96  
 *  by Daniel Spirn based on code from Sun Microsystems, Inc.
 *  (see http://www.javasoft.com/applets/applets/3D/classes/ThreeD.java)
 *
 */
package graphrender;

/** A fairly conventional 3D matrix object that can transform sets of
    3D points and perform a variety of manipulations on the transform */
class Matrix3D {
    GRGraphArea ga;

    double xx, xy, xz;
    double yx, yy, yz;
    double zx, zy, zz;
    double ux, uy, uz;
    double vx, vy, vz;
    static final double pi = 3.14159265;
    /** Create a new unit matrix */
    Matrix3D (GRGraphArea g) {
	xx = 1.0f;
	yy = 1.0f;
	zz = 1.0f;
	ga = g;
    }
    /** Scale by f in all dimensions */
    void scale(double f) {
	xx *= f;
	xy *= f;
	xz *= f;
	yx *= f;
	yy *= f;
	yz *= f;
	zx *= f;
	zy *= f;
	zz *= f;
    }
    /** Scale along each axis independently */
    void scale(double xf, double yf, double zf) {
	xx *= xf;
	xy *= xf;
	xz *= xf;
	yx *= yf;
	yy *= yf;
	yz *= yf;
	zx *= zf;
	zy *= zf;
	zz *= zf;
    }
    /** rotate theta degrees about the y axis */
    void yrot(double theta) {
	theta *= (pi / 180);
	double ct = Math.cos(theta);
	double st = Math.sin(theta);

	double Nxx = (double) (xx * ct + zx * st);
	double Nxy = (double) (xy * ct + zy * st);
	double Nxz = (double) (xz * ct + zz * st);

	double Nzx = (double) (zx * ct - xx * st);
	double Nzy = (double) (zy * ct - xy * st);
	double Nzz = (double) (zz * ct - xz * st);

	xx = Nxx;
	xy = Nxy;
	xz = Nxz;
	zx = Nzx;
	zy = Nzy;
	zz = Nzz;
    }
    /** rotate theta degrees about the x axis */
    void xrot(double theta) {
	theta *= (pi / 180);
	double ct = Math.cos(theta);
	double st = Math.sin(theta);

	double Nyx = (double) (yx * ct + zx * st);
	double Nyy = (double) (yy * ct + zy * st);
	double Nyz = (double) (yz * ct + zz * st);

	double Nzx = (double) (zx * ct - yx * st);
	double Nzy = (double) (zy * ct - yy * st);
	double Nzz = (double) (zz * ct - yz * st);

	yx = Nyx;
	yy = Nyy;
	yz = Nyz;
	zx = Nzx;
	zy = Nzy;
	zz = Nzz;
    }
    /** rotate theta degrees about the z axis */
    void zrot(double theta) {
	theta *= (pi / 180);
	double ct = Math.cos(theta);
	double st = Math.sin(theta);

	double Nyx = (double) (yx * ct + xx * st);
	double Nyy = (double) (yy * ct + xy * st);
	double Nyz = (double) (yz * ct + xz * st);

	double Nxx = (double) (xx * ct - yx * st);
	double Nxy = (double) (xy * ct - yy * st);
	double Nxz = (double) (xz * ct - yz * st);

	yx = Nyx;
	yy = Nyy;
	yz = Nyz;
	xx = Nxx;
	xy = Nxy;
	xz = Nxz;
    }
    /** Multiply this matrix by a second: M = M*R */
    void mult(Matrix3D rhs) {
	double lxx = xx * rhs.xx + yx * rhs.xy + zx * rhs.xz;
	double lxy = xy * rhs.xx + yy * rhs.xy + zy * rhs.xz;
	double lxz = xz * rhs.xx + yz * rhs.xy + zz * rhs.xz;

	double lyx = xx * rhs.yx + yx * rhs.yy + zx * rhs.yz;
	double lyy = xy * rhs.yx + yy * rhs.yy + zy * rhs.yz;
	double lyz = xz * rhs.yx + yz * rhs.yy + zz * rhs.yz;

	double lzx = xx * rhs.zx + yx * rhs.zy + zx * rhs.zz;
	double lzy = xy * rhs.zx + yy * rhs.zy + zy * rhs.zz;
	double lzz = xz * rhs.zx + yz * rhs.zy + zz * rhs.zz;

	xx = lxx;
	xy = lxy;
	xz = lxz;

	yx = lyx;
	yy = lyy;
	yz = lyz;

	zx = lzx;
	zy = lzy;
	zz = lzz;
    }

    /** Reinitialize to the unit matrix */
    void unit() {
	xx = 1;
	xy = 0;
	xz = 0;
	yx = 0;
	yy = 1;
	yz = 0;
	zx = 0;
	zy = 0;
	zz = 1;
    }

    // Transform the nodes of the graph into the nodes as seen from the 
    // viewing plane.
    //
    void transform(GRGraph graph) {
	double lxx = xx, lxy = xy, lxz = xz;
	double lyx = yx, lyy = yy, lyz = yz;
	double lzx = zx, lzy = zy, lzz = zz;

	for (int i = 0; i < graph.numnodes() ; i++) {
	    double x = graph.nodes()[i].x();
	    double y = graph.nodes()[i].y();
	    double z = graph.nodes()[i].z();
	
	    double tx = x * lxx + y * lxy + z * lxz; 
	    double ty = x * lyx + y * lyy + z * lyz;
	    double tz = x * lzx + y * lzy + z * lzz;
	    
	    graph.nodes()[i].settx(tx);
	    graph.nodes()[i].setty(ty);
	    graph.nodes()[i].settz(tz);
	}
    }

    // Projects 3d graph onto the viewing plane
    //
    void project(GRGraph graph) {
	double lxx = xx, lxy = xy, lxz = xz;
	double lyx = yx, lyy = yy, lyz = yz;
	double lzx = zx, lzy = zy, lzz = zz;

	for (int i = 0; i < graph.numnodes() ; i++) {
	    double x = graph.nodes()[i].x();
	    double y = graph.nodes()[i].y();
	    double z = graph.nodes()[i].z();
	
	    double tx = x * lxx + y * lxy + z * lxz; 
	    double ty = x * lyx + y * lyy + z * lyz;
	    
	    graph.nodes()[i].setx(tx);
	    graph.nodes()[i].sety(ty);
	    graph.nodes()[i].setz(0);
	
     	    unit();
	}
    }

    // Takes the u,v coordinates and uses vector parallel to view 
    // vector to calculate universal coordinates - 
    //   needed for adding and moving nodes
    //
    public void setNodePosition(Node node, double u, double v)
    {
	double lxx = xx, lxy = xy, lxz = xz;
	double lyx = yx, lyy = yy, lyz = yz;
	double lzx = zx, lzy = zy, lzz = zz;
	double x,y,z;
	
	x = u * lxx + v*lyx + node.tz()*lzx;
	y = u * lxy + v*lyy + node.tz()*lzy;
	z = u * lxz + v*lyz + node.tz()*lzz;	

	node.setx(x);
	node.sety(y);
	node.setz(z);
    }

    public String toString() {
	return ("[" + xx + "," + xy + "," + xz + ";"
		+ yx + "," + yy + "," + yz + ";"
		+ zx + "," + zy + "," + zz + "]");
    }
}







