package sprite;

import java.awt.*;

public class TextSprite extends Sprite {
    Color color_;
    Font font_;
    String text_;
    int width_, height_, ascent_;
    
    public TextSprite(SpriteArea area, int x, int y, String text) {
	super(area, x, y);
	color_ = Color.black;
	font_ = new Font("Helvetica", Font.BOLD, 14);
	text_ = text;
	RecomputeSize();
    }

    public void SetColor(Color color) {
	color_ = color;
	Redraw();
    }

    public void SetFont(Font font) {
	font_ = font;
	RecomputeSize();
	Redraw();
    }

    public void SetText(String text) {
	text_ = text;
	RecomputeSize();
	Redraw();
    }

    public Font GetFont() {
	return font_;
    }
    
    public int GetWidth() {
	return width_;
    }
    
    public int GetHeight() {
	return height_;
    }

    public boolean Inside(int x, int y) {
        int xOff = x - x_;
        int yOff = y - y_;
        return (xOff > 0 && xOff < width_ &&
		yOff > 0 && yOff < height_);
    }
    
    public void Draw(Graphics g) {
	g.setFont(font_);
	g.setColor(color_);
	g.drawString(text_, x_, y_ + ascent_);
    }

    void RecomputeSize() {
	FontMetrics m = area_.getFontMetrics(font_);
	ascent_ = m.getAscent();
	width_ = m.stringWidth(text_);
	height_ = ascent_ + m.getDescent();
    }
}
