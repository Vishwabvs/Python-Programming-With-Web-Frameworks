import java.util.*;
import java.awt.*;

import LayoutAlgorithm;
import Node;
import WebTree;

public class PostOrderAlgorithm extends LayoutAlgorithm
{

   private int leftAlign_ = 20;
   
   private int topAlign_ = 20;
   
   private int boxWidth_ = 25;
   private int boxHeight_ = 40;
   
   final private boolean DEBUG = false;

   WebTree wt_;


// CONSTRUCTOR ///////////////////////////////////////////////////////
   
   PostOrderAlgorithm (WebTree wt)
   {

      wt_ = wt;

   }


// EXECUTE //////////////////////////////////////////////////////////
   
public void execute (Vector nodeList)
  {

     if (DEBUG) System.out.println("post-order algorithm execute called");

    int total = nodeList.size();
    if (DEBUG) System.out.println("total nodes: " + total);
    
    if (total == 0) return;

    
    Node root = (Node)nodeList.elementAt(0);


    
    if (DEBUG) System.out.println("Computing bounding boxes...");

    DoBoundingBoxes(root); // postorder traversal

    
    
    if (DEBUG) System.out.println("Computing box origins...");

    // preorder traversal

    DoBoxOrigins(root, new Point(leftAlign_, topAlign_));

    

    if (DEBUG) System.out.println("Computing node positions...");
    
    DoNodePositions(root); // postorder traversal

    wt_.snapTo(root.getPosition());
    
  }


// DO BOUNDING BOXES /////////////////////////////////////////////
   
private void DoBoundingBoxes (Node node)
  {

     for (Node child = node.getFirstChild(); child != null;
          child = child.getSibling()) {
        
        DoBoundingBoxes(child);
        
     }

     DoBoundingBox(node);
    
  }


// DO BOUNDING BOX ///////////////////////////////////////////////
   
private void DoBoundingBox (Node node)
   {

      if (node.isLeaf()) {

         node.setWidth(boxWidth_);
         node.setHeight(boxHeight_);
         
      } else {

         Node child;
         
         node.setWidth(0);

         for (child = node.getFirstChild(); child != null;
              child = child.getSibling()) {
            
            node.setWidth(node.getWidth() + child.getWidth());
            
         }

         // height = (max of heights of children) + 1
         
         node.setHeight(0);

         for (child = node.getFirstChild(); child != null;
              child = child.getSibling()) {

            if (child.getHeight() > node.getHeight())
               node.setHeight(child.getHeight());
            
         }

         node.setHeight(node.getHeight() + 1);
      }

      if (DEBUG) System.out.println(node.getId() + "'s width: " +
                                    node.getWidth() + ", height: " +
                                    node.getHeight());
      
   }


// DO BOX ORIGINS ////////////////////////////////////////////////
   
private int DoBoxOrigins (Node node, Point p)
   {

      node.setOrigin(new Point(p.x, p.y)); // new ?

      if (DEBUG) System.out.println(node.getId() + "'s origin: [" +
                                    node.getOrigin().x + ", " +
                                    node.getOrigin().y + "]");
      
      int first_childs_width = 0;
      Point p2 = new Point(0, 0);

      for (Node child = node.getFirstChild(); child != null;
           child = child.getSibling()) {
         
         p2.x = p.x + first_childs_width;
         p2.y = p.y + boxHeight_;
         first_childs_width += DoBoxOrigins(child, p2);
         
      }

      return node.getWidth();

   }


// DO NODE POSITIONS ////////////////////////////////////////////
   
private void DoNodePositions(Node node)
   {

      for (Node child = node.getFirstChild(); child != null;
           child = child.getSibling()) {
         DoNodePositions(child);
      }

      DoNode(node);
      
   }


// DO NODE ////////////////////////////////////////////////////////
   
private void DoNode(Node node)
   {

      Point orig = node.getOrigin();

      int x = orig.x;
      int y = orig.y;

      int w = node.getWidth();
      int h = node.getHeight();

      Point newPos = new Point(0, 0);

      newPos.y = orig.y;


      if (node.isLeaf()) {

         // position at box midpoint
         
         newPos.x = orig.x + w / 2;


      } else {

         // position at midpoint between leftmost and rightmost child

         int xl = -1, xr = -1;

         for (Node child = node.getFirstChild(); child != null;
              child = child.getSibling()) {

            if (xl == -1) xl = child.getPosition().x;

            xr = child.getPosition().x;
            
         }

         newPos.x = (xl + xr) / 2;
         
      }  

      node.setPosition(newPos);

      if (DEBUG) System.out.println(node.getId() + "'s position: [" +
                                    node.getPosition().x + ", " +
                                    node.getPosition().y + "]");
      
   }

}
