import java.io.IOException;
import java.awt.*;

import java.util.*;
import java.io.*;
import java.lang.*;
import geometry.*;
import Box;
import VCRPanel;
import VCR;
import GridSpacingSlider;
import VCRSpeedSlider;
import NameTile;

public class AnimatorGeometryClient extends GeometryClient {
/*
 * Instance data -- set later
 */

protected VCRPanel control_panel_;
protected VCR vcr_;
protected Box   user_input_area_;
protected Color active_color_, inactive_color_;
protected boolean last_position_active_=false;
protected GridSpacingSlider 	grid_spacing_slider_;
protected VCRSpeedSlider	vcr_speed_slider_;
private final static int NAME_WIDTH_ = 50;
protected int old_grid_spacing_=0;

   public AnimatorGeometryClient()
   {
	super();
	control_panel_ = new VCRPanel();
	vcr_ = new VCR();
	control_panel_.setVCR(vcr_);
   }




public void init()
{
	super.init();
	user_input_area_ = new Box(1,
				   size().height/2,
				   size().width-2,
				   (size().height/2)-1);
	active_color_=   attribute("activeboundary_color",Color.red);
	inactive_color_= attribute("inactiveboundary_color",Color.blue);

	user_input_area_.setColor(inactive_color_);
	// active/inactive colors are to differentiate between when
	// the mouse is inside the user area or not
	user_input_area_.setActive(true);

	Panel p = new Panel();
	p.setLayout(new GridLayout(1,0));
	
	grid_spacing_slider_ = new GridSpacingSlider(this);
	vcr_speed_slider_ = new VCRSpeedSlider(this);


	NameTile name1 = new NameTile("Animation delay:",
					NAME_WIDTH_,
					vcr_speed_slider_.size().height);

	NameTile name2 = new NameTile("Grid spacing:",
					NAME_WIDTH_,
					grid_spacing_slider_.size().height);

	p.add(name1);
	p.add(vcr_speed_slider_);
	p.add(name2);
	p.add(grid_spacing_slider_);
	control_panel_.add("South", p);
	add("South", control_panel_);

	vcr_speed_slider_.SetMaximum(1000);
	vcr_speed_slider_.SetValue(500);

	grid_spacing_slider_.SetMinimum(20);
	grid_spacing_slider_.SetMaximum(100);
	grid_spacing_slider_.SetValue(gridSpacing);

	old_grid_spacing_= gridSpacing;
   }


/**
 * Draws the background for the derived applets.  Extended by
 * subclassed geometry clients to draw other geometry components.
 */
public void draw(Graphics g)
{
   if (imBackground != null)
      g.drawImage (imBackground, 0, 0, this);
 
   else 
   {
      g.fill3DRect(0, 0, size().width, size().height, true);
      g.setColor(Color.darkGray);
   }
   bBox.draw(g);
   user_input_area_.draw(g);
}



public boolean mouseDown(Event evt, int x, int y)
{
	if (user_input_area_.inside(x,y))
	{	
		if (GRIDSWITCH.equals(GRIDOFF))
		  {
		    Point gpt = findClosestGridPoint(x,y,gridSpacing);
			x = gpt.x;
			y = gpt.y;		    
		  }
		resetSelectionRectangle(x,y);
		if(evt.metaDown())
		{
			unSelectPts();
			//resetSelectionRectangle(x,y);
		}
		return super.mouseDown(evt, x, y);
	}
	return false;
}

/** Adds a point upon a mouseUp.
 */
public boolean mouseUp(Event evt, int x, int y)
{
	if (user_input_area_.inside(x,y))
	  {
	    if (GRIDSWITCH.equals(GRIDOFF))
		  {
		    Point gpt = findClosestGridPoint(x,y,gridSpacing);
		    x = gpt.x;
		    y = gpt.y;		    
		  }
	    return super.mouseUp(evt, x, y);
	  }
	return false;
}

public boolean mouseDrag(Event evt, int x, int y)
{
	// actually we should check all selected points
	if (user_input_area_.inside(x,y))
	{
	  if (GRIDSWITCH.equals(GRIDOFF))
	    {
	      Point gpt = findClosestGridPoint(x,y,gridSpacing);
	      x = gpt.x;
	      y = gpt.y;		    
	    }
	  return super.mouseDrag(evt, x, y);	
	}
	return false;
}


public boolean mouseMove(Event evt, int x, int y)
{
	// redraw the rect only when mouse crosses boundary of the
	// user input region

	if (user_input_area_.inside(x,y) &&  !last_position_active_)
	{
	  //System.out.println("Drawing active box in red");
		last_position_active_ = true;
		user_input_area_.setColor(active_color_);
		user_input_area_.draw(grOffscreen);
		myGeometryPanel.getGraphics().drawImage(imOffscreen, 0, 0, this);
	}
	else if (!user_input_area_.inside(x,y) && last_position_active_)
	{
	  //System.out.println("Drawing deactivated box in blue");
		last_position_active_ = false;
		user_input_area_.setColor(inactive_color_);
		user_input_area_.draw(grOffscreen);
		myGeometryPanel.getGraphics().drawImage(imOffscreen, 0, 0, this);
	}
	return true;
}

public boolean mouseEnter(Event evt, int x, int y)
{
	return true;
}
public boolean mouseExit(Event evt, int x, int y)
{
	return true;
}


public boolean action(Event evt, Object arg) 
{	
	if (UNSELECTNODES.equals(arg) || CLEARGRAPH.equals(arg)
		|| DELETENODES.equals(arg))
	     resetSelectionRectangle();
	return super.action(evt, arg);
}


public void resetSelectionRectangle(int x, int y)
{
	bBox.setOrigPt(x,y);
	bBox.setPt(x,y);
}

public void resetSelectionRectangle()
{
	bBox.setOrigPt(0,0);
	bBox.setPt(0,0);
}



public void asyncRecalculate()
{
	resetSelectionRectangle();
	super.asyncRecalculate();
}

public VCRPanel getVcrPanel()
{
	return control_panel_;
}

public void removePointsNotOnGrid(int grid_spacing)
{
	  // must subclass
}
public void gridSpacingChanged(int old_grid_spacing, int new_grid_spacing)
{
  // must subclass
}
public void setGridSpacing(int n)
{
	old_grid_spacing_=gridSpacing;
	gridSpacing = n;
	vcr_.eject();
	if (GRIDSWITCH.equals(GRIDOFF))
	{
	        removePointsNotOnGrid(old_grid_spacing_);
	        gridSpacingChanged(old_grid_spacing_, gridSpacing);
		initBackground (imBackground, imBackTile,
             		        attribute ("grid_color", Color.lightGray),
         	      		gridSpacing, 0, 0, 
		      		size().width, 
	              		size().height); 
		myGeometryPanel.repaint();
	}
}

	protected int calcClosestGrid(int i, int grid_spacing)
	{
		int dx = i % grid_spacing;
		if (dx > (grid_spacing/2))
			 return (i + grid_spacing - dx);
		else 	 return (i - dx);
	}
	protected Point findClosestGridPoint(	int x,
						int y,
						int grid_spacing)
	{
		int temp_x = calcClosestGrid(x, grid_spacing);
		int temp_y = calcClosestGrid(y, grid_spacing);
		return new Point(temp_x, temp_y);
	}

};



