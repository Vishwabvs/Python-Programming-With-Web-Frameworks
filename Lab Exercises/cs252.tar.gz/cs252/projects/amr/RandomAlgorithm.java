import java.util.*;
import java.awt.*;

import LayoutAlgorithm;
import Node;
import WebTree;

public class RandomAlgorithm extends LayoutAlgorithm {

   final private int RADIUS = 10;
   final private int DIAMETER = RADIUS * 2;
   
   private WebTree wt_;
   private int width_, height_;
   private int offScreenWidth_, offScreenHeight_;
   private int centerX_, centerY_;

   final private boolean DEBUG = false;
   
   
   // CONSTRUCTOR ////////////////////////////////////////////////////
   
   RandomAlgorithm (WebTree wt)
   {
      wt_ = wt;

      width_ = wt_.getWidth();
      height_ = wt_.getHeight();

      offScreenWidth_ = wt_.getOffScreenWidth();
      offScreenHeight_ = wt_.getOffScreenHeight();

      centerX_ = offScreenWidth_ / 2;
      centerY_ = offScreenHeight_ / 2;

   }


   // EXECUTE ///////////////////////////////////////////////////////
   
public void execute (Vector nodeList)
  {

    System.out.println("random algorithm execute called");

    int total = nodeList.size();
    System.out.println("total nodes: " + total);
    
    if (total == 0) return;

    if (DEBUG) {

       System.out.println("(" + width_ + " x " + height_ + ") of (" +
                          offScreenWidth_ + " x " + offScreenHeight_ +
                          ")");

       System.out.println("[" + centerX_ + ", " + centerY_ + "]");

    }
    
    Date date = new Date();

    Random random = new Random();

    random.setSeed(date.getTime());

    int xRange = total * DIAMETER;
    int yRange = total * DIAMETER;

    if (xRange < width_) xRange = width_;
    else if (xRange > offScreenWidth_) xRange = offScreenWidth_;
    
    if (yRange < height_) yRange = height_;
    else if (yRange > offScreenHeight_) yRange = offScreenHeight_;

    if (DEBUG) System.out.println("(0.." + xRange + "), (0.." + yRange +
                                  ")");
    
    for (int i = 0; i < total; i++) {
       
      Node tempNode = (Node)nodeList.elementAt(i);

      int x = (int)(random.nextDouble() * (xRange - DIAMETER)) + RADIUS;
      int y = (int)(random.nextDouble() * (yRange - DIAMETER)) + RADIUS;

      if (DEBUG) System.out.println("[" + x + ", " + y + "]");
      
      x += centerX_ - xRange / 2;
      y += centerY_ - yRange / 2;
      
      tempNode.setPosition(new Point(x, y));

      if (DEBUG) System.out.println("[" + x + ", " + y + "]");
    }

    wt_.snapTo(new Point(centerX_, centerY_));
    
  }

}
