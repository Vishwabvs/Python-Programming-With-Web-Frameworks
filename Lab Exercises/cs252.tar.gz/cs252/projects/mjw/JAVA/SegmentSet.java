import java.awt.*;
import java.util.*;
import java.io.*;
import java.awt.image.ImageObserver;
import geometry.*;
import Box;
import GeometryLine;
import Segment;

/****************************************************************/
/*    NAME:                                                     */
/*    ACCT: mjw                                                 */
/*    FILE: SegmentSet.java                                     */
/*    ASGN:                                                     */
/*    DATE: Wed Jun 19 18:09:45 1996                            */
/****************************************************************/
                             


import java.util.Vector;
import geometry.*;

public class SegmentSet {
	
	protected Vector segments_;
	protected int minX_=0, minY_=0, maxX_=0, maxY_=0;
	protected Color selected_segment_color_ = Color.red;
	protected Color unselected_segment_color_ = Color.blue;
	protected int default_thickness_ = 2;
	final static int MIDDLE = 0;
	final static int LEFT = 1;
	final static int RIGHT = 2;

  	//***************************************************
	public SegmentSet()
	//***************************************************	
	{
	 	segments_ = new Vector();
	}                            
	//***************************************************
	public Segment addSegment(Point s, Point e)
	//***************************************************
	{
		Segment sg = addSegment(s, e, null, null, null);
		sg.setSelectedColor(selected_segment_color_);
		sg.setUnselectedColor(unselected_segment_color_);
		return sg;
	}
	//***************************************************
	public Segment addSegment(Point s,
				  Point e,
				  Image sel_im,
				  Image unsel_im,
				  ImageObserver obs)
	//***************************************************
	{
		//System.out.println("in SegmentSet::addSegment");
		Segment sg = new Segment(s, e, default_thickness_);
		if (sel_im != null && unsel_im != null && obs != null)
			sg.setEndPointImg(sel_im, unsel_im, obs);
		segments_.addElement(sg);
		return sg;
	}

	//***************************************************
        public Segment elementAt(int i)
	//***************************************************
        {
             return (Segment)(segments_.elementAt(i));
        }
  
	//***************************************************
	// only works for horizontal segments               
	public Segment findSegment(int x, int y)
	//***************************************************
	{
		//System.out.println("in findSegment");
		Segment s;
		//System.out.println();
		//System.out.println(segments_.size() + " segments.");
		for (Enumeration e = segments_.elements(); e.hasMoreElements();)
		{
		   s = (Segment) e.nextElement();	 		
		   if (s.inside(x,y))
		   {
		      //System.out.println("#######    found segment    #######");
		      return s;
		   }
		}
		//System.out.println("did not find segment");
		return null;
	}

	//***************************************************
	public Segment findSegment(Segment sg)
	//***************************************************
	{
	       for (Enumeration e = segments_.elements(); e.hasMoreElements();)
	       {
		 Segment s = (Segment) e.nextElement();
		 if(s.equals(sg))
			  return sg;
	       }
	       return null;
	}



	//***************************************************
        public void setThickness(int t)
	//***************************************************
        {
	        if (t > 0)
		  default_thickness_ = t;
        }

	//***************************************************
	public boolean contains(Segment sg)
	//***************************************************
        {
             for (Enumeration e = segments_.elements(); e.hasMoreElements();)
             {
               Segment s = (Segment) e.nextElement();
	       if(s.equals(sg))
	          return true;
             }     
             return false;
        }

  	//***************************************************
	public void moveSegment(Segment s, int offx, int offy)
	//***************************************************
	{
	 	Point start = s.getFrom();
	 	Point end   = s.getTo();

		start.x += offx;
		start.y += offy;
		end.x   += offx;
		end.y   += offy;
			         
		checkBounds(start);
		checkBounds(end); 	

		s.setFrom(start);
		s.setTo(end);	 	
	}


	//***************************************************
	public void moveEndPoint(Segment s, int end_pt, int offx)
	//***************************************************
	{
		Point endp;	
		if (end_pt == LEFT)
		{
	 		endp  = s.getFrom();
			endp.x += offx;
			s.setFrom(endp);
		}
		else if (end_pt == RIGHT)
		{
		  	endp = s.getTo();
			endp.x += offx;
			s.setTo(endp);
		}
	}


	//***************************************************
	public int isClickOnEndPoint(Segment s, int x, int y)
	//***************************************************
	{
		Point start = s.getFrom();
	 	Point end   = s.getTo();
		int width, height;
		Image im;
		ImageObserver im_obs = s.getImgObserver();
		// check if dragging one of the endpoints
		if (im_obs != null)
		{
			if (s.isSelected())
				im = s.getSelectedEndPointImg();
			else 	im = s.getUnselectedEndPointImg();
			width = im.getWidth(im_obs);
			height =im.getHeight(im_obs);
		}
		else
		{
			width = 3; // for now
			height = s.getThickness();
		}
		if (start.x <= x && x <=(start.x+width) &&
			(start.y-(height/2)) <= y && y <= start.y+(height/2))
		// dragging left end-point
		{
			//System.out.println("\n\n  MOVING LEFT POINT");
			return LEFT;
		}
		else if ((end.x-width) <=x && x <= end.x &&
			end.y-(height/2) <= y && y <= end.y+(height/2))
		// dragging right point
		{
			//System.out.println("\n\n  MOVING RIGHT POINT");
			return RIGHT;
		}
		return MIDDLE;
	}


	//***************************************************
	protected boolean checkBounds(Point p)
	//***************************************************
	{
		boolean ok = true;
	 	if (p.x < minX_)
		{
			ok = false;
	 		p.x = minX_;
		}
		if (p.y < minY_)
		{
			ok = false;
			p.y = minY_;
		}
		if (p.x > maxX_)
		{
			ok = false;
			p.x = maxX_;
		}
		if (p.y > maxY_)
		{
			ok = false;
			p.y = maxY_;
		}
		return ok;
	}
	//***************************************************
	public void removeSegment(Segment s)
	//***************************************************
	{
		segments_.removeElement(s);	
	} 
	
	//***************************************************
	public void clearSegments()
	//***************************************************
	{
	 	segments_.removeAllElements();
	}    
	
	//***************************************************
	public void removeSelectedSegments()
	//***************************************************
	{             
		Segment s;
		for (Enumeration e = segments_.elements(); e.hasMoreElements();)
		  {
		    s = (Segment) e.nextElement();
		    if (s.isSelected())
		      removeSegment(s);		   
		  }
	}                            

	//***************************************************
	public void unselectSegments()
	//***************************************************
	{
	    Segment s;
	    for (Enumeration e = segments_.elements(); e.hasMoreElements();)
		  {
		    s = (Segment) e.nextElement();
		    if (s.isSelected())
		      s.setSelected(false);		   
		  }
	}                                

	//***************************************************
        public int numSelectedSegments()
	//***************************************************
        {
	  int counter=0; Segment s;
	  for (Enumeration e = segments_.elements(); e.hasMoreElements();)
		  {
		    s = (Segment) e.nextElement();
		    if (s.isSelected())
		      counter++;
		  }
	  return counter;
        }
	//***************************************************	
	public void moveSelectedSegments(int offx, int offy)
	//***************************************************
	{
		if (allAreMovable(offx, offy))
		{
                	Segment s;
			for (Enumeration e = segments_.elements(); e.hasMoreElements();)
		  	{
		    		s = (Segment) e.nextElement();
		    		if (s.isSelected())
		   	   	moveSegment(s, offx, offy);		   
		  	}
		}
	}
	//***************************************************
	public boolean allAreMovable(int offx, int offy)
	//***************************************************
	{
		boolean ok = true;
		Segment s;
		for (Enumeration e = segments_.elements(); e.hasMoreElements();)
		  	{
		    		s = (Segment) e.nextElement();
		    		Point st = s.getFrom();
				Point en = s.getTo();
				st.x += offx;
				st.y += offy;
				en.x += offx;
				en.y += offy;
		   	   	if (!checkBounds(st) || !checkBounds(en))
					ok =  false;
		  	}
		return ok;
	}

	//***************************************************
	public void selectSegment(int x, int y)
	//***************************************************
	{
	 	Segment s = findSegment(x,y);
	 	if (s != null)
	 	{
	 	 	s.setSelected(true);
	 	}
	}

	//***************************************************
	public void selectSegment(Segment s)
	//***************************************************
	{
	 	if (s != null)
	 	 	s.setSelected(true);
	}

	//***************************************************
	public void unselectSegment(Segment s)
	//***************************************************
	{
	 	if (s != null)
	 	 	s.setSelected(false);
	}

	//***************************************************
	public void unselectSegment(int x, int y)
	//***************************************************
	{
	 	Segment s = findSegment(x,y);
	 	if (s != null)
	 	 	s.setSelected(false);
	}

	public void setSelectedColor(Color c)
	{
		Segment s;
		for (Enumeration e = segments_.elements(); e.hasMoreElements();)
		  {
		    s = (Segment) e.nextElement();
		    s.setSelectedColor(c);
		  }
		selected_segment_color_ = c;
	}
	public void setUnselectedColor(Color c)
	{
		Segment s;
		for (Enumeration e = segments_.elements(); e.hasMoreElements();)
		  {
		    s = (Segment) e.nextElement();
		    s.setUnselectedColor(c);
		  }
		unselected_segment_color_ = c;
	}


       
	//***************************************************	
        public void draw (Graphics g,  Box bounding_box)
	//***************************************************
        {
          Segment s;
	  bounding_box.clearTickMarks(Box.TOP);
          for (Enumeration e = segments_.elements(); e.hasMoreElements();)
          {
              s = (Segment) e.nextElement();
	      Point start = s.getFrom();
	      Point end = s.getTo();
	      // set the corresponding tick marks
	      bounding_box.setTickMark(Box.TOP, start.x);
	      bounding_box.setTickMark(Box.TOP, end.x);
	      s.draw(g);
          }
        }


	//***************************************************
	public void write(PrintStream os)
	//***************************************************
	{
	    Segment s;
	    for (Enumeration e = segments_.elements(); e.hasMoreElements();)
	    {
	      s = (Segment) e.nextElement();
	      s.print(os);
      	    }
	    os.println();
	}
	//***************************************************
	public int numSegments()
	//***************************************************
	{
	  return segments_.size ();
	}

	//***************************************************
	public void setLimits(int x0, int y0, int x1, int y1)
	//***************************************************
	{
            minX_=x0;
            minY_=y0;
            maxX_=x1;
            maxY_=y1;
        }

	public void gridSpacingChanged(	int old_grid_spacing,
					int new_grid_spacing,
					Box bounding_box)
	{
	    Segment s;
	    for (Enumeration e = segments_.elements(); e.hasMoreElements();)
	    {
	      	s = (Segment) e.nextElement();

	      	Point start = s.getFrom();
	      	Point end = s.getTo();

		int dx = end.x - start.x;
		int ratio_width = dx / old_grid_spacing;
		int ratio_x = start.x / old_grid_spacing;
		int ratio_y = start.y / old_grid_spacing;
	

		start.x = ratio_x * new_grid_spacing;
		start.y = ratio_y * new_grid_spacing;

		end.x = start.x + (ratio_width * new_grid_spacing);
		end.y = start.y;

		s.setFrom(start);
		s.setTo(end);	      
      	    }
	}


	// yes this is duplicated code (from SegmentTree) but it's
	// one of those late-night, quickie, fixes

	protected int calcClosestGrid(int i, int grid_spacing)
	{
		int dx = i % grid_spacing;
		if (dx > (grid_spacing/2))
			 return (i + grid_spacing - dx);
		else 	 return (i - dx);
	}

	protected Point findClosestGridPoint(	int x,
						int y,
						int grid_spacing)
	{
		int temp_x = calcClosestGrid(x, grid_spacing);
		int temp_y = calcClosestGrid(y, grid_spacing);
		return new Point(temp_x, temp_y);
	}



};

