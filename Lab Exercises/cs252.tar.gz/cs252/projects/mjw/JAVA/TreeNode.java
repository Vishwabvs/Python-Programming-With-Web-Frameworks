import java.awt.*;
import java.awt.image.*;
import java.util.Vector;
import java.util.Enumeration;
import java.util.Stack;
import java.io.PrintStream;
import java.io.StreamTokenizer;
import java.io.InputStream;
import geometry.*;


class TreeNode
{
   protected int   id_, begin_, median_, end_;
   protected GeometryPoint node_;
   protected TreeNode left_child_;
   protected TreeNode right_child_;
   protected boolean selected_=false;
   protected boolean left_edge_selected_=false;
   protected boolean right_edge_selected_=false;
   protected boolean is_allocation_node_ = false;

public TreeNode (int id, int x, int y)
{
        id_ = id;
	begin_ = median_ = end_ = 0;
	node_ = new GeometryPoint(x, y);
	
	left_child_  = null;
	right_child_ = null;
}

public TreeNode (GeometryStreamTokenizer st) {

	int x,y;
	left_child_  = null;
	right_child_ = null;
	begin_ = median_ = end_ = 0;
	
	try {
		id_  = nextInt(st);
	} catch (GeometryException e) {
		//System.out.println("error: "+e.getMessage());
		id_ = -1;
		node_ = new GeometryPoint(-1, -1);
		return;
	}
	// since GeometryPoint constructor does not propagate
	// exceptions from the st, we have to read st
	// ourselves
	try {
		x = nextInt(st);
	} catch (GeometryException e) {
		//System.out.println("error: "+e.getMessage());
		node_ = new GeometryPoint(-1, -1);
		return;
	}
	try {
		y = nextInt(st);
	}catch (GeometryException e) {
		//System.out.println("error: "+e.getMessage());
		node_ = new GeometryPoint(-1, -1);
		return;
	}
	node_ = new GeometryPoint(x,y);

	try {
		begin_ = nextInt(st);
	}catch (GeometryException e) {
		//System.out.println("error: "+e.getMessage());
		return;
	}
	try {
		median_ = nextInt(st);
	}catch (GeometryException e) {
		//System.out.println("error: "+e.getMessage());
		return;
	}
	try {
		end_ = nextInt(st);
	}catch (GeometryException e) {
		//System.out.println("error: "+e.getMessage());
	}
   }


   private int nextInt(GeometryStreamTokenizer st) throws GeometryException {
	int type;
	try {
		type = st.nextToken();
	} catch (java.io.IOException e) {
		//System.out.println(e.toString());
		throw new GeometryException(e.toString());
        }
	if (type != st.TT_NUMBER)
	{
		//System.out.println("Throwing am exception: newline");
		throw new GeometryException
			("Expected to read an integer" );
	}
	return (int) (st.nval + 0.5);
   }

   public int getID() {
      return id_;
   }

   public void setLeftChild(TreeNode n) {
      left_child_ = n;
   }

   public void setRightChild(TreeNode n) {
      right_child_ = n;
   }

   public void setX(int x) {
      node_.x = x;
   }

   public void setY(int y) {
      node_.y = y;
   }

   public int getX() {
      return node_.x;
   }

   public int getY() {
      return node_.y;
   }

   public TreeNode getLeftChild() {
      return left_child_;
   }

   public TreeNode getRightChild() {
      return right_child_;
   }

   public boolean equal(TreeNode node) {
      return (id_ == node.getID());
   }

   public boolean valid() {
      return (node_.x != -1 && node_.y != -1);
   }

   public void setSelected(boolean s)
   {
	selected_ = s;
   }

   public boolean isSelected()
   {
	return selected_;
   }

   public void setAllocationNode(boolean b)
   {
	is_allocation_node_ = b;	
   }

   public boolean isAllocationNode()
   {
	return is_allocation_node_;
   }

   public void setLeftEdgeSelected(boolean s)
   {
	left_edge_selected_ = s;
   }

   public void setRightEdgeSelected(boolean s)
   {
	right_edge_selected_= s;
   }

   public boolean isLeftEdgeSelected()
   {
	return left_edge_selected_;
   }

   public boolean isRightEdgeSelected()
   {
	return right_edge_selected_;
   }

   public int getBegin()
  {
    return begin_;
  }

  public int getMedian()
  {
    return median_;
  }

  public int getEnd()
  {
    return end_;
  }

  public void setBegin(int b)
  {
    begin_ = b;
  }
  public void setMedian(int m)
  {
    median_ = m;
  }
  public void setEnd(int e)
  {
    end_ = e;
  }
}


