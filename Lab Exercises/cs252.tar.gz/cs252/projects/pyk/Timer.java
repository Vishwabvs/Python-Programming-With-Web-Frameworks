/*
 * Timer.java
 *
 * Description:
 *    This class is used to as a timer thread in order to implement
 *    callbacks and asynchronous events.
 *    The definition of a tick is in interface timed.
 */
class Timer extends Thread
{
   private Timed target;          // the caller's tick routine
   private int interval;          // sleep interval
   private boolean stillRunning;  // flag that represents the state of
                                  // the thread
   public boolean operationDone;  // flag set when the asynchronous event
                                  // is done

   // cosntructor for the timer
   public Timer(Timed t, int i)
   {
      target = t;
      interval = i;
      stillRunning = true;
      operationDone = false;
   }

   // set operation done flag
   public void setOperationDone()
   {
      operationDone = true;
   }

   // indicate that the thread should stop running
   public void stopRunning()
   {
      stillRunning = false;
   }

   // while the thread is still running, sleep for the specified interval,
   // wakeup, and invoke the caller's tick method
   public void run()
   {
      while (stillRunning)
      {
         try
         {
            sleep(interval);
         }
         catch(InterruptedException e)
         {
         }
         target.tick(this);
      }
   }
}