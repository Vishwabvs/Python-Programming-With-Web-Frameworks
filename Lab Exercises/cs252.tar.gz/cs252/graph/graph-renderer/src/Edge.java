/*
 *  Edge - edge object
 *  4/14/96 
 *  by Daniel Spirn 
 *
 */
package graphrender;

import java.awt.*;
import java.applet.*;

class Edge extends Object
{
    // The two nodes of the edge
    Node node1_;
    Node node2_; 

    // Whether an edge has been selected (different color)
    boolean selected_ = false;

    // Whether an edge has been locked (NOT IMPLEMENTED)
    boolean locked_ = false;

    // Next and Previous edges in the linked list
    Edge next_,prev_;

    Edge(Node n1, Node n2)
    {
	node1_ = n1;
	node2_ = n2;
	next_ = null;
    }

    public Node node1()
    {
	return(node1_);
    }

    public Node node2()
    {
	return(node2_);
    }

    public Edge next()
    {
	return(next_);
    }

    public Edge prev()
    {
	return(prev_);
    }

    public void setnext(Edge newnext)
    {
	next_ = newnext;
	return;
    }

    public void setprev(Edge newprev)
    {
	prev_ = newprev;
	return;
    }

    public void deleteEdge(Edge deledge)
    {
	if (next_ == null) {
		if (prev_ != null)
			prev_.setnext(null);
		return;
	}
	prev_.setnext(next_);
	next_.setprev(prev_);
    }

    public Graphics draw(int ncolor,Graphics g)
    {
	if (selected_ == true)
		g.setColor(selectColor());
	else if (locked_ == true)
		g.setColor(lockedColor());
	else 
		g.setColor(basicColor(ncolor));
	
	g.drawLine(((int) node1_.viewx()), ((int) node1_.viewy()),
		((int) node2_.viewx()), ((int) node2_.viewy())); 
	return g;   
}
 
    private Color basicColor(int ncolor) {
	return new Color(ncolor,ncolor,ncolor);
    }

    private Color selectColor() {
	return new Color(50,205,50);
    }

    private Color lockedColor() {
	return new Color(199,21,133);
    }

    public void setSelected() {
	selected_ = true;
    }

    public void setUnselected() {
	selected_ = false;
    }

    public void setLocked() {
	locked_ = true;
    }

    public void setUnlocked() {
	locked_ = false;
    }
}

