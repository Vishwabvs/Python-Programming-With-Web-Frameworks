/*
 * AnalysisFrame.java
 *
 * Description:
 *    This class is the popup window used in "Show
 *    Analysis" mode
 */
import java.awt.Frame;
import java.awt.Panel;
import java.awt.Button;
import java.awt.Event;
import java.awt.Canvas;
import java.awt.Scrollbar;
import java.awt.Dimension;
import java.awt.BorderLayout;
import java.awt.Graphics;

class AnalysisFrame extends Frame
{
   private Scrollbar horiz;         // the horizontal scrollbar
   private Scrollbar vert;          // the vertical scrollbar
   private AnalysisCanvas canvas;   // the scrolled region where the
                                    // trees will be displayed
   public Query queryParent;        // the query that initiated this
                                    // analysis request
   protected int treeType;          // the specific tree being output

   // states within the 3D box intersection algorithm
   final int EDGEX = 0;             // edge tree of x values
   final int EDGEY = 1;             // edge tree of y values
   final int EDGEZ = 2;             // edge tree of z values
   final int INTERVALX = 3;         // interval tree of x values
   final int INTERVALY = 4;         // interval tree of y values
   final int INTERVALZ = 5;         // interval tree of z values
   final int INTERSECTX = 6;        // tree of x values intersected with
                                    // camera
   final int INTERSECTY = 7;        // tree of y values intersected with
                                    // camera
   final int INTERSECTZ = 8;        // tree of z values intersected with
                                    // camera
   final int LOCATEX = 9;           // tree of x values intersected with
                                    // point of interest
   final int LOCATEY = 10;          // tree of y values intersected with
                                    // point of interest
   final int LOCATEZ = 11;          // tree of z values intersected with
                                    // point of interest

   // constructor for AnalysisFrame
   public AnalysisFrame(Query parent, int operation, String title)
   {
      queryParent = parent;
      buildAnalysisFrame(title);
      treeType = operation;
   }

   // layout the popup window
   private void buildAnalysisFrame(String title)
   {
      setTitle(title);
      Panel p1 = new Panel();
      p1.setLayout(new BorderLayout());
      p1.add("East", vert = new Scrollbar(Scrollbar.VERTICAL));
      p1.add("South", horiz = new Scrollbar(Scrollbar.HORIZONTAL));
      p1.add("Center", canvas = new AnalysisCanvas(this));
      add("Center", p1);
      Panel p2 = new Panel();
      p2.add(new Button("OK"));
      add("South", p2);
      resize(600, 600);
      canvas.setSize();
   }

   // show the popup window to the screen
   public void show()
   {
      super.show();
      Dimension dim = canvas.size();
      horiz.setValues(0, dim.width, 0, 3000);
      vert.setValues(0, dim.height, 0, 3000);
      canvas.repaint();
   }

   // handle the scrolling, movement, and destroy events
   public boolean handleEvent(Event event)
   {
      if (event.id == Event.WINDOW_DESTROY)
      {
         queryParent.timer.setOperationDone();
         dispose();
         return true;
      }
      else if (event.id == Event.WINDOW_MOVED)
      {
         Dimension dim = canvas.size();
         horiz.setValues(horiz.getValue(), dim.width, 0, 3000);
         vert.setValues(vert.getValue(), dim.height, 0, 3000);
         return true;
      }
      else if (event.id == Event.SCROLL_ABSOLUTE ||
               event.id == Event.SCROLL_LINE_DOWN ||
               event.id == Event.SCROLL_LINE_UP ||
               event.id == Event.SCROLL_PAGE_DOWN ||
               event.id == Event.SCROLL_PAGE_UP)
      {
          canvas.translate(horiz.getValue(), vert.getValue());
          return true;
      }
      return super.handleEvent(event);
   }

   // event handler for the pressing of the OK button, this causes
   // the popup window to be disposed
   public boolean action(Event evt, Object arg)
   {
      if (arg.equals("OK"))
      {
         queryParent.timer.setOperationDone();
         dispose();
         return true;
      }
      return false;
   }
}