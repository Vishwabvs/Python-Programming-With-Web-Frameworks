
import java.awt.*;
import java.applet.*;

class EmptyCanvas extends Canvas
{
    public void paint(Graphics g) {}
}

class CheckButton extends Panel
{
    String label;
    Button button;
    EmptyCanvas canvas;
    int status;
    static int FontSize = 11;
    static int Border = 8;
    static int CheckHeight = FontSize;
    static int CheckWidth = 16;
    static int CheckX = 10;
    static int CheckY = Border-2;

    public CheckButton(String str) { label=str; status=0; }
    public CheckButton(String str, int stat) { label=str; status=stat; }

    public void init()
    {
        setLayout(new FlowLayout(FlowLayout.LEFT, 0, 0));
        Font font = new Font("Helvetica", Font.PLAIN, FontSize);
        setFont(font);
        button = new Button(label);
        canvas = new EmptyCanvas();
        canvas.resize(25,CheckHeight+2*Border);
        add(canvas);
        add(button);
    }

    public synchronized void paint(Graphics gr)
    {
        Graphics g = canvas.getGraphics();
        g.setColor(getBackground());
        g.fill3DRect(CheckX, CheckY, CheckHeight, CheckWidth, true);
        if (status == 1) {
            g.setColor(Color.yellow);
            g.fill3DRect(CheckX+1, CheckY+1, CheckHeight-2, CheckWidth-2, true);
        }
    }

    public boolean action(Event e, Object arg)
    {
        if (label.equals(arg)) {
            status = 1-status;
            repaint();
        }
        return false;
    }

    public void setStatus(int i)
    {
        status = i;
        repaint();
    }
}

