import java.awt.*;
import java.io.*;
import java.util.Vector;

class X_Tree{ 
  Vector rectangles;
  Vector temp1=new Vector();
  Vector temp2=new Vector();
  public TreeNode root;
  public IntervalInfo[] info;
  int size_of_info;
  public int cur_ind;
  int[] end_points;

  //the constructor take an argument which should
  //be a Vector for all the rectangles
  public X_Tree(Vector rects){
    rectangles=rects;
    int k=rectangles.size();
    if(k<=0){
      Debug.print_err("k is supposed to be >0");
    }
    size_of_info=2*k-1;
    info=new IntervalInfo[size_of_info];
    for(int i=0; i<size_of_info; i++){
      info[i]=new IntervalInfo();
    }
    Debug.print("rectangles size is: "+rectangles.size());
    end_points=new int[2*k]; 
    Debug.print("here 4");
    for(int i=0; i<k; i++){
      Debug.print("here 3");
      RecTangle rec=(RecTangle)rectangles.elementAt(i);
      end_points[2*i]=rec.x;
      end_points[2*i+1]=rec.x+rec.w;
    }
    Debug.print("here 4");
    MyMethod.sort(end_points,2*k);
    Debug.print("here 1");
    k=2*k-1;
    //now set up the tree bottom up
      for(int i=0; i<k; i++){
        TreeNode new_node=new TreeNode(end_points[i], 
          end_points[i+1], i);
        temp1.addElement(new_node);
      }
      int r=k-(k/2)*2;
      k=k/2;
      while(true){
        Debug.print("here 2");
        for(int w=0; w<k; w++){
          temp2.addElement(new TreeNode((TreeNode)temp1.
            elementAt (2*w), (TreeNode)temp1.elementAt(2*w+1)));
        }
        if (r==1)
          temp2.addElement(temp1.elementAt(2*k));
        temp1=temp2;
        Debug.print("temp1.size()is: "+temp1.size());
        temp2=new Vector();
        k=temp1.size(); 
        if(temp1.size()==1)
          break;
        else{
          r=k-(k/2)*2;
          k=k/2;
        }
      }
      //now, temp1 contains the root:
      root=(TreeNode)temp1.elementAt(0);
      root.print();
      traverse();
  }//end of constructor.

  public void traverse(){
    int k=rectangles.size();
    for(int i=0; i<k; i++){
      RecTangle rect=(RecTangle)rectangles.elementAt(i);
      root.decorate(rect.x, rect.x+rect.w, i);
    } 
    size_of_info=2*k-1;
    info=new IntervalInfo[size_of_info];
    for(int i=0; i<size_of_info; i++){
      info[i]=new IntervalInfo();
      Debug.print("end_points["+i+"]="+end_points[i]);
      info[i].left=end_points[i];
      info[i].right=end_points[i+1];
      Vector temp_inds=new Vector();
      root.collect_inds(info[i].left, info[i].right,temp_inds);  
      int l=0;
      int j=temp_inds.size();
      if(j<=0)
        info[i].sweep_height=0;
      else{
        Vector temp_intervals=new Vector();
        for(int w=0; w<j; w++){
          RecTangle rec=(RecTangle)rectangles.elementAt(
            ((Integer)(temp_inds.elementAt(w))).intValue());
          Interval interval=new Interval(rec.y, rec.y+rec.h);
          interval.rect=rec;
          temp_intervals.addElement(interval);
        } 
        Y_Tree y_tree=new Y_Tree(temp_intervals);
        info[i].sweep_height=y_tree.total_length;
        info[i].intervals=temp_intervals;
        info[i].y_tree=y_tree;
      } 
      Debug.print("in X_traverse, info["+i+"]="+
        info[i].sweep_height);
    } 
  }//end of traverse.

  public int get_left_area(int cur_pos){
    int k=root.get_ind(cur_pos);
    cur_ind=k;
    int area=0;
    for(int i=0; i<k; i++){
      Debug.print("sweep_height: "+info[i].sweep_height);
      area+=info[i].sweep_height*(info[i].right-info[i].left);
    }
    if(k>=0 && k<size_of_info){
      Debug.print("sweep_height: "+info[k].sweep_height);
      area+=info[k].sweep_height*(cur_pos-info[k].left);  
    }
    return area;
  }

}

