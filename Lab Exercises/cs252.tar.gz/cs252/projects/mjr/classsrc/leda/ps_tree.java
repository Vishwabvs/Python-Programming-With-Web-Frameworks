/*
 * @(#)ps_tree.java	1.0 5/4/96 Michael John Radwin
 */

package leda;

import java.util.Vector;

/**
 * LEDA's priority search tree, laboriously ported to java.
 *
 * @version 1.0 5/4/96
 * @author <A HREF="http://www.cs.brown.edu/people/mjr/">Michael John Radwin</A>
 */
public class ps_tree {
    protected ps_item root;
    protected int   anzahl; 
    protected double alpha;
    protected double d;
    protected b_stack st;

    /**
     * according to tree.size and alpha here: tree.size <= 10^9
     * alpha = 0.25 ( worst case )
     */
    protected static final int BSTACKSIZE = 70 ; 

    protected void lrot(ps_item p, ps_item q)
    { 
	int xh ,yh;

	ps_item h = p.sohn[right];
	xh = h.x_value();
	yh = h.y_value();
  
	p.sohn[right] = h.sohn[left];
	h.sohn[left] = p;
   
	if (q == null) root=h;
	else
	    {
		if ( p == q.sohn[left] )   q.sohn[left]=h;
		else q.sohn[right]=h;
	    }; 
  
	h.x_val = p.x_value();
	h.y_val = p.y_value();
	p.x_val = p.y_val = 0;

	if (cmp(xh,yh,h.split_value_x(),h.split_value_y())>0)  
	    sink(h.sohn[right],xh,yh);
	else  sink(p.sohn[right],xh,yh); 
    
	fill(p);
  
	p.gr=p.sohn[left].groesse()+p.sohn[right].groesse();
	h.gr=p.groesse()+h.sohn[right].groesse();
    }

    protected void rrot(ps_item p, ps_item q)
    { 
	int xh, yh;
  
	//cout << "rrot\n"; 
	// cout << "p :" << p.split_value_x() << "\n";
	// cout << "q :" << q.split_value_x() << "\n";
	ps_item h = p.sohn[left];
	// cout << "h :" << h.split_value_x() << "\n";
	xh=h.x_value();
	yh=h.y_value();
  
	p.sohn[left] = h.sohn[right];
	h.sohn[right] = p;

	if (q == null) root=h;
	else
	    {
		if ( p == q.sohn[left] ) q.sohn[left] = h;
		else q.sohn[right] = h; 
	    };

	h.x_val = p.x_value();
	h.y_val = p.y_value();
	p.x_val = p.y_val = 0;
  
	if (cmp(xh,yh,h.split_value_x(),h.split_value_y())<=0)  
	    sink(h.sohn[left],xh,yh);
	else sink(p.sohn[left],xh,yh);
  
	fill(p);

	p.gr=p.sohn[left].groesse()+p.sohn[right].groesse();
	h.gr=p.groesse()+h.sohn[left].groesse();
    }

    protected void ldrot(ps_item p, ps_item q)
    { 
    
	//cout << "ldrot\n";
	ps_item h = p.sohn[right];
	//ps_item t = h.sohn[left];
	rrot(h,p);
	lrot(p,q);
	// cout << "p:" << p.split_value_x() << "\n";
	// cout << "h:" << h.split_value_x() << "\n";
    }

    protected void rdrot(ps_item p, ps_item q)
    {

	//cout << "rdrot\n";
	ps_item h = p.sohn[left];
	//ps_item t = h.sohn[right];
	lrot(h,p);
	rrot(p,q);
	// cout << "p:" << p.split_value_x() << "\n";
	//cout << "h:" << h.split_value_x() << "\n";
	//cout << "t:" << t.split_value() << "\n";
    }
 
    protected void fill(ps_item p)
    {
	int leer=0;
	int diff=0;
	//cout << "fill\n";
	while (!p.blatt() && leer!=1)
	    {
		diff=cmp(p.sohn[left].y_value(),p.sohn[right].y_value()); 
		//cout << "diff = " << diff << "\n";
		if (diff==0) leer=1;                                           // Kinder von p gefuellt ?
		else if ( (diff<0 && p.sohn[left].y_value()!=0) 
			  || (diff>0 && p.sohn[right].y_value()==0))
		    {
			p.x_val = p.sohn[left].x_value();
			p.y_val = p.sohn[left].y_value();
			p.sohn[left].x_val = p.sohn[left].y_val = 0;   
			//cout <<"gefuellt von links :"<<p.split_value()<<":"<<p.x_value()<<":"<<p.y_value()<<"\n";
			p = p.sohn[left];
		    }
		else if ( (diff>0 && p.sohn[right].y_value()!=0) 
			  || (diff<0 && p.sohn[left].y_value()==0)) 
		    {
			p.x_val = p.sohn[right].x_value();
			p.y_val = p.sohn[right].y_value();
			p.sohn[right].x_val = p.sohn[right].y_val = 0;   
			p.sohn[right].x_val = p.sohn[right].y_val =0;
			p = p.sohn[right];
		    };
	    };
    }

    protected ps_item sink(ps_item q, int x, int y)
    {
	int xh, yh, xneu=x;
	int yneu=y;
	ps_item p =q;
	ps_item inserted = null; 
 
	while(!p.blatt() && cmp(p.x_value(),0)!=0)
	    {
		//cout << "sink\n";
		//cout << p.split_value_x() << ":" << p.split_value_y() <<":"<< p.x_value() << ":" << p.y_value() <<"\n";
		if (cmp(p.y_value(),0)!=0 && cmp(y,p.y_value())<0)
		    {                                                    // Tausch
			xh=p.x_value();
			yh=p.y_value();
			p.x_val=x;
			p.y_val=y;
			x=xh;
			y=yh;
			if (cmp(p.x_value(),xneu)==0 && cmp(p.y_value(),yneu)==0) inserted=p;
			//cout << "inserted in Tausch\n";
			//cout << inserted.split_value() <<":"<< inserted.x_value() << ":" << inserted.y_value() <<"\n";
		    };
		//cout << "hallo\n";
		if (cmp(x,y,p.split_value_x(),p.split_value_y())<=0)   p=p.sohn[left];
		else 
		    {
			p=p.sohn[right]; 
			//cout << p.split_value_x() << ":" << p.split_value_y() <<":"<< p.x_value() << ":" << p.y_value() <<"\n";
		    };
	    };
	p.x_val=x;
	p.y_val=y;
	if (cmp(p.x_value(),xneu)==0 && cmp(p.y_value(),yneu)==0) inserted=p;
	// cout << "inserted" << inserted.split_value_y() <<":"<< inserted.x_value() << ":" << inserted.y_value() <<"\n";
	return inserted;
    }

    protected ps_item search(int x,int y)
    {
	ps_item p = root;
	//ps_item q = 0;

// cout << "search\n";
	if (root.blatt())
	    {
		st.push(root);
		return p;
	    }
	else
	    {
		st.push(p);
		while ( p!=null && !p.blatt() )
		    {
			if ( cmp(x,p.x_value())==0 && cmp(y,p.y_value())==0) 
			    {
				p=null;
			    }
			else 
			    { 
				if ( cmp(x,y,p.split_value_x(),p.split_value_y())<=0 ) p=p.sohn[left];
				else p=p.sohn[right]; 
				st.push(p);
			    }
		    }
		return p;
	    }
    }  

  
    protected ps_item locate(int x,int y)
    {
	ps_item p = root;
	ps_item q = null;

	//cout << "locate\n";
	while ( q==null && p!=null && cmp(y,p.y_value())>=0 )
	    {
		st.push(p);
		if ( cmp(x,p.x_value())==0 && cmp(y,p.y_value())==0) 
		    {
			q=p;
		    }
		else 
		    { 
			if ( cmp(x,y,p.split_value_x(),p.split_value_y())<=0 ) p=p.sohn[left];
			else p=p.sohn[right]; 
		    }
	    }
	return q;
    }

 
    protected void delleaf(ps_item q)
    {
	ps_item p;	
	ps_item t;	
	ps_item father;
	int xh,yh;

	//cout << "delleaf\n";
	q.x_val=0;
	q.y_val=0;
	p=st.pop();
	father=st.pop();
	if (q==father.sohn[left] ) father.sohn[left]=null;
	else father.sohn[right]=null;
	q = null;                                           // loescht Blatt
	t= st.empty() ? null : st.top();
	xh=father.x_value();
	yh=father.y_value();
	//cout << "xh: " << xh << "\n";
	//cout << "yh: " << yh << "\n";
  
	if ( father.sohn[left]!=null) q=father.sohn[left];
	else q=father.sohn[right];
	if (t!=null)
	    {
		if (father==t.sohn[left])  t.sohn[left]=q;
		else  t.sohn[right]=q;
	    }
	else root=q;
	father = null;                                       // loescht Vater
 
	//cout << "q-x_value: " << q.x_value() << "\n";
	//cout << "q-y_value: " << q.y_value() << "\n";
	//cout << "q-split_value: " << q.split_value() << "\n";
	sink(q,xh,yh);
    }
  
    public ps_item insert(int x,int y)
    { 
	ps_item p;
	ps_item t;
	ps_item father;
 
	if (root == null)                                     // neuer Baum
	    {  
		ps_item new_p=new ps_item(x,y,x,y);
		root=new_p; 
		anzahl=1; 
		return new_p;
	    }
	else
	    {
		p=search(x,y);
		//cout << "p-x_value: " << p.x_value() << "\n";
		//cout << "p-y_value: " << p.y_value() << "\n";
		//cout << "p-split_value_x: " << p.split_value_x() << "\n";
		//cout << "p-split_value_y: " << p.split_value_y() << "\n";
  
		if (p==null)
		    {
			System.err.println("point already there !");   // Warnung
			st.clear();
			return p;
		    }
		else
		    {
			ps_item q = new ps_item(0,0,p.split_value_x(),p.split_value_y());   
			ps_item w = new ps_item(0,0,x,y);           // zwei neue Blaetter
			//cout << "q-x_value: " << q.x_value() << "\n";
			//cout << "q-y_value: " << q.y_value() << "\n";
			//cout << "q-split_value_x: " << q.split_value_x() << "\n";
			//cout << "q-split_value_y: " << q.split_value_y() << "\n";
			//cout << "w-x_value: " << w.x_value() << "\n";
			//cout << "w-y_value: " << w.y_value() << "\n";
			//cout << "w-split_value_x: " << w.split_value_x() << "\n";
			//cout << "w-split_value_y: " << w.split_value_y() << "\n";
			if(cmp(p.split_value_x(),p.split_value_y(),x,y)<=0)
			    {
				p.sohn[left]=q; 
				p.sohn[right]=w; 
			    }
			else
			    {
				p.split_val[0] = x;
				p.split_val[1] = y;
				p.sohn[left]=w;
				p.sohn[right]=q;
			    } 
				   
			//cout << "p-x_value: " << p.x_value() << "\n";
			//cout << "p-y_value: " << p.y_value() << "\n";
			//cout << "p-split_value_x: " << p.split_value_x() << "\n";
			//cout << "p-split_value_y: " << p.split_value_y() << "\n";
			while (!st.empty())                          // rebalancieren
			    { 
				t=st.pop();
				// cout << "stack\n";
				father = st.empty() ? null : st.top();
				t.gr++;  
				double i = t.bal();
  
				//cout << "i" << i << "\n";
				if (i < alpha)
				    {
					if (t.sohn[right].bal()<=d) lrot(t,father);
					else ldrot(t,father);
				    }
				else if (i>1-alpha) 
				    {
					if (t.sohn[left].bal() > d ) rrot(t,father);
					else rdrot(t,father);
				    }
			    }
			p = sink(root,x,y);
			//cout<< p.split_value() <<":"<< p.x_value() << ":" << p.y_value() <<"\n";
			return p;
		    }
	    } 
    }



    
    public ps_item del(int x,int y)
    { 
	ps_item p;
	ps_item t;
	ps_item father;
	ps_item deleted = new ps_item(x,y,0,0);
 
	if (root==null) 
	    {
		System.err.println("Tree is empty");
		return null;                                          // leerer Baum
	    }
	else
	    {
		p=locate(x,y);
		//cout << "located:"<<p.split_value()<<"\n";
		if (p==null) 
		    {
			System.err.println("Pair is not in tree ");
			st.clear();
			return null;                                         // Paar nicht im Baum
		    }
		else
		    { 
			if (p.blatt()) 
			    {
				if (p==root)
				    {
					System.err.println("Root is deleted.");
					p=st.pop();
					root=null;
					anzahl=0;
					return p;                                       // Wurzel geloescht
				    } 
				else
				    {
					delleaf(p);                                 // (x,y) steht in einem Blatt
				    }
			    }
			else                                          // (x,y) steht in einem Knoten
			    {
				p.x_val = p.y_val = 0;
				fill(p);
				while (!p.blatt())                               // Knoteninhalt loeschen
				    {                                                 // und neu auffuellen
					if (cmp(x,y,p.split_value_x(),p.split_value_y())<=0) p=p.sohn[left];
					else p=p.sohn[right];
					st.push(p);
				    };
    
				delleaf(p);                                    // loescht zugehoeriges Blatt
			    }
 
			while (!st.empty())                                 // rebalancieren
			    { 
				t = st.pop();
				//cout << "stack\n";
				//cout << t.split_value()<<":"<<t.x_value()<<":"<<t.y_value()<<"\n";
				father = st.empty() ? null : st.top() ;
				t.gr--;              
				double i=t.bal();
				//cout << "i :" << i << "\n";
				if (i<alpha)
				    { 
					if (t.sohn[right].bal() <= d) lrot(t,father);
					else ldrot(t,father);
				    }
				else if (i>1-alpha)
				    { 
					if(t.sohn[left].bal() > d) rrot(t,father);
					else rdrot(t,father);
				    }
			    }
			return(deleted);
		    }
	    }
    } 

    protected void enumerate(int x1,int x2,int y0,ps_item p)
    {
	if (p!=null && cmp(y0,p.y_value())>=0)
	    {
		if (cmp(x1,p.split_value_x())<=0 && cmp(p.split_value_x(),x2)<=0)
		    {
			if (cmp(x1,p.x_value())<=0 && cmp(p.x_value(),x2)<=0)
			    System.out.println(p.split_value_x() + "(" +
					       p.x_value() + "," +
					       p.y_value() + ")");
			enumerate(x1,x2,y0,p.sohn[left]); 
			enumerate(x1,x2,y0,p.sohn[right]); 
		    }
		else if (cmp(p.split_value_x(),x1)<=0) 
		    {
			if(cmp(x1,p.x_value())<=0 && cmp(p.x_value(),x2)<=0)
			    System.out.println(p.split_value_x() + "(" +
					       p.x_value() + "," +
					       p.y_value() + ")");
			enumerate(x1,x2,y0,p.sohn[right]);
		    }
		else if (cmp(x2,p.split_value_x())<=0) 
		    {
			if(cmp(x1,p.x_value())<=0 && cmp(p.x_value(),x2)<=0)
			    System.out.println(p.split_value_x() + "(" +
					       p.x_value() + "," +
					       p.y_value() + ")");
			enumerate(x1,x2,y0,p.sohn[left]);
		    }
	    }
    }
   	

 
    protected pair_item min_x_in_rect(int x1,int x2,int y0,ps_item p)
    {
	pair_item  c;

	if (p==null)
	    {
		return null;                                   // Baum ist leer.
	    }
	else
	    {
		c=new pair_item();
		c.x_pkt=c.y_pkt=0;
		c.valid=false;
		if (cmp(y0,p.y_value())>=0)
		    {
			if (!p.blatt())
			    {
				if (cmp(x1,p.split_value_x())<=0) 
				    c=min_x_in_rect(x1,x2,y0,p.sohn[left]);
				if (!c.valid && cmp(p.split_value_x(),x2)<0) 
				    c=min_x_in_rect(x1,x2,y0,p.sohn[right]);
			    }
			if (cmp(x1,p.x_value())<=0 && cmp(p.x_value(),x2)<=0 
			    && cmp(p.y_value(),y0)<=0
			    && (!c.valid || cmp(p.x_value(),c.x_pkt)<0)     )
			    {
				c.x_pkt=p.x_value();  
				c.y_pkt=p.y_value();  
				c.valid=true;
			    }
		    }
		return c;
	    }
    }

    protected pair_item max_x_in_rect(int x1,int x2,int y0,ps_item p)
    {
	pair_item c;

	if (p==null) 
	    {
		return null;                                      // Baum ist leer.
	    }
	else
	    {
		c=new pair_item();
		c.x_pkt=c.y_pkt=0;
		c.valid=false;
		if (cmp(y0,p.y_value())>=0)
		    {
			if (!p.blatt())
			    {
				if (cmp(p.split_value_x(),x2)<=0) 
				    c=max_x_in_rect(x1,x2,y0,p.sohn[right]);
				if (!c.valid && cmp(x1,p.split_value_x())<0) 
				    c=max_x_in_rect(x1,x2,y0,p.sohn[left]);
			    }
			if (cmp(x1,p.x_value())<=0 && cmp(p.x_value(),x2)<=0 
			    && cmp(p.y_value(),y0)<=0
			    && (!c.valid || cmp(p.x_value(),c.x_pkt)>0)     )
			    {
				c.x_pkt=p.x_value();  
				c.y_pkt=p.y_value();  
				c.valid=true;
			    }
		    }
		return c;
	    }
    }
 
 
    protected pair_item min_y_in_xrange(int x1,int x2,ps_item p)
    {
	pair_item c1,c2;

	if (p==null)
	    {
		return null;                                      // Baum ist leer.
	    }
	else
	    {
		c1 = new pair_item();
		c2 = new pair_item();
		c1.x_pkt=c1.y_pkt=c2.x_pkt=c2.y_pkt=0; 
		c1.valid=c2.valid=false;
		if (cmp(x1,p.x_value())<=0 && cmp(p.x_value(),x2)<=0)
		    {
			c1.x_pkt=p.x_value();
			c1.y_pkt=p.y_value();
			c1.valid=true;
		    }
		else if (!p.blatt())
		    {
			if (cmp(x1,p.split_value_x())<=0) c1=min_y_in_xrange(x1,x2,p.sohn[left]);
			if (cmp(p.split_value_x(),x2)<0)  c2=min_y_in_xrange(x1,x2,p.sohn[right]);
			if (!c1.valid || (c2.valid && cmp(c2.y_pkt,c1.y_pkt)<0)) c1=c2;
		    }
		return c1;
	    } 
    }
  
    protected void deltree(ps_item p)
    {
	if (p != null)
	    {
		if (!p.blatt())
		    {
			deltree(p.sohn[left]);
			deltree(p.sohn[right]);
		    }
		p = null;
	    }
    }

    public int cmp(int x,int y) { return x-y; }
    public int cmp(int x1,int y1,int x2,int y2)
    {
	if (x1==x2)
	    return y1-y2; 
	else
	    return x1-x2;
    }

    public int   x_value(ps_item it)      { return (it != null) ? it.x_value() : 0 ; }
    public int   y_value(ps_item it)      { return (it != null) ? it.y_value() : 0 ; }
    public int   split_value_x(ps_item it)  { return (it != null) ? it.split_value_x() : 0 ; }
    public int   split_value_y(ps_item it)  { return (it != null) ? it.split_value_y() : 0 ; }
 
    public pair_item min_x_in_rect(int x1,int x2,int y0) { return min_x_in_rect(x1,x2,y0,root); }
    public pair_item max_x_in_rect(int x1,int x2,int y0) { return max_x_in_rect(x1,x2,y0,root); }
    public pair_item min_y_in_xrange(int x1,int x2) { return min_y_in_xrange(x1,x2,root); }

    public void enumerate(int x1,int x2,int y0) { enumerate(x1,x2,y0,root); }
    
    public ps_tree()
    {
	st = new b_stack(BSTACKSIZE);
	root = null;
	anzahl = 0;
	alpha=0.28;
	d=1/(2-alpha);
    }
    // enum children     { left = 0 , right = 1 };
    protected static final int left = 0;
    protected static final int right = 1;
}
    


class pair_item {
    public int x_pkt;
    public int y_pkt;
    public boolean valid;
}


class b_stack extends Vector {
    public b_stack(int capacity)
    {
	super(capacity);
    }
    
    public ps_item top()
    {
	return (ps_item) lastElement();
    }

    public ps_item pop()
    {
	ps_item r = (ps_item) lastElement();
	removeElementAt(size() - 1);
	return r;
    }

    public void clear()
    {
	removeAllElements();
    }

    public boolean empty()
    {
	return isEmpty();
    }

    public void push(ps_item p)
    {
	addElement(p);
    }
	   
}    
