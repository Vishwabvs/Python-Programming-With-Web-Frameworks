import java.net.*;
import java.awt.*;
import java.util.*;

public class Node {


  // Data members

  private int id_;  
  private URL url_;
  private Point pos_;
  private int depth_;

  private int width_;
  private int height_;
  private Point origin_;
   
  private int status_;
  private Color color_;

  private Node firstChild_;
  private Node sibling_;
  private Node parent_;

  private int rank_;

  // Accessor methods

public int getId () { return id_; }
  
public URL getURL () { return url_; }

public Point getPosition () { return pos_; }

public int getDepth () { return depth_; }


public int getWidth () { return width_; }

public int getHeight () { return height_; }

public Point getOrigin () { return origin_; }


public int getStatus () { return status_; }

public Color getColor () { return color_; }


public Node getFirstChild () { return firstChild_; }

public Node getSibling () { return sibling_; }

public Node getParent  () { return parent_; }


public int  getRank () { return rank_; }


  // Set methods

public void setId (int id) { id_ = id; }

public void setURL (URL url) { url_ = url; }

public void setPosition (Point pos) { pos_ = pos; }

public void setDepth (int depth) { depth_ = depth; }


public void setWidth (int width) { width_ = width; }

public void setHeight (int height) { height_ = height; }

public void setOrigin (Point origin) { origin_ = origin; }


public void setStatus (int status) { status_ = status; }

public void setColor (Color color) { color_ = color; }

public void setColor (int r, int g, int b) { color_ = new Color(r, g, b); }


public void setFirstChild (Node firstChild) { firstChild_ = firstChild; }

public void setSibling (Node sibling) { sibling_ = sibling; }

public void setParent (Node parent) { parent_ = parent;}


public void setRank (int rank) { rank_ = rank; }

  // Debugging methods

public void print ()
  {

    System.out.print("url_: ");
    if (url_ != null) System.out.println(url_.toString());
    else System.out.println("NULL");

    System.out.print("depth_: " + depth_ + "\npos_: ");
    
    if (pos_ != null) System.out.println("[" + pos_.x + ", " + pos_.y + "]");
    else System.out.println("NULL");

    System.out.print("id_: " + id_ + "\nwidth: " + width_ +
    "\nheight: " + height_ + "\norigin_: ");

    if (origin_ != null)
       System.out.println("[" + origin_.x + ", " + origin_.y + "]");
    else System.out.println("NULL");
    
    System.out.print("status_: " + status_ + "\ncolor_: "); 
    if (color_ != null) System.out.println(color_.toString());
    else System.out.println("NULL");

    System.out.print("firstChild's id: ");
    if (firstChild_ != null) System.out.println(firstChild_.getId());
    else System.out.println("NULL");

    System.out.print("sibling's id: ");
    if (sibling_ != null) System.out.println(sibling_.getId());
    else System.out.println("NULL");

    System.out.print("parents's id: ");
    if (parent_ != null) System.out.println(parent_.getId());
    else System.out.println("NULL");

    System.out.println("rank: " + rank_);
    
  }

public Vector getChildren ()
  {

    Vector children = new Vector();

    if (firstChild_ != null) children.addElement(firstChild_);
    
    Node child = sibling_;

    while (child != null) {

      children.addElement(child);
      child = child.getSibling();
      
    }

    return children;
    
  }

public boolean isLeaf ()
  {

    if (firstChild_ == null) return true;
    else return false;

  }

public boolean isRoot ()
  {

    if (parent_ == null) return true;
    else return false;
    
  }

}







