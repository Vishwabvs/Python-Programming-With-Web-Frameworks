/****************************************************************/
/*    NAME:                                                     */
/*    ACCT: mjw                                                 */
/*    FILE: STSegmentTree.C                                     */
/*    ASGN:                                                     */
/*    DATE: Sun Jun  2 20:45:37 1996                            */
/****************************************************************/



#include "STSegmentTree.H"
//#include "STSegment.H"
#include "STNode.H"
#include "assert.h"
#include <fstream.h>
#include "RTEvent.H"

//ofstream ffout("tree.log");
int compareIntX(const int& a, const int& b);

#define GET_ITEM(i, list)   list[list[i]]

inline void LOG(ostream& os, char* msg) 
{
    os << msg;
    os.flush();
}

inline void LOG(ostream& os, int arg)
{
    os << arg;
    os.flush();
}


STSegmentTree::STSegmentTree(): GTree()
{
    //LOG(ffout, "\ncreated the segment tree");
    root_ = NULL;
    num_nodes_=0;
}

STSegmentTree::~STSegmentTree()
{
    //LOG(ffout, "\n\nend.\n");
    destroy();
}

bool
STSegmentTree::build(STSegmentList& segments)
{
    	#if _DEBUG_
    	cerr << "\ndestroying the tree";
	#endif
	destroy();

	//LOG(ffout,"\ndestroying the previous tree");
	
	//setSegments(segments);
 	if (segments.empty())
	    {
		//LOG(ffout, "\nsegment list is empty in build, aborting...");
		return false;
	    }
 	STIntList xlist;  
 	STSegmentPtr seg;
 	forall (seg, segments)
 	{
		#if _DEBUG_
	    	cerr << "\nsegment..."<<seg->xcoord1()<<" "<<seg->xcoord2();
		#endif
 	 	if (xlist.search(seg->xcoord1()) == NULL)
		    xlist.append(seg->xcoord1());
		if (xlist.search(seg->xcoord2()) == NULL)
		    xlist.append(seg->xcoord2());
 	}
	#if _DEBUG_
	cerr << "\nsorting x's";
	#endif

	//LOG(ffout,"\nsorting x's");
 	xlist.sort(compareIntX);
	
	#if _DEBUG_
    	int a;
    	cerr <<"\nx's:\n";
    	forall (a, xlist)
	{
	    cerr << a<< " ";
	}
	cerr << "\ncalling create"; 
	#endif

	//LOG(ffout,"\ncalling create");
 	create(&root_, xlist, 0, xlist.length()-1);
	
	#if _DEBUG_
	cerr << "\ncalling insert";
	#endif
	//LOG(ffout, "\nback from create");
	
	if (root_)
	    {
		STSegmentPtr seg;
		int len = segments.length();
		for (int i=0; i < len; i++)
		    {
			//LOG(ffout,"\ncalling insert");
			seg = segments.pop();
			insert(*root_,seg);
		    }
		//LOG(ffout,"\ntree set up successfully");
		return true;
	    }
	//LOG(ffout,"\ndid not call insert");
	return false;
}                            


bool
STSegmentTree::build(list<point>& seg_end_points)
{
        if (seg_end_points.length() % 2) // id odd # of points
	    {
		#if _DEBUG_
		cerr << "\nSTSegmentTree::build(list<points>& seg_end_points): odd number of points, aborting...";
                #endif
		//LOG(ffout, "\nSTSegmentTree::build(list<points>& seg_end_points): odd number of points, aborting...");
		return false;
	    }        
        point *s, *e;
        STSegment *sg;
        STSegmentList segments;

        while (!seg_end_points.empty())
        {
                #if _DEBUG_
		cerr << "\n	 creating a segment...";
                #endif
		//LOG(ffout, "\n	 creating a segment...");
                s = &seg_end_points.pop();
		e = &seg_end_points.pop();
                sg = new STSegment(*s, *e);
                assert(sg);
                segments.append(sg);
        }
        if (!segments.empty())
                return build(segments);
        return false;
}

	




void 
STSegmentTree::create(STNodePtr* node, STIntList& xlist, int l, int r)
{
	int left, right;

	if (xlist.empty())
	    {
		//LOG(ffout, "\nlist of indecies is empty, aborting...");
		return;
	    }
	
	left =  GET_ITEM(l,xlist);
	right = GET_ITEM(r,xlist);

	#if _DEBUG_
	cerr << "\nnode "<<num_nodes_+1<<" , left= "<< left << " right= "<<right;
	cerr << "\ncreating a node";
	#endif
	//LOG(ffout, "\nnode , left= ");
	//LOG(ffout, left);
	//LOG(ffout,  " right= ");
	//LOG(ffout, right);
	
	(*node) = new STNode();
	(*node)->setID(++num_nodes_);
	(*node)->setBegin(left);
	(*node)->setEnd(right);
	(*node)->setChild(GNode::LEFT_CHILD, NULL);
	(*node)->setChild(GNode::RIGHT_CHILD, NULL);

	int m = (l + r)/2;	// median of the xlist
	int mx = GET_ITEM(m, xlist);
	(*node)->setMedian(mx);
	
	// Set the px coord of the node.  The py coord
	// is app dependend so it should be set from the app.
	(*node)->setPX(left + (right - left)/2);
	
	
       	STNodePtr left_child = NULL;
	STNodePtr right_child = NULL;
	                              
	// here we need to partition the list in half
	if (l < m)
	    create(&left_child, xlist, l, m);
	if (m < r && (r - l != 1))
	    create(&right_child, xlist, m, r);
	
	(*node)->setChild(GNode::LEFT_CHILD, left_child);
	(*node)->setChild(GNode::RIGHT_CHILD, right_child);
} 

void 
STSegmentTree::insert(STNode& node, STSegmentPtr seg)
{
	int begin = seg->xcoord1();
	int end = seg->xcoord2();
	
	//ffout << "\ninsert: begin("<<begin<<") < node.getBegin("<<node.getBegin()<<") && end("<<end<<") >= node.getEnd("<<node.getEnd()<<")\n";
	
	if ((begin <= node.getBegin()) && (end >= node.getEnd()))
	{
	 	node.addSegment(seg);
		//LOG(ffout, "\ninserted segment");
	}                
	else
	{
	    STNode *left_child = node.getChild(GNode::LEFT_CHILD);
	    STNode *right_child = node.getChild(GNode::RIGHT_CHILD);
	    int median =  node.getMedian();//(node.getBegin()+node.getEnd())/2;
	    
	    if (begin < median)
		{
		    if (left_child)
			{
			    //ffout << "\ninsert: going left";
			    insert(*left_child, seg);
			}
		    //else LOG(ffout,"\ninsert: went off the left end.");
		}
	    if (median < end)
		{
		    if (right_child)
			{
			  //ffout << "\ninsert: going right";
			    insert(*right_child,seg);
			}
		    //else LOG(ffout, "\ninsert: went off the right end.");
		}
	}
}

void 
STSegmentTree::destroy()
{
	num_nodes_ = 0;
	destroy(root_);
}

void 
STSegmentTree::destroy(STNodePtr& node)
{
    if (!node) return;
    STNode *left_child = node->getChild(GNode::LEFT_CHILD);
    if (left_child)
	destroy(left_child);
    STNode *right_child = node->getChild(GNode::RIGHT_CHILD);
    if (right_child)
	destroy(right_child);	
    
    delete node;
    node = NULL;
}
void STSegmentTree::write(ostream &os)
{
    //LOG(ffout,"\nwrite,  num nodes: ");
    //LOG(ffout, num_nodes_);
    
    os << tree_marker_<< "\n"<<num_nodes_;
    os << "\n"<<*root_;
    write(os, root_);
    os << "\n";
}	


// pre-order 
void STSegmentTree::write(ostream &os, STNodePtr node)
{
    STNode *lchild, *rchild;
 
    assert(node);
    os <<"\n"<<*node;
    if ((lchild =node->getChild(STNode::LEFT_CHILD)) != NULL)
	{
	    //LOG(ffout,"\nwriting left child");
	    os << "   "<< *lchild;
	}
    
    if ((rchild =node->getChild(STNode::RIGHT_CHILD)) != NULL)
	{
	    //LOG(ffout, "\nwriting right child");
	    os << "   "<< *rchild;
	}
    if (lchild)
	write(os, lchild);
    if (rchild)
	write(os, rchild);
}


void 
STSegmentTree::intersection(STSegment& query_segment, RTEventList& event_list)
{
    if (root_)
	intersection(root_, query_segment, event_list);
}


static void getMinMax(int& y1, int& y2, STSegment& query_segment)
{

    if (query_segment.ycoord1() <= query_segment.ycoord2())
	{
	    y1 = query_segment.ycoord1();
	    y2 = query_segment.ycoord2();
	}
    else
	{
	    y1 = query_segment.ycoord2();
	    y2 = query_segment.ycoord1();
	}
}



// NOTE: query segment must be vertical
void 
STSegmentTree::intersection(STNodePtr node, STSegment& query_segment, RTEventList& event_list)
{
    if (!node)
	return;

    
    RTEventPtr event;
    STSegmentPtr sg;
    int i, y1, y2, length;
    
    event = new RTEvent(RTEvent::RT_EVENT_CHECK_OVERLAP, node);
    event_list.append(event);
    //LOG(ffout,"\nRT_EVENT_CHECK_OVERLAP");
    
    event = new RTEvent(RTEvent::RT_EVENT_OVERLAP, node);
    event_list.append(event);
    //LOG(ffout,"\nRT_EVENT_OVERLAP");
    
    STSegmentList& node_segments = node->getSegments();
    
    getMinMax(y1, y2, query_segment);
    length = node_segments.length();
    
    for (i=0; i < length; i++)
	{
	   sg = GET_ITEM(i, node_segments);
	   if ((sg->ycoord1() >= y1) && (sg->ycoord1() <= y2))
	       {
		   //LOG(ffout,"\nRT_EVENT_VISIT_SEGMENT");
		   event = new RTEvent(RTEvent::RT_EVENT_VISIT_SEGMENT, node);
		   event->setSegmentBegin(new point(sg->xcoord1(),sg->ycoord1()));
		   event->setSegmentEnd(new point(sg->xcoord2(),sg->ycoord2()));
		   event_list.append(event);
	      }
	}
    STNodePtr left_child  = node->getChild(STNode::LEFT_CHILD);
    STNodePtr right_child = node->getChild(STNode::RIGHT_CHILD);

    if (right_child)
	{
	    if (query_segment.xcoord1() < right_child->getBegin())
		{
		    if (left_child != NULL)
			{
			    //LOG(ffout,"\nRT_EVENT_GO_LEFT");
			    event = new RTEvent(RTEvent::RT_EVENT_GO_LEFT, node);
			    event_list.append(event);
			    intersection(left_child, query_segment, event_list);
			}
		}
	    else if  (right_child!=NULL)
		{
		    //LOG(ffout,"\nRT_EVENT_GO_RIGHT");
		    event = new RTEvent(RTEvent::RT_EVENT_GO_RIGHT, node);
		    event_list.append(event);
		    intersection(right_child, query_segment, event_list);
		}
	}
}


/*
// NOTE: query segment must be vertical
void 
STSegmentTree::intersection(STNodePtr node, STSegment& query_segment, RTEventList& event_list)
{

    if (!node)
	return;

    
	RTEventPtr event;
	STSegmentPtr sg;
	int i, y1, y2, length;
	
	event = new RTEvent(RTEvent::RT_EVENT_CHECK_OVERLAP, &node);
        event_list.append(event);
	//LOG(ffout,"\nRT_EVENT_CHECK_OVERLAP");
	
	event = new RTEvent(RTEvent::RT_EVENT_OVERLAP, &node);
	event_list.append(event);
	//LOG(ffout,"\nRT_EVENT_OVERLAP");
	
	STSegmentList& node_segments = node.getSegments();
	
	getMinMax(y1, y2, query_segment); 
	// perform binary search on y values
	//LOG(ffout, " about to do binary search");
	i = binarySearch(y1, node_segments);
	
	if (i < (length = node_segments.length()))
	    sg = GET_ITEM(i, node_segments);

	//LOG(ffout, "\ni: ");
	//LOG(ffout,i);
	//LOG(ffout,"\ny1: ");
	//LOG(ffout, y1);
	//LOG(ffout, "\ny2: ");
	//LOG(ffout,y2);
	//LOG(ffout, "\nsegment list length: ");
	//LOG(ffout,length);
	
	while ((i < length) && (sg->ycoord1() <= y2))
	    {
		//LOG(ffout,"\nRT_EVENT_VISIT_SEGMENT");
		event = new RTEvent(RTEvent::RT_EVENT_VISIT_SEGMENT, &node);
		event->setSegmentBegin(new point(sg->xcoord1(),sg->ycoord1()));
		event->setSegmentEnd(new point(sg->xcoord2(),sg->ycoord2()));
		event_list.append(event);
		i++;
		if (i<length)
		    sg = GET_ITEM(i, node_segments);
	    }
       
	STNodePtr left_child  = node.getChild(STNode::LEFT_CHILD);
	STNodePtr right_child = node.getChild(STNode::RIGHT_CHILD);
	
	if (query_segment.xcoord1() < right_child->getBegin()))
	    {
		if (left_child != NULL)
		    {
			//LOG(ffout,"\nRT_EVENT_GO_LEFT");
			event = new RTEvent(RTEvent::RT_EVENT_GO_LEFT, &node);
			event_list.append(event);
			intersection(left_child, query_segment, event_list);
		    }
	    }
	else if  (right_child!=NULL)
	    {
		//LOG(ffout,"\nRT_EVENT_GO_RIGHT");
		event = new RTEvent(RTEvent::RT_EVENT_GO_RIGHT, &node);
		event_list.append(event);
		intersection(right_child, query_segment, event_list);
	    }
}

*/



/****************************************************************/
/*                                                              */
/* Function Name: binarySearch                                  */
/* Parameters:    int, STSegmentList&                           */
/* Returns:       int                                           */
/* Effects:       Given a y-value and a segm list, it performs  */
/*                a binary search on the segments and returns the */
/*                index of the segment that was found.           */
/*                                                              */
/****************************************************************/


int STSegmentTree::binarySearch(int y_coord, STSegmentList& segments)
{
    int l, r, m;
    bool found = false;
    STSegmentPtr sg;
    
    l = 0;
    r = segments.length()-1;

    while ((l <= r) && (! found))
	{
	    m = (l + r) / 2;
	    sg = GET_ITEM(m, segments);
	    if (y_coord < sg->ycoord1())
		r = m - 1;
	    else if (y_coord > sg->ycoord1())
		l = m + 1;
	    else
		{
		    found = true;
		    //cout << "\n FOUND MATCH !!!\n";
		}
	}
    if (found)
	return m;
    else
	return l; 
}








int compareIntX(const int& a, const int& b)
{
    if (a < b) return -1;
    if (a ==b) return 0;
    return 1;
}





