/*
 * @(#)LineSprite.java	1.0 5/6/96 Michael John Radwin
 */

package mjr.pstree;

import sprite.*;
import java.awt.*;

/**
 * a simple line (not an edge)
 *
 * @version 1.0 5/6/96
 * @author <A HREF="http://www.cs.brown.edu/people/mjr/">Michael John Radwin</A>
 */
public class LineSprite extends Sprite {
    Color pen;
    int x1, x2, y1, y2;

    public LineSprite(SpriteArea area,
		      int x1, int y1, int x2, int y2,
		      Color pen)
    {
	super(area, x1, y1);
	this.x1 = x1; this.x2 = x2; this.y1 = y1; this.y2 = y2;
	this.pen = pen;
//	Add();
    }

    public LineSprite(SpriteArea area,
		      int x1, int y1, int x2, int y2)
    {
	this(area, x1, y1, x2, y2, Color.black);
    }


    public void setColor(Color color)
    {
	pen = color;
    }
    
    public boolean Inside(int x, int y)
    {
	int minX, minY, maxX, maxY;
	if (x1 < x2) {
	    minX = x1; maxX = x2;
	} else {
	    minX = x2; maxX = x1;
	}
	
	if (y1 < y2) {
	    minY = y1; maxY = y2;
	} else {
	    minY = y2; maxY = y1;
	}
	
	boolean inside = (minX - MARGIN) < x && x < maxX + MARGIN;
	if (!inside) return false;
	inside = (minY - MARGIN) < y && y < maxY + MARGIN;	
	if (!inside) return false;	

	if (x1 == x2 || y1 == y2)
	    return true;

	int dX = x2 - x1;
	int dY = y2 - y1;
	int a2 = (y - y1) * dX - (x - x1) * dY;
	double d = (double)(a2 * a2) / (double)(dX * dX + dY * dY);
	    
	return ((d > 0) ? d : -d) < FUDGE;
    }

    public void Draw(Graphics g)
    {
	g.setColor(pen);
	g.drawLine(x1, y1, x2, y2);
    }


    public String toString()
    {
	return "Line (" + x1 + "," + y1 + ") -> (" + x2 + "," + y2 + ")";
    }

    private final static double FUDGE = 8;
    private final static int MARGIN = 3;
    public static void mjr() { ; }
}
