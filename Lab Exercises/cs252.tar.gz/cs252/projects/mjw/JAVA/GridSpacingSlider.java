import Slider;
import AnimatorGeometryClient;
import AnimatorSlider;


public class GridSpacingSlider extends AnimatorSlider {

	public GridSpacingSlider(AnimatorGeometryClient client)
	{
		super(client);
	}

	public void Motion()
	{
		if (client_ != null)
			client_.setGridSpacing(GetValue());
	}
};
