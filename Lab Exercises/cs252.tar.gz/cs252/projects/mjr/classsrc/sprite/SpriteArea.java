package sprite;

import java.net.*;
import java.awt.*;
import java.applet.*;
import java.util.Vector;

public class SpriteArea extends Canvas {
    public final static int NO_UPDATING = 0;
    public final static int DELAYED_UPDATING = 1;
    public final static int INSTANT_UPDATING = 2;        

    Toolkit kit_;
    Vector sprites_;
    int width_, height_;
    
    Graphics background_, anchorG_, scratch_, onscreen_;
    Image backgroundImage_, anchorImage_, scratchImage_;

    Sprite target_;
    boolean dirtyAnchor_;
    int updateMode_;
    
    public SpriteArea(int width, int height) {
        resize(width, height);
	
        width_ = width;
        height_ = height;
        scratch_ = null;
	sprites_ = new Vector();
	dirtyAnchor_ = false;
	updateMode_ = DELAYED_UPDATING;
    }

    static public void Tile(Applet applet, Graphics g,
			    int width, int height, String url) {

        URL u = null;
        try
            u = new URL(url);
        catch (MalformedURLException e) {
            System.out.println("Error: " + e);
	    return;
	}
        Image tile = applet.getImage(u);
	
        MediaTracker tracker = new MediaTracker(applet);
        tracker.addImage(tile, 0);
        try
            tracker.waitForID(0);
        catch (InterruptedException e) {
            System.out.println("Error: " + e);
	    return;
        }

	int tileX = tile.getWidth(null); int tileY = tile.getHeight(null);
	int x = (width / tileX) + 1; int y = (height / tileY) + 1;
	for (int loopX = 0; loopX < x; ++loopX)
	    for (int loopY = 0; loopY < y; ++loopY)
		g.drawImage(tile, loopX * tileX, loopY * tileY, null);
    }
    
    public synchronized void WaitForGraphics() {
	if (getParent() == null)
	    throw new RuntimeException(
		"WaitForGraphics called on an un-added SpriteArea.");
	if (scratch_ == null) {
	    repaint();
	    try
		wait();
            catch (InterruptedException e);
	}
    }
    
    public Graphics GetBackgroundGraphics() {
	return background_;
    }
    
    public Graphics GetOnscreenGraphics() {
	return onscreen_;
    }

    public void BackgroundDirty() {
	DirtyAnchor();
    }
    
    public synchronized void SetUpdateMode(int updateMode) {
	updateMode_ = updateMode;
	Update();
    }

    public synchronized void FullUpdate() {
//	long tm = System.currentTimeMillis();
	int a = 0;
	int u = 0;

	Sprite s[] = new Sprite[sprites_.size()];
	sprites_.copyInto(s);

//	System.out.println();
	if (dirtyAnchor_) {
	    anchorG_.drawImage(backgroundImage_, 0, 0, null);
	    for (int loop = 0; loop < s.length; ++loop)
		if (s[loop].anchored_ && s[loop].visible_) {
		    a++;
		    s[loop].Draw(anchorG_);
		}
//	    System.out.println("Just drew " + a + " anchored sprites.");
	    dirtyAnchor_ = false;
	}
	scratch_.drawImage(anchorImage_, 0, 0, null);
	for (int loop = 0; loop < s.length; ++loop)
	    if (!s[loop].anchored_ && s[loop].visible_) {
		++u;
		s[loop].Draw(scratch_);
	    }
//	System.out.println("Just drew " + u + " unanchored sprites.");
	onscreen_.drawImage(scratchImage_, 0, 0, null);
//	System.out.println("Time = " + (System.currentTimeMillis() - tm) +
//			   " ms");
    }
    
    public Sprite LocateMouse(int x, int y) {
	Sprite s[] = new Sprite[sprites_.size()];
	sprites_.copyInto(s);
	for (int loop = s.length - 1; loop >= 0; --loop) {
	    if (s[loop].Inside(x, y))
		return s[loop];
	}
	return null;
    }

    public void Delay(int delay) {
	try
	    Thread.currentThread().sleep(delay);
	catch (InterruptedException e);
    }
    
    public void HandleBackgroundEvent(Event e) { ; }

    public boolean Inside(int x, int y) {
	return (x >= 0 && y >= 0 && x < width_ & y < height_);
    }
    
    void AddSprite(Sprite s) {
	sprites_.addElement(s);
	if (s.visible_) {
	    if (s.anchored_)
		DirtyAnchor();
	    else
		Update();
	}
    }

    void RemoveSprite(Sprite s) {
	sprites_.removeElement(s);
	if (s.visible_) {
	    if (s.anchored_)
		DirtyAnchor();
	    else
		Update();
	}
    }

    synchronized void ZToTop(Sprite s) {
	sprites_.removeElement(s);
	sprites_.addElement(s);
	if (s.visible_) {
	    if (s.anchored_)
		DirtyAnchor();
	    else
		Update();
	}
    }

    synchronized void ZToBottom(Sprite s) {
	sprites_.removeElement(s);
	sprites_.insertElementAt(s, 0);
	if (s.visible_) {
	    if (s.anchored_)
		DirtyAnchor();
	    else
		Update();
	}
    }

    synchronized void DirtyAnchor() {
	dirtyAnchor_ = true;
	Update();
    }

    synchronized void Update() {
	switch (updateMode_) {
	case NO_UPDATING: break;
	case DELAYED_UPDATING: repaint(); break;
	default: FullUpdate(); break;
	}
    }

    public synchronized void update (Graphics g) {
        paint(g);
    }
    
    public synchronized void paint (Graphics g) {
	if (onscreen_ != g)
	    onscreen_ = g;
	
        if (scratch_ == null) {
            resize(width_, height_);

            backgroundImage_ = createImage(width_, height_);
            background_ = backgroundImage_.getGraphics();
	    
            anchorImage_ = createImage(width_, height_);
            anchorG_ = anchorImage_.getGraphics();

            scratchImage_ = createImage(width_, height_);
            scratch_ = scratchImage_.getGraphics();

	    
	    background_.setColor(Color.red);
	    background_.fillRect(0, 0, width_, height_);
	    anchorG_.setColor(Color.green);
	    anchorG_.fillRect(0, 0, width_, height_);
	    scratch_.setColor(Color.blue);
	    scratch_.fillRect(0, 0, width_, height_);
	    
            notify();
        }
	else if (updateMode_ == DELAYED_UPDATING)
	    FullUpdate();
	else if (updateMode_ != NO_UPDATING)
	    onscreen_.drawImage(scratchImage_, 0, 0, null);
    }
    
    public boolean handleEvent(Event event) {
	boolean forward = true;

	switch (event.id) {
	case Event.MOUSE_ENTER:
	    requestFocus();
	    break;

	case Event.MOUSE_DOWN:
	    if (event.id == Event.MOUSE_DOWN)
		target_ = LocateMouse(event.x, event.y);
	    if (target_ != null) {
		target_.handleEvent(event);
		forward = false;				
	    }
	    break;
	case Event.MOUSE_DRAG:
	    if (target_ != null) {
		target_.handleEvent(event);
		forward = false;		
	    }
	    break;
	    
	case Event.MOUSE_UP:
	    if (target_ != null) {
		target_.handleEvent(event);
		forward = false;
		target_ = null;
	    }
	    break;

	case Event.KEY_PRESS:
	case Event.KEY_ACTION:
	case Event.KEY_RELEASE:
	case Event.KEY_ACTION_RELEASE:
	    Sprite keyTarget = LocateMouse(event.x, event.y);
	    if (keyTarget != null) {
		keyTarget.handleEvent(event);
		forward = false;
	    }
	}
	
	if (forward)
	    HandleBackgroundEvent(event);
	
	return true;
    }
}
