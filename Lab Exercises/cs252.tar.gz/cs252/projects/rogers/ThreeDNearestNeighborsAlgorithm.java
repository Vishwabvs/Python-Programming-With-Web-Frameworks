/** Brian Rogers
    cs252
    spring 1996
    Final Project */

import java.awt.*;


/** This is the all nearest-neighbors algorithm.  It is responsible for 
    controlling what goes on in one step of the nearest-neighbor process. */
    
public class ThreeDNearestNeighborsAlgorithm extends ThreeDSweepAlgorithm {

     public static final Color COLOR = Color.blue;

     /** The closest distance-squared we have found for the current vertex so
         far.  We use distance-squared to avoid wasting time taking square 
	 roots. */
     int _distsq;
     
     /** The closest vertex we have found to the current vertex so far. */
     ThreeDVertex _closest;

     /** The current vertex's coordinates */
     int curr_x;
     int curr_y;
     int curr_z;



     public ThreeDNearestNeighborsAlgorithm (ThreeDSpace space, 
                                 ThreeDCanvas canvas, ThreeD applet,
				 ThreeDVertex verts[], int numverts) {
          super(space, canvas, applet, COLOR, verts, numverts);
     }


     public void step () {
          try {
               _distsq = 1000000000;   // We need to set it really high at first.
	       _closest = current_vert;

               curr_x = current_vert.xCoord();
	       curr_y = current_vert.yCoord();
	       curr_z = current_vert.zCoord();

               /* Forwards in the array for the closest vertex. */
	       checkForwards(vert_index); 
	       /* Now look backwards in the array */
	       checkBackwards(vert_index);

               /* give the vertex an edge to the closest neighbor we found */
	       ThreeDDirectedEdge edge = new ThreeDDirectedEdge(current_vert, 
	                                               _closest, Color.red);
	       edge.draw(_canvas.getGraphics());
	       sleep(calc_step);
	       edge.setColor((COLOR.darker()).darker());
	       current_vert.addEdge(edge);
	       current_vert.setColor(COLOR);
	  }
	  catch (InterruptedException e) System.out.println(e);
     }


     /** This looks to the right (forward in the array) for the closest 
         vertex.  It stops when the next vertex in the array is farther
	 in the x, y or z direction than the closest vertex so far */
     private void checkForwards (int index) {
          try {
               /* if there are any more vertices to the right */
	       if (index < num_verts - 1) {

                    /* Get the next vertex, and it's coordinates */
		    ThreeDVertex checkvert = _verts[index+1];
		    int checkx = checkvert.xCoord();
		    int checky = checkvert.yCoord();
		    int checkz = checkvert.zCoord();

                    /* if this vertex is possibly closer */ 
		    if ((checkx-curr_x)*(checkx-curr_x) <= _distsq) {
	                 if ((checky-curr_y)*(checky-curr_y) <= _distsq &&
		             (checkz-curr_z)*(checkz-curr_z) <= _distsq) {

                              /* draw an edge so we can see we've checked it */
			      ThreeDDirectedEdge temp = new ThreeDDirectedEdge(
			               current_vert, checkvert, Color.orange);
			      temp.draw(_canvas.getGraphics());
			      
			      sleep(calc_step);

                              /* figure out the distance-squared between them */
			      int distsq = (checkx-curr_x)*(checkx-curr_x) +
	                              (checky-curr_y)*(checky-curr_y) +
			              (checkz-curr_z)*(checkz-curr_z);

                              /* If this one is closest, save it as such */
			      if (distsq < _distsq) {
	                           _distsq = distsq;
				   _closest = checkvert;
	                      }
                         }
               
	                 /* check the next vertex forwards */
	                 checkForwards(index+1);
	            }
	       }
	  }
	  
	  catch (InterruptedException e) System.out.println(e);
     }

     /** This works the same way as checkForwards, but it looks to the left 
         (back in the array) for the closest vertex. */
     private void checkBackwards (int index) {
          try {
               /* if there are any more vertices to the left */
	       if (index > 0) {
	  
	            /* Get the vertex and it's coordinates */
		    ThreeDVertex checkvert = _verts[index-1];
		    int checkx = checkvert.xCoord();
		    int checky = checkvert.yCoord();
		    int checkz = checkvert.zCoord();

                    /* if this vertex is possibly closer */
		    if ((checkx-curr_x)*(checkx-curr_x) <= _distsq) {
	                 if ((checky-curr_y)*(checky-curr_y) <= _distsq &&
		             (checkz-curr_z)*(checkz-curr_z) <= _distsq) {

                              /* draw an edge to see that we've checked it */
                              ThreeDDirectedEdge temp = new ThreeDDirectedEdge(
			               current_vert, checkvert, Color.orange);
		              temp.draw(_canvas.getGraphics());

                              sleep(calc_step);

		              int distsq = (checkx-curr_x)*(checkx-curr_x) +
		                      (checky-curr_y)*(checky-curr_y) +
			      	      (checkz-curr_z)*(checkz-curr_z);

                              /* if this one is closest, save it as such */
		              if (distsq < _distsq) {
		                   _distsq = distsq;
		 	           _closest = checkvert;
		              }
                         }
		    
                         /* check the next vertex backwards */
			 checkBackwards(index-1);
	            }
	       }
	  }
	  
          catch (InterruptedException e) System.out.println(e);
     }
}
