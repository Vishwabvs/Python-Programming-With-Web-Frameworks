/*
 * @(#)TGLeafCommand.java 1.0 1/13/96 Michael John Radwin
 */
 
package mjr.pstree;
 
import mjr.treegraphics.TreeGraphics;
import leda.*;
 
public class TGLeafCommand extends PSTCommand {
    TreeGraphics tg;
    
    public TGLeafCommand(TreeGraphics tg)
    {
	this.tg = tg;
    }
    
    public Object _execute(ps_item p)
    {
//	System.err.println("leaf:");
	tg.DrawLeaf("blue");
	return null;
    }
    public static void mjr() { ; }
}
