import java.awt.Graphics;
import java.awt.*;
import java.awt.Event;
import java.awt.Point;
import java.lang.Boolean;
import java.util.Vector;
import java.awt.image.ImageObserver;
class TreeAreaHolder extends java.applet.Applet{
  Interface inf;
  Scrollbar h_bar;
  Scrollbar v_bar;
  int h_val;
  int v_val;
  public TreeAreaHolder(Interface inter){
    inf=inter;
    h_bar=new Scrollbar(Scrollbar.HORIZONTAL,
      1,0,0,500);
    v_bar=new Scrollbar(Scrollbar.VERTICAL,
      1,0,0,500);
    inf.treeArea=new TreeArea(inf);
    inf.treeArea.repaint();
    inf.treeArea.init();

    setLayout(new BorderLayout());
    add("North",h_bar);
    add("West",v_bar);
    add("Center",inf.treeArea);

  } 

  public boolean handleEvent(Event evt){
    int k=0;
    if(evt.target==v_bar){
      k=((Scrollbar)evt.target).getValue();
      inf.treeArea.v_scroll(k);
    }
    if(evt.target==h_bar){
      k=((Scrollbar)evt.target).getValue();
      inf.treeArea.h_scroll(k);
    }
    return true;
  }
} 
public class TreeArea extends java.applet.Applet implements Runnable {
  Interface inf;
  Vector intervals;
  D_Tree  d_tree;
  D_TreeNode cur_node;
  Dimension old_dim;
  Graphics offscreenGraphics;
  Image offscreenImage;
  Thread runner;
  Y_Tree y_tree;
  Image background_image;

  public TreeArea(Interface a){
    inf=a;
//    background_image=getImage(getCodeBase(),"video/bgw2.gif");    
  }

  public void reset_tree(Y_Tree a){
    //intervals=inters;
    y_tree=a;
    if(y_tree==null)
      d_tree=null;
    else d_tree=new D_Tree(a);
    repaint();
  }
  public void v_scroll(int k){
    D_Tree.set_base_y(6*k);
    repaint();
  }
  public void h_scroll(int k){
    D_Tree.set_base_x(k);
    repaint();
  }
  void test(){
    repaint();
  }

  public void run(){
    if(d_tree.current_picked_node==null)
      return;
    Vector intervals=new Vector();
    Vector rects=new Vector();
    d_tree.current_picked_node.get_flash_intervals(intervals,rects);
    while(true){
      if(d_tree.current_picked_node==null){
        inf.reset_flash_color();
        return;
      }
      else{
        d_tree.current_picked_node.switch_color();
        repaint();
        inf.sweep_line_flash(intervals,rects);
        inf.sweep_line_switch_color(); 
      }
      try{
        Thread.sleep(200);
      }catch(InterruptedException e){
       ;
      } 
    }
   
  }
  public void init(){
    background_image=inf.bg1; 
  }
  public boolean mouseMove(Event evt, int x, int y){
    d_tree.pick_node(x,y);
    repaint();
    return true;
  }

  public boolean mouseDown(Event evt, int x, int y){
    runner=new Thread(this);
    runner.start();
    return true;
  }
 
  public boolean mouseUp(Event evt, int x, int y){
    if(runner!=null)
      runner.stop();
    inf.reset_flash_color();
    return true;
  }

  public void update(Graphics g){
    paint(g);
  }
  public void paint(Graphics g){
    Dimension d=size();
    int k,l;
    RecTangle rec;
    if(offscreenImage==null || d.width!=old_dim.width || 
       d.height!=old_dim.height){
      offscreenImage=createImage(this.size().width,
        this.size().height);
      offscreenGraphics = offscreenImage.getGraphics();
      old_dim=d;
    }
    offscreenGraphics.setColor(Color.blue);
    ImageObserver observer=null;
    offscreenGraphics.drawImage(inf.bg1,
     0,0,this.size().width,this.size().height,observer);
    offscreenGraphics.setColor(Color.black);
    if(d_tree!=null)
      d_tree.root.show_self(offscreenGraphics); 
    g.drawImage(offscreenImage,0,0,this); 
 }
}
