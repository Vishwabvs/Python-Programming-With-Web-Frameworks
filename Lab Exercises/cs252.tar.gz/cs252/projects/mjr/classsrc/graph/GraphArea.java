package graph;

import java.awt.*;
import java.util.*;
import java.net.URL;
import java.io.*;
import sprite.*;

public class GraphArea extends SpriteArea {
    protected Vector graph_, edges_;
    protected Color newEdgeColor_;
    boolean editingOn_, directed_;
    // mjr
    Vector instLines;
    
    public GraphArea(boolean directed, int width, int height) {
	this(directed, width, height, false);
    }

    public GraphArea(boolean directed, int width, int height,
		     boolean instructions, Color instructions_color) {
	super(width, height);
	graph_ = new Vector();
	edges_ = new Vector();
	newEdgeColor_ = Color.black;
	editingOn_ = true;
	directed_ = directed;
	instLines = new Vector(3);
	if (instructions)
	    display_instructions(instructions_color, INST);
    }

    public GraphArea(boolean directed, int width, int height,
		     boolean instructions) {
	this(directed, width, height, instructions, Color.white);
    }

    // mjr
    public void display_instructions(Color col, String theInst[])
    {
	for (int mjr = 0; mjr < instLines.size(); mjr++)
	    ((TextSprite)instLines.elementAt(mjr)).Remove();
	instLines.removeAllElements();
	
	Font font = new Font("Dialog", Font.PLAIN, 10);
	FontMetrics metrics = getFontMetrics(font);
	int lineH = metrics.getHeight();
	int first = metrics.getAscent() + 3;
	int max = metrics.stringWidth(theInst[0]);
	for (int loop = 1; loop < theInst.length; ++loop)
	    max = Math.max(max, metrics.stringWidth(theInst[loop]));
	max = size().width - max - 3;

	for (int loop = 0; loop < theInst.length; ++loop) {
	    TextSprite line =  new TextSprite(
		this, max, size().height - first - (theInst.length - loop-1) * lineH,
		theInst[loop]);
	    line.Add(); line.SetFont(font);
	    line.SetColor(col); line.Anchor();
	    instLines.addElement(line);
	}
    }
    
    public void LoadGraph(URL u) {
	try {
	    String result = "";
	    byte buffer[] = new byte[1000];
	    InputStream iStream = u.openStream();
	    int actual = 0;
	    do {
		actual = iStream.read(buffer);
		if (actual != -1)
		    result += new String(buffer, 0, 0, actual);
	    }
	    while (actual != -1);
	    LoadGraph(result);
	}
	catch (IOException e) {
	    System.out.println(e);
	}
    }
    
    public void LoadGraph(String s) {
	StringTokenizer tokens = new StringTokenizer(s, " \t\r\n->(),");
	Hashtable hash = new Hashtable();
	
	while(tokens.hasMoreTokens()) {
	    String type = tokens.nextToken();
	    if (type.equalsIgnoreCase("node")) {
		String label = tokens.nextToken();
		int x = Integer.parseInt(tokens.nextToken());
		int y = Integer.parseInt(tokens.nextToken());
		hash.put(label, GetNewNode(x, y));
	    }
	    else if (type.equalsIgnoreCase("edge")) {
		String a = tokens.nextToken();
		String b = tokens.nextToken();
		Node nodeA = (Node)hash.get(a);
		Node nodeB = (Node)hash.get(b);
		new Edge(this, nodeA, nodeB);
	    }
	}
    }

    public Node GetNewNode(int x, int y) {
	return new Node(this, x, y, false);
    }
    
    public void SetNewEdgeColor(Color color) {
        newEdgeColor_ = color;
    }

    public Vector GetGraph() {
	return graph_;
    }
    
    public Vector GetEdges() {
	return edges_;
    }

    public Node[] GetGraphArray() {
	Node[] result = new Node[graph_.size()];
	graph_.copyInto(result);
	return result;
    }
    
    public Edge[] GetEdgeArray() {
	Edge[] result = new Edge[edges_.size()];
	edges_.copyInto(result);
	return result;
    }

    public void AllowEditing() {
	editingOn_ = true;
    }
    
    public void DisallowEditing() {
	editingOn_ = false;
    }

    public boolean CanEdit() {
	return editingOn_;
    }

    public void ClearGraph() {
	SetUpdateMode(NO_UPDATING);
	Node nodes[] = new Node[graph_.size()];
	graph_.copyInto(nodes);
	
	for (int loop = 0; loop < nodes.length; ++loop)
	    nodes[loop].Remove();
	graph_.removeAllElements();
        SetUpdateMode(DELAYED_UPDATING);        
    }

    protected void AddEdge(Edge edge) {
	edges_.addElement(edge);
    }
    
    protected void RemoveEdge(Edge edge) {
	edges_.removeElement(edge);
    }

    protected void AddNode(Node node) {
	graph_.addElement(node);
    }

    protected void RemoveNode(Node node) {
	graph_.removeElement(node);
    }

    public String toString() {
	String result = "";
	Node nodes[] = GetGraphArray();
	Edge edges[] = GetEdgeArray();
	for (int loop = 0; loop < nodes.length; ++loop)
	    result += nodes[loop] + "\n";
	result += "\n";
	for (int loop = 0; loop < edges.length; ++loop)
	    result += edges[loop] + "\n";
	return result;
    }

    private final static String[] INST =  {
	"Click to place edges and nodes.", "Shift-drag to move nodes.",
	"Delete key removes edges or nodes."
    };
}
