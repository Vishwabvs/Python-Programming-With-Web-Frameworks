import java.util.*;
import java.lang.*;
import java.awt.*;
import VCR;
import java.lang.Thread;
import java.lang.InterruptedException;



class PlayThread extends Thread {
protected VCR vcr_;
protected VCRPanel panel_;

	public PlayThread(VCRPanel panel, VCR vcr)
	{
		panel_ = panel;
		vcr_ = vcr;
	}

	public void run()
	{
		if (vcr_ != null && panel_ != null)
		{
			vcr_.notifyObservers(VCRPanel.PLAY);
			while (vcr_.play(1))
			{
				try {
				 sleep(panel_.delay_);
				} catch (InterruptedException e){
				}
			}
		}
	} 
};



public class VCRPanel extends Panel implements Observer {

        final static String PLAY        = "PLAY";
	final static String STEP_FWD    = "STEP >";
	final static String STEP_BWD    = "STEP <";
	final static String REWIND	= "REW <<";
	final static String FASTFORWARD = "FFW >>";
	final static String STOP	= "STOP";
	
	int i=0;
        int PLAY_STATE     = i++;
	int STEP_FWD_STATE = i++;
	int STEP_BWD_STATE = i++;
	int REWIND_STATE   = i++;
	int FASTFORWARD_STATE = i++;
	int STOP_STATE     = i++;
	int END_STATE	   = i++;
	int BEGIN_STATE	   = i++;
	int NUM_STATES	   = i;

	protected VCR		vcr_;
	public  int delay_ = 0;
	protected boolean[][] state_table_;
	protected Button play_btn_, stepF_btn_, stepB_btn_, rewind_btn_;
	protected Button fastfwd_btn_, stop_btn_;	
	protected Panel p_;
	protected PlayThread play_;



	public VCRPanel()
	{
		setLayout(new BorderLayout());
		p_ = new Panel();
		p_.setLayout(new GridLayout(1,0));
		play_btn_ = new Button(PLAY);
		stepF_btn_ = new Button(STEP_FWD);
		stepB_btn_ = new Button(STEP_BWD);
		rewind_btn_ = new Button(REWIND);
		fastfwd_btn_ = new Button(FASTFORWARD);
		stop_btn_ = new Button(STOP);

		p_.add(play_btn_);
		p_.add(stepF_btn_);
		p_.add(stepB_btn_);
		p_.add(rewind_btn_);
		p_.add(fastfwd_btn_);
		p_.add(stop_btn_);
		p_.disable();
		add("North", p_);
		vcr_ = null;
		initStateTable();
	}

	protected void finalize()
	{
		vcr_.deleteObserver(this);
	}


	public void setVCR(VCR vcr)
	{
		vcr_ = vcr;
		vcr_.addObserver(this);
	}


	public void update(Observable model, Object arg)
	{
	  //System.out.println("VCRPanel.update: arg = " +arg.toString());
		if (VCR.ACTIVATE.equals(arg))
			p_.enable();
		else if (VCR.DEACTIVATE.equals(arg))
			p_.disable();
		else
		{
			if (arg instanceof String)
			{
				int state = getStateNumber((String)arg);
				if (state!= -1)
					updateButtons(state);
			}
		}
	}


	public boolean action(Event evt, Object arg) 
	{

		if (PLAY.equals(arg))
			playCtrlButton();
		else if (STEP_FWD.equals(arg))
			stepForwardCtrlButton();
		else if (STEP_BWD.equals(arg))
			stepBackwardCtrlButton();
		else if (REWIND.equals(arg))
			rewindCtrlButton();
		else if (FASTFORWARD.equals(arg))
			fastForwardCtrlButton();
		else if (STOP.equals(arg))
			stopCtrlButton();
		return true;
	}



	protected void updateButtons(int state)
	{
		if ((state >= NUM_STATES) || (state < 0))
		{
		  //System.out.println("updateButtons: given state is >=NUM_STATES");
			return;
		}
		if (state_table_[state][PLAY_STATE])
			play_btn_.enable();
		else    play_btn_.disable();
		if (state_table_[state][STEP_FWD_STATE])
			stepF_btn_.enable();
		else	stepF_btn_.disable();
		if (state_table_[state][STEP_BWD_STATE])
			stepB_btn_.enable();
		else	stepB_btn_.disable();
		if (state_table_[state][REWIND_STATE])
			rewind_btn_.enable();
		else	rewind_btn_.disable();
		if (state_table_[state][FASTFORWARD_STATE])
			fastfwd_btn_.enable();
		else	fastfwd_btn_.disable();
		if (state_table_[state][STOP_STATE])
			stop_btn_.enable();
		else	stop_btn_.disable();
	}



	public void playCtrlButton()
	{
	  //System.out.println(PLAY + "  button hit.");
		if (vcr_ != null)
		{
			vcr_.notifyObservers(PLAY);
			play_ = new PlayThread(this, vcr_);
			play_.start();
		}
	}

	public void stepForwardCtrlButton()
	{
	  //System.out.println(STEP_FWD + "  button hit.");
		if (vcr_ != null)
		{
			vcr_.notifyObservers(STEP_FWD);
			if (play_ != null)
				play_.stop();
			vcr_.play(1);
		}
	}

	public void stepBackwardCtrlButton()
	{
	  //System.out.println(STEP_BWD + "  button hit.");
		if (vcr_ != null)
		{
			vcr_.notifyObservers(STEP_BWD);
			if (play_ != null)
				play_.stop();
			vcr_.play(-1);
		}
	}

	public void rewindCtrlButton()
	{
	  //System.out.println(REWIND + "  button hit.");
		if (vcr_ != null)
		{
			vcr_.notifyObservers(REWIND);
			if (play_ != null)
				play_.stop();
			while (vcr_.play(-1))
				;
		}
		
	}

	public void fastForwardCtrlButton()
	{
	  //System.out.println(FASTFORWARD + "  button hit.");
		if (vcr_ != null)
		{
			vcr_.notifyObservers(FASTFORWARD);
			if (play_ != null)
				play_.stop();
			while (vcr_.play(1))
				;
		}
	}

	public void stopCtrlButton()
	{
		if (vcr_ != null)
		{
			vcr_.notifyObservers(STOP);
			if (play_ != null)
				play_.stop();
		}
	}


	public void setDelay(int d)
	{
		if (d < 0) return;
		delay_ = d;
	}


	public int getDelay()
	{
		return delay_;
	}


	protected int getStateNumber(String state)
	{
		if (PLAY.equals(state)) return PLAY_STATE;
		else if (STEP_FWD.equals(state)) return STEP_FWD_STATE;
		else if (STEP_BWD.equals(state)) return STEP_BWD_STATE;
		else if (REWIND.equals(state))   return REWIND_STATE;
		else if (FASTFORWARD.equals(state)) return FASTFORWARD_STATE;
		else if (STOP.equals(state)) return STOP_STATE;
		else if (VCR.END.equals(state)) return END_STATE;
		else if (VCR.BEGINNING.equals(state)) return BEGIN_STATE;
		else return -1; // caller needs to check for this 
	}


	protected void initStateTable()
	{
		/*
		 *	This table will be accessed in the
		 *	following manner:
		 *
		 *	state_table_[<input_state>][<relative state>]
		 *
		 *	* input_state is caused by user action (ie.
		 *	  which button is pressed)
		 *	* relative_state is each button's state
		 *	  (actually, each button uses it's state id
		 *	  to figure out how it should behave in the
		 *	  given state).
		 */

		state_table_ = new boolean[NUM_STATES][NUM_STATES];

		state_table_[PLAY_STATE][PLAY_STATE] = true;
		state_table_[PLAY_STATE][STEP_FWD_STATE] = false;
		state_table_[PLAY_STATE][STEP_BWD_STATE] = false;
		state_table_[PLAY_STATE][REWIND_STATE] = false;
		state_table_[PLAY_STATE][FASTFORWARD_STATE] = true;
		state_table_[PLAY_STATE][STOP_STATE] = true;
		state_table_[PLAY_STATE][END_STATE] = false;
		state_table_[PLAY_STATE][BEGIN_STATE] = true;

		state_table_[STEP_FWD_STATE][PLAY_STATE] = true;
		state_table_[STEP_FWD_STATE][STEP_FWD_STATE] = true;
		state_table_[STEP_FWD_STATE][STEP_BWD_STATE] = true;
		state_table_[STEP_FWD_STATE][REWIND_STATE] = true;
		state_table_[STEP_FWD_STATE][FASTFORWARD_STATE]=true;
		state_table_[STEP_FWD_STATE][STOP_STATE] = false;
		state_table_[STEP_FWD_STATE][END_STATE] = false;
		state_table_[STEP_FWD_STATE][BEGIN_STATE] = true;

		state_table_[STEP_BWD_STATE][PLAY_STATE] = true;
		state_table_[STEP_BWD_STATE][STEP_FWD_STATE]=true;
		state_table_[STEP_BWD_STATE][STEP_BWD_STATE]=true;
		state_table_[STEP_BWD_STATE][REWIND_STATE]=true;
		state_table_[STEP_BWD_STATE][FASTFORWARD_STATE]=true;
		state_table_[STEP_BWD_STATE][STOP_STATE] = false;
		state_table_[STEP_BWD_STATE][END_STATE] = true;
		state_table_[STEP_BWD_STATE][BEGIN_STATE] = false;

		state_table_[REWIND_STATE][PLAY_STATE] = false;
		state_table_[REWIND_STATE][STEP_FWD_STATE]=false;
		state_table_[REWIND_STATE][STEP_BWD_STATE]=false;
		state_table_[REWIND_STATE][REWIND_STATE]=true;
		state_table_[REWIND_STATE][FASTFORWARD_STATE]=false;
		state_table_[REWIND_STATE][STOP_STATE] = false;
		state_table_[REWIND_STATE][END_STATE]= true;
		state_table_[REWIND_STATE][BEGIN_STATE]=false;

		state_table_[FASTFORWARD_STATE][PLAY_STATE]=false;
		state_table_[FASTFORWARD_STATE][STEP_FWD_STATE]=false;
		state_table_[FASTFORWARD_STATE][STEP_BWD_STATE]=false;
		state_table_[FASTFORWARD_STATE][REWIND_STATE]=false;
		state_table_[FASTFORWARD_STATE][FASTFORWARD_STATE]=true;
		state_table_[FASTFORWARD_STATE][STOP_STATE]=false;
		state_table_[FASTFORWARD_STATE][END_STATE] = false;
		state_table_[FASTFORWARD_STATE][BEGIN_STATE] = true;
		
		state_table_[STOP_STATE][PLAY_STATE]=true;
		state_table_[STOP_STATE][STEP_FWD_STATE]=true;
		state_table_[STOP_STATE][STEP_BWD_STATE]=true;
		state_table_[STOP_STATE][REWIND_STATE]=true;
		state_table_[STOP_STATE][FASTFORWARD_STATE]=true;
		state_table_[STOP_STATE][STOP_STATE]=true;
		state_table_[STOP_STATE][END_STATE]=false;
		state_table_[STOP_STATE][BEGIN_STATE]=false;

		state_table_[END_STATE][PLAY_STATE]=false;
		state_table_[END_STATE][STEP_FWD_STATE]=false;
		state_table_[END_STATE][STEP_BWD_STATE]=true;
		state_table_[END_STATE][REWIND_STATE]=true;
		state_table_[END_STATE][FASTFORWARD_STATE]=false;
		state_table_[END_STATE][STOP_STATE]=false;
		state_table_[END_STATE][END_STATE]=false;
		state_table_[END_STATE][BEGIN_STATE]=false;

		state_table_[BEGIN_STATE][PLAY_STATE]=true;
		state_table_[BEGIN_STATE][STEP_FWD_STATE]=true;
		state_table_[BEGIN_STATE][STEP_BWD_STATE]=false;
		state_table_[BEGIN_STATE][REWIND_STATE]=false;
		state_table_[BEGIN_STATE][FASTFORWARD_STATE]=true;
		state_table_[BEGIN_STATE][STOP_STATE]=false;
		state_table_[BEGIN_STATE][END_STATE]=false;
		state_table_[BEGIN_STATE][BEGIN_STATE]=false;

	}
};
