import java.awt.*;
import java.io.*;
import java.util.Vector;

class D_TreeNode extends TreeNode{
  final static int PICK_DIST=20;

  Graphics graphic;

  int position_x;
  int position_X;
  int position_y;
  int position_Y;

  Bar bar;

//  private D_TreeNode left_child;
// private D_TreeNode right_child;
  public D_TreeNode parent;

  Color color=Color.green;

  public void addBar(Bar b){
    if(bar!=null && bar.status==Bar.DEAD)
      return;
    bar=b;
  }

  public D_TreeNode(int a, int b, int i){
    hitting_inds=new Vector();
    type=TERMINAL;
    left_most=a;
    right_most=b;
    length=b-a;
    if(length<=0)
      Debug.print("ERROR here in TreeNode");
    index_for_terminal=i;
  }

  public D_TreeNode(int a, int b, int p_x, int p_y){
    left_most=a;
    right_most=b;
    length=b-a;
    type=TERMINAL;
    position_x=p_x;
    position_y=p_y;
  }
  
  public  D_TreeNode(D_TreeNode l,D_TreeNode r){
    left_most=l.left_most;
    right_most=r.right_most;
    l.parent=this;
    r.parent=this;
    left_child=l;
    right_child=r;
    position_x=((D_TreeNode)left_child).position_x-
                D_Tree.DIST_BETWEEN_NODE;
    position_y=(((D_TreeNode)left_child).position_y+
                ((D_TreeNode)right_child).position_y)/2;
  }

  public void reset(){
    if(bar==null)
      return;
    if(bar.status!=Bar.DEAD){
      bar=null;
      color=Color.green;
    }
    if(left_child!=null)
      ((D_TreeNode)left_child).reset();
    if(right_child!=null)
      ((D_TreeNode)right_child).reset(); 
  }

  public void setColor(){
    color=Color.red;
  }
  public void resetColor(){
    color=Color.green;
  }
  public void switch_color(){
    if(color==Color.green)
      color=Color.red;
    else
      color=Color.green;
  }
  public D_TreeNode paint_closest_node(int x, int y){
    if(Math.abs(x-position_X)+Math.abs(y-position_Y)<
       PICK_DIST){
      color=Color.red;
      return this;
    } 
    else if(type==TERMINAL){
      return null;
    } 
    else{
      D_TreeNode temp=((D_TreeNode)left_child).paint_closest_node(x,y);
      if(temp==null)
        temp=((D_TreeNode)right_child).paint_closest_node(x,y);
      return temp;
    }  
  }

  public void get_flash_intervals(Vector intervals, Vector rects){
    if(painted){
      intervals.addElement(new Interval(left_most, right_most));
      if(rectangles==null)
        System.out.println("[DEBUG 1] weird");
      //rects=rectangles;
      int k=rectangles.size();
      if(k!=0){
        for(int i=0; i<k; i++){
           rects.addElement(rectangles.elementAt(i));
        }
        
      }
      return;
    }
//    else rects=null;
/*
    if(left_child!=null)
      ((D_TreeNode)left_child).get_flash_intervals(intervals);
    if(right_child!=null)
      ((D_TreeNode)right_child).get_flash_intervals(intervals); 
*/
  }

  public void show_self(Graphics graphic){
    position_X=position_x+D_Tree.X_MOVE;
    position_Y=position_y-D_Tree.Y_MOVE;
    graphic.setColor(Color.red);
    graphic.drawString("("+left_most/50.0, position_X-30
      , position_Y-5);
    graphic.drawString(right_most/50.0+")", position_X+10,
      position_Y-5);

    if(bar!=null && bar.status==Bar.ACTIVE){
      graphic.setColor(Color.blue);
      graphic.drawLine(bar.l, bar.y, bar.r, bar.y);
      graphic.drawString(""+bar.left, bar.l-7, bar.y+5);
      graphic.drawString(""+bar.right,bar.r+3, bar.y+5);
    }
    if(type==TERMINAL){
      graphic.setColor(color);
      graphic.fillRect(position_X-5, position_Y-5,
        10, 10);
    }
    else{
      graphic.setColor(Color.black);
      graphic.drawLine(position_X, position_Y,
         ((D_TreeNode)left_child).position_x+D_Tree.X_MOVE, 
         ((D_TreeNode)left_child).position_y-D_Tree.Y_MOVE);
      graphic.drawLine(position_X, position_Y,
        ((D_TreeNode)right_child).position_x+D_Tree.X_MOVE, 
        ((D_TreeNode)right_child).position_y-D_Tree.Y_MOVE);
      graphic.setColor(color);
      graphic.fillOval(position_X-5, position_Y-5, 10,10);
      ((D_TreeNode)left_child).show_self(graphic);
      ((D_TreeNode)right_child).show_self(graphic);
    }
   
  } 

  public int get_result(){
    if(bar==null || bar.status!=Bar.DEAD){
      if(left_child!=null && right_child!=null)
        return ((D_TreeNode)left_child).get_result()+((D_TreeNode)right_child).get_result();
      else
        return 0;
    }
    if(bar.status==Bar.DEAD)
      return bar.right-bar.left;
    return 0;
  }

  public void flash_self(Graphics graphic){
      if(bar==null){
        if(left_child!=null)
          ((D_TreeNode)left_child).flash_self(graphic);
        if(right_child!=null)
          ((D_TreeNode)right_child).flash_self(graphic);
      }
      else if (bar.status==Bar.DEAD){
        if(type!=TERMINAL)
          graphic.fillOval(position_x-5, position_y-5, 10,10);
        else
          graphic.fillRect(position_x-5, position_y-5,
            10,10);
      }
      else{
        if(left_child!=null)
          ((D_TreeNode)left_child).flash_self(graphic);
        if(right_child!=null)
          ((D_TreeNode)right_child).flash_self(graphic);

      }
  }

  public boolean set_falling_bars(Vector bars){ 
    if(bar==null){
      return false; 
      } 
    if(bar.status==Bar.DEAD){ 
      bars.addElement(bar); 
      return  false; 
    } 
    else if(bar.status==Bar.WAIT){ 
      int mid=((D_TreeNode)left_child).right_most; 
      if(!((D_TreeNode)left_child).set_falling_bars(bars)){ 
        return ((D_TreeNode)right_child).set_falling_bars(bars);
      }
      return true; 
    }
    else if(bar.status==Bar.ACTIVE){
      if(bar.y>position_y){
        bar.y--;
        int center=((bar.y-position_y)*
                   (parent.position_x-position_x))
                   /(parent.position_y- position_y)+
                   position_x;
        bar.l=center-bar.graph_length;
        bar.r=center+bar.graph_length;
        bars.addElement(bar);
        return true;
      }
      if(bar.y!=position_y){
        return true;
      }
      if(bar.left==left_most && bar.right==right_most){
        bar.status=Bar.DEAD;
        color=Color.red;
        bars.addElement(bar);
        //color=red;
        return true;
      }
      if(left_child==null || right_child==null){
        return true;
      }
      int mid=((D_TreeNode)left_child).right_most;
      color=Color.blue;
      if(bar.right>mid){
        bar.status=Bar.WAIT;
        int end_p=Math.max(bar.left,mid);
        Bar bar1=new Bar(end_p, bar.right, position_x-30,
          position_x+30,position_y);
        bar1.status=Bar.ACTIVE;
        if(bar.left<mid)
          bar1.graph_length=bar.graph_length/2;
        else
          bar1.graph_length=bar.graph_length;
        ((D_TreeNode)right_child).addBar(bar1);
      }
      if(bar.left<mid){
        bar.status=Bar.WAIT;
        int end_p=Math.min(mid, bar.right);
        Bar bar1=new Bar(bar.left, end_p, position_x-30,
          position_x+30, position_y);
        bar1.status=Bar.ACTIVE;
        if(bar.right>mid)
          bar1.graph_length=bar.graph_length/2;
        else
          bar1.graph_length=bar.graph_length;
        ((D_TreeNode)left_child).addBar(bar1);
        ((D_TreeNode)left_child).set_falling_bars(bars);
        return true;
      }
      else
        ((D_TreeNode)right_child).set_falling_bars(bars);
      return true;
    }//end of case ACTIVE
    return true; //false;
  }
} 

class Bar{
  static final int ACTIVE=1;
  static final int DEAD=2;
  static final int WAIT=3;
  int status;

  int left;                 //interval left end;
  int right;                //interval right endl;
  int l;                    //graph left end;
  int r;                    //graph right end;
  int y;                    //graph y_cor;
  int graph_length;


  public Bar(int a, int b, int c, int d, int e){
    left=a;
    right=b;
    l=c;
    r=d;
    y=e;
  }

}

public class D_Tree{
  static final int DIST_BETWEEN_NODE=60;
  static int BASE_MARGIN_X=60;
  static int BASE_MARGIN_Y=50;
  static int BASE_X=360;
  static int X_MOVE=0;
  static int Y_MOVE=0;
  Vector temp1=new Vector();
  Vector temp2=new Vector();
  int total_length;
  Vector intervals=new Vector();
  int[] end_points;
  D_TreeNode root;
  D_TreeNode current_picked_node;
  

  public static void set_base_x(int k){
     X_MOVE=k;
  }

  public static void set_base_y(int k){
     Y_MOVE=k;
  }
  public D_Tree(Y_Tree a){
  root=a.root;
  }

  public void show_result(Graphics graphic){
    int k=root.get_result();
    graphic.drawString("the sum of the lenght on the"+
      " flashing nodes is the lengh of the overlapped"+
      " segment: "+k, 30, root.position_y+20);
  }
  public void pick_node(int x, int y){
     if(current_picked_node!=null){
       current_picked_node.resetColor();
     }
     current_picked_node=root.paint_closest_node(x,y);
  }
}

