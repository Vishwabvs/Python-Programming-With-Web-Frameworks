
import java.awt.*;
import java.io.*;
import java.util.Vector;

//a debug class to faciliate debug job
class Debug{
  static int index=0;
  static boolean debug_on=false;
  static void print(String str){
    if(debug_on){
     System.out.println("[DEBUG "+index+"]"+str);
     index++;
    }
  }
  static void print_err(String str){
    System.out.println("[ERROR] "+str);
  }
}

//AAlgorithm to calculate the sweep width of some given
//rectangls
//give rectangles to this class and it should set up the
//intervals on x_axis with sweep width on the end point.
//notice: instance of this class should be created after
//        sweep button clicked.
public class AAlgo extends Thread{
  Interface inf;
  X_Tree x_tree;
  boolean no_rec=false;
  int pre_ind=0;
  int pre_area=0;
  int pre_pos;
  int pre_sweep_h=0;
  int cur_pos=0;
  int total_area=0;
  int left_most=0;
  int right_most=99999; 
  float area;
  float sweep_h;
  Vector cur_recs=new Vector();
  IntervalInfo[] info;


  public AAlgo(Interface a){
    inf=a;
    set_tree(inf.rectangles);
  }


  public void run(){
    while(true){
      int temp=cur_pos-pre_pos;
      if(temp!=0){
        area=(float)(get_left_area(cur_pos)/2500.0);
        sweep_h=(float)(get_sweep_height(cur_pos)/50.0);
        inf.resultArea.set_result(area,sweep_h);
      }
      suspend();
    } 
  }

  public void reset_cur_pos(int a){
    cur_pos=a;
    resume();
  }

  public void set_tree(Vector rects){
    if(rects.size()<=0)
      no_rec=true;
    else{
      x_tree=new X_Tree(rects);
      info=x_tree.info;
      total_area=x_tree.get_left_area(99999);
      left_most=x_tree.root.left_most;
      right_most=x_tree.root.right_most;
      pre_pos=left_most;
      pre_sweep_h=info[0].sweep_height;
    }
  }

  int get_left_area(int cur_pos){
    if(no_rec)
      return 0;
      if(pre_ind==0 && cur_pos>=left_most){
        inf.treeArea.reset_tree(info[0].y_tree);
      }
      if(pre_ind==x_tree.size_of_info-1 && cur_pos<=right_most){
        inf.treeArea.reset_tree(info[pre_ind].y_tree);
      } 
      if(info[pre_ind].left<=cur_pos && 
        cur_pos <info[pre_ind].right){

        pre_area= pre_area+(cur_pos-pre_pos)*pre_sweep_h;
        pre_pos=cur_pos;
        return pre_area;
      } 
      if(cur_pos<=left_most){
        inf.treeArea.reset_tree(null);
        return 0;
      }
      if(cur_pos>=right_most){
        inf.treeArea.reset_tree(null);
        return total_area; 
      }
      else{
        pre_pos=cur_pos;
        pre_area= x_tree.get_left_area(cur_pos);
        pre_ind=x_tree.cur_ind;
        pre_sweep_h=info[pre_ind].sweep_height;
        inf.treeArea.reset_tree(info[pre_ind].y_tree);
        return pre_area;
      }

  }

  int get_sweep_height(int cur_pos){
    if(no_rec)
      return 0;
    if(cur_pos<left_most || cur_pos>right_most)
      return 0;
    return pre_sweep_h;
  }
}
 
