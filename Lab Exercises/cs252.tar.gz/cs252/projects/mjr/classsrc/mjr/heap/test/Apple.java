/*
 * @(#)Apple.java	1.0 2/23/96 Michael J. Radwin
 */

import mjr.treegraphics.*;
import mjr.heap.*;

public
class Apple implements Heapable {
    int seeds_;

    public Apple(int seeds)
    {
	seeds_ = seeds;
    }
    
    public boolean greaterThan(Object other)
    {
	return (seeds_ > ((Apple)other).seeds_);
    }
    
    public boolean lessThan(Object other)
    {
	return (seeds_ < ((Apple)other).seeds_);
    }
    
    public boolean equalTo(Object other)
    {
	return (seeds_ == ((Apple)other).seeds_);
    }

    public String toString()
    {
	return String.valueOf(seeds_);
    }
    
    public static void main(String args[])
    {
	Apple apples[] = new Apple[10];

	int i = 0;
	apples[i++] = new Apple(4);
	apples[i++] = new Apple(1);
	apples[i++] = new Apple(3);
	apples[i++] = new Apple(2);
	apples[i++] = new Apple(16);
	apples[i++] = new Apple(9);
	apples[i++] = new Apple(10);
	apples[i++] = new Apple(14);
	apples[i++] = new Apple(8);
	apples[i++] = new Apple(7);

	Heap h = new Heap(apples);
	h.visualize(new ASCIITreeGraphics());

	while (!h.isEmpty()) {
	    Apple a = (Apple)h.remove();
	    System.out.println(a);
//	    h.visualize(new ASCIITreeGraphics());
	}

	for (int j = 0; j < 10; j++) {
	    h.insert(new Apple((int)(Math.random() * 50)));
	    h.visualize(new ASCIITreeGraphics());
	}

	for (int j = 0; j < 5; j++) {
	    Apple a = (Apple)h.remove();
	    System.out.println(a);
	}

	h.visualize(new ASCIITreeGraphics());
	
	for (int j = 0; j < 10; j++) {
	    h.insert(new Apple((int)(Math.random() * 50)));
	}
	
	h.visualize(new ASCIITreeGraphics());
	
    }
}
