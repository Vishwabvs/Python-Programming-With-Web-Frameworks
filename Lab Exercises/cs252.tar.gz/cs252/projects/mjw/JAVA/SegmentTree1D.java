import java.awt.*;
import geometry.*;
import Tree;
import AbstractPrototypeFactory;
import java.io.StreamTokenizer;
import TreeAccessible;
import SegmentSet;
import VCR;
import java.lang.Math;
import EventVisitSegmentCommand;

public class SegmentTree1D extends AnimatorGeometryClient implements TreeAccessible {

	protected SegmentSet 	segment_set_;
	protected Tree		segment_tree_;
	protected boolean		dragging_ = false, dragging_end_pt_ = false;
	protected int 		drag_end_pt_=-1;
        protected Segment	        edited_segment_;
	protected AbstractPrototypeFactory   command_factory_;
	protected CommandList		   command_list_;
        protected EventCheckOverlapCommand   node_range_;
	protected GeometryPoint 	query_start_, query_end_;
	protected int 		query_segment_width_;
	protected Image 		allocation_node_image_;
        protected Image           leaf_node_image_, selected_seg_endpt_img_, unselected_seg_endpt_img_;
  	protected Color		unselected_segment_tree_color_;
        protected Color		selected_segment_tree_color_;
        protected Color 		query_segment_color_;
        protected Color           range_color_;
        protected Color selected_segment_color_;
	protected Color unselected_segment_color_;
        protected int segment_thickness_;

	public void init()
	{
		super.init();

		disableButton(GRIDSWITCH);

		segment_set_ = new SegmentSet();
		segment_set_.setLimits(	user_input_area_.minX(),
					user_input_area_.minY(),
					user_input_area_.maxX(),
					user_input_area_.maxY());
									
		segment_tree_ = new Tree();
		initTreeColors();
		edited_segment_ = null;

		// begin applet parameters
		unselected_segment_tree_color_ =
		  attribute("unselected_segment_tree_color", Color.blue);
		selected_segment_tree_color_ =
		  attribute("selected_segment_tree_color",Color.red);

		selected_segment_color_ = attribute("selected_segment_color", Color.red);
		unselected_segment_color_ = attribute("unselected_segment_color", Color.blue);
		segment_thickness_ = attribute("segment_thickness", 2);
		segment_set_.setThickness(segment_thickness_);
		
		leaf_node_image_ = getImage (getCodeBase(),
				attribute ("leaf_node","../images/redball.gif"));
		
		allocation_node_image_ =  getImage (getCodeBase(),
				attribute ("allocation_node","../images/pr_ball.gif"));
		selected_seg_endpt_img_=  getImage (getCodeBase(),
						    attribute ("selected_seg_endpt","../images/redball.gif"));
		unselected_seg_endpt_img_ =  getImage (getCodeBase(),
				attribute ("unselected_seg_endpt","../images/blueball.gif")); 
      		tracker.addImage(allocation_node_image_, 0);
		tracker.addImage(leaf_node_image_,0);
		query_segment_color_ = attribute ("query_segment_color",Color.black);
		query_segment_width_ = attribute ("query_segment_width",2);
		range_color_ = attribute("range_color",Color.lightGray);
		// end applet paramenters

		
		user_input_area_.enableTickMarks();
		command_factory_ = new AbstractPrototypeFactory();
		command_list_ = new CommandList();
		
		
		EventVisitSegmentCommand c1 = new
			EventVisitSegmentCommand( imOffscreen,
						  myGeometryPanel,
						  this,
						  user_input_area_);
	
		command_factory_.registerType(c1.toString(),c1);

		EventCheckOverlapCommand c2 = new
			EventCheckOverlapCommand( imOffscreen,
						  myGeometryPanel,
						  this,
						  user_input_area_);
		command_factory_.registerType(c2.toString(),c2);

		EventVisitPointCommand c3 = new
			EventVisitPointCommand(	  imOffscreen,
						  myGeometryPanel,
						  this,
						  user_input_area_);
		command_factory_.registerType(c3.toString() ,c3);

	
		EventGoLeftCommand c4 = new
			EventGoLeftCommand(	 imOffscreen,
						 myGeometryPanel,
						 this,
						 user_input_area_);
		command_factory_.registerType(c4.toString() ,c4);

		EventGoRightCommand c5 = new
			EventGoRightCommand(	 imOffscreen,
						 myGeometryPanel,
						 this,
						 user_input_area_);
		command_factory_.registerType(c5.toString(),c5);

		EventNoChildrenCommand c6 = new
			EventNoChildrenCommand(	 imOffscreen,
						 myGeometryPanel,
						 this,
						 user_input_area_);
		command_factory_.registerType(c6.toString() ,c6);

		EventOverlapCommand c7 = new
			EventOverlapCommand(	 imOffscreen,
						 myGeometryPanel,
						 this,
						 user_input_area_);

		command_factory_.registerType(c7.toString() ,c7);
		node_range_ =  new
			EventCheckOverlapCommand( imOffscreen,
						  myGeometryPanel,
						  this,
						  user_input_area_);
	}                    


	public void disableButton(String label)
	{
		int num_components = UIpanel.countComponents();
		//System.out.println("in disableButton; num_components: " + num_components);
		for (int i = 0; i < num_components; i++)
		{
			Component c = UIpanel.getComponent(i);
			//System.out.println("checking type...");
			if (c instanceof Container)
			{
				int num = ((Container) c).countComponents();
				for (int j=0; j < num; j++)
				{
					Component cp = ((Container) c).getComponent(j);
					if (cp instanceof Button)
					{
						String s  = ((Button) cp).getLabel();
						//System.out.println("comparing "+ s + " with  " + label);
						if (s.equals(label))
						{
						  //System.out.println("disableing GRID BUTTON");
							((Button) cp).disable();
							return;
						}
					}
				}  // for j
			}
		} // for i
	}



//*************************************************************************************	   
	public void asyncRecalculate()
	{
	  //System.out.println("********** ** ** ** ** ** in asyncrecalculate");
	 	if (segment_set_.numSegments() > 1)
	 	{
		  //System.out.println("sending gen_segment_tree,# of  items"+segment_set_.numSegments());
		  //segment_set_.write(System.out);
	 	 	pstrmServerOut.print("gen_segment_tree ");
	 	 	segment_set_.write(pstrmServerOut);
	 	 	try {
	 	 		segment_tree_ = new Tree(stknServerIn);
	 	 		initTreeColors();
	 	 	} catch (GeometryException e) {
			  System.out.println(e.getMessage());
			  System.out.println("Could not read tree data from the stream.");
	 	 	}
			super.asyncRecalculate();
	 	 }                                                            
	 	 else 
	 	 {
		   //System.out.println("not ready to send yet: #of items"+segment_set_.numSegments());
	 	  	segment_tree_ = new Tree();
	 	  	initTreeColors();
			myGeometryPanel.repaint();
	 	 }
	}                          

	 	
//*************************************************************************************	
	public void initTreeColors()
	{
	 	setUnselectedNodeImage(imBlueDot);
	 	setSelectedNodeImage(imRedDot);
		setLeafNodeImage(leaf_node_image_);
		setAllocationNodeImage(allocation_node_image_);
	 	segment_tree_.setUnselectedColor(unselected_segment_tree_color_);
	 	segment_tree_.setSelectedColor(selected_segment_tree_color_);
		segment_set_.setSelectedColor(selected_segment_color_);
		segment_set_.setUnselectedColor(unselected_segment_color_);
		segment_set_.setThickness(segment_thickness_);
	}	
	
//*************************************************************************************	
    
    public Segment addSegment(int x1, int x2, int y)
    {
    	return addSegment(new Point(x1, y), new Point(x2, y));
    }
    
    
    public Segment addSegment(Point p1, Point p2)
    {
      //System.out.println("adding a segment");
      	if (p1.y != p2.y)
       		p2.y = p1.y;
	   		
      	Segment s = segment_set_.addSegment(p1, p2,selected_seg_endpt_img_, unselected_seg_endpt_img_,this);
       	recalc();
       	//myGeometryPanel.repaint();   		 
       	return s;	   
    }            
	
//*************************************************************************************	

	public Segment findSegment(int x, int y)
	{
	  //System.out.println("in app.findSegment");
	 	return segment_set_.findSegment(x, y);
	}	                                      
	
	
//*************************************************************************************
	public void moveSegment(Segment s, int offx, int offy)
	{
	 	segment_set_.moveSegment(s, offx, offy); 
		recalc();   
		//myGeometryPanel.repaint();			
	}                             
//*************************************************************************************

	public void removeSegment(Segment s)
	{
	 	segment_set_.removeSegment(s);
	 	recalc();
		//myGeometryPanel.repaint();	 	
	 }
	 	
 //*************************************************************************************


  	public void clearSegments()
  	{
		user_input_area_.clearAllTickMarks();
  	 	segment_set_ = new SegmentSet();
  	 	segment_set_.setLimits(0,0, myGeometryPanel.size().width,
				       myGeometryPanel.size().height);  
		segment_tree_ = new Tree();
		initTreeColors();
		vcr_.eject();
		myGeometryPanel.repaint();
  	}      
  	
 //*************************************************************************************
 
 	public void removeSelectedSegments()
 	{
 	 	segment_set_.removeSelectedSegments();
 	 	vcr_.eject();
		recalc();
 	} 	                          
 	
 	public void moveSelectedSegments(int offx, int offy)
 	{
 	 	segment_set_.moveSelectedSegments(offx, offy);
 	 	vcr_.eject();
 	 	recalc();
 	}                             
 	
 	public void unselectSegments()
 	{
 		segment_set_.unselectSegments();
 		vcr_.eject();
 		myGeometryPanel.repaint();
 	}                             
 	
 	public int numSelectedSegments()
 	{
 	 	return segment_set_.numSelectedSegments();
 	}                                             
 	
 	public void selectSegment(int x, int y)
 	{
 	 	segment_set_.selectSegment(x,y);
 	 	myGeometryPanel.repaint();
 	}                             

	public void selectSegment(Segment s)
 	{
		if (s != null)
		{
 	 		segment_set_.selectSegment(s);
 	 		myGeometryPanel.repaint();
		}
 	}                             
 	
 	public void unselectSegment(int x, int y)
 	{
 	 	Segment s = segment_set_.findSegment(x,y);
		if (s != null)
		    segment_set_.unselectSegment(s);
 	 	myGeometryPanel.repaint();
 	}

	public void unselectSegment(Segment s)
 	{
		if (s != null)
		    segment_set_.unselectSegment(s);
 	 	myGeometryPanel.repaint();
 	}


	public void moveEndPoint(Segment s, int endp, int offx)
	{
		segment_set_.moveEndPoint(s, endp,offx);
		vcr_.eject();
 	 	recalc();
	}

	public boolean mouseDown(Event evt, int x, int y)
	{
	     if (user_input_area_.inside(x,y))
             {
   		requestFocus();
	     	//System.out.println("mouseDown");
		query_start_ = null;
	     	query_end_ = null;
   	  	edited_segment_ = findSegment(x, y);

		if (evt.metaDown())
		{
			unselectSegments();
			//System.out.println("evt.metaDown()");
			query_start_ = new GeometryPoint(x,y);
			query_end_ = new GeometryPoint(x,y);
			myGeometryPanel.repaint();
			return true;
		}

		query_start_ = null;
		query_end_ = null;
     	 	if (edited_segment_ == null)
 		{
			unselectSegments();
			Point gpt = findClosestGridPoint(x,y,gridSpacing);
			x = gpt.x;
			y = gpt.y;
       			edited_segment_ = addSegment(x, x+gridSpacing, y);
     		}
		else
		{
			drag_end_pt_ =segment_set_.isClickOnEndPoint(edited_segment_,x,y);
			if (drag_end_pt_ != 0)
				dragging_end_pt_ = true;
			else
			{
				dragging_end_pt_ = false;
				drag_end_pt_ = 0;
			}
			if (edited_segment_.isSelected())
			  unselectSegment(edited_segment_);
			else
			  selectSegment(edited_segment_);
		}
 	     }
	     else
	       {   
		 TreeNode node = segment_tree_.findNode(x, y, this);
		 if (node != null)
		   {		  
		     Graphics g = myGeometryPanel.getGraphics();      
		     g.clipRect (0, 0, size().width, size().height);
		     draw(grOffscreen);
		     g.drawImage(imOffscreen, 0, 0, this);
		     node_range_.setNode(node);
		     node_range_.setReversible(true);
		     node_range_.undo();
		   }
		 return false;
	       }
      	     return true;
	}


        public void drawQuerySegment(Graphics g)
	{
	  if (query_start_ != null && query_end_ != null)
		GeometryLine.draw(g, query_start_.x, query_start_.y,
				  query_end_.x, query_end_.y, query_segment_width_, query_segment_color_); 
	}
  
	public boolean mouseUp(Event evt, int x, int y)
	{
	     if (user_input_area_.inside(x,y))
             {

		if (evt.metaDown())
		{
			query_end_ = new GeometryPoint(query_start_.x, y);
			myGeometryPanel.repaint();
			if (query_start_ != null)
				sendIntersectionQuery(query_start_, query_end_);
			return true;
		}

		if (edited_segment_ != null && bDragging)
     		{
			Point move = calculateGridMove(	edited_segment_,
							x,y,
							gridSpacing,
							dragging_end_pt_,
							drag_end_pt_);

			int offx = move.x;
			int offy = move.y;
			if (dragging_end_pt_ && drag_end_pt_ != 0)
				moveEndPoint(edited_segment_,drag_end_pt_, offx);
			else
        			moveSegment (edited_segment_, offx, offy);
		}
      	     }
	     drag_end_pt_ = 0;
	     dragging_end_pt_ = false;
	     edited_segment_ = null;
    	     bDragging = false;
   	     return true;
	}


	protected Point calculateGridMove(Segment sg,
					  int x, int y, //mouse coords
					  int 		grid_spacing,
					  boolean 	is_drag_pt,
					  int 		dragged_pt)
	{
		int offx = 0, offy =0;
		Point s, e;
		if (is_drag_pt && dragged_pt == SegmentSet.RIGHT)
		{
			s = sg.getTo();
			e = sg.getFrom();
		}
		else
		{
			s = sg.getFrom();
			e = sg.getTo();
		}			
		int dx = x - s.x;
		if (Math.abs(dx) > grid_spacing/2)
		// snap to grid
		{
			if (dx < 0)
			{
				if (!(dragged_pt == SegmentSet.RIGHT
					&& Math.abs(e.x - s.x)==grid_spacing))
					offx = -grid_spacing;
			}
			else {
				if (!(dragged_pt == SegmentSet.LEFT
					&& Math.abs(e.x - s.x)==grid_spacing))
					offx = grid_spacing;
			}
		}

		int dy = y - s.y;
		if (Math.abs(dy) > grid_spacing/2)
		// snap to grid
		{
			if (dy < 0)
				offy = -grid_spacing;
			else	offy = grid_spacing;
		}
		return new Point(offx, offy);
	}


	public boolean mouseDrag(Event evt, int x, int y)
	{
	    if (user_input_area_.inside(x,y))
            {

	      //System.out.println("mouseDrag x: "+x+",  y: "+y);
		if (evt.metaDown())
		{
		  //System.out.println("meta Down");
			query_end_ = new GeometryPoint(query_start_.x, y);
			myGeometryPanel.repaint();
			return true;
		}

		
		if (edited_segment_ == null)
			return false;
		selectSegment(edited_segment_);
		int offx=0, offy=0;
		bDragging = true;
		//System.out.println("before calcMove");
		Point move = calculateGridMove(	edited_segment_,
						x,y,
						gridSpacing,
						dragging_end_pt_,
						drag_end_pt_);
		offx = move.x;
		offy = move.y;
		//System.out.println("mouseDrag offx: "+offx+",  offy: "+offy);
		

		if (offx == 0 && offy == 0)
			return true;

		if ((numSelectedSegments() == 1) && dragging_end_pt_ && drag_end_pt_ != 0)
			moveEndPoint(edited_segment_,drag_end_pt_, offx);
     		else if(numSelectedSegments()<2 && edited_segment_.isSelected())
       			moveSegment (edited_segment_, offx, offy);
    		else 
       			moveSelectedSegments(offx,offy);
	    }
   	    return true;
	}




	 /**
    	* Draws the user's input point set and the computed range tree
    	*/
   	public void draw(Graphics g) {
    	  	super.draw (g);
     	  	drawSegmentSet(g);
		user_input_area_.draw(g);
     	  	drawTree(g);
		if (query_start_ != null && query_end_ != null)
			drawQuerySegment(g);
  	}

	 public void drawTree(Graphics g)
    	 {
		segment_tree_.draw (g, this);
   	 }

   	 public void drawSegmentSet(Graphics g)
   	 {
		segment_set_.draw (g, user_input_area_);
  	 }

	// need to overwrite this method since we have different
	// methods for correcponding actions
	public boolean action(Event evt, Object arg) 
	{
	  query_start_ = null;
	  query_end_ = null;
	  segment_tree_.resetAttributes();

   	  if(CLEARGRAPH.equals(arg))
		clearSegments();
   	  else  if(GRIDSWITCH.equals(arg))
	 	switchGrid();
       	  else if(DELETENODES.equals(arg))
	    	removeSelectedSegments();
	  else if(UNSELECTNODES.equals(arg))
	      	unselectSegments();
   	  return false;
	}

	public SegmentSet getSegmentSet()
	{
		return segment_set_;
	}


    public Tree getTree()
    {
        return segment_tree_;
    }

    public void drawPointSet(Graphics g)
    {
    }

    public PointSet getPointSet()
    {
        return null;
    }

    public Dimension getTreeNodeImageDimension()
    {
        return new Dimension(imBlueDot.getWidth(this),imBlueDot.getHeight(this));
    }

    public Dimension getPointImageDimension()
    {
        return new Dimension(imRedDot.getWidth(this),imRedDot.getHeight(this));
    }



    public void sendIntersectionQuery(GeometryPoint query_start, GeometryPoint query_end)
    {
	if (segment_set_.numSegments() > 1)
        {
		segment_tree_.resetAttributes();

		//System.out.println("sending 'alg_segment_intersection' to server"+server.getInetAddress().getHostName()+" "+server.getPort());
		//query_start.print(System.out);
		//query_end.print(System.out);

		pstrmServerOut.print("alg_segment_intersection ");
		query_start.print(pstrmServerOut);
		query_end.print(pstrmServerOut);
		pstrmServerOut.println();

		int num_events = stknServerIn.nextInt();
		stknServerIn.nextEOL();
		command_list_ = new CommandList();
		for (int i=0; i < num_events; i++)
		{
			RangeSearchAnimationCommand c =(RangeSearchAnimationCommand)
				command_factory_.create(stknServerIn);
			stknServerIn.nextEOL();
			/*if (c==null)
			{
				System.out.println("factory returned null");
				break;
			}*/
			command_list_.addCommand(c);
			//System.out.println(c.toString());
		}
		if (command_list_.numElements() != 0)
			vcr_.insert(command_list_);
	}

    }



	public Image getUnselectedNodeImage()
	{
		return segment_tree_.getUnselectedNodeImage();
	}
	public Image getSelectedNodeImage()
	{
		return segment_tree_.getSelectedNodeImage();	
	}
	public Image getAllocationNodeImage()
	{
		return segment_tree_.getAllocationNodeImage();
	}
	public void setUnselectedNodeImage(Image im)
	{
		segment_tree_.setUnselectedNodeImage(im);	
	}
	public void setSelectedNodeImage(Image im)
	{
		segment_tree_.setSelectedNodeImage(im);
	}
	public void setAllocationNodeImage(Image im)
	{
		segment_tree_.setAllocationNodeImage(im);
	}

	public void setGridSpacing(int n)
	{
		query_start_ = null;
		query_end_ = null;
		super.setGridSpacing(n);
		recalc();
		segment_set_.gridSpacingChanged(old_grid_spacing_, n, user_input_area_);
	
	}
  
   public void setLeafNodeImage(Image im)
  {
        segment_tree_.setLeafNodeImage(im);
  }

  public Image getLeafNodeImage()
  {
        return leaf_node_image_;
  }

  public Color getRangeColor()
  {
    return range_color_;
  }
};	











	



