import java.util.*;
import java.awt.*;
import LayoutAlgorithm;
import Node;
import WebTree;


public class MuratsAlgorithm extends LayoutAlgorithm {

  
  private int rank;
  Vector nodeList_;
  WebTree webtree_;
  int canvasWidth_, canvasHeight_;

  MuratsAlgorithm(WebTree webtree) {
    webtree_ = webtree;
    canvasWidth_ = webtree_.getWidth();
    canvasHeight_ = webtree_.getHeight();

  }



public void execute (Vector nodeList)
  {
    nodeList_ = nodeList;
    System.out.println("Murat's algorithm execute called");
    int total = nodeList_.size();
    System.out.println("total nodes: " + total);
    if (total==0) return;
    System.out.println("traversing...");
    
    
    int ver_interval = 70;
    int hor_interval = 40;

    // FInd the level with most nodes
    int maxLevel = getMaxLevel();
    Node root = (Node)nodeList.elementAt(0);
    
    System.out.println("MAX LEVEL = " + maxLevel);

    if (((maxLevel+1) *hor_interval) > canvasWidth_*3) 
      hor_interval = canvasWidth_*3/(maxLevel+1);
    else
      if ((maxLevel * hor_interval)< 570)
     	hor_interval = canvasWidth_/(maxLevel+1);
    
    int max_hor = hor_interval * maxLevel;

    root.setPosition(new Point(max_hor/2, 20));
    webtree_.snapTo(new Point(max_hor/2, canvasHeight_/2));

    InsertionSort(nodeList);
    RankSort(nodeList);
    int max_depth = getMaxDepth();

    if (max_depth*ver_interval > 1690) 
      {
	ver_interval = 1670/max_depth+1;
      }

    int index = 1;
    int orig_index = 1;



    for (int i=1; i<=max_depth; i++)
      {
	index = orig_index+1;
	int depth_count =1;

	if (index != total){
	while (((Node)nodeList.elementAt(index)).getDepth() == i)
	  {
	    depth_count++;
	    index ++;
	    if (index == total ) break;

	  }
	}

	int y = ver_interval*(i) + 20;
	int x = max_hor / (depth_count+2);
	


	  for (int j=1; j<=depth_count; j++)
	  {
	  
	    ((Node)nodeList.elementAt(orig_index)).setPosition(new Point(x*j, y));
	    orig_index++;
	  }
      }
  


  }


public final int getMaxLevel(){
  int maxLevel = 0;
  int currentDepth = 0;
  int depthCount=0;

  for (int i=0; i<nodeList_.size(); i++){
    if (((Node)nodeList_.elementAt(i)).getDepth() == currentDepth)
      {
	    depthCount++;
	    System.out.println(depthCount);
      }
    else 
      {
	if (maxLevel < depthCount) maxLevel = depthCount;
	depthCount = 1;
	currentDepth = ((Node)nodeList_.elementAt(i)).getDepth();
      }
  }
  	if (maxLevel < depthCount) maxLevel = depthCount;
  return maxLevel;

}


public final int getMaxDepth(){
  int temp =0;
  for (int i=0; i<nodeList_.size(); i++){
    if (((Node)nodeList_.elementAt(i)).getDepth() >  temp)
      temp =((Node)nodeList_.elementAt(i)).getDepth(); 
  }
  return temp;
}




public final void InsertionSort (Vector list)
  {

    int k, j, n;
    Node itemToInsert;
    boolean stillLooking;

    n = list.size();

    for (k = 1; k < n; k++) {

      itemToInsert = (Node)list.elementAt(k);
      j = k - 1;
      stillLooking = true;
      
      while (j >= 1 && stillLooking)

        if (itemToInsert.getDepth() < ((Node)(list.elementAt(j))).getDepth()) {

          list.setElementAt(list.elementAt(j), j + 1);
          j--;

        } else
	   stillLooking = false;

        list.setElementAt(itemToInsert, j + 1);
    }
  }

  



public final void RankSort (Vector list)
  {

    int k, j, n;
    Node itemToInsert;
    boolean stillLooking;

    n = list.size();

    for (k = 1; k < n; k++) {

      itemToInsert = (Node)list.elementAt(k);
      j = k - 1;
      stillLooking = true;
      
      while (j >= 1 && stillLooking){
	boolean cond1 = false;
	boolean cond2 = false;

	if (itemToInsert.getDepth() == ((Node)(list.elementAt(j))).getDepth())
	{
	  cond1 = true;
	Node temp1 = itemToInsert.getParent();
	Node temp2 = ((Node)(list.elementAt(j))).getParent();

	while (temp1.getParent() != temp2.getParent())
	  {
	    temp1 = temp1.getParent();
	    temp2 = temp2.getParent();
	  }

	if (temp1.getRank() > 
		  (temp2.getRank()))
	  cond2 = true;
      }
	if (cond1 && cond2)
	  {
	    list.setElementAt(list.elementAt(j), j + 1);
	    j--;
	  }
	
            else
	      	      stillLooking = false;
      }
        list.setElementAt(itemToInsert, j + 1);
    }
  }

  

}

