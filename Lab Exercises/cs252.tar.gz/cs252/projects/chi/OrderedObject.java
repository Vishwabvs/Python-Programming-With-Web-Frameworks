public abstract class OrderedObject {
      public abstract boolean lessThan(OrderedObject k);
      public abstract boolean largerThan(OrderedObject k);
      public abstract boolean equals(OrderedObject k);
}
