/*
 * @(#)HeapImpl.java	1.0 3/9/96 Michael John Radwin
 */

package mjr.heap;

import java.util.NoSuchElementException;
import mjr.treegraphics.*;

/**
 * An interface for a heap implementation.  Can either be descending or
 * ascending.
 *
 * @see HeapDescending
 * @see HeapAscending
 * @version 1.0 3/9/96
 * @author <A HREF="http://www.cs.brown.edu/people/mjr/">Michael John Radwin</A>
 */
public
interface HeapImpl {
    public Heapable remove() throws NoSuchElementException;
    public void insert(Heapable key);
    public void preorder(int i, TreeGraphics tg);
    public boolean isEmpty();
    public int size();
    public void removeAllElements();
}
