package cs252;

import java.awt.*;
import java.util.Vector;
import sprite.*;
import graph.*;

public class TransitiveEnforcer extends Enforcer {
    Vector nodes_;

    public TransitiveEnforcer(DominanceGraph area, int id) {
	super (area, id);
    }

    public void Enforce(Vector nodes, Vector edges, OrderNode lowest) {
	nodes_ = new Vector();
	
	area_.ClearVisited();
	lowest.Reachable();
	
	area_.ClearVisited();	
	Vector transitive = new Vector();
	lowest.TransitiveEdges(transitive);
	
	for (int loop = 0; loop < transitive.size(); ++loop) {
	    Edge current = (Edge)(transitive.elementAt(loop));
	    Node nodeA = current.GetA(); Node nodeB = current.GetB();
	    int pX = (nodeA.x_ + nodeB.x_) / 2;
	    int pY = (nodeA.y_ + nodeB.y_) / 2;
	    current.Remove();
	    area_.RemoveDelay();

	    Node node = new OrderNode(area_, pX, pY, true);
	    node.SetColor(Color.red);
	    nodes_.addElement(node);
	    area_.Delay(DominanceGraph.ADD_DELAY);

	    Edge a = new Edge(area_, nodeA, node);
	    area_.AddDelay();
	    Edge b = new Edge(area_, node, nodeB);
	    area_.AddDelay();
	    InformAllSplit(current, a, node, b);
	}
    }
    
    public boolean DidAnything() {
	return nodes_.size() > 0;
    }
    
    public void Restore() {
 	for (int loop = 0; loop < nodes_.size(); ++loop) {
 	    Node center = (Node)(nodes_.elementAt(loop));
	    center.Hide();
 	    area_.RemoveDelay();
 	}
    }
    
    public void Undo() {
 	for (int loop = 0; loop < nodes_.size(); ++loop) {
 	    Node center = (Node)(nodes_.elementAt(loop));
	    center.Remove();
 	    area_.RemoveDelay();

	    Edge edgeA = (Edge)(center.GetAllEdges().elementAt(0));
	    Edge edgeB = (Edge)(center.GetAllEdges().elementAt(1));
	    Node nodeA = edgeA.GetOther(center);
	    Node nodeB = edgeB.GetOther(center);
	    
	    if (nodeA.y_ > nodeB.y_)
		new Edge(area_, nodeA, nodeB);
	    else
		new Edge(area_, nodeB, nodeA);
 	    area_.AddDelay();
 	}
    }
}
