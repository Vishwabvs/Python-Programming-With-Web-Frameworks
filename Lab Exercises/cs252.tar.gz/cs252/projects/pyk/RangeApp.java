/*
 * RangeApp.java
 *
 * Description:
 *    This class is the main applet class for the 3D box intersection
 *    algorithm, it mainly creates the interface and starts the other
 *    components
 */
import java.awt.Graphics;
import java.awt.FontMetrics;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Button;
import java.awt.Label;
import java.awt.TextField;
import java.awt.Choice;
import java.awt.Component;
import java.awt.Insets;
import java.awt.Event;
import java.util.Vector;

public class RangeApp extends java.applet.Applet implements Runnable
{

     Thread running;                      // state of the applet
     int appletWidth = 0;                 // width of the applet
     int appletHeight = 0;                // height of the applet
     int cellWidth = 0;                   // the interface is a gridbag
                                          // layout, this is the width
                                          // of a cell in the grid
     int cellHeight = 0;                  // the height of a cell in
                                          // the grid
     DrawingPanel drawingCanvas;          // the drawing area
     Positioner positionCanvas;           // area for the positioning tool
     TextField statusLine;                // status message text area
     Button previousButton;               // previous button under the
                                          // positioning tool
     Button nextButton;                   // next button under the
                                          // positioning tool
     Choice controllerOptions;            // choice box of controller
                                          // options
     Choice objectChoice;                 // choice box of objects to
                                          // be created
     Choice actionChoice;                 // choice box of action to take
     Choice queryChoice;                  // choice box of query types
     Choice analysisChoice;               // choice box for analysis mode
     Button doQueryButton;                // do query button located at
                                          // the bottom of the applet
     Button resetButton;                  // reset button located at the
                                          // bottom of the applet, used
                                          // to restore initial state
                                          // of applet
     Camera camera = null;                // the camera
     PixelPoint pointOfInterest = null;   // the point of interest
     boolean objectSeen = false;          // flag which indicates whether
                                          // there are any cubes
     boolean cameraSeen = false;          // flag to indicate whether the
                                          // camera has been created
     boolean pixelSeen = false;           // flag to indicate whether a
                                          // point of interest has been
                                          // created
     boolean debugMode = false;           // flag to indicate whether to
                                          // show analysis
     boolean changeDepth = false;         // flag to indicate whether
                                          // a cube's depth is being
                                          // changed
     Query query = null;                  // the query to perform

     // add a component to the grid bag
     private void add(Component component, GridBagLayout gridBag,
                      GridBagConstraints constraints, int x, int y, int width,
                      int height)
     {
        constraints.gridx = x;
        constraints.gridy = y;
        constraints.gridwidth = width;
        constraints.gridheight = height;
        gridBag.setConstraints(component, constraints);
        add(component);
     }

     // set up the interface
     public void init()
     {
        GridBagLayout gridBag = new GridBagLayout();
        setLayout(gridBag);
        GridBagConstraints constraints = new GridBagConstraints();
        appletWidth = size().width;
        appletHeight = size().height;
        cellWidth = appletWidth / 6;
        cellHeight = appletHeight / 15;

        statusLine = new TextField();
        statusLine.setText("Depress, drag, and release mouse to position bounding boxes");
        statusLine.setEditable(false);
        previousButton = new Button("Previous");
        previousButton.disable();
        nextButton = new Button("Next");
        nextButton.disable();
        controllerOptions = new Choice();
        controllerOptions.addItem("Selected Placement");
        controllerOptions.addItem("Latest Placement");
        controllerOptions.addItem("Cycled Placement From First Object");
        controllerOptions.addItem("Cycled Placement From Latest Object");
        controllerOptions.addItem("Camera Placement");
        controllerOptions.select("Latest Placement");
        controllerOptions.disable();
        objectChoice = new Choice();
        objectChoice.addItem("Bounding Box");
        objectChoice.addItem("Camera");
        objectChoice.addItem("Point of Interest");
        objectChoice.select("Bounding Box");
        actionChoice = new Choice();
        actionChoice.addItem("Initial Placement");
        actionChoice.addItem("Change Depth");
        actionChoice.addItem("3D Positioning");
        actionChoice.select("Initial Placement");
        actionChoice.disable();
        queryChoice = new Choice();
        queryChoice.addItem("All Objects Detected");
        queryChoice.addItem("First Object Encountered");
        queryChoice.select("All Objects Detected");
        queryChoice.disable();
        analysisChoice = new Choice();
        analysisChoice.addItem("No");
        analysisChoice.addItem("Yes");
        analysisChoice.select("No");
        analysisChoice.disable();
        doQueryButton = new Button("Do Query");
        doQueryButton.disable();
        resetButton = new Button("Reset");
        resetButton.disable();
        drawingCanvas = new DrawingPanel(this);
        positionCanvas = new Positioner(this);
        camera = new Camera(this);
        pointOfInterest = new PixelPoint(this);

        constraints.weightx =100;
        constraints.weighty = 100;
        constraints.fill = GridBagConstraints.NONE;
        constraints.anchor = GridBagConstraints.WEST;
        add(new Label("Drawing Area"), gridBag, constraints, 1, 0, 2, 1);
        add(new Label("Object"), gridBag, constraints, 4, 0, 1, 1);
        add(objectChoice, gridBag, constraints, 5, 0, 1, 1);
        add(new Label("Action"), gridBag, constraints, 4, 1, 1, 1);
        add(actionChoice, gridBag, constraints, 5, 1, 1, 1);
        add(new Label("Query"), gridBag, constraints, 4, 2, 1, 1);
        add(queryChoice, gridBag, constraints, 5, 2, 1, 1);
        add(new Label("Show Analysis"), gridBag, constraints, 4, 3, 1, 1);
        add(analysisChoice, gridBag, constraints, 5, 3, 1, 1);
        add(new Label("Position"), gridBag, constraints, 4, 4, 1, 1);
        add(controllerOptions, gridBag, constraints, 5, 4, 1, 1);

        constraints.fill = GridBagConstraints.NONE;
        constraints.anchor = GridBagConstraints.CENTER;
        add(new Label("   "), gridBag, constraints, 4, 5, 1, 1);
        add(new Label("3D Positioning Controller"), gridBag,
                      constraints, 4, 6, 2, 1);
        constraints.fill = GridBagConstraints.NONE;
        constraints.anchor = GridBagConstraints.NORTH;
        add(new Label("Status Messages:"), gridBag, constraints, 0, 13,
            1, 1);
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.anchor = GridBagConstraints.NORTH;
        add(statusLine, gridBag, constraints, 1, 13, 5, 1);
        constraints.fill = GridBagConstraints.NONE;
        constraints.anchor = GridBagConstraints.EAST;
        add(previousButton, gridBag, constraints, 4, 12, 1, 1);
        constraints.fill = GridBagConstraints.NONE;
        constraints.anchor = GridBagConstraints.CENTER;
        add(nextButton, gridBag, constraints, 5, 12, 1, 1);
        add(positionCanvas, gridBag, constraints, 4, 7, 2, 5);
        constraints.fill = GridBagConstraints.BOTH;
        add(drawingCanvas, gridBag, constraints, 0, 1, 4, 12);
        constraints.fill = GridBagConstraints.NONE;
        constraints.anchor = GridBagConstraints.SOUTH;
        add(doQueryButton, gridBag, constraints, 2, 14, 1, 1);
        add(resetButton, gridBag, constraints, 3, 14, 1, 1);
        drawingCanvas.setSize(cellWidth * 4, cellHeight * 12);
        positionCanvas.setSize(cellWidth * 2, cellHeight * 5);
     }

     // start the thread running
     public void start()
     {
        if (running == null)
        {
           running = new Thread(this);
           running.start();
        }
     }

     // stop the thread from running
     public void stop()
     {
        if (running != null)
        {
           running.stop();
           running = null;
        }
     }

     // event handler
     public boolean action(Event evt, Object arg)
     {
        if (evt.target instanceof Choice)
        {
           handleChoice((String) arg);
        }
        else if (evt.target instanceof Button)
        {
           handleButton((String) arg);
        }
        return true;
     }

     // portion of event handler that handle chocie string events
     private void handleChoice(String choiceString)
     {
        drawingCanvas.highLightObjects(false);
        drawingCanvas.repaint();
        if (choiceString.equals("Latest Placement"))
        {
           latestPlacement();
        }
        else if (choiceString.equals("Camera"))
        {
           if (cameraSeen == false)
           {
              statusLine.setText(
                "Click mouse in the Drawing area to position the camera and view screen");
           }
           else
           {
              statusLine.setText(
                "A camera is already present, there can only be one camera");
           }
           if (controllerOptions.isEnabled())
           {
              controllerOptions.disable();
              positionCanvas.reset();
              drawingCanvas.setRectSelected(-1);
              disableDirectionButtons();
              drawingCanvas.repaint();
           }
           if ((actionChoice.getSelectedItem().equals("3D Positioning") == true) ||
               (actionChoice.getSelectedItem().equals("Change Depth") == true))
           {
              actionChoice.select("Initial Placement");
           }
        }
        else if (choiceString.equals("No"))
        {
           debugMode = false;
           drawingCanvas.clearScreen();
           drawingCanvas.repaint();
        }
        else if (choiceString.equals("Yes"))
        {
           debugMode = true;
           drawingCanvas.clearScreen();
           drawingCanvas.repaint();
        }
        else if (choiceString.equals("Point of Interest"))
        {
           if (pixelSeen == false)
           {
              statusLine.setText("Click mouse in the Drawing area to position the point of interest");
           }
           else
           {
              statusLine.setText("A point of interest already exists, there can only be one");
           }
           if (controllerOptions.isEnabled())
           {
              controllerOptions.disable();
              positionCanvas.reset();
              drawingCanvas.setRectSelected(-1);
              disableDirectionButtons();
              drawingCanvas.repaint();
           }
           if ((actionChoice.getSelectedItem().equals("3D Positioning") == true) ||
               (actionChoice.getSelectedItem().equals("Change Depth") == true))
           {
              actionChoice.select("Initial Placement");
           }
        }
        else if (choiceString.equals("Bounding Box"))
        {
           if (actionChoice.getSelectedItem().equals("3D Positioning"))
           {
              statusLine.setText(
                "Depress arrowheads in 3D Positioning tool to position the bounding box");
           }
           else
           {
              if (choiceString.equals("Change Depth"))
              {
                 statusLine.setText(
                   "Depress arrowheads in 3D Positioning tool to change the depth");
              }
              else
              {
                 statusLine.setText(
                   "Depress, drag, and release mouse in the Drawing area to position the bounding boxes");
              }
           }
           positionCanvas.reset();
        }
        else if (choiceString.equals("3D Positioning"))
        {
           controllerOptions.select("Latest Placement");
           if (changeDepth == true)
           {
              positionCanvas.rebuildPositioner();
           }
           else
           {
              positionCanvas.reset();
           }
           changeDepth = false;
           positionCanvas.reset();
           statusLine.setText(
               "Type of positioning will depend on setting of Position choice");
           if (controllerOptions.isEnabled() == false)
           {
              controllerOptions.enable();
           }
           setSelected();
        }
        else if (choiceString.equals("Change Depth"))
        {
           controllerOptions.select("Latest Placement");
           changeDepth = true;
           statusLine.setText(
               "Depth to be changed will depend upon setting of Position choice");
           if (controllerOptions.isEnabled() == false)
           {
              controllerOptions.enable();
           }
           positionCanvas.buildDepthPositioner();
           setSelected();
        }
        else if (choiceString.equals("Initial Placement"))
        {
           if (controllerOptions.isEnabled())
           {
              controllerOptions.disable();
              positionCanvas.reset();
              drawingCanvas.setRectSelected(-1);
              disableDirectionButtons();
              drawingCanvas.repaint();
           }
        }
        else if (choiceString.equals("Selected Placement"))
        {
           selectedPlacement();
        }
        else if (choiceString.equals("Cycled Placement From First Object"))
        {
           cycledPlacementFromFirst();
        }
        else if (choiceString.equals("Cycled Placement From Latest Object"))
        {
           cycledPlacementFromLatest();
        }
        else if (choiceString.equals("Camera Placement"))
        {
           cameraPlacement();
        }
     }

     // event handler for controller options choice box
     private void setSelected()
     {
        if (controllerOptions.getSelectedItem().equals("Cycled Placement From Latest Object"))
        {
           cycledPlacementFromLatest();
        }
        else if (controllerOptions.getSelectedItem().equals("Cycled Placement From First Object"))
        {
           cycledPlacementFromFirst();
        }
        else if (controllerOptions.getSelectedItem().equals("Selected Placement"))
        {
           selectedPlacement();
        }
        else if (controllerOptions.getSelectedItem().equals("Latest Placement"))
        {
           latestPlacement();
        }
        else if (controllerOptions.getSelectedItem().equals("Camera Placement"))
        {
           cameraPlacement();
        }
     }

     // handle camera placement
     private void cameraPlacement()
     {
        if (cameraSeen)
        {
           statusLine.setText(
             "Depress arrowheads in 3D Positioning tool to position the camera and viewport");
        }
        else
        {
           statusLine.setText(
             "A camera must be initially placed before it can be positioned");
        }
        if (drawingCanvas.candidates.isEmpty() == false)
        {
           drawingCanvas.candidates.removeAllElements();
        }
        positionCanvas.reset();
        drawingCanvas.setRectSelected(-1);
        disableDirectionButtons();
        drawingCanvas.repaint();
     }

     // disable previous and next buttons
     private void disableDirectionButtons()
     {
        if (previousButton.isEnabled() == true)
        {
           previousButton.disable();
        }
        if (nextButton.isEnabled() == true)
        {
           nextButton.disable();
        }
     }

     // handle the placement of the last created cube
     private void latestPlacement()
     {
        if (actionChoice.getSelectedItem().equals("Change Depth"))
        {
           statusLine.setText(
             "Depress arrowheads in 3D Positioning tool to change the depth of the latest cube");
        }
        else
        {
           statusLine.setText(
             "Depress arrowheads in 3D Positioning tool to position the latest bounding box");
        }
        drawingCanvas.setRectSelected(drawingCanvas.getLastRectID());
        disableDirectionButtons();
        drawingCanvas.repaint();
        if (drawingCanvas.candidates.isEmpty() == false)
        {
           drawingCanvas.candidates.removeAllElements();
        }
        positionCanvas.reset();
     }

     // handle selected placement
     private void selectedPlacement()
     {
        drawingCanvas.candidateNum = 0;
        drawingCanvas.setRectSelected(-1);
        disableDirectionButtons();
        if (actionChoice.getSelectedItem().equals("Change Depth"))
        {
           statusLine.setText(
             "Click on cube to select it then use 3D Positioning tool to change the depth");
        }
        else
        {
           statusLine.setText(
             "Click in a bounding box to select it then use 3D Positioning tool to position it");
        }
        if (drawingCanvas.candidates.isEmpty() == false)
        {
           drawingCanvas.candidates.removeAllElements();
        }
        drawingCanvas.repaint();
        positionCanvas.reset();
     }

     // handle cycled placement from the first created cube to the last
     private void cycledPlacementFromFirst()
     {
        if (actionChoice.getSelectedItem().equals("Change Depth"))
        {
           statusLine.setText(
             "Depress arrowheads in 3D Positioning tool to change the depth of the highlighted cube");
        }
        else
        {
           statusLine.setText(
             "Depress arrowheads in 3D Positioning tool to position the highlighted bounding box");
        }
        if (drawingCanvas.candidates.isEmpty() == false)
        {
           drawingCanvas.candidates.removeAllElements();
        }
        positionCanvas.reset();
        nextButton.enable();
        if (previousButton.isEnabled() == true)
        {
           previousButton.disable();
        }
        drawingCanvas.setRectSelected(0);
        drawingCanvas.repaint();
     }

     // handle cycled placement from the last created cube to the first
     private void cycledPlacementFromLatest()
     {
        if (actionChoice.getSelectedItem().equals("Change Depth"))
        {
           statusLine.setText(
             "Depress arrowheads in 3D Positioning tool to change the depth of the highlighted cube");
        }
        else
        {
           statusLine.setText(
             "Depress arrowheads in 3D Positioning tool to position the highlighted bounding box");
        }
        positionCanvas.reset();
        if (drawingCanvas.candidates.isEmpty() == false)
        {
           drawingCanvas.candidates.removeAllElements();
        }
        previousButton.enable();
        if (nextButton.isEnabled() == true)
        {
           nextButton.disable();
        }
        drawingCanvas.setRectSelected(drawingCanvas.getLastRectID());
        drawingCanvas.repaint();
     }

     // event handler for mouse button events
     private void handleButton(String buttonName)
     {
        int tempSelected = 0;

        if (buttonName.equals("Reset"))
        {
           drawingCanvas.reset();
           if (changeDepth == true)
           {
              positionCanvas.rebuildPositioner();
           }
           else
           {
              positionCanvas.reset();
           }
           changeDepth = false;
           camera.reset(drawingCanvas.offScreenGraphics);
           pointOfInterest.reset(drawingCanvas.offScreenGraphics);
           if ((actionChoice.getSelectedItem().equals("3D Positioning") == true) ||
               (actionChoice.getSelectedItem().equals("Change Depth") == true))
           {
              actionChoice.select("Initial Placement");
           }
           if (nextButton.isEnabled())
           {
              nextButton.disable();
           }
           if (previousButton.isEnabled())
           {
              previousButton.disable();
           }
           actionChoice.disable();
           resetButton.disable();
           controllerOptions.disable();
           if (objectChoice.getSelectedItem().equals("Bounding Box"))
           {
              statusLine.setText(
             "Depress, drag, and release mouse in the Drawing area to position bounding boxes");
           }
           else if (objectChoice.getSelectedItem().equals("Camera"))
           {
              statusLine.setText(
                 "Click mouse in Drawing area to position camera and view screen");
           }
           else
           {
              statusLine.setText(
                "Click mouse in Drawing area to position point of interest");
           }
        }
        else if (buttonName.equals("Next"))
        {
           if (controllerOptions.getSelectedItem().
               equals("Selected Placement"))
           {
              if (drawingCanvas.candidateNum < drawingCanvas.candidates.
                  size() - 1)
              {
                 drawingCanvas.candidateNum++;
                 tempSelected = ((Integer) drawingCanvas.candidates.
                                elementAt(drawingCanvas.candidateNum)).
                                intValue();
              }
              if (drawingCanvas.candidateNum ==
                  drawingCanvas.candidates.size() - 1)
              {
                 nextButton.disable();
              }
           }
           else
           {
              tempSelected = drawingCanvas.getRectSelected() + 1;
              if (tempSelected >= drawingCanvas.getLastRectID())
              {
                 nextButton.disable();
              }
           }
           if (previousButton.isEnabled() == false)
           {
              previousButton.enable();
           }
           positionCanvas.reset();
           drawingCanvas.setRectSelected(tempSelected);
           drawingCanvas.repaint();
        }
        else if (buttonName.equals("Previous"))
        {
           if (controllerOptions.getSelectedItem().
               equals("Selected Placement"))
           {
              if (drawingCanvas.candidateNum > 0)
              {
                 drawingCanvas.candidateNum--;
                 tempSelected = ((Integer) drawingCanvas.candidates.
                                elementAt(drawingCanvas.candidateNum)).
                                intValue();
              }
              if (drawingCanvas.candidateNum == 0)
              {
                 previousButton.disable();
              }
           }
           else
           {
              tempSelected = drawingCanvas.getRectSelected() - 1;
              if (tempSelected <= 0)
              {
                 previousButton.disable();
              }
           }
           if (nextButton.isEnabled() == false)
           {
              nextButton.enable();
           }
           positionCanvas.reset();
           drawingCanvas.setRectSelected(tempSelected);
           drawingCanvas.repaint();
        }
        else if (buttonName.equals("Do Query"))
        {
           drawingCanvas.highLightObjects(false);
           positionCanvas.reset();
           drawingCanvas.setRectSelected(-1);
           if (actionChoice.getSelectedItem().equals("3D Positioning") == true)
           {
              actionChoice.select("Initial Placement");
           }
           controllerOptions.select("Latest Placement");
           controllerOptions.disable();
           disableDirectionButtons();
           drawingCanvas.repaint();
           query = new Query(this);
           if (analysisChoice.getSelectedItem().equals("No"))
           {
              debugMode = false;
              drawingCanvas.clearScreen();
              drawingCanvas.repaint();
              if (queryChoice.getSelectedItem().equals("All Objects Detected"))
              {
                 statusLine.setText(
                   "Performing query to find all bounding boxes which can be seen by the camera");
                 query.doQuery(false, true);
              }
              else
              {
                 statusLine.setText(
                  "Performing query to find bounding box within viewport which contains pixel");
                 query.doQuery(false, false);
              }
           }
           else
           {
              debugMode = true;
              drawingCanvas.repaint();
              if (queryChoice.getSelectedItem().equals("All Objects Detected"))
              {
                 statusLine.setText(
                   "Performing query (with analysis) to find all bounding boxes which can be seen by the camera");
                 query.doQuery(true, true);
              }
              else
              {
                 statusLine.setText(
                  "Performing query (with analysis) to find bounding box within viewport which contains pixel");
                 query.doQuery(true, false);
              }
           }
        }
     }

     // insets from the edge of the applet
     public Insets insets()
     {
        return new Insets(10, 10, 0, 0);
     }

     // run the thread at maximum priority
     public void run()
     {
        Thread thisThread = Thread.currentThread();
        thisThread.setPriority(Thread.MAX_PRIORITY);
        repaint();
     }

     // update the applet
     public void update(Graphics g)
     {
        paint(g);
     }

     // the painting method
     public void paint(Graphics g)
     {
     }
}
