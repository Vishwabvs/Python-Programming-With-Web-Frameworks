package cs252;

import java.awt.*;
import sprite.*;
import graph.*;
import java.applet.Applet;
import java.util.Vector;
import java.net.URL;

public class LoadPanel extends SpriteArea implements ButtonOwner {
    String base_;
    GraphArea target_;
    ButtonSprite buttons_[];

    public LoadPanel(Applet applet, Container container, GraphArea target) {
	super(WIDTH, HEIGHT);

	target_ = target;
        SetUpdateMode(NO_UPDATING);

        base_ = applet.getCodeBase().toString() + "cs252/graphs/";

	buttons_ = new ButtonSprite[TITLES.length];
	int x = OFFSET; int y = OFFSET;
	for (int loop = 0; loop < TITLES.length; ++loop) {
	    buttons_[loop] = new ButtonSprite(this, this, x, y, BUTTON_WIDTH,
					      BUTTON_HEIGHT, TITLES[loop]);
	    y += BUTTON_HEIGHT + OFFSET;
	}

        SetUpdateMode(DELAYED_UPDATING);

        container.add(this);
        container.resize(container.preferredSize());
        WaitForGraphics();
        
	Graphics back = GetBackgroundGraphics();
	back.setColor(Color.lightGray);
	back.fillRect(0, 0, WIDTH, HEIGHT);
        BackgroundDirty();
    }

    public void Enable() {
	for (int loop = 0; loop < TITLES.length; ++loop)
	    buttons_[loop].Enable();
    }

    public void Disable() {
	for (int loop = 0; loop < TITLES.length; ++loop)
	    buttons_[loop].Disable();
    }

    public void ButtonClicked(ButtonSprite button) {
	for (int loop = 0; loop < TITLES.length; ++loop)
	    if (buttons_[loop] == button) {
		URL u;
		try {
		    u = new URL(base_ + URLS[loop]);
		}
		catch (Exception e) {
		    System.out.println(e);
		    return;
		}
		target_.ClearGraph();
		target_.LoadGraph(u);
		return;
	    }
    }

    public final static String TITLES[] = {
	"Paper 1", "Paper 2", "HW", "Rhombus", "Pentagon"
    };
    
    public final static String URLS[] = {
	"paper1", "paper2", "hw", "rhombus", "pent"
    };

    final public static int OFFSET = 5;
    final public static int BUTTON_WIDTH = 60;
    final public static int BUTTON_HEIGHT = 20;

    final public static int WIDTH = BUTTON_WIDTH + OFFSET * 2;
    final public static int HEIGHT = (TITLES.length * (BUTTON_HEIGHT +
						       OFFSET) + OFFSET);
}
