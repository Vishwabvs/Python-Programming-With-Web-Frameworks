/*
 * @(#)PSTGraph.java	1.0 5/2/96 Michael John Radwin
 */

package mjr.pstree;

import java.awt.*;
import java.applet.*;
import java.io.*;
import java.net.*;
import java.util.*;
import sprite.*;
import graph.*;
import leda.*;

/**
 * Interactive graph area for the priority search tree demo.
 *
 * @version $Revision: 1.43 $
 * @author <A HREF="http://www.cs.brown.edu/people/mjr/">Michael John Radwin</A>
 */
public class PSTGraph extends GraphArea implements ButtonOwner, CheckboxOwner {
//    Thread kicker;
    protected ButtonSprite draw, clear, random;
    protected SearchBoxSprite searchBox = null;
    protected CheckboxSprite median;

    Vector points;
    protected Vector getPoints() { return points; }
    protected Vector queryPts, queryEdges;
    protected Vector images;
    protected PSTree tree = null;
    protected Applet applet;
    protected boolean showSplitLine;
    protected String statusText = "";
    ParameterInfo info;
    
    public PSTGraph(Applet applet, int WIDTH, int HEIGHT, ParameterInfo info)
    {
	super(true, WIDTH, HEIGHT, true, Color.black);
	points = new Vector(30);
	queryPts = new Vector(30);
	queryEdges = new Vector(30);

	this.applet = applet;
	this.info = info;
	int button_y = size().height - BUTTON_HEIGHT - BUTTON_BORDER;
	POINT_BOUND = size().height - BUTTON_HEIGHT - (2 * BUTTON_BORDER);

	DisallowEditing();
        SetUpdateMode(NO_UPDATING);
	random = new ButtonSprite(this, this,
				  BUTTON_BORDER, button_y,
				  BUTTON_WIDTH, BUTTON_HEIGHT, "Random pts");
        draw = new ButtonSprite(this, this,
				BUTTON_WIDTH + BUTTON_BORDER * 2, button_y,
				BUTTON_WIDTH, BUTTON_HEIGHT, "Create tree");
	draw.Disable();
        clear = new ButtonSprite(this, this,
				 BUTTON_WIDTH * 2 + BUTTON_BORDER * 3, button_y,
				 BUTTON_WIDTH, BUTTON_HEIGHT, "Reset");
	median = new CheckboxSprite(this, this,
				    BUTTON_WIDTH * 3 + BUTTON_BORDER * 4, button_y,
				   "Visualize median");
	showSplitLine = false;
	SetUpdateMode(DELAYED_UPDATING);

	applet.add("North", this);
//        applet.resize(applet.preferredSize());
//        applet.show();
        WaitForGraphics();
	Graphics back = GetBackgroundGraphics();

	Tile(applet, back, WIDTH, HEIGHT, info.BACKGROUND);
	images = loadImages(applet, info.IMAGEBASE, GIFNode.IMAGES);
	addPanels(applet, info.BACKGROUND);
	dispInstructions(PST_INST);
        BackgroundDirty();
	AllowEditing();

	applet.resize(applet.preferredSize());
	applet.show();
	dprintln("height: " + applet.preferredSize().height +
		 " width : " + applet.preferredSize().width);
    }

    public void dispInstructions(String theInst[])
    {
	display_instructions(info.INSTRUCTIONS, theInst);

	statusText = new String(theInst[0]);
	for (int i = 1; i < theInst.length; i++)
	    statusText = statusText.concat(" " + theInst[i]);
	
	showStatus();
    }

    /**
     * displays the current instructions in the status area
     * of the applet
     */
    public void showStatus()
    {
	if (applet != null && applet.getAppletContext() != null)
	    applet.showStatus(statusText);
    }

    /**
     * inserts from 0 to RANDOM_PTS random points into
     * each of the 4 quadrants of the graph
     */
    protected void randomPoints()
    {
	int x[] = new int[RANDOM_PTS * 4];
	int y[] = new int[RANDOM_PTS * 4];
	int w = (size().width / 2) - Node.RADIUS;
	int h = (POINT_BOUND / 2) - Node.RADIUS;
	int i;
	PSTNode n;
	
        SetUpdateMode(NO_UPDATING);
	// try and get a good random distribution by doing
	// x before y and breaking into 4 quadrants
	for (i = 0; i < RANDOM_PTS; i++) {
	    x[i]              = (int)(Math.random() * w) + Node.RADIUS;
	    x[i+RANDOM_PTS]   = (int)(Math.random() * w) + Node.RADIUS;
	    x[i+RANDOM_PTS*2] = (int)(Math.random() * w) + w + Node.RADIUS;
	    x[i+RANDOM_PTS*3] = (int)(Math.random() * w) + w + Node.RADIUS;
	}
	for (i = 0; i < RANDOM_PTS; i++) {
	    y[i]              = (int)(Math.random() * h) + Node.RADIUS;
	    y[i+RANDOM_PTS]   = (int)(Math.random() * h) + h + Node.RADIUS;
	    y[i+RANDOM_PTS*2] = (int)(Math.random() * h) + Node.RADIUS;
	    y[i+RANDOM_PTS*3] = (int)(Math.random() * h) + h + Node.RADIUS;
	}
	for (i = 0; i < RANDOM_PTS * 4; i++) {	
	    if (LocateMouse(x[i], y[i]) == null) addPoint(x[i], y[i]);
	}
	SetUpdateMode(DELAYED_UPDATING);
    }

    public void CheckboxChanged(CheckboxSprite checkbox, boolean newState)
    {
	showSplitLine = newState;
	if (showSplitLine)
	    for (int i = 0; i < points.size(); i++)
		((PSTNode)points.elementAt(i)).showSplitLine();
	else
	    for (int i = 0; i < points.size(); i++)
		((PSTNode)points.elementAt(i)).hideSplitLine();
    }
    
    
    public void ButtonClicked(ButtonSprite button)
    {
	if (button == random)
	    randomPoints();

	else if (!points.isEmpty()) {
	    if (button == draw) {
		lockGraph();
		drawTree();
		allowSearching();
	    }
	    else if (button == clear) {
		disallowSearching();
		ClearGraph();
		unLockGraph();
	    }
	}
    }


    protected Vector loadImages(Applet applet, String base, String gifs[])
    {
	Vector v = new Vector(gifs.length);
	v.setSize(gifs.length);
	Image tmpImages[] = new Image[gifs.length];
	MediaTracker tracker = new MediaTracker(applet);

	for (int i = 0; i < gifs.length ; i++) {
	    URL u = null;
	    try {
		u = new URL(base + gifs[i]);
	    } catch (MalformedURLException e) {
		trouble("Error: " + e);
		return null;
	    }
	    tmpImages[i] = applet.getImage(u);
	    dprintln("addImage  " + base + gifs[i]);
	    tracker.addImage(tmpImages[i], i);
	}

	try {
	    for (int j = 0; j < gifs.length ; j++) {
		dprintln("waitForID " + base + gifs[j]);
		tracker.waitForID(j);
		v.setElementAt(tmpImages[j], j);
	    }
	} catch (InterruptedException e) {
	    trouble("Error: " + e);
	    return null;
	}

	return v;
    }

    public void rangeQuery(int x0, int x1, int y0)
    {
	if (tree == null) return;

	// return the previous set of found points to blue first
	for (int j = 0; j < queryPts.size(); j++)
	    ((PSTNode)queryPts.elementAt(j)).setImage(info.UNVISITED);
	queryPts.removeAllElements();
	for (int j = 0; j < queryEdges.size(); j++) {
	    ((PSTEdge)queryEdges.elementAt(j)).thin();
	    ((PSTEdge)queryEdges.elementAt(j)).Anchor();
	    ((PSTEdge)queryEdges.elementAt(j)).ZToBottom();
	}
	queryEdges.removeAllElements();

	// do a new search, color the found nodes with VISITED_SUCCESS
	Vector result[] = tree.range_query(x0, x1, y0);
	for (int i = 0; i < result[0].size(); i++) {
	    PSTNode n = (PSTNode)((ps_item)result[0].elementAt(i)).client_data;
	    if (n != null) {
		n.setImage(info.VISITED_SUCCESS);
		Vector incoming = n.GetIncomingEdges();
		queryPts.addElement(n);

		for (int e = 0; e < incoming.size(); e++) {
		    ((PSTEdge)incoming.elementAt(e)).thick();
		    ((PSTEdge)incoming.elementAt(e)).Anchor();
		    ((PSTEdge)incoming.elementAt(e)).ZToBottom();
		    queryEdges.addElement(incoming.elementAt(e));
		}
	    }
	    else
		trouble("unexpected null in Success vector of rangeQuery" +
			(ps_item)result[0].elementAt(i));
	}

	// color those failure points with VISITED_FAILURE
	for (int i = 0; i < result[1].size(); i++) {
	    PSTNode n = (PSTNode)((ps_item)result[1].elementAt(i)).client_data;
	    if (n != null) {
		n.setImage(info.VISITED_FAILURE);
		queryPts.addElement(n);

		Vector incoming = n.GetIncomingEdges();
		for (int e = 0; e < incoming.size(); e++) {
		    ((PSTEdge)incoming.elementAt(e)).thick();
		    ((PSTEdge)incoming.elementAt(e)).Anchor();
		    ((PSTEdge)incoming.elementAt(e)).ZToBottom();
		    queryEdges.addElement(incoming.elementAt(e));
		}
	    }
	    else
		trouble("unexpected null in Failure vector: " +
			(ps_item)result[1].elementAt(i));
	}

    }

    protected void allowSearching()
    {
	if (searchBox == null) {
	    searchBox = new SearchBoxSprite(this);
	    searchBox.Add();
	}

	dispInstructions(RANGE_INST);
	rangeQuery(searchBox.x0(), searchBox.x1(), searchBox.y0());
    }
    
    protected void disallowSearching()
    {
 	tree = null;
	if (searchBox != null) {
	    searchBox.Remove();
	    searchBox = null;
	}
	queryPts.removeAllElements();
	queryEdges.removeAllElements();
	dispInstructions(PST_INST);
    }
    

    protected void lockGraph()
    {
	DisallowEditing();
	draw.Disable();
	random.Disable();
    }

    protected void unLockGraph()
    {
	AllowEditing();
	draw.Disable();
	random.Enable();
    }

    
    protected synchronized void drawTree()
    {
	dprintln("drawTree");

	tree = new PSTree();
	for (int i = 0; i < points.size(); i++) {
	    PSTNode n = (PSTNode)points.elementAt(i);
	    tree.insert(n.x_, n.y_);
	    dprintln("inserted " + n.toString());
	}
	
	// draw the tree, split lines, and store the nodes in client_data
	try {
	    tree.postorder(new DrawTreeCommand(this, info), new NullCommand());
	    if (showSplitLine)
		for (int i = 0; i < points.size(); i++)
		    ((PSTNode)points.elementAt(i)).showSplitLine();
//	    TreeGraphics tg = new ASCIITreeGraphics();
//	    tree.preorder(new TGNodeCommand(tg), new TGLeafCommand(tg));
	}
	catch (Throwable t)
	    trouble("Unexpected Throwable: " + t);
    }


    /**
     * Gets input from the user that isn't intercepted by any sprite.
     * Currently only handles mouse clicks, which create a new node.
     */
    public void HandleBackgroundEvent(Event e)
    {
	if (e.id == Event.MOUSE_ENTER) {
	    showStatus();
	    return;
	}
	if (!CanEdit()) return;
	if (e.id == Event.MOUSE_DOWN) {
	    // don't cover the instructions or buttons
	    if (e.y > POINT_BOUND) return;
					       
	    // ensure that all coordinates are greater than zero
	    PSTNode n = addPoint(((e.x > 0) ? e.x : 1), ((e.y > 0) ? e.y : 1));
	    dprintln("graph added " + n.toString());
	}
    }

    protected PSTNode addPoint(int x, int y)
    {
	PSTNode n = new PSTNode(this, x, y, images, info);
	points.addElement(n);
	n.setImage(info.UNVISITED);
	n.Add();
	n.Anchor();

	if (GetGraph().size() == 1)
	    draw.Enable();

	return n;
    }
	
    
    protected void RemoveNode(Node node)
    {
	points.removeElement(node);
	super.RemoveNode(node);
    }

    public PSTNode getNodeAt(int x, int y)
    {
	for (int i = points.size() - 1; i >= 0; --i) {
	    PSTNode n = (PSTNode)points.elementAt(i);
	    if ((n.x_ == x) && (n.y_ == y))
		return n;
	}
	return null;
    }


    synchronized public void LoadGraph(String s)
    {
	StringTokenizer tokens = new StringTokenizer(s, " \t\r\n->(),");
	
	while(tokens.hasMoreTokens()) {
	    String type = tokens.nextToken();
	    if (type.equalsIgnoreCase("node")) {
		String label = tokens.nextToken();
		int x = Integer.parseInt(tokens.nextToken());
		int y = Integer.parseInt(tokens.nextToken());
		addPoint(x, y);
	    }
	    else if (type.equalsIgnoreCase("edge")) {
		// ignore these
		tokens.nextToken();
		tokens.nextToken();
	    }
	}
    }

    public void dprintln(String str)
    {
	if (info.DEBUG)
	    System.err.println(str);
    }

    public void dprint(String str)
    {
	if (info.DEBUG)
	    System.err.print(str);
    }

    public void trouble(String str)
    {
	System.err.println(str);
    }

    private final static String[] PST_INST =  {
	"Click to place points, drag to move",
	"points.  Delete key removes points."
    };

    protected final static String[] RANGE_INST =  {
	"Resize box from sides or corners",
	"and release mouse to perform query."
    };

    final public static String rcsid = "$Id: PSTGraph.java,v 1.43 1996/05/31 17:08:34 mjr Exp $";

    final public static int RANDOM_PTS = 3;
    final public static int BUTTON_WIDTH = 70;
    final public static int BUTTON_HEIGHT = 20;
    final public static int BUTTON_BORDER = 10;
    public int POINT_BOUND;

    final public static int LEGEND_HEIGHT = 40;
    protected final static String[] LEGEND_TXT = {
	"unvisited", "success", "failure",
	"left child", "right child"
    };


    protected void addPanels(Applet applet, String theTile)
    {
	GIFNode n;
	TextSprite text;
	GraphArea legend = new GraphArea(true, size().width, LEGEND_HEIGHT);
	legend.DisallowEditing();
	Font font = new Font("Dialog", Font.BOLD, 10);
	
	applet.add("Center", legend);
	legend.WaitForGraphics();
	legend.Tile(applet, legend.GetBackgroundGraphics(),
		    size().width, LEGEND_HEIGHT, theTile);

	// horizontal divider
	LineSprite l = new LineSprite(legend, 0, 5, size().width, 5);
	l.Add(); l.Anchor();

	// unvisited node
	n = new GIFNode(legend, 10, 20, images); 
	n.setImage(info.UNVISITED);
	n.Add(); 
 	text = new TextSprite(legend, 25, 15, LEGEND_TXT[0]);
 	text.Add(); text.SetFont(font); text.Anchor();

	// visited, success
	n = new GIFNode(legend, 110, 20, images);
	n.setImage(info.VISITED_SUCCESS);
	n.Add(); n.Anchor();
 	text = new TextSprite(legend, 125, 15, LEGEND_TXT[1]);
 	text.Add(); text.SetFont(font); text.Anchor();

	// visited, failure
	n = new GIFNode(legend, 210, 20, images);
	n.setImage(info.VISITED_FAILURE);
	n.Add(); n.Anchor();
 	text = new TextSprite(legend, 225, 15, LEGEND_TXT[2]);
 	text.Add(); text.SetFont(font); text.Anchor();

	// left child
	GIFNode a = new GIFNode(legend, 310, 20, images);
	a.setImage(info.UNVISITED);
	a.Add();
	GIFNode b = new GIFNode(legend, 330, 30, images);
	b.setImage(info.UNVISITED);
	b.Add();
	Edge e = new Edge(legend, a, b, info.LEFT_EDGE);
	e.Add(); e.Anchor();
	
 	text = new TextSprite(legend, 335, 15, LEGEND_TXT[3]);
 	text.Add(); text.SetFont(font); text.Anchor();

	// right child
	GIFNode a2 = new GIFNode(legend, 430, 20, images);
	a2.setImage(info.UNVISITED);
	a2.Add();
	GIFNode b2 = new GIFNode(legend, 450, 30, images);
	b2.setImage(info.UNVISITED);
	b2.Add();
	Edge r = new Edge(legend, a2, b2, info.RIGHT_EDGE);
	r.Add(); r.Anchor();

	// force those nodes to front
	a.ZToTop(); b.ZToTop(); a2.ZToTop(); b2.ZToTop();

	text = new TextSprite(legend, 455, 15, LEGEND_TXT[4]);
	text.Add(); text.SetFont(font); text.Anchor();

	legend.BackgroundDirty();
	applet.add("South", new LoadPanel(this));
    }

}

class LoadPanel extends Panel {
    PSTGraph graph;
    TextField text;
    
    LoadPanel(PSTGraph graph)
    {
	this.graph = graph;
	add(new Label("Load/Save pointset:"));
	add(text = new TextField("", 30));
	add(new Button("Load"));
	add(new Button("Save"));
    }
    
    public synchronized boolean action(Event event, Object what)
    {
	if (event.target instanceof Button) {
	    if (((Button)event.target).getLabel().equals("Load"))
		loadGraph(text.getText());
		
	    else if (((Button)event.target).getLabel().equals("Save"))
		saveGraph(text.getText());
	}
	    
	return true;
    }
    
    protected boolean loadGraph(String filename)
    {
	if (!filename.equals("")) {
	    URL u;
	    try
		u = new URL(graph.info.GRAPHBASE + filename);
	    catch (Exception e) {
		graph.trouble("Unexpected exception: " + e);
		return false;
	    }
	    graph.dprintln("Loading graph: " + filename);
	    graph.disallowSearching();
	    graph.ClearGraph();
	    graph.unLockGraph();
	    try
		graph.LoadGraph(u);
	    catch (Exception e) {
		graph.trouble("Unexpected exception: " + e);
		return false;
	    }
	    graph.BackgroundDirty();
	    return true;
	}

	return false;
    }

    protected boolean saveGraph(String filename)
    {
	String nodes = new String();
	for (int i = 0; i < graph.points.size(); i++)
	    nodes += graph.points.elementAt(i).toString() + "\r\n";

	String postURL =
	    graph.info.SAVE_CGI +
	    "?points=" + URLEncoder.encode(nodes) +
	    "&filename=" + URLEncoder.encode(filename);

	graph.dprintln(nodes);
	graph.dprintln(postURL);

	URL u;
	try
	    u = new URL(postURL);
	catch (MalformedURLException e) {
	    graph.trouble("Unexpected exception: " + e);
	    return false;
	}

	try {
	    String result = "";
	    byte buffer[] = new byte[1000];
	    InputStream iStream = u.openStream();
	    int actual = 0;
	    do {
		actual = iStream.read(buffer);
		if (actual != -1)
		    result += new String(buffer, 0, 0, actual);
	    }
	    while (actual != -1);
	    graph.dprintln(result);
	}
	catch (IOException e) {
	    graph.trouble(e.toString());
	    return false;
	}
	
	return true;
    }
}




