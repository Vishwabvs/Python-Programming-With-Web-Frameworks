import java.awt.*; 

class DrawingMethods {
   final static int INFTY = ClosestPairDiagram.INFTY; 
   final static int RIGHT = ClosestPairDiagram.RIGHT;
   final static int LEFT = ClosestPairDiagram.LEFT; 
   final static int LINERESOLUTION = ClosestPairDiagram.LINERESOLUTION; 
   final static int R = ClosestPairDiagram.NODERADIUS;
   final static int COUNTER = 0; 
   final static int CLOCK = 1; 

   // Errase the graphics of the circle  
   public static void erraseCircleAt(Component cmp, Key circleCenter) {
      Graphics g = cmp.getGraphics(); 
      g.setColor(cmp.getBackground()); 
      g.fillOval(circleCenter.getX()-R-2,circleCenter.getY()-R-2,2*R+3,
                  2*R+3);
   } 

   // Draw the graphics of the circle  
   public static void drawCircleAt(Graphics g, int x, int y, Color c) {
      g.setColor(c);  
      g.fillOval(x-R-1, y-R-1, 2*R+1, 2*R+1);
   }

   public static void drawCircleAt(Component cmp, int x, int y, Color c) {
      Graphics g = cmp.getGraphics(); 
      drawCircleAt(g, x, y, c); 
   }

   public static void drawCircleAt(Image img, int x, int y, Color c) {
      Graphics g = img.getGraphics(); 
      drawCircleAt(g, x, y, c); 
   }
   
   public static void drawSweepLine(Graphics g, int linePosition,  
        int height, Color c) {
      g.setColor(c);
      if(linePosition <0) linePosition  = 0; 
      drawLine(g, linePosition, 0, linePosition, height, c, COUNTER);
   } 

   public static void drawSweepLine(Component cmp, int linePosition, 
     Color c) {
      Graphics g = cmp.getGraphics(); 
      int h = cmp.size().height; 
      drawSweepLine(g, linePosition, h, c);
   }   
   
   public static void drawSweepLine(Image img, int linePosition, Color c,
      Component cmp, int x, int y, int width, int height) {
      Graphics g = img.getGraphics(); 
      g.clipRect(x, y, width, height); 
      g.setColor(c);
      if(linePosition <0) linePosition  = 0; 
      int h = img.getHeight(cmp); 
      drawLine(g, linePosition , 0, linePosition, h, c, COUNTER);
   }   

   public static void erraseSweepLineAt(Component cmp, int l) {
      drawSweepLine(cmp, l, cmp.getBackground()); 
   }

   public static void drawQueryBand(Graphics g, int line, double d, 
     int h, Color c) {
      g.setColor(c);  
      int w; 
      if(d > line+1 ) {
         w = line+1; 
      } else {
         w = (int)d; 
      }
      g.fillRect(line-w+1, 0, w, h);  
      int a = line-w+1; 
   } 

   public static void drawQueryBand(Component cmp, int line, double d, 
     Color c) {
      Graphics g = cmp.getGraphics(); 
      drawQueryBand(g, line, d, cmp.size().height, c); 
   } 

   public static void drawQueryBand(Image img, int line, double d, 
     Color c, Component cmp, int x, int y, int width, int height) {
      Graphics g = img.getGraphics(); 
      g.clipRect(x, y, width, height); 
      drawQueryBand(g, line, d, img.getHeight(cmp), c); 
   } 

   public static void erraseQueryBand(Component cmp, int line, 
     double d) {
      drawQueryBand(cmp, line, d, cmp.getBackground()); 
   }

   public static void drawLine(Graphics g, int x_1, int y_1, int x_2, 
              int y_2, Color c, int d) {
      g.setColor(c); 
      g.drawLine(x_1, y_1, x_2, y_2); 
      if(d==COUNTER) {
         if(y_1 < y_2) {
            for(int i=1; i<=LINERESOLUTION-1; i++) 
               g.drawLine(x_1-i, y_1, x_2-i, y_2); 
         } else if(y_1 > y_2) {
            for(int i=1; i<=LINERESOLUTION-1; i++) 
               g.drawLine(x_1+i, y_1, x_2+i, y_2); 
         } else if(x_1 < x_2) {
            for(int i=1; i<=LINERESOLUTION-1; i++) 
               g.drawLine(x_1, y_1-i, x_2, y_2-i); 
         } else {
            for(int i=1; i<=LINERESOLUTION-1; i++) 
               g.drawLine(x_1, y_1+i, x_2, y_2+i); 
         }
      } else if(d==CLOCK) {
         if(y_1 < y_2) {
            for(int i=1; i<=LINERESOLUTION-1; i++) 
               g.drawLine(x_1+i, y_1, x_2+i, y_2); 
         } else if(y_1 > y_2) {
            for(int i=1; i<=LINERESOLUTION-1; i++) 
               g.drawLine(x_1-i, y_1, x_2-i, y_2); 
         } else if(x_1 < x_2) {
            for(int i=1; i<=LINERESOLUTION-1; i++) 
               g.drawLine(x_1, y_1+i, x_2, y_2+i); 
         } else {
            for(int i=1; i<=LINERESOLUTION-1; i++) 
               g.drawLine(x_1, y_1-i, x_2, y_2-i); 
         }
      }
   } 
   public static void drawLine(Component cmp, int x_1, int y_1, int x_2, 
              int y_2, Color c, int direction) {
      Graphics g = cmp.getGraphics(); 
      drawLine(g, x_1, y_1, x_2, y_2, c, direction); 
   } 

   public static void drawLine(Component cmp, int x_1, int y_1, int x_2, 
            int y_2, Color c) {
      drawLine(cmp, x_1, y_1, x_2, y_2, c, COUNTER);  
   }

   public static void drawLine(Image img, int x_1, int y_1, int x_2, 
            int y_2, Color c) {
      Graphics g = img.getGraphics(); 
      drawLine(g, x_1, y_1, x_2, y_2, c, COUNTER);  
   }

   public static void drawLine(Image img, int x_1, int y_1, int x_2, 
            int y_2, Color c, int d) {
      Graphics g = img.getGraphics(); 
      drawLine(g, x_1, y_1, x_2, y_2, c, d);  
   }

   // (x_1, y_1), (x_2, y_2) two end points.  (x,y,width, height) the 
   // parameters of the clipRect 
   public static void drawLine(Image img, int x_1, int y_1, int x_2, 
              int y_2, Color c, int direction, 
              int x, int y, int width, int height) {
      Graphics g = img.getGraphics(); 
      g.clipRect(x, y, width, height); 
      drawLine(g, x_1, y_1, x_2, y_2, c, direction); 
   } 

   public static void drawLine(Image img, int x_1, int y_1, int x_2, 
            int y_2, Color c, int x, int y, int width, int height) {
      drawLine(img, x_1, y_1, x_2, y_2, c, COUNTER, x, y, width, height);  
  } 

  public static void drawBackground(Image img, Component cmp, 
            int x, int y, int w, int h) {
     Graphics g = img.getGraphics(); 
     g.clipRect(x, y, w, h); 
     drawBackground(g, cmp); 
  }  

  public static void drawBackground(Graphics g, Component cmp) {
     g.setColor(cmp.getBackground());
     Dimension size=cmp.size(); 
     int width=size.width, height=size.height; 
     g.fillRect(0, 0, width, height); 
  }  
} 
