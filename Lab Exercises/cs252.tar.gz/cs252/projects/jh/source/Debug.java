//a debug class to faciliate debug job
class Debug{
  static int index=0;
  static boolean debug_on=false;
  static void print(String str){
    if(debug_on){
     System.out.println("[DEBUG "+index+"]"+str);
     index++;
    }
  }
  static void print_err(String str){
    System.out.println("[ERROR] "+str);
  }
}

