
import java.awt.*;
import java.applet.*;

import java.util.Vector;

public class DelTri extends Applet {
    DrawPanel dp = new DrawPanel();
    public void init() {
	setLayout(new BorderLayout());

	add("Center", dp);
	add("South",new DrawControls(dp));
    }

    public void start() {
	dp.start();
    }

    public void stop() {
	dp.stop();
    }

    public boolean handleEvent(Event e) {
	switch (e.id) {
	  case Event.WINDOW_DESTROY:
	    System.exit(0);
	    return true;
	  default:
	    return false;
	}
    }

    public static void main(String args[]) {
	Frame f = new Frame("Delaunay Triangulation");
	DelTri delTri = new DelTri();
	delTri.init();
	delTri.start();

	f.add("Center", delTri);
	f.resize(500, 400);
	
	f.show();
    }
}


class DrawPanel extends Panel implements Runnable { 
//data members.

    public static final int INPUT  =  0;
    public static final int DO_IT  =  1;
    public static final int CLEAR  =  2;
    public static final int DEMO   =  3;
    public static final int START  =  4;
    public static final int PAUSE  =  5;
    public static final int RESUME =  6;
    
    public boolean Hull=false;
    public boolean Vor=false;
    public boolean Tri=false;
    public boolean Drag=false;
    public boolean dragged=false;
  
    int	   mode = DEMO;
    Vector points = new Vector();
    int    drag=0;
    Vec2  dragPt=new Vec2(100,100);
    Thread thread;
    

    Image offscreen;
    Dimension offscreensize;
    Graphics g;
    double xi, yi, xt, yt, deltaX=4, deltaY=4;
    double kx, ky;
    boolean Demo=true;
    int next=0;
    int aniMode=START;
    boolean firstDemo=true;
    boolean finished=false;

    boolean init=true;
    int colorNum;
    
    Voronoi V0, V1, V2;
    int sepX, numSep=0, numPbs=0;
    boolean Hit=false;
    Vec2 interPt;
    Line pbLine=new Line();

    Vector sepVec=new Vector();
    Vector chVec=new Vector();

    Vector pbs=new Vector();
    Vector drawn=new Vector();
    
    Vector passed=new Vector();
    Vector totalRem=new Vector();
    Vector remLines=new Vector();
    Vector sep=new Vector();
    String msg="CHL PRESENTS ...";
    Font font=new Font("Helvetica", Font.BOLD, 24);

//methods.

    public DrawPanel() {
	setBackground(Color.white);
	Vec2 p=new Vec2(268,112);
	points.addElement(p);
	
	p=new Vec2(125, 170);
	points.addElement(p);

	p=new Vec2(164, 324);
	points.addElement(p);

	p=new Vec2(380, 324);
	points.addElement(p);

	p=new Vec2(426, 170);
	points.addElement(p);
	
	setDemoMode(DEMO);
    }

    public void start() {
	thread = new Thread(this);
	thread.start(); 
    }
    
    public void stop() {
	thread.stop();
    }
     
   public void run(){
       Graphics fg=this.getGraphics();
       while (next>=0) {
	   if(mode==DEMO && Demo) {
	       if(aniMode==START || aniMode==RESUME) paint(fg);
	   }
	   int n=(next==0)?1:50;
	   try Thread.sleep(n);
	   catch (InterruptedException e);
       }
       
   }

    public void setDrawMode(int mode) {
	this.mode = mode;  
    }

    public void setHull(boolean b) {
	Hull=b;
	if(b && !Demo) mode=DO_IT;
	else if(!Hull && !Vor && !Tri && !Demo) mode=INPUT;
    }

    public void trim(Line line, int i){

	Vec2 end_1, end_2;
	end_1=new Vec2(510,-10); end_2=new Vec2(512,-8);

	Line invisible=new Line(end_1, end_2);

	Line L[]=new Line[4];
	Vec2 end1, end2;
	end1=new Vec2(-2,-2); end2=new Vec2(502, 0);
	L[0]=new Line(end1, end2);

	end1=new Vec2(-2,-2); end2=new Vec2(-2,370);
	L[1]=new Line(end1, end2);

	end1=new Vec2(502,-2); end2=new Vec2(502,370);
	L[2]=new Line(end1, end2);

	end1=new Vec2(-2, 370); end2=new Vec2(502,370);
	L[3]=new Line(end1, end2);
	
	Vec2 walk=line.getPt(1);
	Vec2 slp=line.slope();

	boolean hit=false;
	double d, d0=1e+30;
	Vec2 inter=new Vec2();
	
	end1=line.getPt(1); end2=line.getPt(2);
	if((Math.abs(end1.x-250)>250 || Math.abs(end1.y-200)>200) && 
	   (Math.abs(end2.x-250)>250 || Math.abs(end2.y-200)>200))
	   {
	       line.setPt(1,end_1);
	       line.setPt(2,end_2);
	   }	   
	else {
	    for(int j=i-1; j<2+i; j++) 
		if(L[j].intersect(walk, slp)){
		    hit=true;
		    d=L[j].interDs();
		    if(d<d0){
			d0=d; 
			inter=L[j].interPoint();
		    }
		}
	    
	    if(!hit){
		line.setPt(1,end_1);
		line.setPt(2,end_2);
	    }
	    else if(i==1) {
		end1=inter;
		line.setPt(1, end1);
	    }
	    else if(i==2){
		end2=inter;
		line.setPt(2, end2);
	    }
	}
    }

    public void setAniMode(int mode){
	this.aniMode=mode;
    }

    public void setDemoMode(int mode){	
	if(firstDemo || Demo==false){
	computeVoronoi();
	font=new Font("Helvetica", Font.PLAIN, 14);
	if(V0.v.size()>3){
	    sep=(Vector)V0.sep.clone();
	    Line line=(Line)sep.elementAt(0);
	    trim(line,1);
	    line=(Line)sep.elementAt(sep.size()-1);
	    trim(line,2);
	
	    sepVec=new Vector();
	    line=new Line(new Vec2(sepX, 0),
			  new Vec2(sepX, 400));
	    sepVec.addElement(line);
	    
	    Line L1, L2;

	    L1=V0.support(1);
	    L2=V0.support(2);
	    chVec=new Vector();
	    chVec.addElement(L1);
	    chVec.addElement(L2);

	    this.mode=mode;
	    Demo=true;
	    aniMode=START;
	    finished=false;
	    if(next!=0) next=1;
	    numSep=0;
	    Hit=false;
	    
	    totalRem=V0.totalRem;
	    passed=new Vector();

	    pbLine=new Line();
	    pbs=new Vector();
	    drawn=new Vector();
	    Vector allPbs=(Vector)V0.pb.clone();
	    for(int i=0; i<allPbs.size(); i++){
		Vector pbi=(Vector)allPbs.elementAt(i);
		if(pbi.size()>0) for(int j=0; j<pbi.size(); j++){
		    Line Ln=(Line)pbi.elementAt(j);
		    if(!pbs.contains(Ln))pbs.addElement(Ln);		    
		}
	    }
	}
	else {
	    this.mode=mode;
	    next=10;
	    Demo=true;
	    finished=true;
	    aniMode=START;
	}

	}
	else Demo=false;
	    
    }

    public void setVor(boolean b) {
	
	Vor=b;
	if(b && !Demo) mode=DO_IT;
	else if(!Hull && !Vor && !Tri && !Demo) mode=INPUT;

    }
    public void setTri(boolean b) {
	Tri=b;
	if(b && !Demo) mode=DO_IT;
	else if(!Hull && !Vor && !Tri && !Demo) mode=INPUT;
    }
    public void setDrag(boolean b) {
	Drag=b;
    }

    
    private double distSq(Vec2 p1, Vec2 p2){
	double x=p1.x-p2.x, y=p1.y-p2.y;
	return x*x + y*y;
    }

    public boolean handleEvent(Event e) {
	
	Vec2 p=new Vec2(e.x, e.y);
	int i=0;
	boolean add=true;
	switch (e.id) {
	    
	case Event.MOUSE_DOWN:
	    finished=false;
	    if(!Drag && !Demo){

		for(i=0; i<points.size(); i++)		    
		    if(distSq((Vec2)points.elementAt(i), p)<25)
			{
			    add=false;
			    points.removeElementAt(i);
			    i=points.size();
			}
		
		if(add) {
		    points.addElement(p);
		    //System.out.print("#points="+points.size()+" ");
		    //System.out.println("COORD:"+e.x+" "+e.y);
		}

	    }
	    else if(!Demo){
		dragged=false;
		for(i=0; i<points.size(); i++)		    
		    if(distSq((Vec2)points.elementAt(i), p)<50){
			drag=i; dragged=true; 
			dragPt=new Vec2(e.x, e.y);
			i=points.size();}
		
	    }
		
	    repaint();
	    return true;
	   

	case Event.MOUSE_UP:
	    
	    dragged=false;
	    add=true; 
	   
	    repaint();
	    return true;

	case Event.MOUSE_DRAG:
	    if(Drag && dragged)
		dragPt=new Vec2(e.x, e.y);			
		    
	    repaint();
	    return true;
		  
	case Event.WINDOW_DESTROY:
	    System.exit(0);
	    return true;
	default:
	    return false;
	    
	}
    }

    private void drawMsg(Graphics g, String s){

	g.setColor(new Color(255, 80, 100));
	g.setFont(font);
	FontMetrics fm=this.getFontMetrics(font);
	int w=fm.stringWidth(s);
	if(next==0) g.drawString(s, 250-w/2, 180);
	else g.drawString(s, 250-w/2, 360);
    }

    private void drawMsg(Graphics g){

	font=new Font("Helvetica", Font.BOLD, 24);
	g.setColor(new Color(255, 80, 100));
	g.setFont(font);
	FontMetrics fm=this.getFontMetrics(font);
	String s="CHL PRESENTS ...";
	int w=fm.stringWidth(s);
	g.drawString(s, 250-w/2, 180);

	g.setColor(new Color(0, 175, 155));
	s=new String("DELAUNAY TRIANGULATION");
	w=fm.stringWidth(s);
	g.drawString(s, 250-w/2, 220);
	font=new Font("Helvetica", Font.PLAIN, 14);	
    }

    public synchronized void paint(Graphics fg){

	Dimension dm = size();
	if ((offscreen == null) || (dm.width != offscreensize.width) 
	    || (dm.height != offscreensize.height)) {
	    offscreen = createImage(dm.width, dm.height);
	    offscreensize = dm;
	    g = offscreen.getGraphics();
	}
	g.setColor(Color.white);
	g.fillRect(0, 0, dm.width, dm.height);
	if(Demo){
	    if(V0.v.size()<4){	    	    
		msg=new String(
		    "Easy case. No further demo given. Try more points.");
		drawMsg(g, msg);
		drawPoints(g, points, Color.black);
		drawVorTri(g, V0, true, true, Color.red, Color.blue);
		fg.drawImage(offscreen, 0, 0, null);
		Demo=false;
	    }

	    else{
		if(0<next && next<3) drawPoints(g, points, Color.black);
		else if(next>0){
		    drawPoints(g, V1.v, Color.green);
		    drawPoints(g, V2.v, Color.blue);
		}

		switch(next){
		case 0:
		    drawMsg(g);
		    fg.drawImage(offscreen, 0, 0, null);
		    
		    try Thread.sleep(3000);
		    catch (InterruptedException e);	    
		    next=5;
		

		    break;
		    
		case 1:
		    msg=new String(
			"The dividing line and the left and right subsets.");
		    drawMsg(g, msg);
		    
		    blinkLines(g, sepVec, 2);
		    fg.drawImage(offscreen, 0, 0, null);
		
		    break;
		
		case 2:
		    msg=new String("Two convex hulls.");
		    drawMsg(g, msg);
		    drawHull(g, V1, Color.green);
		    drawHull(g, V2, Color.blue);
		    fg.drawImage(offscreen, 0, 0, null);

		    try Thread.sleep(1000);
		    catch (InterruptedException e);
	    
		    next=3;

		    break;
	    
		case 3:
		   msg=new String("The two supports of the two convex hulls.");
		    drawMsg(g, msg);
		    drawHull(g, V1, Color.green);
		    drawHull(g, V2, Color.blue);
		    blinkLines(g, chVec, 4);
		    fg.drawImage(offscreen, 0, 0, null);
	  
		    break;

		case 4:
		    msg=new String("The Voronoi diagrams of the two subsets.");
		    drawMsg(g, msg);
		    drawVorTri(g, V1, true, false, Color.green, Color.white);
		    drawVorTri(g, V2, true, false, Color.blue, Color.white);
		    drawSep(g, sep, Color.white);
		    drawRemLines(g); 
		    fg.drawImage(offscreen, 0, 0, null);
	
		    try Thread.sleep(2000);
		    catch (InterruptedException e);
	    
		    next=5;
		    break;
		
		case 5:

		    msg=new String(
	   "Constructing the dividing chain: traversing from top to bottom."); 
		    if(numSep<sep.size()-1) drawMsg(g, msg);
		    walkDown(g);
		    fg.drawImage(offscreen, 0, 0, null);
	
		    break;
		    
		case 6:
				
		    drawDual(g);
		    drawLines(g, pbs, Color.green);
		    drawLines(g, drawn, Color.blue);

		    msg=new String("Delaunay triangulation: a dual graph.");
		    if(pbs.size()>0) drawMsg(g, msg);
		    fg.drawImage(offscreen, 0, 0, null);
		    break;
		}
	    }
	}
	else update(fg);
	
    }
     
    public void drawDual(Graphics g){
	Vec2 p1, p2;
	if(init){
	    
    	    if(pbs.size()==0){
		msg=new String(
		    "Eventually, the Delaunay triangulation is here.");
		drawMsg(g, msg);		
		
		Demo=false;
		finished=true;

	        try Thread.sleep(1000);
		catch(InterruptedException e);	
	        if(Hull || Vor || Tri) repaint();

		if(firstDemo){
		    mode=DO_IT;
		    Tri=true;
		    points=new Vector();
		    firstDemo=false;
		}

	    }

	    else {
		colorNum=0;	
		pbLine=(Line)pbs.elementAt(0);
		pbs.removeElement(pbLine);		
	    }
	    
	    init=false;
	}
	
	colorNum++;
	if(colorNum<11){

	    switch(colorNum%2){
	    case 0:
		g.setColor(Color.green); 
		break;
	    case 1:
		g.setColor(Color.red); 
		break;
	    }
	    p1=pbLine.getFr(1); p2=pbLine.getFr(2);      
	    g.fillOval((int)p1.x-3, (int)p1.y-3, 7, 7);
	    g.fillOval((int)p2.x-3, (int)p2.y-3, 7, 7);	
	    p1=pbLine.getPt(1); p2=pbLine.getPt(2);
	    //if(pbs.size()!=0)
		g.drawLine((int)p1.x, (int)p1.y, 
					(int)p2.x, (int)p2.y);
	}
	else {	
	    p1=pbLine.getFr(1); p2=pbLine.getFr(2);  
	    drawn.addElement(new Line(p1, p2));
	    init=true; 
	}
	
    } 
    public void walkDown(Graphics g){
	
	drawVorTri(g, V1, true, false, Color.green, Color.white);
	drawVorTri(g, V2, true, false, Color.blue, Color.white);	    
	drawSep(g, sep, Color.white);
	drawRemLines(g);
	
	if(!Hit) walkLine(g, (Line)(sep.elementAt(numSep)));
	else if(numSep<sep.size()-1){
	    remLines=(Vector)totalRem.elementAt(0);
	    blinkLines(g, remLines, 5);
	}
	drawSep(g, passed, Color.red);

    }


   public void walkLine(Graphics g, Line line){
	//xi, yi, and xt, yt will be first initiated.
       
       msg=new String("The last of the dividing chain. Triangulation next.");
       if(numSep==sep.size()-1) drawMsg(g, msg);
       
       if(init) {
	    xi=line.getPt(1).x; yi=line.getPt(1).y;
	    xt=xi; yt=yi;
	    kx=line.slope().x; ky=line.slope().y;
	    colorNum=0;
	    init=false;
	}
	xt+=deltaX*kx;
	yt+=deltaY*ky;
       
	g.setColor(Color.red);
	g.drawLine((int)xi, (int)yi, (int)xt, (int)yt);
       

       //blink two points which give this pb. very good.
       Vec2 p1=line.getFr(1), p2=line.getFr(2);       
       colorNum=1-colorNum;
       
       switch(colorNum){
       case 0:
	   g.setColor(Color.red);
	   break;
       case 1:
	   g.setColor(Color.green);
	   break;
       }
       g.fillOval((int)p1.x-3, (int)p1.y-3, 7, 7);
       g.fillOval((int)p2.x-3, (int)p2.y-3, 7, 7);
       
       if(Math.abs(xt-xi)>Math.abs(line.getPt(2).x-line.getPt(1).x)||
	  Math.abs(yt-yi)>Math.abs(line.getPt(2).y-line.getPt(1).y))
	   {   
	       passed.addElement((Line)(sep.elementAt(numSep)));
	       Hit=true; interPt=line.getPt(2); init=true;
	       if(numSep==sep.size()-1){
		   drawPoints(g, V1.v, Color.green);
		   drawPoints(g, V2.v, Color.blue);
		   next=6;
		   
	       }
	   }	
   }


    public void blinkLines(Graphics g, Vector lines, int nxt){

	Vec2 v1, v2;
	if(init) {
	    colorNum=0; init=false;
	}

	colorNum++;
	if(colorNum<13) {
	    switch(colorNum%2){
	    case 0:
		g.setColor(Color.red);
		break;
	    case 1:
		g.setColor(Color.black);
		break;
	    }

	    for(int i=0; i<lines.size(); i++){
		v1=((Line)lines.elementAt(i)).getPt(1);
		v2=((Line)lines.elementAt(i)).getPt(2);	
		if(next==5) g.fillOval((int)interPt.x-3, 
				       (int)interPt.y-3, 7, 7);
		g.drawLine((int)v1.x, (int)v1.y, (int)v2.x, (int)v2.y);
		
	    }
	    
	}
	else { 
	    init=true; next=nxt; 
	    if(Hit && next==5) {
		totalRem.removeElement(lines);
		numSep++;
		Hit=false;
	    }
	    if(nxt==4){
		try Thread.sleep(600);
		catch(InterruptedException e);
	    }
	    
	}
    }

    public void drawLines(Graphics g, Vector lines, Color c){

	Vec2 v1, v2;
	g.setColor(c);
	
	for(int i=0; i<lines.size(); i++){
	    v1=((Line)lines.elementAt(i)).getPt(1);
	    v2=((Line)lines.elementAt(i)).getPt(2);		
	    g.drawLine((int)v1.x, (int)v1.y, (int)v2.x, (int)v2.y);
	}
	
    }

    public void drawRemLines(Graphics g){

	Vec2 v1, v2;
	for(int i=0; i<totalRem.size(); i++){
	    Vector lines=(Vector)totalRem.elementAt(i);
	    	    
	    if(V0.remSide[i+numSep]==1) g.setColor(Color.green);
	    else g.setColor(Color.blue);
	
	    for(int j=0; j<lines.size(); j++){ 
		v1=((Line)lines.elementAt(j)).getPt(1);
		v2=((Line)lines.elementAt(j)).getPt(2);
		g.drawLine((int)v1.x, (int)v1.y, (int)v2.x, (int)v2.y);
	    }
	}
	
    }


   public void computeVoronoi(){

       //partition the list by just partition np.
       int np = points.size();	
       int i, j, k=-2;
       double d2=np;
       while(d2>=1){
	   d2/=2.0;
	   k++;
       }
		
       int tk=1, d=1, level;
       level=k;
		
       for(i=0; i<k; i++) tk*=2;
       int vi[]=new int[tk];
       vi[0]=np;
       tk=1;
       for(j=0; j<k; j++){			
	   for(i=tk-1; i>=0; i--){	
	       if(j==k-1 && vi[i]==4){			
		   vi[2*i+1]=1;
		   vi[2*i]=3;
	       }
	       else{
		   vi[2*i+1]=vi[i]/2;
		   vi[2*i]=(vi[i]+1)/2;
	       }
	       //System.out.print(" "+vi[2*i]+" "+vi[2*i+1]);
	   }
	   tk*=2;
       }	
		
       //for(i=0; i<tk; i++) System.out.print(" "+vi[i]);
       //System.out.println();
       
       //sort according to the increasing order of x.

       Vec2 p, p1, p2;
       double x0=0;

       Vector Points=new Vector();
       for(i=0; i<np; i++){
	   Vec2 fr=(Vec2)points.elementAt(i);
	   Points.addElement(fr);
       }

       for(i=0; i<np; i++){
	   x0=((Vec2)Points.elementAt(i)).x;
	   k=i;
	   for(j=i+1; j<np; j++){
	       p1=(Vec2)Points.elementAt(j); 
	       if(p1.x<x0){k=j; x0=p1.x;}
	   }
	   p2=(Vec2)Points.elementAt(k);
	   Points.removeElementAt(k);
	   Points.insertElementAt(p2,i);
       }

       if(np>=4){
	   i=(np==4)?3:(np+1)/2;
	   double xs1=((Vec2)Points.elementAt(i-1)).x;
	   double xs2=((Vec2)Points.elementAt(i)).x;
	   xs1=(xs1+xs2)/2;
	   sepX=(int)xs1; //initial sepX.
       }

       d=tk; //System.out.println("np="+np+" d="+d+" level="+level);
       Vector v[]=new Vector[d];
       Voronoi vor[]=new Voronoi[d];
       
       for(i=0; i<d; i++) {
	   v[i]=new Vector();
	   vor[i]=new Voronoi();
       }
       
       k=0;
       for(i=0; i<d; i++){
	   for(j=0; j<vi[i]; j++)
	       v[i].addElement(Points.elementAt(k+j));
	   k+=vi[i];
	   
	   vor[i]=new Voronoi(v[i]);
		    
	   if(v[i].size()>2) vor[i]=vor[i].simple34(vi[i]);
	   // System.out.println("eachSize="+vor[i].v.size());
	   // System.out.println("       ");
       }
		    
		    
       // compute voronoi diagrams recursively.
       for(i=level-1; i>=0; i--){
	   int pow2=1; 
	   for(k=0; k<i; k++) pow2*=2;
	   if(i==0){V1=vor[0]; V2=vor[1];}
	   for(k=0; k<pow2; k++){			    
	       vor[k]=new Voronoi(vor[2*k], vor[2*k+1]);
	       //System.out.println("FinalSize="+vor[k].v.size());
	   }
       }
       V0=vor[0];
       
   }

   public void drawHull(Graphics g, Voronoi v, Color c){
       
       int i, j, k;
       Vec2 p1, p2;

       if(v!=null) {
	   Vector convh=v.conv;
	   k=convh.size();
	   if(k>0) for(i=0; i<k; i++){
	       p1=(Vec2)convh.elementAt(i);
	       j=(i+1)%k;
	       p2=(Vec2)convh.elementAt(j);
	       g.setColor(c);
	       g.drawLine((int)p1.x, (int)p1.y, (int)p2.x, (int)p2.y);
	   }	
       }
       
   }
    

   public void drawVorTri(Graphics g, Voronoi v, boolean vor, 
			   boolean tri, Color c1, Color c2){
	
       int i, j, k;
       Vec2 p1, p2;

       Vector pb=new Vector();
       if(v!=null) {
	   pb=v.pb;
	   Vector pbv=new Vector();
	   k=pb.size();
		
	   for(i=0; i<k; i++){
	       pbv=(Vector)pb.elementAt(i);
			
	       for(j=0; j<pbv.size(); j++){
		   Line line=(Line)pbv.elementAt(j);
		   if (vor) {//Voronoi diagram.
		       p1=(Vec2)line.getPt(1);
		       p2=(Vec2)line.getPt(2);
		       g.setColor(c1);
		       g.drawLine((int)p1.x, (int)p1.y, 
				  (int)p2.x, (int)p2.y);
		   }
	       
		   //last draw Delaunay triangulation.
		   if (tri) {
		       p1=(Vec2)line.getFr(1);
		       p2=(Vec2)line.getFr(2);
		       g.setColor(c2);
		       g.drawLine((int)p1.x, (int)p1.y, 
				  (int)p2.x, (int)p2.y);    
		   }
	       }
	   }
       }
   }

   public void drawSep(Graphics g, Vector sep, Color c){
       Vec2 p1, p2;
       int k=sep.size();
       for(int i=0; i<k; i++){
	   Line line=(Line)sep.elementAt(i);
						
	   p1=(Vec2)line.getPt(1);
	   p2=(Vec2)line.getPt(2);
	   g.setColor(c);
	   g.drawLine((int)p1.x, (int)p1.y, (int)p2.x, (int)p2.y);
       }
	      
   }

   public void drawPoints(Graphics g, Vector v, Color c){
       /* draw the points */
       // g.setPaintMode();
       int np = v.size(), i=0;
       Vec2 p;
       
       for (i=0; i < np; i++) { 
	   p = (Vec2)v.elementAt(i);
	   g.setColor(c);
	   g.fillOval((int)p.x-3, (int)p.y-3, 7, 7);
       }
	    
   }

   public void update(Graphics fg) {

       Dimension dm = size();
       if ((offscreen == null) || (dm.width != offscreensize.width) 
	   || (dm.height != offscreensize.height)) {
	   offscreen = createImage(dm.width, dm.height);
	   offscreensize = dm;
	   g = offscreen.getGraphics();
       }

       g.setColor(Color.white);
       g.fillRect(0, 0, dm.width, dm.height);

       if(!Demo){
	   if(Drag && dragged)     
	   points.setElementAt(dragPt, drag);


	   if(mode !=CLEAR && points.size()>0) {
	    
	       drawPoints(g, points, Color.black);
	  
	       if(mode!=INPUT){
	       	
		   computeVoronoi();
		   if(Hull) drawHull(g, V0, Color.black);
		   if(Vor || Tri)                                    
		       drawVorTri(g, V0, Vor, Tri, Color.red, Color.blue);
		   //if(Vor) drawSep(g, V0.sep, Color.red);		
	       }
	   }
	fg.drawImage(offscreen, 0, 0, null);

       }
   
       if(finished){
	   drawPoints(g, points, Color.black);
	   //if(Tri) 
	   drawVorTri(g, V0, false, true, Color.red, Color.blue);
	   if(V0.v.size()<4) {
	       msg=new String(
		"Easy case. No further demo given. Try more points.");
	    drawMsg(g, msg);	    
	    drawVorTri(g, V0, true, true, Color.red, Color.blue);
	   }
	   fg.drawImage(offscreen, 0, 0, null);

       }
	              

   }
}




class DrawControls extends Panel {
//data member.
    DrawPanel target;
    Checkbox d=new Checkbox("Drag");
    Checkbox h=new Checkbox("Hull");
    Checkbox v=new Checkbox("Voronoi");
    Checkbox t=new Checkbox("Triang");
    Checkbox p=new Checkbox("Pause");

//methods.
    public DrawControls(DrawPanel target) {
	this.target = target;
	setLayout(new FlowLayout());
	setBackground(Color.lightGray);

	add(h); add(v); add(t); add(d);
	h.setForeground(Color.red);
	v.setForeground(Color.red);
	t.setForeground(Color.red);
	d.setForeground(Color.red);
	
	
	Button clear=new Button("Clear");
	clear.setForeground(Color.red);
	clear.setBackground(Color.lightGray);
	add(clear);

	Button demo=new Button("Demo");
	demo.setForeground(Color.red);
	demo.setBackground(Color.lightGray);
	add(demo);

	p.setForeground(Color.red);
	add(p);

    }

    public void paint(Graphics g) {
	Rectangle r = bounds();
	g.setColor(Color.lightGray);
	g.draw3DRect(0, 0, r.width, r.height, false); 
    }

    public boolean action(Event e, Object arg) {
	if (arg instanceof Boolean) {
	    String label=((Checkbox)e.target).getLabel();
	    boolean bool=((Boolean)arg).booleanValue();	
	    if (label.equals("Hull")) {
		target.finished=false;
		target.setHull(bool);
		target.repaint();
	    } 
	    else if(label.equals("Voronoi")) {
		target.finished=false;
		target.setVor(bool);
		target.repaint();
	    }
	    else if(label.equals("Triang")) {
		target.finished=false;
		target.setTri(bool);
		target.repaint();
	    }

	    else if(label.equals("Drag")) {
		target.finished=false;
		target.setDrag(bool);
		target.repaint();
	    }

	    else if(label.equals("Pause")){
	
		if(bool) target.setAniMode(DrawPanel.PAUSE);
		else target.setAniMode(DrawPanel.RESUME);
	    }
	    
	    return true;
	} 
	 
	else if (e.target instanceof Button){
	    String label_ = (String)arg;
	    
	    if(label_.equals("Clear")) {
		target.points = new Vector();
		target.setHull(false);
		target.setVor(false);
		target.setTri(false);
		target.setDrag(false);
		
		h.setState(false);
		v.setState(false);
		t.setState(false);
		d.setState(false);
		target.Demo=false;
		target.firstDemo=false;	
		target.finished=false;

		p.setState(false);
		target.setDrawMode(DrawPanel.INPUT);
		target.repaint();
	    }
	    else if(label_.equals("Demo")) {
		target.setDemoMode(DrawPanel.DEMO);
		target.setAniMode(DrawPanel.START);
		
		p.setState(false);
		target.repaint();
	    }
	}	    
	return true;
    }

}
	


    




