package sprite;

import java.awt.*;

public class ButtonSprite extends Sprite {
    ButtonOwner owner_;
    Color fore_, back_;
    Font font_;
    String title_;
    int xAdd_, yAdd_, width_, height_;
    boolean enabled_, selected_;
    
    public ButtonSprite(SpriteArea area, int x, int y,
			int width, int height, String title) {
	this(null, area, x, y, width, height, title);
    }

    public ButtonSprite(ButtonOwner owner, SpriteArea area, int x, int y,
			int width, int height, String title) {
	super(area, x, y);
	owner_ = owner;
	fore_ = Color.black;
	back_ = Color.gray;
	font_ = new Font("Dialog", Font.PLAIN, 10);
	title_ = title;
	width_ = width;
	height_ = height;
	enabled_ = true;
	selected_ = false;
	Add();
	Anchor();
	RecomputeSize();
    }

    public void SetFore(Color color) {
	fore_ = color;
	Redraw();
    }

    public void SetBack(Color color) {
	back_ = color;
	Redraw();
    }

    public void SetFont(Font font) {
	font = font_;
	RecomputeSize();
	Redraw();
    }

    public void SetTitle(String title) {
	title_ = title;
	RecomputeSize();
	Redraw();
    }

    public void Enable() {
	if (!enabled_) {
	    enabled_ = true;
	    Redraw();
	}
    }
    
    public void Disable() {
	if (enabled_) {
	    enabled_ = false;
	    Redraw();
	}
    }

    public void Resize(int width, int height) {
	width_ = width;
	height_ = height;
	RecomputeSize();
	Redraw();
    }

    public boolean Inside(int x, int y) {
        int xOff = x - x_;
        int yOff = y - y_;
        return (xOff > 0 && xOff < width_ &&
		yOff > 0 && yOff < height_);
    }
    
    public void Draw(Graphics g) {
	g.setColor(back_);

	if (enabled_) {
	    g.fill3DRect(x_, y_, width_, height_, !selected_);
	    g.setColor(fore_);
	}
	else {
	    g.fillRect(x_, y_, width_, height_);	    
	    g.setColor(Color.lightGray);
	}
	
	g.setFont(font_);
	g.drawString(title_, x_ + xAdd_, y_ + yAdd_);
    }

    public void handleEvent(Event e) {
        switch (e.id) {
        case Event.MOUSE_DOWN:
	    if (enabled_) {
		selected_ = true;
		Redraw();
	    }
            break;
            
        case Event.MOUSE_DRAG:
	    if (enabled_) {
		boolean newS = Inside(e.x, e.y);
		if (newS != selected_) {
		    selected_ = newS;
		    Redraw();
		}
	    }
            break;

        case Event.MOUSE_UP:
	    if (enabled_ && selected_) {
		if (owner_ != null)
		    owner_.ButtonClicked(this);
		else
		    Action();
		selected_ = false;
		Redraw();
	    }
            break;
        }
    }

    void RecomputeSize() {
	FontMetrics m = area_.getFontMetrics(font_);
	xAdd_ = (width_ - m.stringWidth(title_)) / 2;
	yAdd_ = (height_ + m.getAscent()) / 2;
    }

    public void Action() { ; }
}
