package cs252;

import java.awt.*;
import java.util.Vector;
import sprite.*;
import graph.*;

abstract public class Enforcer {
    DominanceGraph area_;
    int id_;
    static Enforcer enforcers_[];

    static void SetEnforcers(Enforcer enforcers[]) {
	enforcers_ = enforcers;
    }
    
    public Enforcer(DominanceGraph area, int id) {
	area_ = area;
	id_ = id;
    }

    public void InformAllSplit(Edge e, Edge a, Node c, Edge b) {
	for (int loop = id_ - 1; loop >= 0; --loop)
	    enforcers_[loop].InformSplit(e, a, c, b);
    }

    public void InformSplit(Edge e, Edge a, Node c, Edge b) { ; }
    
    abstract public void Enforce(Vector nodes, Vector edges, OrderNode lowest);
    abstract public boolean DidAnything();
    abstract public void Restore();
    abstract public void Undo();
}
