
class RWLock
{
    private int readers=0, writers=0, waiting_writers=0;

    public synchronized void rlock()
    {
        while (writers>0 || waiting_writers>0) {
            try {
                wait();  // waits for notify() call from Producer
            } catch (InterruptedException e) {
            }
        }
        readers++;
    }

    public synchronized void wlock()
    {
        waiting_writers++;
        while (readers>0 || writers>0) {
            try {
                wait();  // waits for notify() call from Producer
            } catch (InterruptedException e) {
            }
        }
        waiting_writers--;
        writers++;
    }

    public synchronized void unlock()
    {
        if (writers==0 && readers==0) {
            System.err.println("#ERROR#: Can't unlock a free variable.");
            return;
        }
        if (writers>0) {
            writers--;
        } else {
            readers--;
        }
        notify();
    }
}

