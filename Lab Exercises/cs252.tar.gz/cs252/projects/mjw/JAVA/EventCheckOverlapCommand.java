import TreeAccessible;
import java.lang.*;
import java.io.StreamTokenizer;
import geometry.*;
import ReversibleCommand;
import Prototype;
import java.awt.*;
import java.awt.image.*;
import RangeSearchAnimationCommand;




/****************************************************************/
/* CLASS NAME :  EventCheckOverlapCommand                       */
/*                                                              */
/*                                                              */
/*                                                              */
/*                                                              */
/*                                                              */
/*                                                              */
/****************************************************************/

public class EventCheckOverlapCommand extends RangeSearchAnimationCommand {

	public EventCheckOverlapCommand(Image		im,
					GeometryPanel	p,
					TreeAccessible  treeApp,
					Box		input_area)
	{
		super(im, p, treeApp, input_area);
		range_color_ = tree_app_.getRangeColor();
	}

	public EventCheckOverlapCommand (Image		im,
					 GeometryPanel	p,
					 TreeAccessible	treeApp,
					 Box		input_area,
					 TreeNode	node)
	{
		super(im, p, treeApp, input_area);
		setNode(node);
		range_color_ = tree_app_.getRangeColor();
	}


	public void execute()
	{
		if (node_ != null)
		{
		        node_.setSelected(true); // select this node
			reversible_ = true;
			drawRange(node_.getBegin(), node_.getMedian(),node_.getEnd(),range_color_);
		}
		else reversible_ = false;
	}

	public void undo()
	{
		if (reversible_)
		{
			execute(); //same action
			node_.setSelected(false);
		}
	}

	public Object clone()
	{
		EventCheckOverlapCommand c = new
			EventCheckOverlapCommand(image_,
						 panel_,
						 tree_app_,
						 user_input_bounds_,
						 node_);
		//c.setBegin(begin_);
		//c.setMedian(median_);
		//c.setEnd(end_);
		return c;
	}

	public Object clone(StreamTokenizer st)
	{
		TreeNode n = new TreeNode((GeometryStreamTokenizer)st);
		//begin_ = ((GeometryStreamTokenizer)st).nextInt();
		//median_ = ((GeometryStreamTokenizer)st).nextInt();
		//end_ = ((GeometryStreamTokenizer)st).nextInt();

		//System.out.println("begin:"+begin_+"median:"+median_+" end:"+end_);

		Tree tree = tree_app_.getTree();
		if (tree == null) return null;

		n = tree.findNode(n.getID());
		EventCheckOverlapCommand c = new
			EventCheckOverlapCommand(image_,
						 panel_,
						 tree_app_,
						 user_input_bounds_,
						 n);

		//c.setBegin(begin_);
		//c.setMedian(median_);
		//c.setEnd(end_);
		c.setReversible(reversible_);
		return c;
	}


	public String toString()
	{
		return new String("RTEVENTCHECKOVERLAP");
	}
};


