import Tree;
import geometry.PointSet;
import java.awt.Graphics;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.image.*;
import java.awt.Color;
import SegmentSet;

// Command objects need the applets to implement this interface
public interface TreeAccessible {

	public Tree     getTree();
	public PointSet getPointSet();
	public SegmentSet getSegmentSet();

	public void drawTree(Graphics g);
	public void drawPointSet(Graphics g);
	public void drawSegmentSet(Graphics g);
        public void drawQuerySegment(Graphics g);

	public Dimension getTreeNodeImageDimension();
	public Dimension getPointImageDimension();

	public Image getUnselectedNodeImage();
	public Image getSelectedNodeImage();
	public Image getAllocationNodeImage();
        public Image getLeafNodeImage();

	public void setUnselectedNodeImage(Image im);
	public void setSelectedNodeImage(Image im);
	public void setAllocationNodeImage(Image im);
        public void setLeafNodeImage(Image im);

        public Color getRangeColor();
}
