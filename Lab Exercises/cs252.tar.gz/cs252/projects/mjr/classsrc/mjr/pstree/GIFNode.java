/*
 * @(#)GIFNode.java	1.0 5/13/96 Michael John Radwin
 */

package mjr.pstree;

import java.awt.*;
import sprite.*;
import graph.*;
import java.util.Vector;

/**
 * A Node that is drawn with a 12x12 image of a sphere.
 * The GIF node takes a vector of images that must be loaded before
 * passed to its constuctor.
 *
 * @version 1.0 5/13/96
 * @author <A HREF="http://www.cs.brown.edu/people/mjr/">Michael John Radwin</A>
 */
public class GIFNode extends Node {
    protected Vector images;
    protected Image image;
    static public final String[] IMAGES = {
	"blue-ball.gif", "yellow-ball.gif", "red-ball.gif",
	"magenta-ball.gif", "green-ball.gif", "cyan-ball.gif"
    };

    protected int currentImage;
    static public final int BLUE = 0;
    static public final int YELLOW = 1;
    static public final int RED = 2;
    static public final int MAGENTA = 3;
    static public final int GREEN = 4;
    static public final int CYAN = 5;

    public GIFNode(GraphArea area, int x, int y, Vector images)
    {
	super(area, x, y, false);
	this.images = images;
	currentImage = BLUE;
	image = (Image)images.elementAt(currentImage);
    }

    
    public void setImage(int newImage)
    {
	currentImage = newImage;
	image = (Image)images.elementAt(currentImage);
	Redraw();
	Anchor();
    }
    
    public void Draw(Graphics g)
    {
	g.drawImage(image, x_ - RADIUS, y_ - RADIUS, null);
    }

    public static void mjr() { ; }
}
