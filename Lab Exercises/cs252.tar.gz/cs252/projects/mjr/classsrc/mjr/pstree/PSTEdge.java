/*
 * @(#)PSTEdge.java	1.0 5/21/96 Michael John Radwin
 */

package mjr.pstree;

import graph.*;
import java.awt.*;

/**
 * A specialized Edge that can be drawn thick or think.
 *
 * @version $Revision: 1.2 $ 5/21/96
 * @author <A HREF="http://www.cs.brown.edu/people/mjr/">Michael John Radwin</A>
 */
public class PSTEdge extends Edge {
    protected boolean thin;
    
    public PSTEdge(GraphArea area, Node a, Node b, Color color)
    {
	super(area, a, b, color);
	thin = true;
    }
    
    public PSTEdge(GraphArea area, Node a, Node b)
    {
	this(area, a, b, Color.black);
    }

    public void thick()
    {
	if (thin) {
	    thin = false;
	    Redraw();
	}
    }

    public void thin()
    {
	if (!thin) {
	    thin = true;
	    Redraw();
	}
    }

    public void Draw(Graphics g)
    {
	if (thin) {
	    super.Draw(g);
	    return;
	}
	
	if (b_.IsVisible()) {
	    int bX, bY;
	    double dX = b_.x_ - a_.x_;
	    double dY = b_.y_ - a_.y_;
	    if (b_.IsSquare()) {
		int rX, rY;
		if (dX * dX > dY * dY) {
		    rX = Node.RADIUS;
		    rY = (int)Math.round(dY / dX * (double)Node.RADIUS);
		    if (dX > 0) {
			rX *= -1;
			rY *= -1;
		    }
		}
		else {
		    rX = (int)Math.round(dX / dY * (double)Node.RADIUS);
		    rY = Node.RADIUS;
		    if (dY > 0) {
			rX *= -1;
			rY *= -1;
		    }
		}
		bX = b_.x_ + rX; bY = b_.y_ + rY;
	    }
	    else {
		double len = Math.sqrt(dX * dX + dY * dY);
		bX = (int)Math.round((double)b_.x_ -
				     ((double)Node.RADIUS / len) * dX);
		bY = (int)Math.round((double)b_.y_ -
				     ((double)Node.RADIUS / len) * dY);
	    }
	    drawLine(g, a_.x_, a_.y_, bX, bY, 2, color_);
	    ArrowHead.FillHead(g, a_.x_, a_.y_, bX, bY);
	}
	else
	    drawLine(g, a_.x_, a_.y_, b_.x_, b_.y_, 2, color_);

    }
		

    /**
     * By Cliff Berg
     * found at http://www.digitalfocus.com/digitalfocus/faq/VR.html#GR_35
     */
    public void drawLine(Graphics g,
			 int startX, int startY, int endX, int endY,
			 int wid, Color col)
      {
	  // Make this reflect the current width and color...
	  g.setColor(col);

	  //
	  // We draw a thick line by computing the four corners of an equivalent
	  // diagonal rectangle, and filling it.

	  //
	  // Compute the corner points of the rectangle to fill
	  //

	  // The x and y deltas from the start to the end of the line...
	  int dX = endX - startX;
	  int dY = endY - startY;

	  // The length of the line...
	  double D = Math.sqrt(dX * dX + dY * dY);

	  // The ratio of half the line thickness to the length of the line...
	  double scale = (double)(wid) / (2 * D);

	  // The x and y increments from an endpoint needed to create a rectangle...
	  double ddx = -scale * (double)dY;
	  double ddy = scale * (double)dX;
	  if (ddx > 0) ddx += 0.5; else ddx -= 0.5;               // round off
	  if (ddy > 0) ddy += 0.5; else ddy -= 0.5;               //  "
	  int dx = (int)ddx;
	  int dy = (int)ddy;

	  // Now we can compute the corner points...
	  int xPoints[] = new int[4];
	  int yPoints[] = new int[4];

	  xPoints[0] = startX + dx;
	  yPoints[0] = startY + dy;

	  xPoints[1] = startX - dx;
	  yPoints[1] = startY - dy;

	  xPoints[2] = endX - dx;
	  yPoints[2] = endY - dy;

	  xPoints[3] = endX + dx;
	  yPoints[3] = endY + dy;

	  // Fill the rectangle, effectively drawing a thick line
	  g.fillPolygon(xPoints, yPoints, 4);
      }

   
    final public static String rcsid = "$Id: PSTEdge.java,v 1.2 1996/05/21 06:56:50 mjr Exp $";
}
