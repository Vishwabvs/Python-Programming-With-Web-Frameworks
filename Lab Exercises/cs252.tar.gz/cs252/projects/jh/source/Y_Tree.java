import java.awt.*;
import java.io.*;
import java.util.Vector;

public class Y_Tree {
  static final int DIST_BETWEEN_NODE=60;
  static  int BASE_MARGIN_X=60;
  static  int BASE_MARGIN_Y=50;
  static  int BASE_X=360;

  int total_length;
  Vector intervals=new Vector();
  int[] end_points;
  Vector temp1=new Vector();
  Vector temp2=new Vector();
  D_TreeNode root;

  //constructo for Y_Tree take an Vector argument, which
  //should be some Interval's
  public static void set_base_x(int k){
    BASE_X=360+3*k;
  }
  public static void set_base_y(int k){
    BASE_MARGIN_Y=50-3*k;
  }
  public Y_Tree(Vector a){
    intervals=a;
    int k=intervals.size();
    int cur_pos_x= BASE_X;
    int cur_pos_y=BASE_MARGIN_Y;
    end_points=new int[2*k];
    for(int i=0; i<k ; i++){
      Interval interval=(Interval)intervals.elementAt(i);
      end_points[2*i]=interval.left;
      end_points[2*i+1]=interval.right;
    }
    MyMethod.sort(end_points,2*k);
    k=2*k-1;
    //now, set up the tree:

    //first, the leaves:
    for(int i=0; i<k; i++){
     if(end_points[i]!=end_points[i+1]){
      D_TreeNode new_node=new D_TreeNode(end_points[i],
        end_points[i+1], cur_pos_x, cur_pos_y);
      cur_pos_y+=DIST_BETWEEN_NODE;
      temp1.addElement(new_node);
     }
    }
    k=temp1.size();
    int r=k-(k/2)*2;
    k=k/2;
    //next, other part of the tree
    while(true){
      for(int i=0; i<k; i++){
        temp2.addElement(new D_TreeNode((D_TreeNode)temp1.
          elementAt(2*i), (D_TreeNode)temp1.elementAt(2*i+1)));
      }
      if(r==1)
        temp2.addElement(temp1.elementAt(temp1.size()-1));
      temp1=temp2;
      temp2=new Vector();
      k=temp1.size();
      if(temp1.size()==1)
        break;
      else{
        r=k-(k/2)*2;
        k=k/2;
      }
    }
  root=(D_TreeNode)temp1.elementAt(0);
      traverse();
  }//end of constructor.

  private void traverse(){
    int k=intervals.size();
    for(int i=0; i<k; i++){
      Interval interval=(Interval)intervals.elementAt(i);
      root.paint(interval.left, interval.right, interval.rect);
    }
    total_length=root.cal_len();    
  }
} 

