#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>
#include <time.h>
#include <sys/stat.h>

#include <X11/Xlib.h>

int dead = 0;

void proc_died (int) {
  dead = 1;
}

void main(int argc, char **argv) {
  char *host;
  
  signal (SIGCHLD, proc_died);

  pid_t pid;
  char *new_argv[255];
  int new_argc;

  for (int i = 0; i < 255; i++) {
    new_argv[i] = new char [255];
  }

  char c;
  i = 0;
  int j = 0, k = 0;
  while (c = argv[1][k++]) {
    if (c != '+')
      new_argv[i][j++] = c;
    else {
      new_argv[i++][j] = 0;
      j = 0;
    }
  }
  new_argv[++i] = 0;
  new_argc = i;

  char name[L_tmpnam];
  FILE *fp;
  tmpnam (name);

  fp = tmpfile();

  // Before we go _anywhere_, stat the file
  struct stat statbuf;
  if (stat (argv[1], &statbuf) == -1) {
    perror (argv[1]);
    exit (EXIT_FAILURE);
  }
  
  if ((pid = fork()) == 0) {
    
    char setdisp[255];
    sprintf (setdisp, "DISPLAY=%s:0.0", getenv ("REMOTE_HOST"));
    putenv (setdisp);

    dup2 (fp->_file, 1);
    dup2 (fp->_file, 2);

    if (new_argc > 1) {
      if (execv (new_argv[0], &new_argv[0]) == -1)
        perror (argv[1]);
    } else {
      if (execl (new_argv[0], new_argv[0], 0) == -1) 
        perror (argv[1]);
    }
  }

  // This would be much more efficient if it used timers...
  time_t old_time, new_time;
  time (&old_time);
  do {
    if (dead) {
      int fd = fp->_file;
      lseek (fd, 0, SEEK_SET);
      char buf[1024];
      int nbytes;
      while ((nbytes = read (fd, &buf, 1024)) > 0)
        write (2, &buf, nbytes);
      exit (1);
    }
    time (&new_time);
  } while (new_time - old_time < 5);
    
  printf ("\n");
  exit (0);
}
