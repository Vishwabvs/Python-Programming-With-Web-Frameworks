import TreeAccessible;
import java.lang.*;
import java.io.StreamTokenizer;
import geometry.*;
import ReversibleCommand;
import Prototype;
import java.awt.Point;
import java.awt.Image;
import java.awt.image.*;
import RangeSearchAnimationCommand;
import Segment;
import SegmentSet;

/****************************************************************/
/* CLASS NAME :  EventVisitSegmentCommand                       */
/*                                                              */
/*                                                              */
/*                                                              */
/*                                                              */
/*                                                              */
/*                                                              */
/****************************************************************/


public class EventVisitSegmentCommand extends RangeSearchAnimationCommand  {

	public EventVisitSegmentCommand(Image		im,
					GeometryPanel	p,
					TreeAccessible	treeApp,
					Box		input_area)
	{
		super(im, p, treeApp, input_area);
	}

	public EventVisitSegmentCommand(Image		im,
					GeometryPanel	p,
					TreeAccessible	treeApp,
					Box		input_area,
					Segment 	seg)
	{
		super(im, p, treeApp, input_area);
		setSegment(seg);
	}

	public void execute()
	{
		if ((segment_ != null) && (node_ != null))
		{
			segment_.setSelected(true);
			panel_.repaint();
			reversible_ = true;
		}
		else reversible_ = false;
	}

	public void undo()
	{
		if (reversible_)
		{
			segment_.setSelected(false);
			panel_.repaint();
		}
	}


	public Object clone()
	{
		EventVisitSegmentCommand c = new
			EventVisitSegmentCommand( image_,
						panel_,
						tree_app_,
						user_input_bounds_,
						segment_);
		c.setBegin(begin_);
		c.setMedian(median_);
		c.setEnd(end_);
		return c;
	}

	public Object clone(StreamTokenizer st)
	{
		// get point x,y
		TreeNode n= new TreeNode((GeometryStreamTokenizer)st);
		begin_ = ((GeometryStreamTokenizer)st).nextInt();
		median_ = ((GeometryStreamTokenizer)st).nextInt();
		end_ = ((GeometryStreamTokenizer)st).nextInt();
		Tree tree = tree_app_.getTree();
		if (tree == null)  return null;

		n = tree.findNode(n.getID());
		GeometryPoint pt1 = new GeometryPoint((GeometryStreamTokenizer)st);
		GeometryPoint pt2 = new GeometryPoint((GeometryStreamTokenizer)st);
		Point p1 = new Point(pt1.x, pt1.y);
		Point p2 = new Point(pt2.x, pt2.y);
		Segment sg = new Segment(p1, p2,1);
		SegmentSet segment_set = tree_app_.getSegmentSet();


		Segment segm = segment_set.findSegment(pt1.x+1,pt1.y);
		//if (segm == null)
		//	System.out.println("\n segment in clone was not found");

		EventVisitSegmentCommand c = new
			EventVisitSegmentCommand( image_,
						panel_,
						tree_app_,
						user_input_bounds_,
						segm);
		c.setNode(n);
		c.setReversible(reversible_);
		c.setBegin(begin_);
		c.setMedian(median_);
		c.setEnd(end_);
		return c;
	}

	public String toString()
	{
		return new String("RTEVENTVISITSEGMENT");
	}

};
