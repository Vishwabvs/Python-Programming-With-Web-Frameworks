package sprite;

import java.awt.*;

public class RectangleSprite extends Sprite {
    Color pen_, fill_;
    int width_, height_;
    
    public RectangleSprite(SpriteArea area, int x, int y,
			int width, int height) {
	super(area, x, y);
	pen_ = Color.black;
	fill_ = Color.white;
	width_ = width;
	height_ = height;
	Anchor();
	ZToBottom();
    }

    public void SetPen(Color color) {
	pen_ = color;
	Redraw();
    }

    public void SetFill(Color color) {
	fill_ = color;
	Redraw();
    }

    public void Resize(int width, int height) {
	width_ = width;
	height_ = height;
	Redraw();
    }

    public boolean Inside(int x, int y) {
        int xOff = x - x_;
        int yOff = y - y_;
        return (xOff > 0 && xOff < width_ &&
		yOff > 0 && yOff < height_);
    }
    
    public void Draw(Graphics g) {
	if (fill_ != null) {
	    g.setColor(fill_);
	    g.fillRect(x_, y_, width_, height_);	    
	}
	
	g.setColor(pen_);
	g.drawRect(x_, y_, width_, height_);
    }

}
