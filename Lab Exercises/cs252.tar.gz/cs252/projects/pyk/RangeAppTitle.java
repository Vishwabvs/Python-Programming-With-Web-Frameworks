/*
 * RangeAppTitle.java
 *
 * Description:
 *    This class is the applet class for the 3D Box Intersection title.
 *    It displays the title gif file in an applet.  This allows the image to be redrawn.
 */
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Color;
import java.awt.Event;
import java.awt.MediaTracker;
import java.awt.Dimension;

public class RangeAppTitle extends java.applet.Applet implements Runnable
{
   MediaTracker tracker = null;         // media tracker, used to ensure that the
                                        // image will not be displayed until it is
                                        // in memory
   Image offScreenImage = null;         // the offscreen image
   Graphics offScreenGraphics = null;   // graphics context of offscreen image
   Thread running;                      // running thread
   int pauseValue = 100;                // time to sleep before repainting

   // initialize the media tracker and offscreen image
   public void init()
   {
      tracker = new MediaTracker(this);
      offScreenImage = createImage(353, 267);
      offScreenGraphics = offScreenImage.getGraphics();
   }

   // start the thread running
   public void start()
   {
      if (running == null)
      {
         running = new Thread(this);
         getFrame();
         running.start();
      }
   }

   // load the image into memory
   private boolean getFrame()
   {
      try
      {
         offScreenImage = getImage(getCodeBase(),
                                   "image/RangeAppTitle.gif");
/*         offScreenImage = getImage(getDocumentBase(),
                                   "image/RangeAppTitle.gif");
*/
      } catch(Exception e1)
      {
         System.out.println(e1);
      }
      tracker.addImage(offScreenImage, 1);
      try
      {
         tracker.checkID(1, true);
         tracker.waitForID(1);
      } catch(Exception e2)
      {
         System.out.println(e2);
      }
      repaint();
      return true;
   }

   // stop the thread from running, if it is running
   public void stop()
   {
      if (running != null)
      {
         running.stop();
         running = null;
         if (offScreenGraphics != null)
         {
            offScreenGraphics.dispose();
         }
      }
   }

   // sleep method
   public void pause(int time)
   {
      try
      {
         Thread.sleep(time);
      }
      catch (InterruptedException e)
      {
      }
   }

   // the loop that ensures that the image will always be displayed correctly
   public void run()
   {
      Thread thisThread = Thread.currentThread();
      thisThread.setPriority(Thread.MIN_PRIORITY);
      while (running != null)
      {
         repaint();
         pause(pauseValue);
      }
    }

   // the update method
   public void update(Graphics g)
   {
      paint(g);
   }

   // the paint method which draws the offscreen image to the screen
   public void paint(Graphics g)
   {
      g.drawImage(offScreenImage, 0, 0, this);
   }
}