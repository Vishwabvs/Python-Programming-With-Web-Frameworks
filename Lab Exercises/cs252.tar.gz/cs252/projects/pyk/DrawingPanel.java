/*
 * DrawingPanel.java
 *
 * Description:
 *    This class is the DrawingPanel class and has all methods and variables
 *    for constructing and drawing to the drawing canvas
 */
import java.awt.Graphics;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Event;
import java.awt.Color;
import java.awt.Image;
import java.awt.Insets;
import java.awt.Canvas;
import java.awt.Rectangle;
import java.util.Vector;

class DrawingPanel extends Canvas
{
   RangeApp appParent;                // the parent application
   Image offScreenImage;              // offscreen display buffer
   Graphics offScreenGraphics;        // graphics context for offscreen
                                      // display buffer
   FontMetrics fm;                    // font metrics, used to get
                                      // the size and with of a text
                                      // string
   Font f;                            // the font to use for text
   boolean highLight;                 // used to determine whether the
                                      // camera has snapped the picture
   Vector rectVector = new Vector();  // vector of bounding boxes
   Vector candidates = new Vector();  // vector of cubes for selecting
                                      // options
   Vector cubeVector = new Vector();  // vector of cubes
   int clipX;                         // clipping x coordinate
   int clipY;                         // clipping y coordinate
   int clipWidth;                     // clipping rectangle width
   int clipHeight;                    // clipping rectangle height
   int imageWidth;                    // buffered image width
   int imageHeight;                   // buffered image height
   int rectSelected;                  // selected bounding box number
   int numRectNodes = 0;              // number of bounding boxes
   int candidateNum = 0;              // number of selected cube
                                      // in candidates vector

   // constructor for DrawingPanel canvas
   DrawingPanel(RangeApp parent)
   {
      f = new Font("TimesRoman", Font.PLAIN, 18);
      appParent = parent;
      rectSelected = -1;
      candidateNum = 0;
      highLight = false;
   }

   // set the size of the canvas and the offscreen image buffer
   public void setSize(int width, int height)
   {
      imageWidth = width;
      imageHeight = height;
      resize(width, height);
      offScreenImage = createImage(width, height);
      offScreenGraphics = offScreenImage.getGraphics();
      offScreenGraphics.setFont(f);
      offScreenGraphics.setColor(Color.black);
      fm = offScreenGraphics.getFontMetrics(f);
      repaint();
   }

   // set the insets from the edge
   public Insets insets()
   {
      return new Insets(10, 10, 0, 0);
   }

   // mouse down event handler
   public boolean mouseDown(Event evt, int x, int y)
   {
      RectangleNode rect;
      CubeNode cube;

      if (appParent.actionChoice.getSelectedItem().equals("Initial Placement"))
      {
         if (appParent.objectChoice.getSelectedItem().equals("Bounding Box"))
         {
            cube = new CubeNode(x, y, 1, 1, numRectNodes);
            cube.setAppParent(appParent);
            cubeVector.addElement(cube);
            rect = new RectangleNode(x, y, numRectNodes);
            numRectNodes++;
            rect.setHeightWidth(x, y);
	        rectVector.addElement(rect);
            setClipRegion(rect.getXPosition(), rect.getYPosition(), rect.getWidth(),
                          rect.getHeight());
         }
      }
      return true;
   }

   // return the id of the last bounding box
   public int getLastRectID()
   {
      return rectVector.size() - 1;
   }

     // set the selected bounding box
     public void setRectSelected(int selectID)
     {
        rectSelected = selectID;
     }

     // return the id of the selected bounding box
     public int getRectSelected()
     {
        return rectSelected;
     }

     // determine and set the clipping area
     public void setClipRegion(int x, int y, int width, int height)
     {
        clipX = (width >= 0) ? x : x + width;
        clipY = (height >= 0) ? y : y + height;
        clipWidth = (width >= 0) ? width : -width;
        clipHeight = (height >= 0) ? height : -height;
     }

     // handler for the mouse up event
     public boolean mouseUp(Event evt, int x, int y)
     {
        if (appParent.actionChoice.getSelectedItem().equals("Initial Placement"))
        {
           if (appParent.objectChoice.getSelectedItem().equals("Bounding Box"))
           {
              Color savedColor = offScreenGraphics.getColor();
              offScreenGraphics.setColor(Color.black);
              RectangleNode rect = (RectangleNode) rectVector.elementAt(rectVector.size() -
                                    1);
              CubeNode cube = (CubeNode) cubeVector.elementAt(cubeVector.size() -
                                    1);
              Rectangle boundingBox = cube.getBoundingBox();
              rect.setHeightWidth(x, y);
              rect.setXYZ(boundingBox.x, boundingBox.y, cube.frontZPosition);
              rect.setHeightWidth(boundingBox.x + boundingBox.width,
                                  boundingBox.y + boundingBox.height);
              setClipRegion(rect.getXPosition(), rect.getYPosition(), rect.getWidth(),
                            rect.getHeight());
              offScreenGraphics.clearRect(rect.getXPosition(),
                                    rect.getYPosition() - fm.getAscent(),
                                    fm.stringWidth(rect.getRectIDString()),
                                    fm.getAscent() + 2);
              offScreenGraphics.setColor(savedColor);
              repaint();
              setClipRegion(0, 0, 0, 0);
              if (appParent.resetButton.isEnabled() == false)
              {
                 appParent.resetButton.enable();
              }
              appParent.objectSeen = true;
              if (appParent.cameraSeen)
              {
                 if (appParent.doQueryButton.isEnabled() == false)
                 {
                    appParent.doQueryButton.enable();
                    appParent.analysisChoice.enable();
                 }
                 if (appParent.pixelSeen)
                 {
                    if (appParent.queryChoice.isEnabled() == false)
                    {
                        appParent.queryChoice.enable();
                    }
                 }
              }
              if (appParent.actionChoice.isEnabled() == false)
              {
                 appParent.actionChoice.enable();
              }
           }
           else if (appParent.objectChoice.getSelectedItem().equals("Camera"))
           {
              if (appParent.camera.firstTime == true)
              {
                 appParent.camera.place(x, y, offScreenGraphics);
                 appParent.cameraSeen = true;
                 if (appParent.resetButton.isEnabled() == false)
                 {
                    appParent.resetButton.enable();
                 }
                 if (appParent.objectSeen)
                 {
                    if (appParent.doQueryButton.isEnabled() == false)
                    {
                       appParent.doQueryButton.enable();
                       appParent.analysisChoice.enable();
                    }
                    if (appParent.pixelSeen)
                    {
                       if (appParent.queryChoice.isEnabled() == false)
                       {
                          appParent.queryChoice.enable();
                       }
                    }
                 }
                 repaint();
              }
           }
           else if (appParent.objectChoice.getSelectedItem().equals("Point of Interest"))
           {
              if (appParent.pointOfInterest.firstTime == true)
              {
                 appParent.pointOfInterest.place(x, y, offScreenGraphics);
                 appParent.pixelSeen = true;
                 if (appParent.resetButton.isEnabled() == false)
                 {
                    appParent.resetButton.enable();
                 }
                 if ((appParent.objectSeen) && (appParent.cameraSeen))
                 {
                    if (appParent.doQueryButton.isEnabled() == false)
                    {
                       appParent.doQueryButton.enable();
                       appParent.analysisChoice.enable();
                    }
                    if (appParent.queryChoice.isEnabled() == false)
                    {
                        appParent.queryChoice.enable();
                    }
                 }
                 repaint();
              }
           }
           appParent.positionCanvas.reset();
        }
        else if (appParent.controllerOptions.getSelectedItem().equals("Selected Placement"))
        {
           if (candidates.isEmpty() == false)
           {
              candidates.removeAllElements();
           }
           candidateNum = 0;
           getSelectedRectangle(x, y);
           if (appParent.previousButton.isEnabled())
           {
              appParent.previousButton.disable();
           }
           if (candidates.size() > 1)
           {
              if (appParent.nextButton.isEnabled() == false)
              {
                 appParent.nextButton.enable();
              }
           }
           repaint();
           appParent.positionCanvas.reset();
        }
        return true;
     }

     // get the selected rectangle based upon the x and y coordinates
     private void getSelectedRectangle(int x, int y)
     {
        int numberRectangles;
        int index;
        Integer tempInt;

        numberRectangles = rectVector.size();
        rectSelected = -1;
        if (numberRectangles > 0)
        {
           for (index = 0; (index < numberRectangles); index++)
           {
              RectangleNode rectNode = (RectangleNode) rectVector.elementAt(index);
              if (rectNode.contains(x, y))
              {
                 tempInt = new Integer(index);
                 candidates.addElement(tempInt);
              }
           }
           if (candidates.isEmpty() == false)
           {
              rectSelected = ((Integer) (candidates.firstElement())).
                             intValue();
              candidateNum = 0;
           }
        }
     }

     // clear the clipping region, this is used as a cube is moved in
     // order to erase the prior position
     public void clearClip()
     {
        int clearX;
        int temp;
        int clearY;
        int clearWidth;
        int clearHeight;

        CubeNode cube = (CubeNode) cubeVector.elementAt(cubeVector.size() - 1);
        temp = cube.getMinX();
        if (clipX < temp)
        {
           clearX = clipX;
           clearWidth = temp - clearX;
        }
        else
        {
           clearX = temp;
           clearWidth = clipWidth;
        }
        temp = cube.getMinY();
        if (clipY < temp)
        {
           clearY = clipY;
           clearHeight = temp - clearY;
        }
        else
        {
           clearY = temp;
           clearHeight = clipHeight;
        }
        Rectangle boundingBox = cube.getBoundingBox();
        clearWidth = Math.max(boundingBox.width, clearWidth);
        clearHeight = Math.max(boundingBox.height, clearHeight);
        clearX = Math.min(boundingBox.x, clearX);
        clearY = Math.min(boundingBox.y, clearY);
        offScreenGraphics.clearRect(clearX - 10, clearY - 10, clearWidth + 20,
                                    clearHeight + 20);

     }

     // move the last object created
     public void moveLatest(int xMove, int yMove, int zMove)
     {
        int height;
        int width;

        RectangleNode rect = (RectangleNode) rectVector.elementAt(rectVector.size() - 1);
        CubeNode cube = (CubeNode) cubeVector.elementAt(cubeVector.size() - 1);
        rectSelected = rectVector.size() - 1;
        moveHelper(rect, cube, xMove, yMove, zMove);
     }

     // change the last object created
     public void changeLatest(int xMove, int yMove, int zMove, boolean modifyBack)
     {
        int height;
        int width;

        RectangleNode rect = (RectangleNode) rectVector.elementAt(rectVector.size() - 1);
        CubeNode cube = (CubeNode) cubeVector.elementAt(cubeVector.size() - 1);
        rectSelected = rectVector.size() - 1;
        changeHelper(rect, cube, xMove, yMove, zMove, modifyBack);
     }

     // move the selected object
     public void moveSelected(int xMove, int yMove, int zMove)
     {
        int height;
        int width;

        RectangleNode rect = (RectangleNode) rectVector.elementAt(rectSelected);
        CubeNode cube = (CubeNode) cubeVector.elementAt(rectSelected);
        moveHelper(rect, cube, xMove, yMove, zMove);
     }

     // change the selected object
     public void changeSelected(int xMove, int yMove, int zMove, boolean modifyBack)
     {
        int height;
        int width;

        RectangleNode rect = (RectangleNode) rectVector.elementAt(rectSelected);
        CubeNode cube = (CubeNode) cubeVector.elementAt(rectSelected);
        changeHelper(rect, cube, xMove, yMove, zMove, modifyBack);
     }

     // helper routine for changing the selected object
     private void changeHelper(RectangleNode rect, CubeNode cube, int xMove, int yMove,
                               int zMove, boolean modifyBack)
     {
        int width;
        int height;
        int x;
        int y;

        if (rect.getWidth() > fm.stringWidth(rect.getRectIDString()))
        {
           width = rect.getWidth();
        }
        else
        {
           width = fm.stringWidth(rect.getRectIDString());
        }
        if (rect.getHeight() > fm.getAscent())
        {
           height = rect.getHeight();
        }
        else
        {
           height = fm.getAscent() + 2;
        }
        offScreenGraphics.clearRect(rect.getXPosition(),
                                    rect.getYPosition() - fm.getAscent() + 2,
                                    width + 2,
                                    height + fm.getAscent() + 2);
        cube.repositionBackFace(xMove, yMove, zMove, modifyBack);
        Rectangle boundingBox = cube.getBoundingBox();
        rect.setXYZ(boundingBox.x, boundingBox.y, cube.frontZPosition);
        rect.setHeightWidth(boundingBox.x + boundingBox.width,
                            boundingBox.y + boundingBox.height);
        setClipRegion(rect.getXPosition(), rect.getYPosition(), rect.getWidth(),
                      rect.getHeight());
        repaint();
     }

     // helper routine for moving the specified object
     private void moveHelper(RectangleNode rect, CubeNode cube, int xMove, int yMove,
                             int zMove)
     {
        int width;
        int height;
        int x;
        int y;

        if (rect.getWidth() > fm.stringWidth(rect.getRectIDString()))
        {
           width = rect.getWidth();
        }
        else
        {
           width = fm.stringWidth(rect.getRectIDString());
        }
        if (rect.getHeight() > fm.getAscent())
        {
           height = rect.getHeight();
        }
        else
        {
           height = fm.getAscent() + 2;
        }
        offScreenGraphics.clearRect(rect.getXPosition(),
                                    rect.getYPosition() - fm.getAscent() + 2,
                                    width + 2,
                                    height + fm.getAscent() + 2);
        cube.reposition(xMove, yMove, zMove);
        Rectangle boundingBox = cube.getBoundingBox();
        rect.setXYZ(boundingBox.x, boundingBox.y, cube.frontZPosition);
        rect.setHeightWidth(boundingBox.x + boundingBox.width,
                            boundingBox.y + boundingBox.height);
        setClipRegion(rect.getXPosition(), rect.getYPosition(), rect.getWidth(),
                      rect.getHeight());
        repaint();
     }

     // event handler for drag, used to move the object continuously
     public boolean mouseDrag(Event evt, int x, int y)
     {
        int height;
        int width;

        if (appParent.actionChoice.getSelectedItem().equals("Initial Placement"))
        {
           if (appParent.objectChoice.getSelectedItem().equals("Bounding Box"))
           {
              Color savedColor = offScreenGraphics.getColor();
              RectangleNode rect = (RectangleNode) rectVector.elementAt(rectVector.size() - 1);
              width = x - rect.getXPosition();
              height = y - rect.getYPosition();
              offScreenGraphics.setColor(new Color(rect.getColorUnit(),
                                                   rect.getColorUnit(),
                                                   rect.getColorUnit()));
              clearClip();
              setClipRegion(rect.getXPosition(), rect.getYPosition(), width, height);
              CubeNode cube = (CubeNode) cubeVector.elementAt(cubeVector.size() - 1);
              cube.move(clipX, clipY);
              cube.resize(clipWidth, clipHeight);
              cube.drawCube(offScreenGraphics, true);
              offScreenGraphics.drawRect(clipX, clipY, clipWidth, clipHeight);
              offScreenGraphics.setColor(savedColor);
              repaint();
           }
        }
        return true;
     }

     // update the drawing canvas
     public void update(Graphics g)
     {
        paint(g);
     }

     // reset the drawing canvas, clears it and resets variables and
     // parent's buttons
     public void reset()
     {
        int numberRectangles;
        int index;

        offScreenGraphics.clearRect(0, 0, imageWidth, imageHeight);
        numberRectangles = rectVector.size();
        if (numberRectangles > 0)
        {
           rectVector.removeAllElements();
           cubeVector.removeAllElements();
        }
        highLight = false;
        rectSelected = -1;
        numRectNodes = 0;
        appParent.camera.reset(offScreenGraphics);
        appParent.pointOfInterest.reset(offScreenGraphics);
        if (appParent.previousButton.isEnabled())
        {
           appParent.previousButton.disable();
        }
        if (appParent.nextButton.isEnabled())
        {
           appParent.nextButton.disable();
        }
        if (appParent.doQueryButton.isEnabled())
        {
           appParent.doQueryButton.disable();
        }
        if (appParent.analysisChoice.isEnabled())
        {
           appParent.analysisChoice.disable();
        }
        if (appParent.queryChoice.isEnabled())
        {
           appParent.queryChoice.disable();
        }
        appParent.queryChoice.select("All Objects Detected");
        appParent.objectSeen = false;
        appParent.cameraSeen = false;
        appParent.pixelSeen = false;
        if (candidates.isEmpty() == false)
        {
           candidates.removeAllElements();
        }
        candidateNum = 0;
        repaint();
     }

     // set the highlight flag to the specified value
     public void highLightObjects(boolean highLightValue)
     {
        highLight = highLightValue;
     }

     // clear the offscreen image buffer
     public void clearScreen()
     {
        offScreenGraphics.clearRect(0, 0, imageWidth, imageHeight);
     }

     // draw present state of all objects (cubes, camera, point) to
     // offscreen buffer and then to screen
     public void paint(Graphics g)
     {
        int numberRectangles;
        int index;
        String tempString;

        Color savedColor = g.getColor();
        if (highLight == true)
        {
           clearViewPort(offScreenGraphics);
           snapPicture(offScreenGraphics);
        }
        else
        {
          if (appParent.camera.ready == true)
          {
             clearViewPort(offScreenGraphics);
          }
        }
        offScreenGraphics.setColor(Color.black);
        numberRectangles = rectVector.size();
        if (numberRectangles > 0)
        {
           for (index = 0; index < numberRectangles; index++)
           {
              RectangleNode rectNode = (RectangleNode) rectVector.elementAt(index);
              if (index == rectSelected)
              {
                 offScreenGraphics.setColor(Color.red);
                 rectNode.drawRectangleNode(offScreenGraphics, false);
              }
              else
              {
                 rectNode.drawRectangleNode(offScreenGraphics, true);
              }
              CubeNode cubeNode = (CubeNode) cubeVector.elementAt(index);
              cubeNode.drawCube(offScreenGraphics, true);
              if (appParent.debugMode == true)
              {
                 tempString = rectNode.getRectIDString();
                 if (rectNode.width > fm.stringWidth(tempString))
                 {
                    offScreenGraphics.drawString(tempString,
                             (rectNode.xPosition + (rectNode.width / 2)) -
                             fm.stringWidth(tempString) / 2,
                             (rectNode.yPosition + (rectNode.height / 2))
                             + fm.getAscent() / 2);
                 }
                 else
                 {
                    offScreenGraphics.drawString(tempString,
                                 rectNode.xPosition,
                                 rectNode.yPosition);
                 }
              }
              g.drawImage(offScreenImage, 0, 0, this);
           }
        }
        if (appParent.camera.ready == true)
        {
           appParent.camera.draw(offScreenGraphics);
        }
        if (appParent.pointOfInterest.ready == true)
        {
           appParent.pointOfInterest.draw(offScreenGraphics);
        }
        g.drawImage(offScreenImage, 0, 0, this);
        offScreenGraphics.setColor(savedColor);
    }

    // clear the viewport
    private void clearViewPort(Graphics offScreenGraphics)
    {
        Color savedColor = offScreenGraphics.getColor();
        offScreenGraphics.setColor(getBackground());
//      offScreenGraphics.setColor(Color.white);
        offScreenGraphics.fillRect(appParent.camera.xPosition -
                                   appParent.camera.viewPortWidth / 2,
                                   appParent.camera.yPosition -
                                   appParent.camera.viewPortHeight / 2,
                                   appParent.camera.viewPortWidth,
                                   appParent.camera.viewPortHeight);
        offScreenGraphics.setColor(savedColor);
    }

    // take the picture, portions of all objects that match query
    // will be filled in red
    private void snapPicture(Graphics offScreenGraphics)
    {
        int index;
        Rectangle cameraRect;
        Rectangle rectangle;
        Rectangle inPicture;

        offScreenGraphics.setColor(Color.red);
        cameraRect = new Rectangle(appParent.camera.xPosition -
                                   appParent.camera.viewPortWidth / 2,
                                   appParent.camera.yPosition -
                                   appParent.camera.viewPortHeight / 2,
                                   appParent.camera.viewPortWidth,
                                   appParent.camera.viewPortHeight);
        for (index = 0; index < appParent.query.newRects.size(); index++)
        {
           RectangleNode rectNode = (RectangleNode) appParent.query.
                                    newRects.elementAt(index);
           rectangle = new Rectangle(rectNode.xPosition, rectNode.yPosition,
                                     rectNode.width, rectNode.height);
           inPicture = rectangle.intersection(cameraRect);
           offScreenGraphics.fillRect(inPicture.x, inPicture.y, inPicture.width,
                                      inPicture.height);
        }
    }
}
