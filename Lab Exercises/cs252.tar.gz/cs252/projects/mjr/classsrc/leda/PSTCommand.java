/*
 * @(#)PSTCommand.java 1.0 1/13/96 Michael John Radwin
 */
 
package leda;
 
public abstract class PSTCommand implements mjr.util.Command {
    final public Object execute(Object o) throws Throwable
    {
        return _execute((ps_item) o);
    }
 
    abstract public Object _execute(ps_item p) throws Throwable;
}

