import java.applet.*;
import java.awt.*;

public class BoxSpring extends NoFlickerApplet {

  BoxSpringFrame bsf_;

  public void test(int num_box) {

    WV_BoxSpringContainer bsc = new WV_BoxSpringContainer(true);

    for (int i = 0; i < 10; i++) {
      WV_Box b = new WV_Box(new WV_String("*" + i), null,
  		     new Point (((i * 50 > 500) ? 250 + i : i * 50), 
  				((i * 50 > 700) ? 350 + 1 : i * 50)),
  		     new Dimension(40, 40));

      bsc.add(b);
      bsc.select();
    }

    bsc.resize(200, 200);
    bsf_.addToSpring(bsc);

    for (int i = 0; i < num_box; i++) {

      Color clr = new Color((int) (Math.random() * 128 + 128),
			    (int) (Math.random() * 128 + 128),
			    (int) (Math.random() * 128 + 128));

      
      int demo_choice = bsf_.demo_choice_.getSelectedIndex();
      if (demo_choice == 3)
	demo_choice = (int) (Math.random() * 3.0);

      switch (demo_choice) {
      case 0:
	WV_Box b = new WV_Box(new WV_String("#" + i), null,
			      new Point (((i * 50 > 500) ? 250 + i : i * 50), 
					 ((i * 50 > 700) ? 350 + 1 : i * 50)),
			      new Dimension(40, 40));
	if (Math.random() < 0.25) {
	  bsc.addConnection(b);
	  System.out.println("Added connection to " + i); 
	}
	bsf_.addToSpring(b);
	break;
      case 1:
	Button btn = new Button("Butt #" + i);
	btn.resize(60, 20);
	//	bsc.addConnection(btn);
	btn.setBackground(clr);
	bsf_.addToSpring(btn);
	break;
      case 2:
	Label l = new Label("Label #" + i);
	l.resize(70, 20);
	l.setBackground(clr);
	// bsc.addConnection(l);
	bsf_.addToSpring(l);
	break;
      }
    }

  }

  void testFile(String s) {

    WV_FileReader f = new WV_FileReader();
    f.openConnection("sample_file.txt");
    WV_BoxSpringContainer bsc = f.readInformation();
    bsf_.setTopLevelContainer(bsc);
    bsc.resize(500, 700); 
    
    
  }	

   public void stop() {

     System.out.println("-- Stop Called! --");
     bsf_.dispose();
     super.stop();
   }

  public void init() {
    bsf_ = new BoxSpringFrame(this);
    //    test(5);
    try {
      testFile("sample.txt");
    }
    catch (Exception e) {
      test(10);
    }
    bsf_.resize(bsf_.preferredSize());
    bsf_.pack();
    bsf_.show();

  }

}



class BoxSpringFrame extends Frame {

  WV_BoxSpringContainer bsc_;
  TextField num_nodes_field_;
  Button reset_button_;
  Button step_button_;
  BoxSpring parent_; 
 TextField cnb_field_;
  Choice demo_choice_;
  GridBagLayout gbl_;
  

  public BoxSpringFrame(BoxSpring bsp) {
    super("Box Spring");


    demo_choice_ = new Choice();
    demo_choice_.addItem("URL Panels");
    demo_choice_.addItem("Buttons");
    demo_choice_.addItem("Labels");
    demo_choice_.addItem("Random");

    parent_ = bsp;
    GridBagConstraints gbc = new GridBagConstraints();
    gbl_ = new GridBagLayout();
    setLayout(gbl_);

    gbc.gridx = 0;
    gbc.gridy = 0;
    gbc.gridheight = 1;
    gbc.gridwidth = 4;
    gbc.weightx = 1.0;
    gbc.weighty = 1.0;
    gbc.fill = gbc.BOTH;
    bsc_ = new WV_BoxSpringContainer(false);
    bsc_.resize(500, 700); 
    gbl_.setConstraints(bsc_, gbc);
    add(bsc_);
    
    step_button_ = new Button("Step");
    gbc.gridx = 0;
    gbc.gridy = 1;
    gbc.gridheight = 1;
    gbc.gridwidth = 1; 
    gbc.weightx = 1.0;
    gbc.weighty = 0.0;
    gbc.fill = gbc.NONE;
    gbl_.setConstraints(step_button_, gbc);
    add(step_button_);

    reset_button_ = new Button("Reset");
    gbc.gridx = 1;
    gbc.gridy = 1;
    gbc.gridheight = 1;
    gbc.gridwidth = 1; 
    gbc.weightx = 1.0;
    gbc.weighty = 0.0;
    gbc.fill = gbc.NONE;
    gbl_.setConstraints(reset_button_, gbc);
    add(reset_button_);

    Label cnb_label = new Label("Crash & Burn");
    gbc.gridx = 0;
    gbc.gridy = 2;
    gbc.gridheight = 1;
    gbc.gridwidth = 3; 
    gbc.weightx = 1.0;
    gbc.weighty = 0.0;
    gbc.fill = gbc.NONE;
    gbc.anchor = gbc.WEST;
    gbl_.setConstraints(cnb_label, gbc);
    add(cnb_label);

    cnb_field_ = new TextField();
    cnb_field_.setText("250");
    gbc.gridx = 3;
    gbc.gridy = 2;
    gbc.gridheight = 1;
    gbc.gridwidth = 1; 
    gbc.weightx = 1.0;
    gbc.weighty = 0.0;
    gbc.fill = gbc.HORIZONTAL;
    gbl_.setConstraints(cnb_field_, gbc);
    add(cnb_field_);

    Label num_nodes_label = new Label("Number of Nodes:");
    gbc.gridx = 0;
    gbc.gridy = 3;
    gbc.gridheight = 1;
    gbc.gridwidth = 3; 
    gbc.weightx = 1.0;
    gbc.weighty = 0.0;
    gbc.fill = gbc.NONE;
    gbl_.setConstraints(num_nodes_label, gbc);
    add(num_nodes_label);

    num_nodes_field_ = new TextField();
    num_nodes_field_.setText("25");
    gbc.gridx = 3;
    gbc.gridy = 3;
    gbc.gridheight = 1;
    gbc.gridwidth = 1; 
    gbc.weightx = 1.0;
    gbc.weighty = 0.0;
    gbc.fill = gbc.HORIZONTAL;
    gbl_.setConstraints(num_nodes_field_, gbc);
    add(num_nodes_field_);

    gbc.gridx = 2;
    gbc.gridy = 4;
    gbc.gridheight = 1;
    gbc.gridwidth = 1; 
    gbc.weightx = 1.0;
    gbc.weighty = 0.0;
    gbc.fill = gbc.HORIZONTAL;
    gbl_.setConstraints(demo_choice_, gbc);
    add(demo_choice_);


  }

  public boolean handleEvent (Event evt) {
    if (evt.id == Event.WINDOW_DESTROY) {
      dispose();
      parent_.stop();
      return true;
    }
    return false;

  }
    public boolean action (Event evt, Object what) {

    if (evt.target == reset_button_) {
      bsc_.removeAll();
      parent_.test((int) (new Integer(num_nodes_field_.getText())).intValue());
      parent_.validate();
      return true;
    }

    if (evt.target == step_button_) {
      bsc_.layout((int) (new Integer(cnb_field_.getText())).intValue());
      bsc_.layout((int) (new Integer(cnb_field_.getText())).intValue());
      return true;
    }


    System.out.println("ACTION " + evt);
    return super.action(evt ,what);
    
  }


  public void setTopLevelContainer(WV_BoxSpringContainer c) {

    remove(bsc_);

    GridBagConstraints gbc = new GridBagConstraints();
    
    gbc.gridx = 0;
    gbc.gridy = 0;
    gbc.gridheight = 1;
    gbc.gridwidth = 4;
    gbc.weightx = 1.0;
    gbc.weighty = 1.0;
    gbc.fill = gbc.BOTH;
    gbl_.setConstraints(c, gbc);
    bsc_ = c;
    add(bsc_);
  }

  public void addToSpring(Component c) {
    bsc_.add(c);

  }

}
