/*
 * @(#)Command.java 1.0 1/13/96 Michael John Radwin
 */
 
package mjr.util;


/**
 * A generic command interface.  Encapsulates a method as an object;
 * useful for pattern programming implementations like Visitor, State,
 * or (of course) Command.
 *
 * @version 1.0 2/23/96
 * @author <A HREF="http://www.cs.brown.edu/people/mjr/">Michael J. Radwin</A>
 */
public interface Command {
    /**
     * Calls the method, passing in any client data needed,
     * returning any data needed.  Casts are required to turn
     * Objects into something useful.
     */
    public Object execute(Object o) throws Throwable;
}
