/*
 * IntervalTree.java
 *
 * Description:
 *    This class is the IntervalTree class and has all methods and variables
 *    for creating, walking, and displaying an IntervalTree
 */
import java.awt.Font;
import java.awt.Graphics;
import java.awt.FontMetrics;
import java.awt.Color;
import java.util.Vector;

class IntervalTree extends RBBinaryTree
{
   private int intervalNodeNumber;   // the unique interval tree node
                                     // number
   private int closestValue;         // closest interval value

   // the constructor for the interval tree simply calls the constructor
   // for the red-black tree
   IntervalTree()
   {
      super();
   }

   // insert an interval tree node into the interval tree
   public void intervalInsert(IntervalTreeNode newNode)
   {
       RBInsert(newNode);
   }

   // build an interval tree given a vector of intervals
   public void buildIntervalTree(Vector intervals)
   {
      int numLeafNodes;
      int totalNodes;
      int rootNodeNumber;
      int numLevels;
      int levelIndex;
      int index;

      numLeafNodes = intervals.size();
      totalNodes = numLeafNodes * 2 - 1;
      for (rootNodeNumber = 1, numLevels = 1; rootNodeNumber < totalNodes;
           rootNodeNumber *= 2, numLevels++)
      {
      }
      if (totalNodes > 1)
      {
         rootNodeNumber /= 2;
         numLevels--;
      }
      levelIndex = 1;
      buildIntervalTreeHelper(rootNodeNumber, levelIndex, numLevels, totalNodes);
      intervalNodeNumber = 0;
      populateIntervalTree(intervals);
   }

   // populate an interval tree from a vector of intervals
   public void populateIntervalTree(Vector intervals)
   {
      populateIntervalHelper((IntervalTreeNode) (getRoot()), intervals);
   }

   // helper to populate interval tree from a vector of intervals
   public void populateIntervalHelper(IntervalTreeNode node, Vector intervals)
   {
      Interval interval;

      if (node != null)
      {
         populateIntervalHelper((IntervalTreeNode) (node.leftChild), intervals);
         populateIntervalHelper((IntervalTreeNode) (node.rightChild), intervals);
         if ((node.leftChild == null) && (node.rightChild == null))
         {
            interval = (Interval) intervals.elementAt(intervalNodeNumber);
            node.interval = new Interval(interval.getLowValue(), interval.getId());
            node.interval.otherIds = interval.otherIds;
            node.setHigh(interval.getHighValue());
            node.setMax(-2147483648);
            intervalNodeNumber++;
         }
         else
         {
            if ((node.leftChild != null) && (node.rightChild != null))
            {
/*
               Vector ids = idIntersection((IntervalTreeNode) node.leftChild,
                                           (IntervalTreeNode) node.rightChild);
*/
               Vector ids = idUnion((IntervalTreeNode) node.leftChild,
                                           (IntervalTreeNode) node.rightChild);
               if (ids.isEmpty())
               {
                  node.interval = new Interval(((IntervalTreeNode) node.leftChild).getLow(),
                                               -1);
               }
               else
               {
                  node.interval = new Interval(((IntervalTreeNode) node.leftChild).getLow(),
                                               ((Integer) ids.firstElement()).intValue());
                  for (int index = 1; index < ids.size(); index++)
                  {
                     node.interval.otherIds.addElement(ids.elementAt(index));
                  }
               }
               node.setMax(((IntervalTreeNode) node.leftChild).getHigh());
            }
            else
            {
               if (node.leftChild == null)
               {
                  node.interval = new Interval(((IntervalTreeNode) node.rightChild).getLow(),
                                               -1);
                  node.setMax(-2147483648);
               }
               else
               {
                  node.interval = new Interval(((IntervalTreeNode) node.leftChild).getLow(),
                                               -1);
                  node.setMax(((IntervalTreeNode) node.leftChild).getHigh());
               }
            }
            if (node.rightChild == null)
            {
               node.setHigh(((IntervalTreeNode) node.leftChild).getHigh());
            }
            else
            {
               node.setHigh(((IntervalTreeNode) node.rightChild).getHigh());
            }
         }
      }
   }

   // get the union of sibling interval tree nodes
   private Vector idUnion(IntervalTreeNode leftChild,
                          IntervalTreeNode rightChild)
   {
      Vector ids = new Vector();
      boolean idFound;
      int index;
      int idToFind;

      if (leftChild.interval.getId() == rightChild.interval.getId())
      {
         ids.addElement(new Integer(leftChild.interval.getId()));
      }
      else
      {
         idFound = idSearch(leftChild.interval.getId(), rightChild.interval.otherIds);
         if (idFound == false)
         {
            ids.addElement(new Integer(leftChild.interval.getId()));
         }
         idFound = idSearch(rightChild.interval.getId(), leftChild.interval.otherIds);
         if (idFound == false)
         {
            ids.addElement(new Integer(rightChild.interval.getId()));
         }
      }
      for (index = 0; index < leftChild.interval.otherIds.size(); index++)
      {
         idToFind = ((Integer) leftChild.interval.otherIds.elementAt(index)).intValue();
         idFound = idSearch(idToFind, ids);
         if (idFound == false)
         {
            ids.addElement(new Integer(idToFind));
         }
      }
      for (index = 0; index < rightChild.interval.otherIds.size(); index++)
      {
         idToFind = ((Integer) rightChild.interval.otherIds.elementAt(index)).intValue();
         idFound = idSearch(idToFind, ids);
         if (idFound == false)
         {
            ids.addElement(new Integer(idToFind));
         }
      }
      return ids;
   }

   // determine the intersection of two sibling interval tree nodes
   private Vector idIntersection(IntervalTreeNode leftChild,
                                IntervalTreeNode rightChild)
   {
      Vector ids = new Vector();
      boolean idFound;
      int index;
      int idToFind;

      if (leftChild.interval.getId() == rightChild.interval.getId())
      {
         ids.addElement(new Integer(leftChild.interval.getId()));
      }
      else
      {
         idFound = idSearch(leftChild.interval.getId(), rightChild.interval.otherIds);
         if (idFound)
         {
            ids.addElement(new Integer(leftChild.interval.getId()));
         }
         else
         {
            idFound = idSearch(rightChild.interval.getId(), leftChild.interval.otherIds);
            if (idFound)
            {
               ids.addElement(new Integer(rightChild.interval.getId()));
            }
         }
      }
      for (index = 0; index < leftChild.interval.otherIds.size(); index++)
      {
         idToFind = ((Integer) leftChild.interval.otherIds.elementAt(index)).intValue();
         idFound = idSearch(idToFind, rightChild.interval.otherIds);
         if (idFound)
         {
            idFound = idSearch(idToFind, ids);
            if (idFound == false)
            {
               ids.addElement(new Integer(idToFind));
            }
         }
      }
      for (index = 0; index < rightChild.interval.otherIds.size(); index++)
      {
         idToFind = ((Integer) rightChild.interval.otherIds.elementAt(index)).intValue();
         idFound = idSearch(idToFind, leftChild.interval.otherIds);
         if (idFound)
         {
            idFound = idSearch(idToFind, ids);
            if (idFound == false)
            {
               ids.addElement(new Integer(idToFind));
            }
         }
      }
      return ids;
   }

   // is the specified id found in a vector of ids
   private boolean idSearch(int idToFind, Vector ids)
   {
      int index;

      for (index = 0; index < ids.size(); index++)
      {
         if (idToFind == ((Integer) ids.elementAt(index)).intValue())
         {
            return true;
         }
      }
      return false;
   }

   // helper to build interval tree
   public void buildIntervalTreeHelper(int nodeNumber, int levelIndex, int numLevels,
                                       int totalNodes)
   {
      Integer numberNode;
      int incrementValue;

      if (levelIndex <= numLevels)
      {
         if (nodeNumber <= totalNodes)
         {
            numberNode = new Integer(nodeNumber);
            IntervalTreeNode newNode = new IntervalTreeNode(numberNode);
            intervalInsert(newNode);
         }
         if (levelIndex < numLevels)
         {
            incrementValue = (int) Math.pow((double) 2, (double) ((numLevels - levelIndex)
                                            - 1));
            buildIntervalTreeHelper(nodeNumber - incrementValue, levelIndex + 1, numLevels,
                                    totalNodes);
            buildIntervalTreeHelper(nodeNumber + incrementValue, levelIndex + 1, numLevels,
                                    totalNodes);
         }
      }
   }

   // calculate node positions of all nodes in the interval tree
   public void intervalTraversal()
   {
      RBCalculate();
   }

   // intersect an interval with the interval tree node, return a vector
   // of intersecting object
   public Vector intersect(Interval interval)
   {
      Vector objectsFound = new Vector();
      intersectWalk(getRoot(), interval, objectsFound);
      return objectsFound;
   }

   // intersect a point with the interval tree node, return a vector
   // of intersecting objects
   public Vector intersectPoint(Interval interval)
   {
      Vector objectsFound = new Vector();

      intersectPointWalk(getRoot(), interval, objectsFound);
      return objectsFound;
   }

   // return a vector of all objects in front of the interval tree node
   public Vector inFront(Interval interval)
   {
      Vector objectsFound = new Vector();
      inFrontWalk(getRoot(), interval, objectsFound);
      return objectsFound;
   }

   // return a vector of all objects which are the closest to the interval
   // tree node
   public Vector closestInFront(Interval interval, int cameraZ)
   {
      closestValue = -2147483648;

      clearEncountered(getRoot());
      Vector objectsFound = new Vector();

      findClosest(getRoot(), interval, cameraZ);
      if (closestValue > -2147483648)
      {
         closestInFrontWalk(getRoot(), objectsFound);
      }
      return objectsFound;
   }

   // clear all encountered bits in the interval tree
   protected void clearEncountered(TreeNode node)
   {
      IntervalTreeNode intervalNode;

      if (node != null)
      {
         intervalNode = (IntervalTreeNode) node;
         intervalNode.resetEncountered();
         intervalNode.resetUseNode();
         clearEncountered(node.leftChild);
         clearEncountered(node.rightChild);
      }
   }

   // find the closest nodes to the camera and the interval
   private void findClosest(TreeNode node, Interval interval, int cameraZ)
   {
      IntervalTreeNode intervalNode;

      if (node != null)
      {
         intervalNode = (IntervalTreeNode) node;
         if (intervalNode.interval.getLowValue() <= cameraZ)
         {
            closestValue = Math.max(closestValue,
                                    intervalNode.interval.getLowValue());
            findClosest(intervalNode.leftChild, interval, cameraZ);
            findClosest(intervalNode.rightChild, interval, cameraZ);
         }
      }
   }

   // helper routine to find the closest objects
   private void closestInFrontWalk(TreeNode node, Vector objectsFound)
   {
      IntervalTreeNode intervalNode;
      boolean idFound;
      int index;
      int idToFind;

      if (node != null)
      {
         intervalNode = (IntervalTreeNode) node;
         if (intervalNode.getMax() != -2147483648)
         {
            if (intervalNode.getMax() < closestValue)
            {
               intervalNode.setEncountered();
               closestInFrontWalk(intervalNode.rightChild, objectsFound);
            }
            else
            {
               intervalNode.setEncountered();
               closestInFrontWalk(intervalNode.leftChild, objectsFound);
            }
         }
         else
         {
            if (intervalNode.interval.getLowValue() == closestValue)
            {
               if (intervalNode.interval.getId() != -1)
               {
                  intervalNode.setEncountered();
                  intervalNode.setUseNode();
                  idFound = idSearch(intervalNode.interval.getId(), objectsFound);
                  if (idFound == false)
                  {
                     objectsFound.addElement(new Integer(intervalNode.interval.getId()));
                  }
                  for (index = 0; index < intervalNode.interval.otherIds.size();
                       index++)
                  {
                      idToFind = ((Integer) intervalNode.interval.otherIds.elementAt(index)).intValue();
                      idFound = idSearch(idToFind, objectsFound);
                      if (idFound == false)
                      {
                         objectsFound.addElement(new Integer(idToFind));
                      }
                  }
               }
            }
         }
      }
   }

   // find all objects that are in front of the specified interval
   private void inFrontWalk(TreeNode node, Interval interval, Vector objectsFound)
   {
      IntervalTreeNode intervalNode;
      boolean idFound;
      int index;
      int idToFind;

      if (node != null)
      {
         intervalNode = (IntervalTreeNode) node;
         if (intervalNode.interval.getLowValue() <= interval.getLowValue())
         {
            intervalNode.setEncountered();
            intervalNode.setUseNode();
            if (intervalNode.interval.getId() != -1)
            {
               idFound = idSearch(intervalNode.interval.getId(), objectsFound);
               if (idFound == false)
               {
                  objectsFound.addElement(new Integer(intervalNode.interval.getId()));
               }
               for (index = 0; index < intervalNode.interval.otherIds.size();
                    index++)
               {
                  idToFind = ((Integer) intervalNode.interval.otherIds.elementAt(index)).intValue();
                  idFound = idSearch(idToFind, objectsFound);
                  if (idFound == false)
                  {
                     objectsFound.addElement(new Integer(idToFind));
                  }
               }
            }
         }
         inFrontWalk(intervalNode.leftChild, interval, objectsFound);
         inFrontWalk(intervalNode.rightChild, interval, objectsFound);
      }
   }

   // walk tree setting flag to indicate nodes encountered in checking
   // against point
   public void intersectPointWalk(TreeNode node, Interval interval,
                                  Vector objectsFound)
   {
      IntervalTreeNode intervalNode;
      boolean idFound;
      int index;
      int idToFind;

      if (node != null)
      {
         intervalNode = (IntervalTreeNode) node;
         if (overlap(intervalNode.interval, interval))
         {
            intervalNode.setEncountered();
            if (intervalNode.getMax() != -2147483648)
            {
               if ((intervalNode.interval.getLowValue() >= interval.getLowValue()) &&
                   (intervalNode.interval.getHighValue() <= interval.getHighValue()))
               {
                  saveObjects(intervalNode.interval, objectsFound);
                  intervalNode.setUseNode();
               }
               else
               {
                  if ((interval.getLowValue() <= intervalNode.getMax()) &&
                      (interval.getLowValue() >= intervalNode.interval.getLowValue()))
                  {
                     intersectPointWalk(intervalNode.leftChild, interval,
                                        objectsFound);
                  }
                  if ((interval.getHighValue() >= intervalNode.getMax()) &&
                      (interval.getHighValue() <= intervalNode.interval.getHighValue()))
                  {
                     intersectPointWalk(intervalNode.rightChild, interval,
                                        objectsFound);
                  }
               }
            }
            else
            {
               saveObjects(intervalNode.interval, objectsFound);
               intervalNode.setUseNode();
            }
         }
      }
   }

   // walk tree for an interval, setting bits for encountered nodes
   public void intersectWalk(TreeNode node, Interval interval, Vector objectsFound)
   {
      IntervalTreeNode intervalNode;

      if (node != null)
      {
         intervalNode = (IntervalTreeNode) node;
/*
         System.out.println("camera low " + interval.getLowValue());
         System.out.println("camera high " + interval.getHighValue());
*/
         if (overlap(intervalNode.interval, interval))
         {
            intervalNode.setEncountered();
            if (intervalNode.getMax() != -2147483648)
            {
               if ((intervalNode.interval.getLowValue() >= interval.getLowValue()) &&
                   (intervalNode.interval.getHighValue() <= interval.getHighValue()))
               {
                  saveObjects(intervalNode.interval, objectsFound);
                  intervalNode.setUseNode();
               }
               else
               {
                  if (interval.getLowValue() <= intervalNode.getMax())
                  {
                     intersectWalk(intervalNode.leftChild, interval, objectsFound);
                  }
                  if (interval.getHighValue() >= intervalNode.getMax())
                  {
                     intersectWalk(intervalNode.rightChild, interval, objectsFound);
                  }
               }
            }
            else
            {
               saveObjects(intervalNode.interval, objectsFound);
               intervalNode.setUseNode();
            }
         }
      }
   }

   // return vector of objects found, only one occurrence per object
   private void saveObjects(Interval interval, Vector objectsFound)
   {
      boolean idFound;
      int index;
      int idToFind;

      idFound = idSearch(interval.getId(), objectsFound);
      if (idFound == false)
      {
         objectsFound.addElement(new Integer(interval.getId()));
      }
      for (index = 0; index < interval.otherIds.size(); index++)
      {
          idToFind = ((Integer) interval.otherIds.elementAt(index)).intValue();
          idFound = idSearch(idToFind, objectsFound);
          if (idFound == false)
          {
             objectsFound.addElement(new Integer(idToFind));
          }
      }
   }

   // determine if the tree interval overlaps a given interval
   public boolean overlap(Interval treeInterval, Interval interval)
   {
      if (((interval.getLowValue() >= treeInterval.getLowValue()) &&
          (interval.getLowValue() <= treeInterval.getHighValue())) ||
          ((interval.getLowValue() <= treeInterval.getLowValue()) &&
          (interval.getHighValue() >= treeInterval.getLowValue())) ||
          ((interval.getLowValue() >= treeInterval.getLowValue()) &&
          (interval.getHighValue() >= treeInterval.getHighValue())) ||
          ((interval.getLowValue() <= treeInterval.getLowValue()) &&
          (interval.getHighValue() >= treeInterval.getHighValue())))
      {
         return true;
      }
      else
      {
/*
         System.out.println("camera low " + interval.getLowValue());
         System.out.println("camera high " + interval.getHighValue());
         System.out.println("object low " + treeInterval.getLowValue());
         System.out.println("object high " + treeInterval.getHighValue());
*/
         return false;
      }
   }

   // draw the interval tree
   public void intervalDrawTraversal(Graphics g)
   {
      RBInOrderDrawTraversal(g);
      Color savedColor = g.getColor();
      reinitializeValues();
      intervalDrawWalk(getRoot(), g);
      intervalKey(g);
      g.setColor(savedColor);
   }

   // create and display a legend for the show analysis mode on the
   // popup window
   public void intervalKey(Graphics g)
   {
      Font f = g.getFont();
      FontMetrics fm = g.getFontMetrics(f);
      restoreKeyValues();
      keyYPosition = keyYPosition + 100;
      int initialY = keyYPosition - 10;
      keyXPosition = keyXPosition + 20;
      g.setColor(Color.black);
      g.drawOval(keyXPosition, keyYPosition, 20, 20);
      g.drawString("= Black node of Red-Black Tree",
                   keyXPosition + 125,
                   keyYPosition + 10 + fm.getAscent() / 2);
      g.setColor(Color.red);
      keyYPosition += 30;
      g.drawOval(keyXPosition, keyYPosition, 20, 20);
      g.setColor(Color.black);
      g.drawString("= Red node of Red-Black Tree",
                   keyXPosition + 125,
                   keyYPosition + 10 + fm.getAscent() / 2);
      keyYPosition += 30;
      g.drawString("number",
                   keyXPosition,
                   keyYPosition + 10 + fm.getAscent() / 2);
      g.drawString("= node number",
                   keyXPosition + 125,
                   keyYPosition + 10 + fm.getAscent() / 2);
      keyYPosition += 30;
      g.setColor(Color.red);
      g.drawString("number<,number...>",
                   keyXPosition,
                   keyYPosition + 10 + fm.getAscent() / 2);
      g.setColor(Color.black);
      g.drawString("= object or objects",
                   keyXPosition + 125,
                   keyYPosition + 10 + fm.getAscent() / 2);
      keyYPosition += 30;
      g.setColor(Color.blue);
      g.drawString("[number, number]",
                   keyXPosition,
                   keyYPosition + 10 + fm.getAscent() / 2);
      g.setColor(Color.black);
      g.drawString("= interval",
                   keyXPosition + 125,
                   keyYPosition + 10 + fm.getAscent() / 2);
      keyYPosition += 30;
      g.setColor(new Color(128, 0, 128));
      g.drawString("number",
                   keyXPosition,
                   keyYPosition + 10 + fm.getAscent() / 2);
      String longString = new String("= maximum value of left child");
      g.setColor(Color.black);
      g.drawString(longString,
                   keyXPosition + 125,
                   keyYPosition + 10 + fm.getAscent() / 2);
      g.drawRect(0, initialY, 2 * keyXPosition + 125 + fm.stringWidth(longString),
                 keyYPosition - initialY + 30);
      g.drawString("Key", (2 * keyXPosition + 125 + fm.stringWidth(longString)) / 2 -
                   fm.stringWidth("Key"), initialY - fm.getAscent() / 2);
   }

   // draw the interval tree showing the walked path
   public void intersectDrawTraversal(Graphics g)
   {
      intervalDrawTraversal(g);
      Color savedColor = g.getColor();
      g.setColor(Color.red);
      reinitializeValues();
      intersectDrawWalk(getRoot(), g);
      intersectKey(g);
      g.setColor(savedColor);
   }

   //display the legend for the show analysis mode on the popup window
   public void intersectKey(Graphics g)
   {
      Font f = g.getFont();
      FontMetrics fm = g.getFontMetrics(f);
      restoreKeyValues();
      keyYPosition = keyYPosition + 100;
      int initialY = keyYPosition - 10;
      keyXPosition = keyXPosition + 20;
      g.setColor(Color.black);
      g.drawOval(keyXPosition, keyYPosition, 20, 20);
      g.drawString("= Black node of Red-Black Tree",
                   keyXPosition + 125,
                   keyYPosition + 10 + fm.getAscent() / 2);
      g.setColor(Color.red);
      keyYPosition += 30;
      g.drawOval(keyXPosition, keyYPosition, 20, 20);
      g.setColor(Color.black);
      g.drawString("= Red node of Red-Black Tree",
                   keyXPosition + 125,
                   keyYPosition + 10 + fm.getAscent() / 2);
      keyYPosition += 30;
      g.drawString("number",
                   keyXPosition,
                   keyYPosition + 10 + fm.getAscent() / 2);
      g.drawString("= node number",
                   keyXPosition + 125,
                   keyYPosition + 10 + fm.getAscent() / 2);
      keyYPosition += 30;
      g.setColor(Color.red);
      g.drawString("number<,number...>",
                   keyXPosition,
                   keyYPosition + 10 + fm.getAscent() / 2);
      g.setColor(Color.black);
      g.drawString("= object or objects",
                   keyXPosition + 125,
                   keyYPosition + 10 + fm.getAscent() / 2);
      keyYPosition += 30;
      g.setColor(Color.blue);
      g.drawString("[number, number]",
                   keyXPosition,
                   keyYPosition + 10 + fm.getAscent() / 2);
      g.setColor(Color.black);
      g.drawString("= interval",
                   keyXPosition + 125,
                   keyYPosition + 10 + fm.getAscent() / 2);
      keyYPosition += 30;
      g.setColor(new Color(128, 0, 128));
      g.drawString("number",
                   keyXPosition,
                   keyYPosition + 10 + fm.getAscent() / 2);
      String longString = new String("= maximum value of left child");
      g.setColor(Color.black);
      g.drawString(longString,
                   keyXPosition + 125,
                   keyYPosition + 10 + fm.getAscent() / 2);
/*
      clear the rectangle created by intervalKey

*/
      g.setColor(new Color(200, 200, 200));
      g.drawRect(0, initialY, 2 * keyXPosition + 125 + fm.stringWidth(longString),
                 keyYPosition - initialY + 30);
      keyYPosition += 30;
      g.setColor(Color.red);
      g.fillRect(keyXPosition,
                 keyYPosition + 10 + fm.getAscent() / 2,
                 20, 1);
      g.setColor(Color.black);
      g.drawString("= path traversed",
                   keyXPosition + 125,
                   keyYPosition + 10 + fm.getAscent() / 2);
      keyYPosition += 30;
      g.setColor(Color.red);
      g.drawRect(keyXPosition, keyYPosition, 20, 20);
      g.setColor(Color.black);
      g.drawString("= node selected",
                   keyXPosition + 125,
                   keyYPosition + 10 + fm.getAscent() / 2);
      g.drawRect(0, initialY, 2 * keyXPosition + 125 + fm.stringWidth(longString),
                 keyYPosition - initialY + 30);
      g.drawString("Key", (2 * keyXPosition + 125 + fm.stringWidth(longString)) / 2 -
                   fm.stringWidth("Key"), initialY - fm.getAscent() / 2);
   }

   // draw the encountered nodes
   public void intersectDrawWalk(TreeNode node, Graphics g)
   {
      IntervalTreeNode intervalNode;

      if (node != null)
      {
         intersectDrawWalk(node.leftChild, g);
         keyXPosition = Math.min(keyXPosition, node.xPosition);
         keyYPosition = Math.max(keyYPosition, node.yPosition);
         setKeyValues();
         intervalNode = (IntervalTreeNode) node;
         if (intervalNode.getEncountered())
         {
            drawLineBetweenNodes(node, g);
            if (intervalNode.getUseNode())
            {
               drawBoxAroundNode(node, g);
            }
         }
         intersectDrawWalk(node.rightChild, g);
      }
   }

   // draw the interval tree and output object and interval lists
   public void intervalDrawWalk(TreeNode node, Graphics g)
   {
      Vector hitList;

      if (node != null)
      {
         intervalDrawWalk(node.leftChild, g);
         StringBuffer boundsString = new StringBuffer("[");
         StringBuffer IdString = new StringBuffer();
         RBTreeNode rbNode = (RBTreeNode) node;
         keyXPosition = Math.min(keyXPosition, node.xPosition);
         keyYPosition = Math.max(keyYPosition, node.yPosition);
         setKeyValues();
         IntervalTreeNode intervalNode = (IntervalTreeNode) rbNode;
         boundsString.append(intervalNode.getLow());
         boundsString.append(", ");
         boundsString.append(intervalNode.getHigh());
         boundsString.append("]");
         if (intervalNode.interval.getId() != -1)
         {
            hitList = intervalNode.interval.otherIds;
            IdString.append(intervalNode.interval.getId());
            if (hitList.isEmpty() == false)
            {
               for (int index = 0; index < hitList.size(); index ++)
               {
                  IdString.append(", ");
                  IdString.append(((Integer) hitList.elementAt(index)).intValue());
               }
            }
         }
         String finalString = boundsString.toString();
         String finalIdString = IdString.toString();
         Font f = g.getFont();
         FontMetrics fm = g.getFontMetrics(f);
         g.setColor(Color.blue);
         g.drawString(finalString,
                      node.xPosition  - fm.stringWidth(finalString) / 2,
                      node.yPosition + 3 * (fm.getAscent() / 2));
         if (intervalNode.interval.getId() != -1)
         {
            g.setColor(Color.red);
            g.drawString(finalIdString,
                         node.xPosition  - fm.stringWidth(finalIdString) / 2,
                         node.yPosition - 1 * (fm.getAscent() / 2));
         }
         if (intervalNode.getMax() != -2147483648)
         {
            g.setColor(new Color(128, 0, 128));
            String maxString = new String((new Integer(intervalNode.getMax())).
                                          toString());
            g.drawString(maxString,
                         node.xPosition  - fm.stringWidth(maxString) / 2,
                         node.yPosition + 5 * (fm.getAscent() / 2));
         }
         intervalDrawWalk(node.rightChild, g);
      }
   }
}

