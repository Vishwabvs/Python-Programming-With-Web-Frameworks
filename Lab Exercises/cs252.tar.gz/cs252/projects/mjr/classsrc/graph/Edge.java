package graph;

import java.awt.*;
import sprite.*;

public class Edge extends Sprite {
    protected GraphArea graph_;
    protected Color color_;
    protected Node a_, b_;
    
    int dragX_, dragY_;
    boolean directed_;

    public Edge(GraphArea area, Node a, Node b, Color color) {
	super(area, -1, -1);
	graph_ = area;
	directed_ = graph_.directed_;
	color_ = color;
	a_ = a;
	b_ = b;	
	a_.AddEdge(this);
	b_.AddEdge(this);
	area.AddEdge(this);
	Add();
	ZToBottom();
    }

    public Edge(GraphArea area, Node a, Node b) {
	this(area, a, b, area.newEdgeColor_);
    }

    Edge(GraphArea area, Node node) {
	super(area, -1, -1);
	graph_ = area;
	directed_ = graph_.directed_;
	color_ = area.newEdgeColor_;	
	a_ = node;
	dragX_ = a_.x_;
	dragY_ = a_.y_;
	Add();
    }

	     

    public void SetColor(Color color) {
        color_ = color;
        Redraw();
    }

    public Node GetOther(Node node) {
	if (node == a_)
	    return b_;
	else if (node == b_)
	    return a_;
	else
	    return null;
    }

    public Node GetA() {
	return a_;
    }

    public Node GetB() {
	return b_;
    }

    public double GetSlope() {
	return (((double)b_.y_ - (double)a_.y_) /
		((double)b_.x_ - (double)a_.x_));
    }

    public Point GetIntersection(Edge other) {
	int x1, y1, x2, y2, x3, y3, x4, y4;
	int a1, a2, b1, b2, c1, c2;
	int r1, r2;
	int denom, offset, num;

	x1 = a_.x_; y1 = a_.y_; x2 = b_.x_; y2 = b_.y_;
	x3 = other.a_.x_; y3 = other.a_.y_;
	x4 = other.b_.x_; y4 = other.b_.y_;
	
	a1 = y2 - y1;
	b1 = x1 - x2;
	c1 = x2 * y1 - x1 * y2;

	r1 = a1 * x3 + b1 * y3 + c1;
	r2 = a1 * x4 + b1 * y4 + c1;	
	if (r1 != 0 && r2 != 0 && r1 * r2 >= 0)
	    return null;

	a2 = y4 - y3;
	b2 = x3 - x4;
	c2 = x4 * y3 - x3 * y4;
	
	r1 = a2 * x1 + b2 * y1 + c2;
	r2 = a2 * x2 + b2 * y2 + c2;	
	if (r1 != 0 && r2 != 0 && r1 * r2 >= 0)
	    return null;

	denom = a1 * b2 - a2 * b1;
	if (denom == 0)
	    return null;
	offset = denom < 0 ? - denom / 2 : denom / 2;

	Point result = new Point(0,0);
	num = b1 * c2 - b2 * c1;
	result.x = (num < 0 ? num - offset : num + offset) / denom;
	num = a2 * c1 - a1 * c2;	
	result.y = (num < 0 ? num - offset : num + offset) / denom;
	return result;
    }

    public Node SharedNode(Edge other) {
	if (a_ == other.a_ || a_ == other.b_)
	    return a_;
	if (b_ == other.a_ || b_ == other.b_)
	    return b_;
	return null;
    }
    
    void Drag(int x, int y) {
	dragX_ = x;
	dragY_ = y;
	Redraw();
    }

    boolean FinishDrag(int x, int y) {
	Sprite s = area_.LocateMouse(x, y);
	boolean valid = false;
	if (s != null && (s instanceof Node)) {
	    Node f = (Node)s;
	    if (a_ != f && !(a_.ConnectsTo(f) || f.ConnectsTo(a_))) {
		b_ = f;
		a_.AddEdge(this);
		b_.AddEdge(this);
		graph_.AddEdge(this);
		ZToBottom();
		valid = true;
	    }
	}
	if (!valid)
	    Remove();
	return valid;
    }

    public void Remove() {
	if (a_ != null)
	    a_.RemoveEdge(this);
	if (b_ != null)
	    b_.RemoveEdge(this);
	graph_.RemoveEdge(this);
	super.Remove();
    }
    
    public void Remove(Node isRemoving) {
	if (a_ != isRemoving)
	    a_.RemoveEdge(this);
	else
	    b_.RemoveEdge(this);
	graph_.RemoveEdge(this);
	super.Remove();
    }

    public boolean Inside(int x, int y) {
	if (a_ == null || b_ == null)
	    return false;

	int minX, minY, maxX, maxY;
	if (a_.x_ < b_.x_) {
	    minX = a_.x_; maxX = b_.x_;
	}
	else {
	    minX = b_.x_; maxX = a_.x_;
	}

	if (a_.y_ < b_.y_) {
	    minY = a_.y_; maxY = b_.y_;
	}
	else {
	    minY = b_.y_; maxY = a_.y_;
	}
	
	boolean inside = (minX - MARGIN) < x && x < maxX + MARGIN;
	if (!inside) return false;
	inside = (minY - MARGIN) < y && y < maxY + MARGIN;	
	if (!inside) return false;	

	if (a_.x_ == b_.x_ || a_.y_ == b_.y_)
	    return true;

	int dX = b_.x_ - a_.x_;
	int dY = b_.y_ - a_.y_;
	int a2 = (y - a_.y_) * dX - (x - a_.x_) * dY;
	double d = (double)(a2 * a2) / (double)(dX * dX + dY * dY);
	    
	return ((d > 0) ? d : -d) < FUDGE;
    }

    public void Draw(Graphics g) {
        g.setColor(color_);
	if (b_ == null)
	    g.drawLine(a_.x_, a_.y_, dragX_, dragY_);
	else {
	    if (directed_ && b_.IsVisible()) {
		int bX, bY;
		double dX = b_.x_ - a_.x_;
		double dY = b_.y_ - a_.y_;
		if (b_.square_) {
		    int rX, rY;
		    if (dX * dX > dY * dY) {
			rX = Node.RADIUS;
			rY = (int)Math.round(dY / dX * (double)Node.RADIUS);
			if (dX > 0) {
			    rX *= -1;
			    rY *= -1;
			}
		    }
		    else {
			rX = (int)Math.round(dX / dY * (double)Node.RADIUS);
			rY = Node.RADIUS;
			if (dY > 0) {
			    rX *= -1;
			    rY *= -1;
			}
		    }
		    bX = b_.x_ + rX; bY = b_.y_ + rY;
		}
		else {
		    double len = Math.sqrt(dX * dX + dY * dY);
		    bX = (int)Math.round((double)b_.x_ -
					 ((double)Node.RADIUS / len) * dX);
		    bY = (int)Math.round((double)b_.y_ -
					 ((double)Node.RADIUS / len) * dY);
		}
		g.drawLine(a_.x_, a_.y_, bX, bY);
		ArrowHead.FillHead(g, a_.x_, a_.y_, bX, bY);
	    }
	    else
		g.drawLine(a_.x_, a_.y_, b_.x_, b_.y_);
	}
    }

    public void handleEvent(Event e) {
	if (graph_.CanEdit()) {
	    switch (e.id) {
	    case Event.KEY_PRESS:
		if (e.key == 8 || e.key == 127)
		    Remove();
		break;
	    }
	}
    }

    public String toString() {
	return "Edge " + a_.numString_ + "->" + b_.numString_;
    }
    
    private final static double FUDGE = 8;
    private final static int MARGIN = 3;
}
