//package Methods;
//sort integers

import java.awt.*;
import java.io.*;

public class MyMethod{
  static int[] A;
  static int size;

  static public void sort(int[] a, int b){
    A=a;
    size=b;
    quick_sort(0,b-1);
  }

  static public void quick_sort(int p,int r){
    if(p<r){
      out("bcda");
      int q=partition(p,r);
      quick_sort(p,q);
      quick_sort(q+1,r);
    }
  }

  static public int partition(int p, int r){
    int x=A[p];
    int i=p-1;
    int j=r+1;
    int temp;
    while(true){
      j-=1;
      while(true){
        if(A[j]<=x)
          break;
        j-=1;
      }

      i+=1;
      while(true){
        if(A[i]>=x)
          break;
        i+=1;
      } 

      if(i<j){
        temp=A[i];
        A[i]=A[j];
        A[j]=temp;
      }
      else
        return j;
    }//end of out most while
  }

  static void out(String a){
  }
}
