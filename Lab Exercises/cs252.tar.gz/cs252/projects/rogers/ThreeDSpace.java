/** Brian Rogers
    cs252
    spring 1996
    Final Project */

import java.awt.*;


/**                          ThreeDSpace
    This class represents a model of three dimensional space.  It keeps
    track of the vertices in space sorted in two arrays.  One array is 
    sorted by the vertice's z-coordinates, and is used for drawing the 
    vertices in the correct order.  The other array is sorted by their
    x-coordiantes, and is used for the sweep plane algorithm that sweeps from
    left to right.  ThreeDSpace also keeps track of the current zoom 
    position the user is at, the canvas to draw on, and the currently running
    algorithm, if there is one. */
    
public class ThreeDSpace {
     public static final int MAX_VERTS = 100;
     public static final int CANVAS_DIMENSION = ThreeDCanvas.CANVAS_DIMENSION;

     public static final int MAX_ZOOM = CANVAS_DIMENSION/2;
     public static final int ZOOM_FACTOR = 10;

     ThreeDVertex z_verts[];     // Sorted by z-coordinate for drawing
     ThreeDVertex x_verts[];    // Sorted by x-coordinate for sweeping
     int num_verts = 0;

     int current_z = 0;      // The user's current zoom perspective
     ThreeDCanvas _canvas;
 
     ThreeDSweepAlgorithm _algorithm;

     public ThreeDSpace () {  
	  z_verts = new ThreeDVertex[MAX_VERTS];
	  x_verts = new ThreeDVertex[MAX_VERTS];
	  for (int i = 0; i < MAX_VERTS; i++) {
	       z_verts[i] = null;
	       x_verts[i] = null;
	  }     
     }
     public void setCanvas (ThreeDCanvas canvas) {_canvas = canvas;}


     /** Sort the vertices in x_verts by their x-coordinates */
     public void xSortVertices () {
          if (num_verts >= 2)
	       for (int i = 1; i < num_verts; i++) xSortVertex(i);
     }
     private void xSortVertex (int i) {
          if (i > 0 && x_verts[i].xLessThan(x_verts[i-1])) {
	       ThreeDVertex temp = x_verts[i];
	       x_verts[i] = x_verts[i-1];
	       x_verts[i-1] = temp;
	       xSortVertex(i-1);
	  }
     }

     /** Sort the vertices in z_verts by their z-coordiantes */
     public void zSortVertices () {
          if (num_verts >= 2)
	       for (int i = 1; i < num_verts; i++) zSortVertex(i);
     }
     private void zSortVertex (int i) {
          if (i > 0 && z_verts[i].zLessThan(z_verts[i-1])) {
	       ThreeDVertex temp = z_verts[i];
	       z_verts[i] = z_verts[i-1];
	       z_verts[i-1] = temp;
	       zSortVertex(i-1);
	  }
     }



     /** calculate a modifier to determine how to draw things that are dist
         from the current user's zoom perspective. */
     public float calcModifier (int dist) {
          float dimension = (float)(CANVAS_DIMENSION);
	  float distance = (float)(dist);

	  return 1 - (1/(2*dimension))*distance;
     }



     /** Zoom the user's perspective in one step.  The amount of step in one
         zoom is equivalent to ZOOM_FACTOR pixels of movement on the x or y
	 axes. */
     public void zoomIn () {
          boolean zchanged = true;

	  if (current_z == -MAX_ZOOM) zchanged = false;
	  else if (current_z - ZOOM_FACTOR >= -MAX_ZOOM)
	       current_z -= ZOOM_FACTOR;
	  else current_z = -MAX_ZOOM;

	  if (zchanged) {
	       _canvas.paint(_canvas.getGraphics());
	  }     
     }

     /** Zoom the user's perspective out one step. */
     public void zoomOut () {
          boolean zchanged = true;

	  if (current_z == MAX_ZOOM) zchanged = false;
	  else if (current_z + ZOOM_FACTOR <= MAX_ZOOM)
	       current_z += ZOOM_FACTOR;
	  else current_z = MAX_ZOOM;

	  if (zchanged) {
	       _canvas.paint(_canvas.getGraphics());
	  }     
     }

     /** Zoom the user's perspective all the way out so he can see the entire
         contents of space while an algorithm runs. */
     public void zoomAllTheWayOut () {
     current_z = MAX_ZOOM;
	  _canvas.paint(_canvas.getGraphics());
     }



     /** Add a vertex to space if there is room for one.  We have to re-sort
         the vertices in the z_verts array everytime one is added so that
	 they will draw correctly.  We sort them in x_verts while we are at it
	 because we have spare time because the user can only click the mouse
	 so fast to enter vertices, so we take advantage of this time instead 
	 of taking the time before an algorithm runs to do it. */
     public void addVert (int xcoord, int ycoord) {
          if (num_verts < MAX_VERTS) {
	       z_verts[num_verts] = 
	                     new ThreeDVertex(xcoord, ycoord, current_z);
	       x_verts[num_verts] = z_verts[num_verts];

	       Graphics grafix = _canvas.getGraphics();
	       grafix.setColor(Color.red);
	       z_verts[num_verts].draw(grafix);
	       num_verts++;
	       zSortVertices();
	       xSortVertices();
	  }
     }



     /** This draws the contents of space by drawing all of the vertices 
         in the order they are sorted in the z_verts array, so that the
	 ones farther away from the user will be drawn before those closer,
	 so the will look properly overlapping. */
     public void drawSpace (Graphics grafix) {
          for (int i = 0; i < num_verts; i++) {
	       int vertz = (z_verts[i].position()).zCoord();
	       float modifier = calcModifier(current_z-vertz);
	       z_verts[i].draw(grafix, current_z, modifier);
	  }
     }


     /** This just draws the fancy shmancy frame defining the cube of space 
         that we are dealing with. */
     public void drawFrame (Graphics grafix) {
          /* Mostly ugly math stuff */
	  float modifier = calcModifier(current_z + CANVAS_DIMENSION/2);

	  int NWx = 0;
	  int NWy = 0;
	  int modNWx = (int)((CANVAS_DIMENSION/2) * (1-modifier));
	  int modNWy = modNWx;

	  int SWx = 0;
	  int SWy = CANVAS_DIMENSION;
	  int modSWx = modNWx;
	  int modSWy = CANVAS_DIMENSION - modSWx;

	  int NEx = CANVAS_DIMENSION;
	  int NEy = 0;
	  int modNEx = CANVAS_DIMENSION - modNWx;
	  int modNEy = modNWy;

	  int SEx = CANVAS_DIMENSION;
	  int SEy = CANVAS_DIMENSION;
	  int modSEx = modNEx;
	  int modSEy = modSWy;

          grafix.setColor(Color.gray);
	  grafix.drawLine(NWx, NWy, modNWx, modNWy);
	  grafix.drawLine(SWx, SWy, modSWx, modSWy);
	  grafix.drawLine(NEx, NEy, modNEx, modNEy);
	  grafix.drawLine(SEx, SEy, modSEx, modSEy);

	  int width = CANVAS_DIMENSION - 2*modNWx;
	  int height = CANVAS_DIMENSION - 2*modNWy;

          grafix.setColor(Color.darkGray);
	  grafix.drawRect(modNWx, modNWy, width, height);

          grafix.setColor(Color.lightGray);
	  int canvasw = _canvas.size().width;
	  int canvash = _canvas.size().height;
	  grafix.drawRect(0, 0, canvasw-1, canvash-1);
     }



     /** This clears space by dumping all of the vertices, and clearing the
         canvas. */
     public void clearSpace () {
          num_verts = 0;
	  for (int i = 0; i < MAX_VERTS; i++) {
	       x_verts[i] = null;
	       z_verts[i] = null;
	  }
	  Graphics grafix = _canvas.getGraphics();
	  _canvas.clearCanvas(grafix);
	  drawFrame(grafix);
     }


     /** This resets space by resetting all of the vertice's colors to the 
         default light gray, and getting rid of all there edges.  Handy when
	 you have run an algorithm, and you want to run another. */
     public void resetSpace () {
         for (int i = 0; i < num_verts; i++) {
	      z_verts[i].setColor(Color.lightGray);
	      z_verts[i].dumpEdges();
	 }
	 _canvas.paint(_canvas.getGraphics());
     }



     /** This starts a closest vertex algorithm running */
     public void startNearestNeighbors (ThreeD applet) {
          zoomAllTheWayOut();
          _algorithm = new ThreeDNearestNeighborsAlgorithm(this, _canvas, 
	                                       applet, x_verts, num_verts);
	  _algorithm.start();
     }
     /** This stars a closest pair algorithm running */
     public void startClosestPair (ThreeD applet) {
          zoomAllTheWayOut();
	  _algorithm = new ThreeDClosestPairAlgorithm(this, _canvas, applet,
	                                               x_verts, num_verts);
	  _algorithm.start();
     }
     /** This sets the calc time in the running algorithm */
     public void setPauseTime(int time) {
          if (_algorithm != null) 
               _algorithm.setCalcStep(time);
     }
     /** This aborts the currently running algortihm */
     public void abortAlgorithm () {
          if (_algorithm != null) {
               _algorithm.stop();
	       _algorithm = null;
	       _canvas.paint(_canvas.getGraphics());
	  }
     }
}
