package cs252;

import java.awt.*;
import java.util.Vector;
import sprite.*;
import graph.*;

public class UpwardEnforcer extends Enforcer {
    Vector downward_;

    public UpwardEnforcer(DominanceGraph area, int id) {
	super (area, id);
    }

    public void Enforce(Vector nodes, Vector edges, OrderNode lowest) {
	downward_ = new Vector();
	for (int loop = 0; loop < edges.size(); ++loop) {
	    Edge current = (Edge)edges.elementAt(loop);
	    if (current.GetA().y_ < current.GetB().y_)
		downward_.addElement(current);
	}

	if (downward_.size() > 0) {
	    for (int loop = 0; loop < downward_.size(); ++loop) {
		Edge current = (Edge)(downward_.elementAt(loop));
		current.SetColor(Color.red);
	    }
	    area_.RemoveDelay();	    
	    for (int loop = 0; loop < downward_.size(); ++loop) {
		Edge current = (Edge)(downward_.elementAt(loop));
		current.Remove();
	    }
	    area_.RemoveDelay();	    	    
	}
    }
    
    public boolean DidAnything() {
	return downward_.size() > 0;
    }
    
    public void Restore() { ; }
    
    public void Undo() {
 	for (int loop = 0; loop < downward_.size(); ++loop) {
	    Edge current = (Edge)(downward_.elementAt(loop));
	    new Edge(area_, current.GetA(), current.GetB());
 	    area_.AddDelay();
 	}
    }
}
