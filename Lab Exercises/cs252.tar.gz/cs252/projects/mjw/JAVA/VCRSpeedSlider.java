import Slider;
import VCRPanel;
import AnimatorGeometryClient;
import AnimatorSlider;

public class VCRSpeedSlider extends AnimatorSlider {
protected VCRPanel vcr_panel_;

	public VCRSpeedSlider(AnimatorGeometryClient client)
	{
		super(client);
		vcr_panel_ = client.getVcrPanel();
	}


	public VCRSpeedSlider(	AnimatorGeometryClient client,
				int width,
				int height,
				int min,
				int max,
				int value)
	{
		super(client);
		vcr_panel_ = client.getVcrPanel() ;
		SetWidth(width);
		SetHeight(height);
		SetMinimum(min);
		SetMaximum(max);
	}

	
	public void Motion()
	{
		if (vcr_panel_ != null)
			vcr_panel_.setDelay(GetValue());
	}

	public void SetValue(int num)
	{
		super.SetValue(num);
		if (vcr_panel_ != null)
			vcr_panel_.setDelay(num);
	}
};




