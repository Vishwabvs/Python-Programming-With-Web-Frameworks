/*
 * ImageApplet.java
 *
 * Description:
 *    This class is the ImageApplet class and has all methods and variables
 *    for displaying an image with the input image name as an applet
 */
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Color;
import java.awt.Event;
import java.awt.MediaTracker;
import java.awt.Dimension;

public class ImageApplet extends java.applet.Applet implements Runnable
{
/*
   MediaTracker tracker = null;
*/
   Image offScreenImage = null;        // offscreen image buffer
   Image picture;                      // image from specified file
   Graphics offScreenGraphics = null;  // offscreen graphics context
   Thread running;                     // thread of running applet
   String imageName;                   // name of image to display
   int pauseValue = 100;               // sleep time

   // initialization routine for applet, gets name of image to be
   // displayed
   public void init()
   {
/*
      tracker = new MediaTracker(this);
*/
      imageName = getParameter("imageName");
      offScreenImage = createImage(size().width, size().height);
      offScreenGraphics = offScreenImage.getGraphics();
   }

   // start running the applet
   public void start()
   {
      if (running == null)
      {
         running = new Thread(this);
         getFrame();
         running.start();
      }
   }

   // get the image and display it
   private boolean getFrame()
   {
      try
      {
         picture = getImage(getCodeBase(), imageName);
/*
         picture = getImage(getDocumentBase(), imageName);
*/
      } catch(Exception e1)
      {
         System.out.println(e1);
      }
/*
      tracker.addImage(picture, 0);
      try
      {
        tracker.checkID(0, true);
        tracker.waitForID(0);
      } catch(Exception e2)
      {
         System.out.println(e2);
      }
*/
      repaint();
      return true;
   }

   // stop running the applet
   public void stop()
   {
      if (running != null)
      {
         running.stop();
         running = null;
         if (offScreenGraphics != null)
         {
            offScreenGraphics.dispose();
         }
      }
   }

   // sleep routine
   public void pause(int time)
   {
      try
      {
         Thread.sleep(time);
      }
      catch (InterruptedException e)
      {
      }
   }

   // run the applet, wake up every once in a while to repaint the
   // screen
   public void run()
   {
      Thread thisThread = Thread.currentThread();
      thisThread.setPriority(Thread.MAX_PRIORITY);
      while (running != null)
      {
         repaint();
         pause(pauseValue);
      }
    }

   // update the screen
   public void update(Graphics g)
   {
      paint(g);
   }

   // draw the image to the offscreen buffer and then display the
   // buffer
   public void paint(Graphics g)
   {
      offScreenGraphics.drawImage(picture, 0, 0, size().width, size().height, this);
      g.drawImage(offScreenImage, 0, 0, size().width, size().height, this);
   }
}