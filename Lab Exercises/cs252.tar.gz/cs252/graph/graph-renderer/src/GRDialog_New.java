/*
 *  GRDialog_New - controls new graph calls 
 *  4/14/96 
 *  by Daniel Spirn 
 *
 */
package graphrender;

import java.awt.*;
import java.applet.*;

public class GRDialog_New extends Frame {

    static final Font txtFont = new Font("Times", Font.PLAIN, 18);
    GRSlider sc1;

    GRGraphArea ga_;
    Button edgebutton_;
    boolean edges_ = true;

    static int min = 0;
    static int max = 2000;

    public GRDialog_New(String title, GRGraphArea ga) {
	super(title);
	this.setResizable(false);
	ga_ = ga;
    }

    public void addNotify() {
	super.addNotify();
	
	GridBagLayout gridbag = new GridBagLayout();
	GridBagConstraints c = new GridBagConstraints();
	c.fill = GridBagConstraints.BOTH;
	
	setLayout(gridbag);

	sc1 = new GRSlider("Number of Nodes",0,100,1);
	edgebutton_ = new Button("Add Random Edges");	
	edgebutton_.setFont(new Font("Times", Font.PLAIN, 14));

	Panel buttonPanel = new Panel();
	buttonPanel.setFont(new Font("Times", Font.PLAIN, 14));
	buttonPanel.setLayout(new GridLayout(1,2,1,1));
	buttonPanel.add(new Button("cancel"));
	buttonPanel.add(new Button("o.k."));
	add(buttonPanel);

	c.weightx = 1.0;
	c.weighty = 2.0;
	c.gridx = GridBagConstraints.REMAINDER;
	gridbag.setConstraints(sc1,c);
	add(sc1);

	c.weightx = 1.0;
	c.weighty = 1.4;
	c.gridx = GridBagConstraints.REMAINDER;
	gridbag.setConstraints(edgebutton_,c);
	add(edgebutton_);

	c.weightx = 1.0;
	c.weighty = 1.4;
	c.gridx = GridBagConstraints.REMAINDER;
	gridbag.setConstraints(buttonPanel,c);
	add(buttonPanel);

	sc1.setValue(0);

	pack();
	positionOnScreen();
	show();
    }

    private void positionOnScreen() {
	Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
	this.move(((screen.width / 2)) + 2*this.size().height, (screen.height / 3) - (this.size().height));
    }

    /** Respond to user actions. */
    public boolean handleEvent(Event e) {
	boolean handled = false;

	if (e.target instanceof GRSlider) {
		boolean a = sc1.handleEvent(e);
		return (a);
	} else if (e.id == Event.ACTION_EVENT) {
		if (e.arg.equals("Add Random Edges")) {
			edgebutton_.setLabel("No Random Edges");
			edges_ = false;
		}
		else if(e.arg.equals("No Random Edges")) {
			edgebutton_.setLabel("Add Random Edges");
			edges_ = true;
		}
		else if (e.arg.equals("cancel")) {
			this.hide();
		}
		else if (e.arg.equals("o.k.")) {
			ga_.newRandomGraph(edges_, Integer.parseInt(sc1.textField.getText()));			
			ga_.resize();
			ga_.repaint();
			this.hide();
		}

	} else if (e.id == Event.WINDOW_DESTROY) {
		this.hide();
		this.dispose();
	}
	return(handled);
    }
}

