package graph;

import java.awt.*;
import java.util.Vector;
import sprite.*;

public class Node extends Sprite {
    public final static int RADIUS = 6;
    public final static int DIAMETER = RADIUS * 2;
    private final static int FUDGE = 2;    
    
    protected GraphArea graph_;
    protected Color color_;
    protected Vector incoming_, outgoing_, all_;
    protected int num_;
    static protected Font font_;
    static protected int tWidth_, tHeight_, tAscent_, yAdd_;
    static protected FontMetrics metrics_;
    
    boolean showNumber_;
    boolean square_;    
    String numString_;
    Edge newEdge_;
    static int counter_;
    int xAdd_;

    static {
        font_ = new Font("Dialog", Font.PLAIN, 10);
	tWidth_ = -1;
	counter_ = 0;
    }
    
    public Node(GraphArea area, int x, int y, boolean square) {
	this(area, x, y, square, counter_++);
    }

    public Node(GraphArea area, int x, int y, boolean square, int num) {
	super(area, x, y);
	square_ = square;
	if (tWidth_ == -1) {
	    metrics_ = area_.getFontMetrics(font_);
	    tWidth_ = metrics_.charWidth('A');
	    tHeight_ = metrics_.getDescent() + metrics_.getAscent();
	    yAdd_ = -tHeight_ / 2 + metrics_.getAscent();
	}
	
	graph_ = area;
	color_ = Color.blue;
	incoming_ = new Vector();
	outgoing_ = new Vector();
	all_ = new Vector();
	num_ = num;
	
	int map = num_ % 62;
	char c;
	if (map < 26)
	    c = (char)(map + 'A');
	else if (map < 52)
	    c = (char)(map - 26 + 'a');
	else
	    c = (char)(map - 52 + '0'); 
	xAdd_ = -metrics_.charWidth(c) / 2;
	
	numString_ = new Character(c).toString();
	showNumber_ = false;
	area.AddNode(this);
    }

    public void SetColor(Color color) {
        color_ = color;
        Redraw();
    }

    public void ShowNumber() {
	showNumber_ = true;
        Redraw();
    }

    public void HideNumber() {
	showNumber_ = false;
        Redraw();
    }

    public int GetNumber() {
	return num_;
    }

    public boolean IsSquare() {
	return square_;
    }

    public String GetLabel() {
	return numString_;
    }

    public Vector GetIncomingEdges() {
	return incoming_;
    }

    public Vector GetOutgoingEdges() {
	return outgoing_;
    }

    public Vector GetAllEdges() {
	return all_;
    }
    
    public Edge[] GetIncomingArray() {
	Edge[] result = new Edge[incoming_.size()];
	incoming_.copyInto(result);
	return result;
    }

    public Edge[] GetOutgoingArray() {
	Edge[] result = new Edge[outgoing_.size()];
	outgoing_.copyInto(result);
	return result;
    }

    public Edge[] GetAllArray() {
	Edge[] result = new Edge[all_.size()];
	all_.copyInto(result);
	return result;
    }

    public boolean ConnectsTo(Node other) {
	for (int loop = 0; loop < outgoing_.size(); ++loop) {
	    Edge current = (Edge)(outgoing_.elementAt(loop));
	    if (current.GetOther(this) == other)
		return true;
	}
	return false;
    }
    
    public Edge ConnectingEdge(Node other) {
	for (int loop = 0; loop < outgoing_.size(); ++loop) {
	    Edge current = (Edge)(outgoing_.elementAt(loop));	    
	    if (current.GetOther(this) == other)
		return current;
	}
	return null;
    }

    public void AddEdge(Edge e) {
	all_.addElement(e);
	if (graph_.directed_) {
	    if (e.GetA() == this)
		outgoing_.addElement(e);
	    else
		incoming_.addElement(e);
	}
	else {
	    outgoing_.addElement(e);
	    incoming_.addElement(e);
	}
    }

    public void RemoveEdge(Edge e) {
	all_.removeElement(e);
	outgoing_.removeElement(e);
	incoming_.removeElement(e);
    }

    public void Remove() {
	graph_.RemoveNode(this);
  	for (int loop = 0; loop < all_.size(); ++loop) {
	    Edge current = (Edge)(all_.elementAt(loop));
	    current.Remove(this);
	}
	super.Remove();
    }
    
    public boolean Inside(int x, int y) {
        return (Math.abs(x - x_) < (RADIUS + FUDGE) &&
		Math.abs(y - y_) < (RADIUS + FUDGE));
    }

    public void Draw(Graphics g) {
        g.setColor(color_);
	if (square_)
	    g.fillRect(x_ - RADIUS, y_ - RADIUS, DIAMETER, DIAMETER);
	else
	    g.fillOval(x_ - RADIUS, y_ - RADIUS, DIAMETER, DIAMETER);
	if (showNumber_) {
	    g.setColor(Color.white);
	    g.setFont(font_);
	    g.drawString(numString_, x_ + xAdd_, y_ + yAdd_);
	}
    }

    public void handleEvent(Event e) {
	if (graph_.CanEdit()) {
	    if ((e.modifiers & Event.SHIFT_MASK) != 0) {
		switch (e.id) {
		case Event.MOUSE_DOWN:
		case Event.MOUSE_DRAG:
		case Event.MOUSE_UP:
		    if (area_.Inside(e.x, e.y))
			MoveTo(e.x, e.y);
		    break;
		}
	    }
	    else {
		switch (e.id) {
		case Event.MOUSE_DOWN:
		    newEdge_ = new Edge(graph_, this);
		    break;
		    
		case Event.MOUSE_DRAG:
		    newEdge_.Drag(e.x, e.y);
		    break;
		    
		case Event.MOUSE_UP:
		    newEdge_.FinishDrag(e.x, e.y);
		    newEdge_ = null;
		    break;
		case Event.KEY_PRESS:
		    if (e.key == 8 || e.key == 127)
			Remove();
		    break;
		}
	    }
	}
    }
    
    public String toString() {
	return "Node " + numString_ + " (" + x_ + "," + y_ + ")";
    }
}
