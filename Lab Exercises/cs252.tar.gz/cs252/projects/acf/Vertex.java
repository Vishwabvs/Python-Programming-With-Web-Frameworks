
import java.util.Vector;

class Vec2d
{
    int x,y;
    public Vec2d(int xx,int yy) { set(xx,yy); }
    public Vec2d(Vec2d v) { set(v.x,v.y); }
    public void set(Vec2d v) { set(v.x,v.y); }
    public void set(int xx, int yy) { x=xx; y=yy; }
    public void setX(int xx) { x=xx; }
    public void setY(int yy) { y=yy; }
    public String toString() { return "("+x+","+y+")"; }
}

class Vertex extends Vec2d
{
    Vector adjedges = new Vector();

    int in;    // marker for bfs/dfs
    Object data;
    boolean fixed = false;

    public Vertex(int xx,int yy) { super(xx,yy); }
    public Vertex(Vertex v) { super(v.x,v.y); }

    public int proximity(int x1,int y1) {
        // Returns a proximity measure: the square of the absolute distance.
        return (x1-x)*(x1-x) + (y1-y)*(y1-y);
    }
}

