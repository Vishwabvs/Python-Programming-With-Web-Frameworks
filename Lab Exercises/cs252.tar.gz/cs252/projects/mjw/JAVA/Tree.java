import java.awt.*;
import java.awt.image.*;
import java.util.Vector;
import java.util.Enumeration;
import java.util.Stack;
import java.io.PrintStream;
import java.io.StreamTokenizer;
import java.io.InputStream;
import geometry.*;
import TreeNode;



class Tree
{
   TreeNode root_;
   int default_y_ = 20;
   int y_scale_   = 30; 
   int num_nodes_;

   Image unselected_node_image_;
   Image selected_node_image_;
   Image query_node_image_;
   Image allocation_node_image_;
   Image leaf_node_image_;
   Color unselected_color_;
   Color selected_color_;
   Color query_color_;



   public Tree() {
      root_ = null;
      num_nodes_ = 0;
   }

   public Tree (GeometryStreamTokenizer st) throws GeometryException {
      /* confirm it's a graph -- first line is GRAPH.TREE */

      st.eolIsSignificant(true);
      String marker = st.nextString();
      //System.out.println("marker received: "+marker);
      if (marker == null || marker.compareTo("GRAPH.TREE") != 0)
         throw new GeometryException
            ("Geometry server did not return a tree:" + marker);
            
      /* next, type of node and edge -- ignore */
      st.nextEOL();
      
      readNodes(st);
   }



  void readNodes(GeometryStreamTokenizer st) {

	TreeNode left_child, right_child;
      /* read number of nodes, then node info (points) */
      num_nodes_ = st.nextInt(); 
      //System.out.println ("Nodes " + num_nodes_);
      st.nextEOL();

      TreeNode stack_node;
      TreeNode stream_node;
      Stack stack = new Stack();

      root_ = new TreeNode(st);
      root_.setY(default_y_);
      st.nextEOL();
      stack.push(root_);

      for (int i = 0; i < num_nodes_; i++)
      {
	stream_node = new TreeNode(st); 
	stack_node  = findMatch(stack, stream_node);

	//System.out.print("stack_node:"+stack_node.getX()+","+stack_node.getY());
	//System.out.print("    stream_node:"+stream_node.getX()+","+stream_node.getY());
	

	// now read children
	left_child = new TreeNode(st);
	if (!left_child.valid())
		right_child = new TreeNode(-1, -1, -1);
	else
	{
		right_child = new TreeNode(st);
		//if (!right_child.valid())
		//System.out.print("   r-invalid ");
	}
	//System.out.print("   leftchild:"+left_child.getX()+","+left_child.getY());
	//System.out.print("  rightchild:"+right_child.getX()+","+right_child.getY());
	if (right_child.valid())
	{
		right_child.setY(stack_node.getY()+ y_scale_);
		stack_node.setRightChild(right_child);
		//System.out.print("   p-r ");
		stack.push(right_child);
	}
	if (left_child.valid())
	{
		left_child.setY(stack_node.getY()+ y_scale_);
		stack_node.setLeftChild(left_child);
		//System.out.print("   p-l");
		stack.push(left_child);
	}
	//System.out.println();
        if (left_child.valid() && right_child.valid())
		st.nextEOL();
      }
}


private TreeNode findMatch(Stack stack, TreeNode node)
{
	boolean match = false;
	TreeNode stack_node = null;
	//if (stack.empty())
		//System.out.println("Stack is empty");
	//else
		while (!match && !stack.empty())
		{
			stack_node = (TreeNode) stack.pop();
			//System.out.println("comparing"+stack_node.getID() + " w/ node " +node.getID());
			if (stack_node.getID() == node.getID())
				match = true;
		}
	return stack_node;
}




public void setUnselectedNodeImage(Image im)
{
	unselected_node_image_ = im;
}


public Image getUnselectedNodeImage()
{
	return unselected_node_image_;
}


public void setSelectedNodeImage(Image im)
{
	selected_node_image_ = im;
}

public Image getSelectedNodeImage()
{
	return selected_node_image_;
}

public void setAllocationNodeImage(Image im)
{
	allocation_node_image_ = im;
}

public Image getAllocationNodeImage()
{
	return allocation_node_image_;
}

public void setLeafNodeImage(Image im)
{
        leaf_node_image_ = im;
}

public Image getLeafNodeImage()
{
        return leaf_node_image_;
} 


public Color setUnselectedColor(Color color)
{
	Color old = unselected_color_;
	unselected_color_ = color;
	return old;
}


public Color setSelectedColor(Color color)
{
	Color old = selected_color_;
	selected_color_ = color;
	return old;
}


public Color getUnselectedColor()
{
	return unselected_color_;
}

public Color getSelectedColor()
{
	return selected_color_;
}

public void draw (Graphics g, ImageObserver is) {
	if (root_ == null || num_nodes_ == 0)
		return;

	Image dot;
	TreeNode node, left_child, right_child;
	Stack stack = new Stack();
	stack.push(root_);

	while (!stack.empty())
	{
		node = (TreeNode) stack.pop();
		if (node.isAllocationNode())
			dot = allocation_node_image_;
		else if (node.isSelected())
			dot = selected_node_image_;
		else    dot = unselected_node_image_;

		drawNode(g, node, is);
		left_child =  node.getLeftChild();
		right_child = node.getRightChild();
		if (left_child != null && left_child.valid())
			stack.push(left_child);
		if (right_child != null && right_child.valid())
			stack.push(right_child);
	}
}


public void drawNode(Graphics g, TreeNode node, ImageObserver is)
{
	TreeNode left_child, right_child;
	Image dot;

	left_child = node.getLeftChild();
	right_child = node.getRightChild();


	if (node.isAllocationNode())
		dot = allocation_node_image_;
	else if (node.isSelected())
		dot = selected_node_image_;
	else
	  {
	    if (left_child == null && right_child == null)
	      dot = leaf_node_image_;
	    else
	      dot = unselected_node_image_;
	  }

	

	if (left_child != null && left_child.valid())
	{
		//if (left_child.isSelected())
		if (node.isLeftEdgeSelected())
			g.setColor(selected_color_);
		else    g.setColor(unselected_color_);

		g.drawLine(node.getX(),
			   node.getY(),
			   left_child.getX(),
			   left_child.getY());
		
	}

	if (right_child != null && right_child.valid())
	{
		//if (right_child.isSelected())
		if (node.isRightEdgeSelected())
			g.setColor(selected_color_);
		else    g.setColor(unselected_color_);

		g.drawLine(node.getX(),
			   node.getY(),
			   right_child.getX(),
			   right_child.getY());
	}
	
	g.drawImage(dot, node.getX() - dot.getWidth(null)/2,
			 node.getY() - dot.getHeight(null)/2,
			 is);
}



public TreeNode findNode(int id)
{
	TreeNode left_child, right_child, node;
	if (root_ == null)
	  return null;
	Stack stack = new Stack();
	stack.push(root_);

	while (!stack.empty())
	{
		node = (TreeNode) stack.pop();
		if (node.getID() == id)  // found it !
			return node;

		left_child =  node.getLeftChild();
		right_child = node.getRightChild();
		if (left_child != null && left_child.valid())
			stack.push(left_child);
		if (right_child != null && right_child.valid())
			stack.push(right_child);
	}
	return null;
}


public TreeNode findNode(int x, int y, ImageObserver ob)
{
	TreeNode left_child, right_child, node;
	int img_width;
	Image dot;
	
	if (root_ == null)
	  return null;
	Stack stack = new Stack();
	stack.push(root_);

	while (!stack.empty())
	{	       
		node = (TreeNode) stack.pop();
		left_child =  node.getLeftChild();
		right_child = node.getRightChild();
		
		if (node.isAllocationNode())
		  dot = allocation_node_image_;
		else if (node.isSelected())
		  dot = selected_node_image_;
		else
		  {
		    if (left_child == null && right_child == null)
		      dot = leaf_node_image_;
		    else
		      dot = unselected_node_image_;
		  }
		img_width = dot.getWidth(ob);
		int nx = node.getX(), ny = node.getY();
		
		if ( nx >= (x - (img_width/2)) &&
		     nx <= (x + (img_width/2)) &&
		     ny >= (y - (img_width/2)) &&
		     ny <= (y + (img_width/2))) // found it !
			return node;
	       
		if (left_child != null && left_child.valid())
			stack.push(left_child);
		if (right_child != null && right_child.valid())
			stack.push(right_child);
	}
	return null;
}


public void resetAttributes()
{
	TreeNode left_child, right_child, node;
	Stack stack = new Stack();
	if (root_ == null)
		return;

	stack.push(root_);
	while (!stack.empty())
	{
		node = (TreeNode) stack.pop();
		node.setSelected(false);
		node.setAllocationNode(false);
		node.setLeftEdgeSelected(false);
		node.setRightEdgeSelected(false);
		

		left_child =  node.getLeftChild();
		right_child = node.getRightChild();
		if (left_child != null && left_child.valid())
			stack.push(left_child);
		if (right_child != null && right_child.valid())
			stack.push(right_child);
	}
}



} // class






