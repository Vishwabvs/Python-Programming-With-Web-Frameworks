/*
 *  GRGraph - an actual graph 
 *  4/14/96 
 *  by Daniel Spirn 
 *
 */
package graphrender;

import java.awt.*;
import java.applet.*;

class GRGraph extends Object
{
    // total # of edges and nodes in model
    int numedges, numnodes;

    // capacity of node array
    int nodecapacity;
 
    // scaling of the viewing port needed to have entire graph in viewing 
    // port independent of viewing angle
    double viewfactor = 0;

    // array of nodes
    Node nodes[];

    // linked list of edges
    Edge edges;

    // Coordinates of a temperary edge -> drawn when user is dragging an edge from one node to another node
    int tx1,tx2,ty1,ty2;

    // Whether or not there is a temperary edge (see above)
    boolean tedge = false;

    // The View vector and the graph area plane  -> does 3D work
    Matrix3D view;	

    // Handle to the graph area
    GRGraphArea ga;

    final double SQRT_THREE = Math.sqrt(3.0);

    GRGraph(GRGraphArea g)
    { 
	ga = g;
	nodes = new Node[16];
	numnodes = 0;
	nodecapacity = 16;
	numedges = 0;
	view = new Matrix3D(ga);
	view.unit();
    }

    public Matrix3D view()
    {
	return view;
    }

    public Node[] nodes()
    {
	return nodes;
    }	

    public int numnodes()
    {
	return numnodes;
    }	
	
    public Edge edges()
    {
	return edges;
    }

    public double viewfactor()
    {
	return viewfactor;
    }

    public void tempedge(int x1, int y1, int x2, int y2, boolean tempedge) {
	tx1 = x1;
	tx2 = x2;
	ty1 = y1;
	ty2 = y2;
	tedge = tempedge;
    }

    // Adds a new node to the graph with u,v coordinates on screen
    //
    public void addNode(int u, int v)
    {
	Node temp[];
	int i;
	double um,vm;

  	// If the node exceeds node array capacity, build new array with twice capacity
	//
	if (numnodes + 1 > nodecapacity) 
	    {
		temp = new Node[2*nodecapacity];
		for(i = 0; i < nodecapacity ; i++) 
			temp[i] = nodes[i];
		nodes = temp;
		nodecapacity = nodecapacity*2;
	    }

	// Find the location of the node in 3D by :
	//       ((location on screen) - translation on screen)/ viewfactor
        // 
	if (numnodes == 0)
		nodes[numnodes] = new Node(0,0,0,u,v);
	else {
		if (numnodes == 1) 
			viewfactor = ga.screenDimension();
		um = (((double) u) - ga.screenDimension()/2.0) / viewfactor;
		vm = (((double) v) - ga.screenDimension()/2.0) / viewfactor;
		nodes[numnodes] = new Node(0,0,0,u,v);
		nodes[numnodes].settz(0.0);
		view.setNodePosition(nodes[numnodes],um,vm);
	}
	numnodes = numnodes+1;
    }

    // Add node with specific universal coordinates  (checks node array also)
    //
    public void addNode(double x, double y, double z)
    {
	Node temp[];
	int i;
	double um,vm;

	if (numnodes + 1 > nodecapacity) 
	    {
		temp = new Node[2*nodecapacity];
		for(i = 0; i < nodecapacity ; i++) 
			temp[i] = nodes[i];
		nodes = temp;
		nodecapacity = nodecapacity*2;
	    }
	nodes[numnodes] = new Node(x,y,z,0,0);
	numnodes = numnodes+1;
    }

    // Deletes node and all edges connected to it
    //
    public void deleteNode(Node node)
    {
	Edge currentedge = edges;
	Edge previousedge = currentedge;
	Edge head = edges;	

	while (currentedge != null) {
		if ((currentedge.node1() == node) || (currentedge.node2() == node)) {
			if (currentedge == head) {
				head = currentedge.next();
				previousedge = head;
			}
			else
				previousedge.setnext(currentedge.next());
			currentedge = currentedge.next();
			numedges--;
		}
		else {
			previousedge = currentedge;
			currentedge = currentedge.next();
		}
	}
	edges = head;
	
	int inode = 0;

        // fill in hole in node array
        //
	for (int i = 0 ; i<numnodes ; i++) {
		if (nodes[i] != node) {
			nodes[inode] = nodes[i];
			inode++;	
		}
	}
	numnodes--;
    }
	
    // Deletes edge
    public void deleteEdge(Edge deledge)
    {
	Edge tempedge;

	numedges--;
	if (deledge == edges) {
		edges = deledge.next();
		return;
	}
	deledge.prev().setnext(deledge.next());
	if (deledge.next() != null)
		deledge.next().setprev(deledge.prev());
    }

    // Adds edge with specific nodes 
    //
    public void addEdge(Node n1, Node n2)
    {
	Edge newedge;
	
	newedge = new Edge(n1, n2);
	if (numedges == 0) {
		edges = newedge;
		numedges = 1;
		newedge.setprev(null);
		return;
	}
	newedge.setnext(edges);
	edges.setprev(newedge);
	newedge.setprev(null);
	edges = newedge;
	numedges++;
	return;
    }

    // Projects the graph onto the plane perpindicular to the view vector
    //
    public void project()
    {
	for (int i = 0; i< numnodes ; i++) {
		nodes[i].setz(0.0);
	}
    }

    // Draws the graph onto the graphic
    //
    public Graphics draw(Graphics g)
    {
	Edge tempedge;
	int i = 0;
	double maxtz = -999999, mintz = 999999, total = 0;

	for(i = 0 ; i < numnodes ; i++) {
		if (nodes[i].tz() > maxtz) maxtz = nodes[i].tz();
		if (nodes[i].tz() < mintz) mintz = nodes[i].tz();
	}
	if (tedge == true) {
		g.setColor(Color.black); 
		g.drawLine(tx1,ty1,tx2,ty2);
	}
	i = 0;
	tempedge = edges;
	total = maxtz - mintz;

        // Calculates the gray scale of the edge depending on the depth of the edge relative to the viewing plane
        //
	while (i <  numedges) {
	 	double pcolor = (tempedge.node1().tz() + tempedge.node2().tz())/2.0;
		int ncolor = (int) (((pcolor - mintz)/total)*215.0);
		ncolor = 215 - ncolor;
		if (total == 0) ncolor = 0;
		g = tempedge.draw(ncolor,g);
		tempedge = tempedge.next();
		i++;
	}
        // Calculates the size of the nodes depending on the depth of the node relative to the viewing plane
        //
	for(i = 0 ; i < numnodes ; i++) {
		int vcolor = (int) (3.0*((nodes[i].tz() - mintz))/total);
		g = nodes[i].draw(vcolor,g);
	}
	return g;
    }	

    // Centers the graph in the "center of mass" sense
    //
    public void centerGraph()
    {
	double x_total = 0,y_total = 0,z_total = 0;
	int i;
	
	for (i = 0 ; i < numnodes ; i++) {
		x_total += nodes[i].x();
	   	y_total += nodes[i].y();
		z_total += nodes[i].z();
	}
	x_total = x_total / ((double) numnodes);
	y_total = y_total / ((double) numnodes);
	z_total = z_total / ((double) numnodes);
	
	for (i = 0 ; i < numnodes ; i++) {
		nodes[i].setx(nodes[i].x() - x_total);
		nodes[i].sety(nodes[i].y() - y_total);
		nodes[i].setz(nodes[i].z() - z_total);
	}
	calculateView();
    }

    // Calculates the viewing x, y for each node.  To do this the method needs the current view factor.
    //
    public void calculateView()
    {
	int i;
	double u,v;	


	calculateViewFactor();
	view.transform(this);

	for (i = 0 ; i < numnodes ; i++) 
	{
		nodes[i].setviewx((int) 
			(nodes[i].tx()*viewfactor + ga.screenDimension() / 2.0));
		nodes[i].setviewy((int) 
			(nodes[i].ty()*viewfactor + ga.screenDimension() / 2.0));	
	}	
    }

    // Calculates the view factor by getting the bounding box of the graph in universal coordinates, multiplying
    // by the size of the viewing port and dividing by sqrt(3.0) [trust me!] 
    //
    public void calculateViewFactor() 
    {
	if (ga.autoscaling() == false) {
		viewfactor = 1.0;
		return;
	}
	if (numnodes == 0)
		viewfactor = ga.screenDimension();
	else if (numnodes == 1)
		viewfactor = ga.screenDimension();
	else
		viewfactor = (0.50 * ga.screenDimension())/findMaxDimension();
	viewfactor /= SQRT_THREE;
    }

    // Gets the bounding box of the Graph
    //
    public double findMaxDimension()
    {
	int i;
	double max = 0;	

	for (i = 0 ; i < numnodes ; i++) {
		if (Math.abs(nodes[i].x()) > max)
			max = Math.abs(nodes[i].x());
		if (Math.abs(nodes[i].y()) > max)
			max = Math.abs(nodes[i].y());
		if (Math.abs(nodes[i].z()) > max)
			max = Math.abs(nodes[i].z());
	}
	return max;
    }

    // Checks whether a mouse click in the viewing port hit a node
    // 
    public Node selectNode(int x,int y) {		
	int i;

	if (numnodes == 0) return null;
	for (i = 0 ; i < numnodes ; i++) {
		if ((Math.abs(nodes[i].viewx() - (double) x) <= 3) &&
			(Math.abs(nodes[i].viewy() - (double) y) <= 3))
			return nodes[i];
	}
	return null;
    }

    // Checks whether a mouse click in the viewing port hit an edge
    // 
     public Edge selectEdge(int x,int y,double gamma) {		
		double tx,ty;
		double perpdist,closestdist;
		double dx,dy;
		double x1,x2,y1,y2;
		double a,b,c;
		Edge tempedge, returnedge = null;	
		
		if (numedges == 0) return null;
		tx = (double) x;
		ty = (double) y;
		closestdist = 999999;
		tempedge = edges;

		while (tempedge != null) {
			x1 = tempedge.node1().viewx();
			x2 = tempedge.node2().viewx();
			y1 = tempedge.node1().viewy();
			y2 = tempedge.node2().viewy();

			dx = x2 - x1;
			dy = y2 - y1;

			a = dx;
			b = -dy;
			c = dy*x2 - dx*y2;

			// calculate the perpindicular distance from point to line
			perpdist = Math.abs(a*ty + b*tx + c)/Math.sqrt(a*a + b*b);

			double newx = (ty*dx*dy + tx*dx*dx - y2*dx*dy + x2*dy*dy)/
					(dx*dx + dy*dy);

			// Check if within radius (3.0)
			//
			if (perpdist <= 3.0) {

				// Check if point is somewhere perpindicularly along segment (not beyond nodes) 
				if (x2 >= x1) {
					if ((newx >= x1) && (newx <= x2)) {
						if (closestdist > perpdist) {
							returnedge = tempedge;
							closestdist = perpdist;
							gamma = (newx-x1)/(x2-x1);
						}
					}
				} 
				else { 
					if ((newx >= x2) && (newx <= x1)) {
						if (closestdist > perpdist) {
							returnedge = tempedge;
							closestdist = perpdist;
							gamma = (newx-x1)/(x2-x1);
						}
					}
				}
			}
			tempedge = tempedge.next();
		}

		return returnedge;
	}
}










