//   void deleteCircleAt()
//   void drawSweep()
//   void drawClosestPair()
//   private void recover()
//   private void rePaint()
//   private void drawNodesNear()
//   private void drawNodesNearRect()
//   void drawQueryBand()
//   void drawAllNodes()
//   void drawTail()
//   void drawGrid()
//   void drawLine()
//   void erraseQueryBand()
//   void removeGrid()

import java.awt.*; 
import java.util.*;
import java.lang.*; 

public class FunctionSet {
   final static int INFTY = ClosestPairDiagram.INFTY; 
   final static int RIGHT = ClosestPairDiagram.RIGHT;
   final static int LEFT = ClosestPairDiagram.LEFT; 
   final static int LINERESOLUTION = ClosestPairDiagram.LINERESOLUTION; 
   final static int R = ClosestPairDiagram.NODERADIUS;
   final static int NR = 2*R+3;
   final static int GRID = ClosestPairDiagram.GRID;   
   final static Color tailColor = new Color(180, 90, 90); 

   private Color sweepLineColor = ClosestPairDiagram.sweepLineColor;  
   private ClosestPairDiagram controller; 
   private DrawingArea drawArea; 

   // The width of the current band. 
   private double band_width;  
   public void setBandWidth(double b) {
      band_width = b; 
   } 
   public double getBandWidth() {
      return band_width; 
   } 

   Image offscreen; 
 
   public FunctionSet(ClosestPairDiagram c) {
      band_width = INFTY; 
      controller = c; 
   }
 
   void adjust() {
      if(offscreen!=null) offscreen.flush(); 
      drawArea = controller.getDrawingArea();  
      Dimension dim=drawArea.size(); 
      offscreen = controller.createImage(dim.width, dim.height); 
      ClosestPair cp = controller.getClosestPair(); 
      int line = controller.getLinePosition(); 
      //System.out.println("In adjust..."); 
      rePaint(cp, line, band_width, Color.yellow, Color.red, 
           0, 0, dim.width, dim.height, controller.getGridChoice());      
      return; 
   } 

   // called when the mouse drags the sweepline
   synchronized void MouseSweep(ClosestPair cp, int line, int mouse_x, 
     int dl) {
      int old_line = line; 

      QueryNode tail = cp.getTail(); 
      int current = tail.getKey().getX(); 
      int right = tail.getNext().getKey().getX(); 
      line = mouse_x + dl; 

      QueryNode old_n1=cp.getClosestPairFirstNode();
      QueryNode old_n2 =cp.getClosestPairSecondNode();
      QueryNode old_t = tail; 

      controller.setLinePosition(line); 

      if(line <= right&& line>current) {
         //System.out.println("Here"); 
         band_width = cp.getMinDistance(); 
         drawSweep(cp, old_line, line, band_width); 
         return; 
      }

      if(line > right) {
         //System.out.println(" right."); 
         //line = right; 
         while(line > right) { 
            cp.sweepLineQuery(RIGHT); 
            tail = cp.getTail(); 
            current = tail.getKey().getX(); 
            right = tail.getNext().getKey().getX(); 
         } 
      } else if(line <= current){
         //line = current; 
         while(line<=current) {
            cp.sweepLineQuery(LEFT); 
            tail = cp.getTail(); 
            current = tail.getKey().getX(); 
            right = tail.getNext().getKey().getX(); 
         } 
      }

      double new_band_width = cp.getMinDistance();  

      Graphics g = drawArea.getGraphics(); 
      recover(g, cp, line, old_n1, old_n2, old_t); 
      drawSweep(cp, old_line, line, new_band_width); 
      band_width = new_band_width; 
   }

   // repaint the old closest pair, the tail blue.  
   private void recover(Graphics g, ClosestPair cp, double line, 
              QueryNode old_n1, QueryNode old_n2, 
              QueryNode old_t) { 
      if(old_t.getKey().getX()>line) {
         DrawingMethods.drawCircleAt(g, old_t.getKey().getX(), 
            old_t.getKey().getY(), Color.blue); 
      }
      if(old_n1.getKey().getX() > line) {
         DrawingMethods.drawCircleAt(g, old_n1.getKey().getX(), 
               old_n1.getKey().getY(), Color.blue); 
      }
      if(old_n2.getKey().getX() > line) {
         DrawingMethods.drawCircleAt(g, old_n2.getKey().getX(), 
               old_n2.getKey().getY(), Color.blue); 
      }
   }   

   // called when the sweep line leaps forward or backward. 
   boolean Sweep(int sweep) {
      ClosestPair cp = controller.getClosestPair(); 
      int line = controller.getLinePosition(); 
      int old_line = line; 

      double d = INFTY;
 
      QueryNode old_n1=cp.getClosestPairFirstNode();
      QueryNode old_n2 =cp.getClosestPairSecondNode();
      QueryNode old_t = cp.getTail();

      if(sweep==RIGHT) {
         d = cp.getMinDistance(); 
      } 
      cp.sweepLineQuery(sweep);
      
      if(sweep==LEFT) {
         QueryNode n = cp.getFiberHead();
         if(n.getMinDistance()>=INFTY) {
            d = INFTY; 
         } else {
            n = (QueryNode)n.getPrev(); 
            d = n.getMinDistance(); 
         }
      } 

      line = cp.getTail().getKey().getX(); 
      controller.setLinePosition(line); 

      Graphics g = drawArea.getGraphics(); 
      recover(g, cp, line, old_n1, old_n2, old_t); 

      drawSweep(cp, old_line, line, d);  
      band_width = d; 

      return true; 
   }

   //x, y, w, h are the parameters of the clipped graphics 
   synchronized private void rePaint(ClosestPair cp, int line, double band_w, 
           Color band_c, Color line_c, int x, int y, int w, int h, 
           boolean grid) {  
      Graphics g = offscreen.getGraphics(); 
      g.clipRect(x, y, w, h); 
  
      int dw = offscreen.getWidth(drawArea); 
      int dh = offscreen.getHeight(drawArea); 
      drawGrid(g, dw,  dh, Color.black); 
      DrawingMethods.drawBackground(g, drawArea);  
      DrawingMethods.drawQueryBand(g, line, band_w, dh, band_c); 

      if(grid){
         drawGrid(g, dw,  dh, Color.black); 
      } 
      Vector nv = cp.nodesBetween(x-R, x+w+R);
      if(nv!=null) {
         //System.out.println("Draw..."+line); 
         for(int i=0; i<nv.size(); i++) {
            QueryNode n = (QueryNode)nv.elementAt(i); 
            Key key = n.getKey(); 
            int cx = key.getX(); 
            int cy = key.getY(); 
            if(n == cp.getClosestPairFirstNode()) {
               //System.out.println("Closest Pair: "+"("+cx+" , "+cy+")"); 
               DrawingMethods.drawCircleAt(g, cx, cy, Color.green); 
            } else if(n == cp.getClosestPairSecondNode()) {
               //System.out.println("Closest Pair: "+"("+cx+" , "+cy+")"); 
               DrawingMethods.drawCircleAt(g, cx, cy, Color.green); 
            } else if(n == cp.getTail()) { 
               //System.out.println("Tail: "+"("+cx+" , "+cy+")"); 
               DrawingMethods.drawCircleAt(g, cx, cy, tailColor); 
            } else if(cx>=line-band_w&&cx<=line) {
               DrawingMethods.drawCircleAt(g, cx, cy, Color.black); 
            } else {
               DrawingMethods.drawCircleAt(g, cx, cy, Color.blue); 
            } 
         }
      }
      DrawingMethods.drawSweepLine(g, line, dh, line_c); 
      g = drawArea.getGraphics(); 
      g.clipRect(x, y, w, h);
      g.drawImage(offscreen, 0, 0, drawArea); 

      return; 
   }

   // draw the screen when the sweep line changes from one postion to another
   void drawSweep(ClosestPair cp, int old_line, 
                  int new_line, double new_band_width) {
      int l= old_line; 
      if(new_line > l) {
          l = new_line; 
      } 
      //System.out.println("Pia..."); 
      rePaint(cp, new_line, new_band_width, 
           Color.yellow, sweepLineColor, 0, 0, l+4*R, drawArea.size().height, 
           controller.getGridChoice());      
      return; 
   }
   
   // Return the first circle node founded which contains the point  
   QueryNode circleContaining(ClosestPair cp, int x, int y) {
      int r = R+1; 
      Vector v=cp.nodesBetween(x-r, x+r); 
      if(v==null) 
         return null; 
      for(int i=0; i<v.size(); i++) {
         QueryNode node=(QueryNode)v.elementAt(i);
         Key center = node.getKey(); 
         int xc = center.getX(); 
         int yc = center.getY(); 
         int d = (xc-x)*(xc-x)+(yc-y)*(yc-y);
         if(d<=r*r) 
            return node; 
      }
      return null;
   } 

   void drawClosestPair(Graphics g, ClosestPair cp, Color c) {
      Key key_=cp.getClosestPairFirstNode().getKey();
      if(key_.getX()>=0 && key_.getY()>=0) {
         DrawingMethods.drawCircleAt(g, key_.getX(), key_.getY(), c);
      }
      key_=cp.getClosestPairSecondNode().getKey();
      if(key_.getX()>=0 && key_.getY()>=0) {
         DrawingMethods.drawCircleAt(g, key_.getX(), key_.getY(), c);
      }
   }
   void drawClosestPair(Component cmp, ClosestPair cp, Color c) {
      Graphics g = cmp.getGraphics(); 
      drawClosestPair(g, cp, c);
   }
   void drawClosestPair(Image img, ClosestPair cp, Color c) {
      Graphics g = img.getGraphics(); 
      drawClosestPair(g, cp, c);
   }

   // Fix the graphics near the rectangle with corners (x_1, y_1), (x_2, y_2)
   // If a node is in [a_1, a_2]x[b_1, b_2], its color is specified c
   private void drawNodesNearRect(Graphics g, ClosestPair cp, 
               int x_1, int y_1, int x_2, int y_2, 
               double a_1, double a_2, double b_1, double b_2, 
               Color c) {
      int r = 3*R; 
      int x, y; 
      int w, h; 
   
      if(x_1<=x_2) {
         x = x_1 - r; 
         w = x_2 - x_1 + 2*r; 
      } else {
         x = x_2 - r; 
         w = x_1 - x_2 + 2*r; 
      }

      if(y_1<=y_2) {
         y = y_1 - r; 
         h = y_2 - y_1 + 2*r; 
      } else {
         y = y_2 - r; 
         h = y_1 - y_2 + 2*r; 
      }

      Vector v=cp.nodesBetween(x, x+w);   
      if(v!=null) {
         for(int i=0; i<v.size(); i++) {
            QueryNode node=(QueryNode)v.elementAt(i);
            Key center = node.getKey();
            int xc = center.getX(); 
            int yc = center.getY(); 
            if(yc>=y && yc<=y+h) {
               if(node==cp.getClosestPairFirstNode()) {
                  DrawingMethods.drawCircleAt(g, xc, yc, Color.green); 
               } else if(node==cp.getClosestPairSecondNode()) {
                  DrawingMethods.drawCircleAt(g, xc, yc, Color.green); 
               } else if(node== cp.getTail()) {
                  DrawingMethods.drawCircleAt(g, xc, yc, tailColor); 
               } else if(xc>=a_1&&xc<=a_2&&yc>=b_1&&yc<=b_2) {
                  DrawingMethods.drawCircleAt(g, xc, yc, c); 
               } else { 
                  DrawingMethods.drawCircleAt(g, xc, yc, Color.blue); 
               } 
            }
         }
      }
   }

   // draws grid with the designated graphics source, this function 
   // did not draw other things 
   void drawGrid(Graphics g, int width, int height, Color c) {
      g.setColor(c); 
      for(int x=0; x<width; x=x+GRID) {
         g.drawLine(x, 0, x, height); 
      }
      for(int y=0; y<height; y=y+GRID) {
         g.drawLine(0, y, width, y); 
      }
   }
   // draws grid on the designated component, also takes care of the 
   // band, sweepline, nodes 
   void drawGrid(Component cmp, Color c) { 
      Graphics g = offscreen.getGraphics(); 
      // Always to clear the offscreen image before drawing 
      DrawingMethods.drawBackground(g, cmp); 
      int line = controller.getLinePosition(); 
      int dw = offscreen.getWidth(cmp); 
      int dh = offscreen.getHeight(cmp); 
      DrawingMethods.drawQueryBand(g, line, band_width, 
           dh, Color.yellow);  
      drawGrid(g, dw, dh, c); 
      drawAllNodes(g);
      DrawingMethods.drawSweepLine(g, line, dh, Color.red); 
      g = cmp.getGraphics(); 
      g.drawImage(offscreen, 0, 0, cmp); 
   }    
 
   // remove the grid line from the component
   void removeGrid(Component cmp) {
      Graphics g = offscreen.getGraphics(); 
      // Always to clear the offscreen image before drawing 
      DrawingMethods.drawBackground(g, cmp); 
      Color c=cmp.getBackground();
      int dw = offscreen.getWidth(cmp); 
      int dh = offscreen.getHeight(cmp); 
      int line = controller.getLinePosition(); 
      drawGrid(g, dw, cmp.size().height, c); 
      DrawingMethods.drawQueryBand(g, line, band_width, 
           dh, Color.yellow);  
      drawAllNodes(g);
      DrawingMethods.drawSweepLine(g, line, dh, Color.red); 
      g = cmp.getGraphics(); 
      g.drawImage(offscreen, 0, 0, cmp); 
      
   }

   //fix the graphics near the rectangle with two corners (x_1, y_1) 
   //and (x_2, y_2). 
   private void drawNodesNearRect(Component cmp, ClosestPair cp, 
               int x_1, int y_1, int x_2, int y_2, 
               double a_1, double a_2, double b_1, double b_2, 
               Color c) {
        drawNodesNearRect(cmp.getGraphics(), cp, x_1, y_1, x_2, y_2, 
               a_1, a_2, b_1, b_2, c); 
   }
   private void drawNodesNearRect(Image img, ClosestPair cp, 
               int x_1, int y_1, int x_2, int y_2, 
               double a_1, double a_2, double b_1, double b_2, 
               Color c) {
        drawNodesNearRect(img.getGraphics(), cp, x_1, y_1, x_2, y_2, 
               a_1, a_2, b_1, b_2, c); 
   }

   void drawTail(Graphics g, ClosestPair cp, Color c) {
      QueryNode node = cp.getTail();
      if(node!=null) {
         Key k=node.getKey(); 
         DrawingMethods.drawCircleAt(g, k.getX(), k.getY(), c); 
      }
   }
   void drawTail(Graphics g, ClosestPair cp)  {
      QueryNode node = cp.getTail();
      if(node==cp.getClosestPairFirstNode()) {
         Key k=node.getKey(); 
         DrawingMethods.drawCircleAt(g, k.getX(), k.getY(), 
                 Color.green); 
      } else if(node==cp.getClosestPairSecondNode()) {
         Key k=node.getKey(); 
         DrawingMethods.drawCircleAt(g, k.getX(), k.getY(), 
                 Color.green); 
      } else if(node!=null) {
         Key k=node.getKey(); 
	 DrawingMethods.drawCircleAt(g, k.getX(), k.getY(), 
                 tailColor); 
      }
   }     
         

   // first delete the point from the nodetree, then remove the 
   // graphics of the point from the designated component
   void deleteCircleAt(ClosestPair cp, QueryNode node) {
      Key k = node.getKey(); 
      cp.deletePoint(node); 
      drawNodesNear(cp, k.getX(), k.getY()); 
   }

   // fix the graphics near the point (x, y). 
   void drawNodesNear(ClosestPair cp, int x, int y) {
      Graphics g = offscreen.getGraphics(); 
      g.clipRect(x-4*R, y-4*R, 8*R+1, 8*R+1);  
      //System.out.println("In drawNodesNear..."); 
      rePaint(cp, controller.getLinePosition(), 
          band_width, Color.yellow, Color.red,  
          x-4*R, y-4*R, 8*R+1, 8*R+1, controller.getGridChoice());
      return; 
   }

   void drawAllNodes(Graphics g) {
      ClosestPair cp = controller.getClosestPair(); 
      int line = controller.getLinePosition(); 
      Vector all = cp.getNodeTree().allNodes(); 

      if(all!=null) {
         for(int i=0; i<all.size(); i++) {
            QueryNode n = (QueryNode)all.elementAt(i); 
            Key key = n.getKey(); 
            int cx = key.getX(); 
            int cy = key.getY(); 
            if(n == cp.getClosestPairFirstNode()) {
               DrawingMethods.drawCircleAt(g, cx, cy, Color.green); 
            } else if(n == cp.getClosestPairSecondNode()) {
               DrawingMethods.drawCircleAt(g, cx, cy, Color.green); 
            } else if(n == cp.getTail()) { 
               DrawingMethods.drawCircleAt(g, cx, cy, tailColor); 
            } else if(cx>=line-band_width&&cx<=line) {
               DrawingMethods.drawCircleAt(g, cx, cy, Color.black); 
            } else {
               DrawingMethods.drawCircleAt(g, cx, cy, Color.blue); 
            } 
         }
      }
   }
   void drawAllNodes(Component cmp) {
      drawAllNodes(cmp.getGraphics()); 
   }
   void drawAllNodes(Image img) {
      drawAllNodes(img.getGraphics()); 
   }

   void erraseQueryBand(ClosestPair cp, int line, double d) {
      int w = (int)d; 
      if(w> line+1) w = line+1; 
      Graphics g = offscreen.getGraphics(); 
      int x_1 = line-w-2*R; 
      int x_2 = line+2*R; 
      if(x_1<0) x_1 = 0; 
      if(x_2>offscreen.getWidth(drawArea)) 
         x_2 = offscreen.getWidth(drawArea);  
      w = x_2 - x_1; 
      g.clipRect(x_1, 0, w, offscreen.getHeight(drawArea));  
      DrawingMethods.drawBackground(g, drawArea); 
      if(controller.getGridChoice()){
         drawGrid(g, drawArea.size().width, drawArea.size().height, 
                  Color.black); 
      } 
      Vector nv = cp.nodesBetween(x_1-R, x_1+w+R);

      if(nv!=null) {
         for(int i=0; i<nv.size(); i++) {
            QueryNode n = (QueryNode)nv.elementAt(i); 
            Key key = n.getKey(); 
            int cx = key.getX(); 
            int cy = key.getY(); 
            DrawingMethods.drawCircleAt(g, cx, cy, Color.blue); 
         }
      }
      g = drawArea.getGraphics(); 
      drawClosestPair(g, cp, Color.blue); 
      drawTail(g, cp, Color.blue); 
      g.clipRect(x_1, 0, w, offscreen.getHeight(drawArea));  
      g.drawImage(offscreen, 0, 0, drawArea); 
      return; 
   }

  
   void drawQueryBand(ClosestPair cp, int line, double band_w) {
         int w = (int)band_w; 
         if(w> line+1) w = line+1; 
         int x_1 = line-w-2*R; 
         int x_2 = line+2*R; 
         if(x_1<0) x_1 = 0; 
         if(x_2>offscreen.getWidth(drawArea)) 
            x_2 = offscreen.getWidth(drawArea);  
         w = x_2 - x_1; 
         //System.out.println("In drawQueryBand..."); 
         rePaint(cp, line, band_w, Color.yellow, 
           sweepLineColor, x_1, 0, w, offscreen.getHeight(drawArea), 
           controller.getGridChoice());      
         return; 
   }

   public void drawLine(Graphics g, ClosestPair cp, 
                 int x_1, int y_1, int x_2, int y_2, 
                 Color linecolor, int direction, 
                 double a_1, double a_2, double b_1, double b_2, 
                 Color nodecolor) {
      DrawingMethods.drawLine(g, x_1, y_1, x_2, y_2, linecolor, direction);
      drawNodesNearRect(g, cp, 
             x_1, y_1, x_2, y_2, a_1, a_2, b_1, b_2, nodecolor);
   } 
   public void drawLine(ClosestPair cp, 
                 int x_1, int y_1, int x_2, int y_2, 
                 Color linecolor, int direction, 
                 double a_1, double a_2, double b_1, double b_2, 
                 Color nodecolor) {
      DrawingMethods.drawLine(drawArea.getGraphics(), x_1, y_1, x_2, y_2, 
             linecolor, direction);
   } 
}

