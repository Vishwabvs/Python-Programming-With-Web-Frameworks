/*
 *  GREnergyGraph - a graph widget that displays energy vs. iteration
 *  4/14/96 
 *  by Daniel Spirn 
 *
 */
package graphrender;

import java.awt.*;
import java.applet.*;

public class GREnergyGraph extends Frame
{  
    // Constants for the window size
    final static int 	height_ = 300;
    final static int 	width_ = 400;
    final static int 	xmargin_ = 30;
    final static int 	ymargin_ = 30;

    // Canvas for drawing graph
    static GREnergyCanvas	graph_canvas_;

    // Value per pixel
    double		dx_,dy_;

    // Min and Max energy from energy array
    double 		min_energy_,max_energy_;

    // Max and Min ints -> bound max,min energy
    int 		max_int_, min_int_;

    // Energy array (stores energy value at each iteration step
    double[]		energy_;

    // Tells where newest energy value is placed in array
    int 		current_energy_step_;

    // Size of energy array
    final static int	ENERGY_ARRAY_SIZE_ = 200;

    GREnergyGraph()
    {
 	super("Energy vs. Iteration");
	setLayout(new BorderLayout(5,5));
	
	Panel panel = new Panel();
	panel.setBackground(new Color(34,133,144));
	panel.setLayout(new BorderLayout(5,5));

	graph_canvas_ = new GREnergyCanvas(width_, height_, xmargin_, ymargin_,ENERGY_ARRAY_SIZE_);
	graph_canvas_.resize(width_,height_);
	graph_canvas_.setBackground(Color.white);
	graph_canvas_.setForeground(Color.black);

	panel.add("Center",graph_canvas_);

	Panel buttonpanel = new Panel();
	buttonpanel.setLayout(new GridLayout(1,3));
	Button resetbutton = new Button("reset");
	Button hidebutton = new Button("hide");
	Button updatebutton = new Button("update");
	buttonpanel.add(updatebutton);
	buttonpanel.add(resetbutton);
	buttonpanel.add(hidebutton);
	add("Center",panel);
	add("South",buttonpanel);
	positionOnScreen();
	pack();

	energy_ = new double[ENERGY_ARRAY_SIZE_];
	for(int i = 0 ; i < ENERGY_ARRAY_SIZE_ ; i++)
		energy_[i] = 0;
	current_energy_step_ = 0;
    }

    //  Positions the energy graph on the screen (for the first time)
    //
    private void positionOnScreen() {
	Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
	this.move(((screen.width / 2)), (screen.height / 3) + (this.size().height));
    }

    // After an iteration this method is called to record energy value
    //
    public void SetNextEnergyStep(double energy) {
	energy_[current_energy_step_] = energy;
	current_energy_step_++;
	if (current_energy_step_ == ENERGY_ARRAY_SIZE_)
		current_energy_step_ = 0;
    }
	
    // Set the energy array to zero
    //
    public void ResetEnergyArray(){
	for(int i = 0 ; i < ENERGY_ARRAY_SIZE_ ; i++) 
		energy_[i] = 0;
	current_energy_step_ = 0;
    }

    // Draws the Energy graph by finding all the constants needed and calling the drawing procedure from GREnergyCanvas
    public void DrawGraph() {
	max_energy_ = 0;
	min_energy_ = 999999;

	for (int i = 0 ; i < ENERGY_ARRAY_SIZE_ ;  i++) {
		if (energy_[i] < min_energy_)
			min_energy_ = energy_[i];
		if (energy_[i] > max_energy_)
			max_energy_ = energy_[i];
	}
		
	max_int_ = (int) Math.ceil(max_energy_);
	min_int_ = (int) Math.floor(min_energy_);	

	dx_ = ((double) (width_ - (2*xmargin_))) / ((double) ENERGY_ARRAY_SIZE_); 
	dy_ = ((double) (height_ - (2*ymargin_))) / ((double) (max_int_ - min_int_));	
    }	
   
    public void paint(Graphics g){
	graph_canvas_.setValues(energy_, current_energy_step_, dx_, dy_, max_energy_, min_energy_, max_int_, min_int_);
	graph_canvas_.paint(g);
    }

    public boolean action(Event evt, Object arg)
    {
	if ("hide".equals(arg))  {
	 	this.hide();
		return true;
	}else if ("reset".equals(arg))  {
		ResetEnergyArray();
		DrawGraph();
		repaint();
		show();
		return true;
	} else if ("update".equals(arg)) {
		DrawGraph();
		show();
		return true;
	}
	else 
		return false;
    }

}

class GREnergyCanvas extends Canvas
{	
   // SAME CONSTANTS AS IN GREnergyGraph 

   int xmargin_,ymargin_;
    int height_ , width_;	
    double dx_,dy_, max_energy_, min_energy_;
    int max_iterations_;
    int current_energy_step_;
    double energy_[];
    int min_int_, max_int_;

    GREnergyCanvas(int width, int height, int xmargin, int ymargin, int energy_array_size_){
	resize(width, height);
	width_ = width;
	height_ = height;
	xmargin_ = xmargin;
	ymargin_ = ymargin;
	max_iterations_ = energy_array_size_;
	setBackground(Color.white);
	setForeground(Color.black);
    }

    public void setValues(double energy[], int currentenergystep, double dx, double dy, double max_energy, double min_energy, int max_int, int min_int)
    {
	energy_ = energy;
	dx_ = dx;
	dy_ = dy;
	max_energy_ = max_energy;
	min_energy_ = min_energy;
	max_int_ = max_int;
	min_int_ = min_int;
	current_energy_step_ = currentenergystep;
    }

    public void paint(Graphics g) {
	g.setColor(Color.black);	
	draw(g);
    }

    // Draws the canvas
    private void draw(Graphics g) 
    {
	int x,y;
	int old_x = 0,old_y = 0;

	g.setColor(Color.white);
	g.fillRect(0,0,width_,height_);
	resize(width_, height_);

        // DRAWS A GRID ON THE CANVAS
        //
	double dx = ((double) (width_ - (2*xmargin_)))/10.0;
	double dy = ((double) (height_ - (2*ymargin_)))/10.0;
	g.setColor(new Color(212,212,212));	
	for (int i = 10 ; i > -1; i--) 
		g.drawLine(xmargin_ + (int)(dx*(double) i),  ymargin_,
			   xmargin_ + (int) (dx*(double) i),(height_ - ymargin_));
	for (int j = 10 ; j > -1 ; j--) 
		g.drawLine(xmargin_, (height_ - ymargin_) - (int)(dy*(double) j),
			   (width_ - xmargin_),(height_ - ymargin_) - (int)(dy*(double) j));


	g.setColor(Color.black);
	g.drawLine(xmargin_,ymargin_,xmargin_,height_ - ymargin_);
	g.drawLine(xmargin_,height_ - ymargin_, width_ - xmargin_, height_ - ymargin_);
	g.drawString("Iterations", width_/2 - 15, (height_ - (ymargin_/2)) + 2);

 	// DRAWS THE ENERGY GRAPH
   	//
	for (int i = 0 ; i < max_iterations_ + 1  ; i++) {
		x = ((int) ((i-1)*dx_)) + xmargin_;
		int j = i+current_energy_step_;
		if (j > (max_iterations_ - 1))
			j = (j-max_iterations_);
		y = ((int) ((energy_[j] - (double) min_int_)*dy_)) + ymargin_;
		y = height_ - y;
		if (i != 0) {
			if (i == max_iterations_) 
				g.drawLine(old_x,old_y, x, old_y); 
			else 		
				g.drawLine(old_x,old_y, x,y);
		}
		old_x = x;
		old_y = y;			
	}
	g.setFont(new Font("Times", Font.PLAIN, 12));
	g.drawString("-"+Integer.toString(max_iterations_),xmargin_-10, (height_ - ymargin_) + 12);
	g.drawString("0",(width_ - xmargin_), (height_ - ymargin_) + 12);
	if (max_energy_ < min_energy_) {
		g.drawString(Integer.toString(0),xmargin_ - 15, ymargin_ + 2);
		g.drawString(Integer.toString(0),xmargin_ - 15, height_ - ymargin_);
	}
	else {
		g.drawString(Integer.toString(max_int_),xmargin_ - 15, ymargin_ + 2);
		g.drawString(Integer.toString(min_int_),xmargin_ - 15, height_ - ymargin_);
	}
    }
}
