
import java.awt.*;

interface WV_SpringLoaded {
  
  public boolean isSelected();
  public void select();
  public void deselect();

  public int getSpringForce(Component c);
  public boolean addConnection(Component c);
  public boolean removeConnection(Component c);
  public WV_ComponentVector connections();
}
