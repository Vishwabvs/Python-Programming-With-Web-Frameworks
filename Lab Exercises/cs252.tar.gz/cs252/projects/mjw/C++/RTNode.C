/****************************************************************/
/*    NAME:                                                     */
/*    ACCT: mjw                                                 */
/*    FILE: RTNode.C                                            */
/*    ASGN:                                                     */
/*    DATE: Wed Apr 10 17:50:10 1996                            */
/****************************************************************/

#include "RTNode.H"
#include <assert.h>




/****************************************************************/
/*                                                              */
/* Function Name: RTNode                                        */
/* Parameters:    void                                          */
/* Returns:       nothing                                       */
/* Effects:							*/
/*                                                              */
/****************************************************************/

RTNode::RTNode()
{
}



/****************************************************************/
/*                                                              */
/* Function Name: ~RTNode                                       */
/* Parameters:     none                                         */
/* Returns:        nothing                                      */
/* Effects:							*/
/*                                                              */
/****************************************************************/

RTNode::~RTNode()
{
}


/****************************************************************/
/*                                                              */
/* Function Name: setChild                                      */
/* Parameters:    CHILD which -- which child to set             */
/*                RTNode node -- new node                       */
/* Returns:       void                                          */
/* Effects:       Sete the specified child node to the given    */
/*                node                                          */
/*                                                              */
/****************************************************************/

void
RTNode::setChild(CHILD which, RTNode *node)
{
    //assert(node != NULL);
    switch (which) {
    case LEFT_CHILD:  left_child_ = node; break;
    case RIGHT_CHILD: right_child_ = node; break;
    default: assert(false);
    };
}


/****************************************************************/
/*                                                              */
/* Function Name: getChild                                      */
/* Parameters:    CHILD -- specifying which child to retrieve   */
/* Returns:       RTNode*                                       */
/* Effects:       If the specified child exists than a pointer  */
/*                to it is returned.  Otherwise, NULL is        */
/*                returned.                                     */
/*                                                              */
/****************************************************************/

RTNode*
RTNode::getChild(CHILD which) const
{
    switch (which) {
    case LEFT_CHILD: 	return (RTNode*)left_child_; 
    case RIGHT_CHILD:   return (RTNode*)right_child_;
    default: assert(false);
    };
    return NULL;
}



/****************************************************************/
/*                                                              */
/* Function Name: getParent                                     */
/* Parameters:    none                                          */
/* Returns:       RTNode* -- pointer to the parent              */
/* Effects:       If the parent exists, a pointer to it is      */
/*                returned.  Otherwise, NULL is returned.       */
/*                                                              */
/****************************************************************/


RTNode* RTNode::getParent() const
{
    return (RTNode*)parent_;
}


