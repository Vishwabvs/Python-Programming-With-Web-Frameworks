/*
 * BinaryTree.java
 *
 * Description:
 *    This class is the BinaryTree class and has all methods for creating,
 *    and outputing the BinaryTree
 */
import java.awt.Font;
import java.awt.Graphics;
import java.awt.FontMetrics;

class BinaryTree
{
   protected TreeNode root = null;     // root tree node
   private boolean typesSeen = false;  // flag which indicates the type of object stored into
                                       // the tree is known, a binary tree can
                                       // contain only the same type of object
   private String treeKeyType = null;  // the type of the key
   private String treeDataType = null; // the type of the data
   // the following values are used for drawing the binary tree
   int keyXPosition;
   int keyYPosition;
   int savedKeyXPosition;
   int savedKeyYPosition;

   // the constructor for the BinaryTree
   public void BinaryTree()
   {
      keyXPosition = 10000;
      keyYPosition = -10000;
      savedKeyXPosition = 10000;
      savedKeyYPosition = 10000;
      root = null;
   }

   // return the root to the caller
   protected TreeNode getRoot()
   {
      return root;
   }

   // set the root node
   protected void setRoot(TreeNode newRoot)
   {
      root = newRoot;
   }

   // reset the positioning values
   protected void reinitializeValues()
   {
      keyXPosition = 10000;
      keyYPosition = -10000;
      savedKeyXPosition = 10000;
      savedKeyYPosition = 10000;
   }

   // restore the key positioning values to the saved values
   protected void restoreKeyValues()
   {
      keyXPosition = savedKeyXPosition;
      keyYPosition = savedKeyYPosition;
   }

   // set the key positioning values
   protected void setKeyValues()
   {
      keyXPosition = 0;
      savedKeyXPosition = keyXPosition;
      savedKeyYPosition = keyYPosition;
   }

   // compare two objects: return -1 if the first object is less than the other
   // return 1 if the first object is greater, return 0 if they are equal
   public int compareTo(Object KeyValue, Object otherObject)
   {
      if (treeKeyType.equals("java.lang.String"))
      {
         return ((String) KeyValue).compareTo((String) otherObject);
      }
      else if (treeKeyType.equals("java.lang.Integer"))
      {
         if (((Integer) KeyValue).intValue() < ((Integer) otherObject).intValue())
         {
            return -1;
         }
         else
         {
            if (((Integer) KeyValue).intValue() == ((Integer) otherObject).intValue())
            {
               return 0;
            }
            else
            {
               return 1;
            }
         }
      }
      else if (treeKeyType.equals("java.lang.Float"))
      {
         if (((Float) KeyValue).floatValue() < ((Float) otherObject).floatValue())
         {
            return -1;
         }
         else
         {
            if (((Float) KeyValue).floatValue() == ((Float) otherObject).floatValue())
            {
               return 0;
            }
            else
            {
               return 1;
            }
         }
      }
      else if (treeKeyType.equals("java.lang.Double"))
      {
         if (((Double) KeyValue).doubleValue() < ((Double) otherObject).doubleValue())
         {
            return -1;
         }
         else
         {
            if (((Double) KeyValue).doubleValue() == ((Double) otherObject).doubleValue())
            {
               return 0;
            }
            else
            {
               return 1;
            }
         }
      }
      else if (treeKeyType.equals("java.lang.Long"))
      {
         if (((Long) KeyValue).longValue() < ((Long) otherObject).longValue())
         {
            return -1;
         }
         else
         {
            if (((Long) KeyValue).longValue() == ((Long) otherObject).longValue())
            {
               return 0;
            }
            else
            {
               return 1;
            }
         }
      }
      else
      {
         return 0;
      }
   }

   // create a new TreeNode
   public TreeNode create(Object keyValue, Object value)
   {
      TreeNode node;

	  node = new TreeNode(keyValue, value);
      return node;
   }

   // insert the TreeNode into the tree, most algorithms discard multiple hits,
   // this algorithm will maintain a vector of multiple hit objects that have
   // the same key
   public TreeNode insert(TreeNode newTreeNode)
   {
	  TreeNode parent = null;
	  TreeNode node;
	  boolean valueSeen = false;

      // determine the type of tree if this is the first TreeNode, otherwise
      // ensure compatability
      if (typesSeen == false)
      {
         treeKeyType = newTreeNode.getKey().getClass().getName();
         treeDataType = newTreeNode.getData().getClass().getName();
         typesSeen = true;
      }
      else
      {
         if (treeKeyType.equals(newTreeNode.getKey().getClass().getName()) == false)
         {
            System.out.println("Incompatible types: " + "treeKeyType is " + treeKeyType +
                               " and keyValue is " +
                               newTreeNode.getKey().getClass().getName());
            return null;
         }
      }
	  node = root;
	  while (node != null)
	  {
		 parent = node;

		 if (compareTo(newTreeNode.key, node.key) < 0)
		 {
	        node = node.leftChild;
		 }
		 else
		 {
		    if (compareTo(newTreeNode.key, node.key) > 0)
		    {
		       node = node.rightChild;
		    }
		    else
		    {
               node.addToMultHitList(newTreeNode);
		       valueSeen = true;
               return node;
		    }
		 }
	  }
	  if (valueSeen == false)
	  {
	     newTreeNode.parent = parent;
		 if (parent == null)
		 {
		    root = newTreeNode;
		 }
		 else
		 {
		    if (compareTo(newTreeNode.key, parent.key) < 0)
		    {
		       parent.leftChild = newTreeNode;
		    }
		    else
		    {
		       parent.rightChild = newTreeNode;
		    }
		 }
         return newTreeNode;
	  }
      return null;
   }

   // walk the tree in preorder
   public void preOrderTraversal()
   {
	  preOrderHelper(root);
   }

   // output the key value if the node is not null
   private void preOrderHelper(TreeNode node)
   {
	  if (node != null)
      {
         System.out.println(node.getKey());
		 preOrderHelper(node.leftChild);
		 preOrderHelper(node.rightChild);
   	  }
   }

   // walk the tree in postorder, to calculate the positions of
   // the nodes
   public void postOrderPlacement()
   {
      if (root != null)
      {
         root.xPosition = 100;
         root.yPosition = 100;
	     postOrderPlacementHelper(root);
         preOrderPlacementHelper(root);
      }
   }

   // walk the tree to get the positions of the nodes
   private void preOrderPlacementHelper(TreeNode node)
   {
	  if (node != null)
	  {
         if (node.parent != null)
         {
            int numberNodesSibling;
            int subTreeWidthSibling;
            if (node == node.parent.leftChild)
            {
               if (node.parent.rightChild != null)
               {
                  numberNodesSibling = node.parent.rightChild.numberNodes;
                  subTreeWidthSibling = node.parent.rightChild.subTreeWidth;
               }
               else
               {
                  numberNodesSibling = 0;
                  subTreeWidthSibling = 0;
               }
            }
            else
            {
               if (node.parent.leftChild != null)
               {
                  numberNodesSibling = node.parent.leftChild.numberNodes;
                  subTreeWidthSibling = node.parent.leftChild.subTreeWidth;
               }
               else
               {
                  numberNodesSibling = 0;
                  subTreeWidthSibling = 0;
               }
            }
            if ((node.numberNodes < numberNodesSibling) ||
                ((node.numberNodes == numberNodesSibling) &&
                (node == node.parent.leftChild)))
            {
               node.xPosition = node.parent.xPosition;
               node.yPosition = node.parent.yPosition + 105;
            }
            else
            {
               node.xPosition = node.parent.xPosition + subTreeWidthSibling + 105;
               node.yPosition = node.parent.yPosition;
            }
         }
		 preOrderPlacementHelper(node.leftChild);
		 preOrderPlacementHelper(node.rightChild);
   	  }
   }

   // helper for the placement of nodes
   private void postOrderPlacementHelper(TreeNode node)
   {
	  if (node != null)
	  {
		 postOrderPlacementHelper(node.leftChild);
		 postOrderPlacementHelper(node.rightChild);
         if (node.leftChild != null)
         {
            node.numberNodes += node.leftChild.numberNodes;
            node.subTreeWidth += node.leftChild.subTreeWidth;
         }
         if (node.rightChild != null)
         {
            node.numberNodes += node.rightChild.numberNodes;
            node.subTreeWidth += node.rightChild.subTreeWidth;
         }
         node.numberNodes++;
         if ((node.leftChild != null) || (node.rightChild != null))
         {
            node.subTreeWidth += 105;
         }
      }
   }

   // in order drawing of the nodes
   public void inOrderDrawTraversal(Graphics g)
   {
	  inOrderDrawHelper(root, g);
   }

   // draws box around node
   protected void drawBoxAroundNode(TreeNode node, Graphics g)
   {
      g.drawRect(node.xPosition - 40, node.yPosition - 40, 80, 80);
   }

   // draws lines between connected nodes
   protected void drawLineBetweenNodes(TreeNode node, Graphics g)
   {
      if (node.parent != null)
      {
         if (node.xPosition == node.parent.xPosition)
         {
            if (node.yPosition > node.parent.yPosition)
            {
               g.drawLine(node.xPosition, node.yPosition - 40,
                          node.parent.xPosition, node.parent.yPosition + 40);
            }
            else
            {
               g.drawLine(node.xPosition, node.yPosition + 40,
                          node.parent.xPosition, node.parent.yPosition - 40);
            }
         }
         else
         {
            if (node.xPosition > node.parent.xPosition)
            {
               g.drawLine(node.xPosition - 40, node.yPosition,
                          node.parent.xPosition + 40, node.parent.yPosition);
            }
            else
            {
               g.drawLine(node.xPosition + 40, node.yPosition,
                          node.parent.xPosition - 40,
                          node.parent.yPosition);
            }
         }
      }
   }

   // helper routine for the inorder drawing of nodes
   private void inOrderDrawHelper(TreeNode node, Graphics g)
   {
      Font f = g.getFont();
      FontMetrics fm = g.getFontMetrics(f);
	  if (node != null)
	  {
		 inOrderDrawHelper(node.leftChild, g);
         drawLineBetweenNodes(node, g);
         g.drawOval(node.xPosition - 40, node.yPosition - 40, 80, 80);
         g.drawString(node.getKey().toString(),
                      node.xPosition - fm.stringWidth(node.getKey().toString()) / 2,
                      node.yPosition + fm.getAscent() / 2);
		 inOrderDrawHelper(node.rightChild, g);
	  }
   }

   // inorder printing of node keys
   public void inOrderTraversal()
   {
	  inOrderHelper(root);
   }

   // helper for inorder printing of node keys
   private void inOrderHelper(TreeNode node)
   {
	  if (node != null)
	  {
		 inOrderHelper(node.leftChild);
         System.out.println(node.getKey());
		 inOrderHelper(node.rightChild);
	  }
   }

   // postorder printing of node keys
   public void postOrderTraversal()
   {
	  postOrderHelper(root);
   }

   // helper for postorder printing of node keys
   private void postOrderHelper(TreeNode node)
   {
	  if (node != null)
	  {
		 postOrderHelper(node.leftChild);
		 postOrderHelper(node.rightChild);
         System.out.println(node.getKey());
      }
   }

   // search tree for specified object key value
   public TreeNode treeSearch(Object value)
   {
	  return treeSearchHelper(root, value);
   }

   // helper for key search
   protected TreeNode treeSearchHelper(TreeNode node, Object keyValue)
   {
	  if ((node == null) || (compareTo(keyValue, node.key) == 0))
	  {
		 return node;
	  }
	  else
	  {
		 if (compareTo(keyValue, node.key) < 0)
	     {
		    return treeSearchHelper(node.leftChild, keyValue);
		 }
		 else
		 {
		    return treeSearchHelper(node.rightChild, keyValue);
		 }
	  }
   }

   // find left most leaf node
   public TreeNode treeMinimum(TreeNode node)
   {
	  while (node.leftChild != null)
      {
		 node = node.leftChild;
	  }
	  return node;
   }

   // find right most leaf node
   private TreeNode treeMaximum(TreeNode node)
   {
	  while (node.rightChild != null)
	  {
		 node = node.rightChild;
	  }
	  return node;
   }

   // find node that follows the specified node
   public TreeNode treeSuccessor(TreeNode node)
   {
	  TreeNode returnNode;

      if (node.rightChild != null)
	  {
		 return treeMinimum(node.rightChild);
	  }
	  returnNode = node.parent;
	  while ((returnNode != null) &&
             (node == returnNode.rightChild))
	  {
		 node = returnNode;
		 returnNode = returnNode.parent;
	  }
	  return returnNode;
   }

   // find the node that precedes the specified node
   public TreeNode treePredecessor(TreeNode node)
   {
	  TreeNode returnNode;

      if (node.leftChild != null)
	  {
		 return treeMaximum(node.leftChild);
	  }
	  returnNode = node.parent;
	  while ((returnNode != null) && (node == returnNode.leftChild))
	  {
		 node = returnNode;
		 returnNode = returnNode.parent;
	  }
	  return returnNode;
   }

   // delete the node with the specified key from the tree
   public void treeDelete(Object keyValue)
   {
	  TreeNode node;
	  TreeNode temp;
	  TreeNode tempNode;

      node = treeSearchHelper(root, keyValue);
	  if ((node.leftChild == null) || (node.rightChild == null))
	  {
		 temp = node;
	  }
	  else
	  {
		 temp = treeSuccessor(node);
	  }
	  if (temp.leftChild != null)
	  {
		 tempNode = temp.leftChild;
	  }
	  else
	  {
		 tempNode = temp.rightChild;
	  }
	  if (tempNode != null)
	  {
		 tempNode.parent = temp.parent;
	  }
	  if (temp.parent == null)
	  {
		 root = tempNode;
	  }
	  else
	  {
		 if (temp == (temp.parent).leftChild)
		 {
		    (temp.parent).leftChild = tempNode;
		 }
		 else
		 {
		    (temp.parent).rightChild = tempNode;
		 }
	  }
	  if (temp != node)
	  {
		 node.data = temp.getData();
         node.key = temp.getKey();
	  }
   }
};
