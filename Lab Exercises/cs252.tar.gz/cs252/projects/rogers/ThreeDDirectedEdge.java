/** Brian Rogers
    cs252
    spring 1996
    Final Project */
    
import java.awt.*;


/** ThreeDDirectedEdge
    This is a subclass of ThreeDEdge that is drawn with an arrow pointing from 
    vertex 1 to vertex 2. */
    
public class ThreeDDirectedEdge extends ThreeDEdge {

     public static final int TRIANGLE_HEIGHT = 10;
     public static final int TRIANGLE_WIDTH = 4;

     public ThreeDDirectedEdge (ThreeDVertex vert1, ThreeDVertex vert2,
                                Color color) {
          super(vert1, vert2, color);
     }



     public void draw (Graphics grafix) {
          super.draw(grafix);

	  ThreeDVector app1 = vert_1.apparent();
	  ThreeDVector app2 = vert_2.apparent();

	  double x1 = (double)(app1.xCoord());
	  double x2 = (double)(app2.xCoord());

	  double y1 = (double)(app1.yCoord());
	  double y2 = (double)(app2.yCoord());

	  double theta = Math.atan((y2-y1) / (x2-x1));

	  double basex;
	  double basey;

          if (x2 > x1) {
               basex = x2 - TRIANGLE_HEIGHT*Math.cos(theta);
	       basey = y2 - TRIANGLE_HEIGHT*Math.sin(theta);
	  }
	  else {
	       basex = x2 + TRIANGLE_HEIGHT*Math.cos(theta);
	       basey = y2 + TRIANGLE_HEIGHT*Math.sin(theta);
	  }

          double leftx = basex - TRIANGLE_WIDTH*Math.sin(theta);
	  double lefty = basey + TRIANGLE_WIDTH*Math.cos(theta);

	  double rightx = basex + TRIANGLE_WIDTH*Math.sin(theta);
	  double righty = basey - TRIANGLE_WIDTH*Math.cos(theta);

	  int drawx = (int)(x2 + CANVAS_DIMENSION/2);
	  int drawy = (int)(CANVAS_DIMENSION/2 - y2);

	  int drawleftx = (int)(leftx + CANVAS_DIMENSION/2);
	  int drawlefty = (int)(CANVAS_DIMENSION/2 - lefty);

	  int drawrightx = (int)(rightx + CANVAS_DIMENSION/2);
	  int drawrighty = (int)(CANVAS_DIMENSION/2 - righty);

	  int xs[] = {drawx, drawleftx, drawrightx};
	  int ys[] = {drawy, drawlefty, drawrighty};
	  
	  grafix.fillPolygon(xs, ys, 3);
     }
}	  
