/*
 * @(#)DrawTreeCommand.java 1.0 1/13/96 Michael John Radwin
 */
 
package mjr.pstree;

import leda.*;
import graph.*;
import java.awt.*;
import java.util.NoSuchElementException;

public class DrawTreeCommand extends PSTCommand {
    PSTGraph graph;
    ParameterInfo info;
    
    public DrawTreeCommand(PSTGraph graph, ParameterInfo info)
    {
	this.graph = graph;
	this.info = info;
    }

    public Object _execute(ps_item p) throws NoSuchElementException
    {
	PSTNode n = makeSplit(p);
	if (n != null) {
	    p.client_data = n;
	    drawEdge(p, n);
	}

	return null;
    }
    
    public PSTNode makeSplit(ps_item p)
    {
	if (p.x_value() <= 0 || p.y_value() <= 0)
	    return null;
	
	PSTNode n = graph.getNodeAt(p.x_value(), p.y_value());
	if (n != null)
	    n.makeSplitLine(p);
	else
	    System.err.println("makeSplit found a weird node: " + p);

	return n;
    }
    
    protected PSTNode getNode(ps_item p, PSTNode parent)
    {
	if (p != null && p.x_value() > 0 && p.y_value() > 0) {
	    PSTNode result = graph.getNodeAt(p.x_value(), p.y_value());
	    if (result == null) {
		System.err.println("Graph couldn't find node at " +
				   p.x_value()+", "+p.y_value());
		throw new NoSuchElementException();
	    }
	    if (result == parent) {
		System.err.println("Child is same point as parent!? " +
				   p.x_value()+", "+p.y_value());
		throw new NoSuchElementException();
	    }
	    return result;
	}
	return null;
    }


    public void drawEdge(ps_item p, PSTNode n)	throws NoSuchElementException
    {
	Node l = null, r = null;
	ps_item leftChild = p.left_child();
	ps_item rightChild = p.right_child();
//	System.err.println("DTCommand got: " + p.toString());
	if (p.x_value() <= 0 || p.y_value() <= 0)
	    return;
	
	l = getNode(leftChild, n);
	if (l != null) {
	    PSTEdge e = new PSTEdge(graph, n, l, info.LEFT_EDGE);
	    e.Anchor();
	    e.ZToBottom();
	}
	
	r = getNode(rightChild, n);
	if (r != null) {
	    PSTEdge e = new PSTEdge(graph, n, r, info.RIGHT_EDGE);
	    e.Anchor();
	    e.ZToBottom();
	}

	return;
    }
    public static void mjr() { ; }
}
