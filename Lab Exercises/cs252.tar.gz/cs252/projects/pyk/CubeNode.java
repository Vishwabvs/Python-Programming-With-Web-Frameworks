/*
 * CubeNode.java
 *
 * Description:
 *    This class is the CubeNode class and has all methods and variables
 *    for creating, and manipulating the cubes
 */
import java.awt.Graphics;
import java.awt.Color;
import java.awt.Rectangle;

class CubeNode
{
   Rectangle frontFace;      // front face of the cube
   Rectangle backFace;       // back face of the cube
   RangeApp appParent;       // parent is the application
   int frontZPosition;       // z position of the front face
   int backZPosition;        // z position of the back face
   Color color;              // color of the front face
   Color backFaceColor;      // color of the back face and lines
                             // that connect fron and back faces
   int colorUnit;            // integer value of red component of
                             // front face
   int backFaceColorUnit;    // integer value of red component of
                             // back face
   int depth;                // depth of the cube
   int width;                // width of the cube
   int height;               // height of the cube
   int cubeID;               // unique cube id
   int xDiff;                // x difference between front face and
                             // back face
   int yDiff;                // y difference between front face and
                             // back face
   double unitXDiff;         // unit x difference between front face and
                             // back face
   double unitYDiff;         // unit y difference between front face and
                             // back face
   double xRemainder;        // x running remainder
   double yRemainder;        // y running remainder
   boolean depthChanged;     // was the depth changed
   final int XORIGIN = 266;  // x value of center of drawing canvas
   final int YORIGIN = 266;  // y value of center of drawing canvas

   // constructor for cube node
   CubeNode(int x, int y, int width, int height, int ID)
   {
      frontFace = new Rectangle(x, y, width, height);
      frontZPosition = 0;
      depthChanged = false;
      color = new Color(150, 150, 150);
      colorUnit = 150;
      cubeID = ID;
      backFaceColorUnit = 190;
      backFaceColor = new Color(190, 190, 190);
      createBackFace();
      xRemainder = 0;
      yRemainder = 0;
   }

   // set the parent application value
   public void setAppParent(RangeApp parent)
   {
      appParent = parent;
   }

   // return the cube's id
   public int getID()
   {
      return cubeID;
   }

   // create the back face
   public void createBackFace()
   {
      if (depthChanged)
      {
        positionChangedBackFace();
      }
      else
      {
        createInitialBackFace();
      }
   }

   // position the changed back face in relation to the front face
   // to maintain the illusion of 1 point perspective
   public void positionChangedBackFace()
   {
      int tempX;
      int tempY;


      xDiff = (int) (((266.0 - frontFace.x) * unitXDiff) / 266.0);
      yDiff = (int) (((266.0 - frontFace.y) * unitYDiff) / 266.0);
      if (xDiff > 0)
      {

         tempX = frontFace.x - xDiff;
/*
         tempX = frontFace.x + (int) Math.round((double) xDiff * (1.0 - (2.0 *
                 (double) frontFace.x / 532.0)));
*/
      }
      else
      {
         tempX = frontFace.x - xDiff;
/*
         tempX = frontFace.x - (int) Math.round((double) xDiff * (1.0 - (2.0 *
                 (double) frontFace.x / 532.0)));
*/
      }
      if (yDiff > 0)
      {
         tempY = frontFace.y - yDiff;
/*
         tempY = frontFace.y + (int) Math.round((double) yDiff * (1.0 - (2.0 *
                (double) frontFace.y / 532.0)));
*/
      }
      else
      {
         tempY = frontFace.y - yDiff;
/*
         tempY = frontFace.y - (int) Math.round((double) yDiff * (1.0 - (2.0 *
                (double) frontFace.y / 532.0)));
*/
      }
      backFace = new Rectangle(tempX, tempY, backFace.width, backFace.height);
   }

   // create the initial back face, it will be a set distance from the
   // front face in order to give the illusion of 1 point perspective
   public void createInitialBackFace()
   {
      int tempWidth;
      int tempHeight;
      int tempX;
      int tempY;

      tempWidth = frontFace.width;
      if (tempWidth > 1)
      {
         tempWidth = (int) Math.round(((double) (tempWidth * 8)) / 10.0) ;
      }
      else
      {
         tempWidth = 1;
      }
      tempHeight = frontFace.height;
      if (tempHeight > 1)
      {
         tempHeight = (int) Math.round(((double) (tempHeight * 8)) / 10.0) ;
      }
      else
      {
         tempHeight = 1;
      }
      tempX = frontFace.x + ((int) Math.round(((0.5 - ((double) frontFace.x) /
                             (532.0 - (double) frontFace.width)) * frontFace.width)));
      tempY = frontFace.y + ((int) Math.round(((0.5 - ((double) frontFace.y) /
                             (532.0 - (double) frontFace.height)) * frontFace.height)));
      backFace = new Rectangle(tempX, tempY, tempWidth, tempHeight);
      backZPosition = -4;
      xDiff = backFace.x - frontFace.x;
      yDiff = backFace.y - frontFace.y;
      if (frontFace.x != 266)
      {
         unitXDiff = (long) ((long) xDiff * 266.0) / ((long) frontFace.x - 266.0);
      }
      else
      {
         unitXDiff = 1;
      }
      if (frontFace.y != 266)
      {
         unitYDiff = (yDiff * 266.0) / (frontFace.y - 266.0);
      }
      else
      {
         unitYDiff = 1;
      }
   }

   // set the width and height of the front face
   public void setHeightWidth()
   {
      height = frontFace.height;
      width = frontFace.width;
   }

   // move the front face, and create a back face that maintains the
   // 1 point perspective illusion
   public void move(int x, int y)
   {
      frontFace.x = x;
      frontFace.y = y;
      createBackFace();
   }

   // resize the front face, and the back face in order to maintain
   // the 1 point perspective
   public void resize(int newWidth, int newHeight)
   {
      frontFace.width = newWidth;
      frontFace.height = newHeight;
      createBackFace();
   }

   // reposition the cube and the resulting bounding box, darken the
   // cube as it moves in the positive z direction, lighten it as
   // it moves in the negative z direction
   public Rectangle reposition(int x, int y, int z)
   {
      if ((frontFace.width > 2) || (z > 0))
      {
        frontFace.x = frontFace.x + frontFace.width / 2;
        frontFace.width = frontFace.width + (2 * z);
        frontFace.x = frontFace.x + (2 * x);
        frontFace.x = frontFace.x - frontFace.width / 2;
      }
      if ((frontFace.height > 2) || (z > 0))
      {
        frontFace.y = frontFace.y + frontFace.height / 2;
        frontFace.height = frontFace.height + (2 * z);
        frontFace.y = frontFace.y - (2 * y);
        frontFace.y = frontFace.y - frontFace.height / 2;
      }
      frontZPosition = frontZPosition + z;
      if (z < 0)
      {
         colorUnit = colorUnit + 1;
         backFaceColorUnit = backFaceColorUnit + 1;
         if (colorUnit > 200)
         {
            colorUnit = 200;
            backFaceColorUnit = 240;
         }
      }
      else
      {
         if (z > 0)
         {
            colorUnit = colorUnit - 1;
            backFaceColorUnit = backFaceColorUnit - 1;
            if (colorUnit < 0)
            {
               colorUnit = 0;
               backFaceColorUnit = 40;
            }
         }
      }
      color = new Color(colorUnit, colorUnit, colorUnit);
      backFaceColor = new Color(backFaceColorUnit, backFaceColorUnit,
                                backFaceColorUnit);
      if (depthChanged && (z != 0))
      {
         repositionBackFace(x, y, z, false);
      }
      else
      {
         createBackFace();
      }
      return getBoundingBox();
   }

   // reposition the back face of the cube, it gets darker as it moves
   // in the positive z direction, it gets lighter as it moves in the
   // negative z direction
   public Rectangle repositionBackFace(int x, int y, int z, boolean modifyBack)
   {
      if (((backZPosition + z) < frontZPosition) || (z < 0))
      {
         backZPosition = backZPosition + z;
         appParent.positionCanvas.allowGrowth(true);
         if (((backFace.width > 2) && (backFace.height > 2)) || (z > 0))
         {
            if (((backFace.width + 4 < frontFace.width) &&
                (backFace.height + 4 < frontFace.height)) || (z < 0))
            {
               backFace.x = backFace.x + backFace.width / 2;
               backFace.width = backFace.width + (2 * z);
               backFace.x = backFace.x + (2 * x);
               backFace.x = backFace.x - backFace.width / 2;
            }
         }
         if (((backFace.height > 2) && (backFace.width > 2)) || (z > 0))
         {
            if (((backFace.height + 4 < frontFace.height) &&
                (backFace.width + 4 < frontFace.width)) || (z < 0))
            {
               backFace.y = backFace.y + backFace.height / 2;
               backFace.height = backFace.height + (2 * z);
               backFace.y = backFace.y - (2 * y);
               backFace.y = backFace.y - backFace.height / 2;
            }
         }
         if (z > 0)
         {
            if (modifyBack)
            {
/*
              if ((backFace.width + 2 < frontFace.width) &&
                  (backFace.height + 2 < frontFace.height))
               {
*/
                  getBackFaceOffsets(z);
                  xDiff = backFace.x - frontFace.x;
                  yDiff = backFace.y - frontFace.y;
                  if (frontFace.x != 266)
                  {
                     unitXDiff = (xDiff * 266.0) / (frontFace.x - 266.0);
                  }
                  else
                  {
                     unitXDiff = 1;
                  }
                  if (frontFace.y != 266)
                  {
                     unitYDiff = (yDiff * 266.0) / (frontFace.y - 266.0);
                  }
                  else
                  {
                     unitYDiff = 1;
                  }
/*
               }
*/
               backFaceColorUnit = backFaceColorUnit - 1;
               if (backFaceColorUnit < 40)
               {
                  backFaceColorUnit = 40;
               }
            }
         }
         else if (z < 0)
         {
            if (modifyBack)
            {
               if ((Math.abs(xDiff) > 4) && (Math.abs(yDiff) > 4) &&
                   (backFace.width > 2) && (backFace.height > 2))
               {
                  getBackFaceOffsets(z);
                  xDiff = backFace.x - frontFace.x;
                  yDiff = backFace.y - frontFace.y;
                  if (frontFace.x != 266)
                  {
                     unitXDiff = (xDiff * 266.0) / (frontFace.x - 266.0);
                  }
                  else
                  {
                     unitXDiff = 1;
                  }
                  if (frontFace.y != 266)
                  {
                     unitYDiff = (yDiff * 266.0) / (frontFace.y - 266.0);
                  }
                  else
                  {
                     unitYDiff = 1;
                  }
               }
            }
            else
            {
/*
               if (Math.abs(xDiff) > 4)
               {
                  getBackFaceOffsets(z);
                  xDiff = backFace.x - frontFace.x;
                  if (frontFace.x != 266)
                  {
                     unitXDiff = (xDiff * 266.0) / (frontFace.x - 266.0);
                  }
                  else
                  {
                     unitXDiff = 1;
                  }
               }
               if (Math.abs(yDiff) > 4)
               {
                  getBackFaceOffsets(z);
                  yDiff = backFace.y - frontFace.y;
                  if (frontFace.y != 266)
                  {
                     unitYDiff = (yDiff * 266.0) / (frontFace.y - 266.0);
                  }
                  else
                  {
                     unitYDiff = 1;
                  }
               }
*/
            }
            backFaceColorUnit = backFaceColorUnit + 1;
            if (backFaceColorUnit > 240)
            {
               backFaceColorUnit = 240;
            }
         }
         xDiff = (int) (((266.0 - frontFace.x) * unitXDiff) / 266.0);
         yDiff = (int) (((266.0 - frontFace.y) * unitYDiff) / 266.0);
         depthChanged = true;
         backFaceColor = new Color(backFaceColorUnit, backFaceColorUnit,
                                   backFaceColorUnit);
      }
      else
      {
         appParent.positionCanvas.allowGrowth(false);
      }
      return getBoundingBox();
   }

   // calculate the difference between the two faces
   public void getBackFaceOffsets(int z)
   {
      double tempDiffX;
      double tempDiffY;
      double temp1;
      double temp2;
      double slope;

      if (backFace.x == frontFace.x)
      {
         if (backFace.x >= 266)
         {
            yRemainder = yRemainder + 2.0 * z;
         }
         else
         {
            yRemainder = yRemainder - 2.0 * z;
         }
         xRemainder = xRemainder + 0.0;
      }
      else if (backFace.y == frontFace.y)
      {
         if (backFace.y >= 266)
         {
            xRemainder = xRemainder + 2.0 * z;
         }
         else
         {
            xRemainder = xRemainder - 2.0 * z;
         }
         yRemainder = yRemainder + 0.0;
      }
      else
      {
         tempDiffY = (double) (backFace.y - frontFace.y);
         tempDiffX = (double) (backFace.x - frontFace.x);
         slope = tempDiffY / tempDiffX;
         if (Math.abs(slope) > 1)
         {
            if (slope < 0.0)
            {
               if (tempDiffY < 0.0)
               {
                  yRemainder = yRemainder + 2.0 * z;
                  xRemainder = xRemainder - (z * 2.0) / slope;
               }
               else
               {
                  yRemainder = yRemainder - 2.0 * z;
                  xRemainder = xRemainder + (z * 2.0) / slope;
              }
            }
            else
            {
               if (tempDiffY < 0.0)
               {
                  yRemainder = yRemainder + 2.0 * z;
                  xRemainder = xRemainder + (z * 2.0) / slope;
               }
               else
               {
                  yRemainder = yRemainder - 2.0 * z;
                  xRemainder = xRemainder - (z * 2.0) / slope;
               }
            }
         }
         else if (Math.abs(slope) < 1.0)
         {
            if (slope < 0.0)
            {
               if (tempDiffY < 0.0)
               {
                  xRemainder = xRemainder - 2.0 * z;
                  yRemainder = yRemainder + (2.0 * z) * slope;
               }
               else
               {
                  xRemainder = xRemainder + 2.0 * z;
                  yRemainder = yRemainder - (2.0 * z) * slope;
               }
            }
            else
            {
               if (tempDiffY < 0.0)
               {
                  xRemainder = xRemainder + 2.0 * z;
                  yRemainder = yRemainder + (2.0 * z) * slope;
               }
               else
               {
                  xRemainder = xRemainder - 2.0 * z;
                  yRemainder = yRemainder - (2.0 * z) * slope;
               }
            }
         }
         else
         {
            if (slope < 0)
            {
               if (tempDiffX < 0.0)
               {
                  xRemainder = xRemainder + 2.0 * z;
                  yRemainder = yRemainder - 2.0 * z;
               }
               else
               {
                  xRemainder = xRemainder - 2.0 * z;
                  yRemainder = yRemainder + 2.0 * z;
               }
            }
            else
            {
               if (tempDiffX < 0.0)
               {
                  xRemainder = xRemainder + 2.0 * z;
                  yRemainder = yRemainder + 2.0 * z;
               }
               else
               {
                  xRemainder = xRemainder - 2.0 * z;
                  yRemainder = yRemainder - 2.0 * z;
               }
            }
         }
      }
      if (xRemainder >= 1.0)
      {
         if (backFace.x >= 266)
         {
            backFace.x = backFace.x + (int) Math.floor(xRemainder) * z;
         }
         else
         {
            backFace.x = backFace.x - (int) Math.floor(xRemainder) * z;
         }
         xRemainder = xRemainder - Math.floor(xRemainder);
      }
      else if (xRemainder <= -1.0)
      {
         if (backFace.x >= 266)
         {
            backFace.x = backFace.x - (int) Math.floor(xRemainder) * z;
         }
         else
         {
            backFace.x = backFace.x + (int) Math.floor(xRemainder) * z;
         }
         xRemainder = xRemainder - Math.floor(xRemainder);
      }
      if (yRemainder >= 1.0)
      {
         if (backFace.y >= 266)
         {
            backFace.y = backFace.y + (int) Math.floor(yRemainder) * z;
         }
         else
         {
            backFace.y = backFace.y - (int) Math.floor(yRemainder) * z;
         }
         yRemainder = yRemainder - Math.floor(yRemainder);
      }
      else if (yRemainder <= -1.0)
      {
         if (backFace.y >= 266)
         {
            backFace.y = backFace.y - (int) Math.floor(yRemainder) * z;
         }
         else
         {
            backFace.y = backFace.y + (int) Math.floor(yRemainder) * z;
         }
         yRemainder = yRemainder - Math.floor(yRemainder);
      }
   }


    // get the bounding box of the cube
    public Rectangle getBoundingBox()
    {
       Rectangle boundingBox;
       int x;
       int y;
       int tempWidth;
       int tempHeight;

       x = getMinX();
       y = getMinY();
       tempWidth = getMaxX() - x;
       tempHeight = getMaxY() - y;
       boundingBox = new Rectangle(x, y, tempWidth, tempHeight);
       return boundingBox;
     }

     // get the minimum x value of the two faces
     public int getMinX()
     {
        return Math.min(Math.min(frontFace.x, frontFace.x + frontFace.width),
                        Math.min(backFace.x, backFace.x + backFace.width));
     }

     // get the minimum y value of the two faces
     public int getMinY()
     {
        return Math.min(Math.min(frontFace.y, frontFace.y + frontFace.height),
                        Math.min(backFace.y, backFace.y + backFace.height));
     }

     // get the maximum x value of the two faces
     public int getMaxX()
     {
        return Math.max(Math.max(frontFace.x, frontFace.x + frontFace.width),
                        Math.max(backFace.x, backFace.x + backFace.width));
     }

     // get the maximum y value of the two faces
     public int getMaxY()
     {
        return Math.max(Math.max(frontFace.y, frontFace.y + frontFace.height),
                        Math.max(backFace.y, backFace.y + backFace.height));
     }

     // get the x position of the front face
     public int getXPosition()
     {
        return frontFace.x;
     }

     // get the y position of the front face
     public int getYPosition()
     {
        return frontFace.y;
     }

     // get the z position of the front face
     public int getZPosition()
     {
        return frontZPosition;
     }

     // get the width of the front face
     public int getWidth()
     {
        return frontFace.width;
     }

     // get the height of the front face
     public int getHeight()
     {
        return frontFace.height;
     }

     // change the color of the front face
     public void changeColor(Color newColor)
     {
        color = newColor;
        colorUnit = newColor.getRed();
     }

     // get the red component of the front face
     public int getColorUnit()
     {
        return colorUnit;
     }

     // draw the cube as two faces connected by 4 lines
     public void drawCube(Graphics g, boolean useObjectColor)
     {
        Color savedColor = g.getColor();
        if (useObjectColor)
        {
           g.setColor(color);
        }
        g.drawRect(frontFace.x, frontFace.y, frontFace.width, frontFace.height);
        if (useObjectColor)
        {
           g.setColor(backFaceColor);
        }
        g.drawRect(backFace.x, backFace.y, backFace.width, backFace.height);
        g.drawLine(frontFace.x, frontFace.y, backFace.x, backFace.y);
        g.drawLine(frontFace.x + frontFace.width, frontFace.y,
                   backFace.x + backFace.width, backFace.y);
        g.drawLine(frontFace.x + frontFace.width, frontFace.y + frontFace.height,
                   backFace.x + backFace.width, backFace.y + backFace.height);
        g.drawLine(frontFace.x, frontFace.y + frontFace.height,
                   backFace.x, backFace.y + backFace.height);
        g.setColor(savedColor);
     }
}
