package sprite;

import java.awt.*;

public class AnimationThread extends Thread {
    AnimationLock lock_;
    
    Sprite sprite_;
    int chunks_, delay_;
    int x1_, y1_, xDist_, yDist_;
    boolean hide_, anchor_;
    
    public AnimationThread(AnimationLock lock, Sprite sprite,
			   int x2, int y2, int chunks, int delay,
			   boolean hide, boolean anchor) {
	lock_ = lock;
	sprite_ = sprite;
	chunks_ = chunks;
	delay_ = delay;
	x1_ = sprite_.x_; y1_ = sprite_.y_;
	xDist_ = x2 - x1_; yDist_ = y2 - y1_;
	hide_ = hide;
	anchor_ = anchor;
	if (lock_ != null)
	    lock_.StartAnimation();
	start();
    }
    
    public void run() {
	sprite_.Show();
	long time = System.currentTimeMillis();
	for (int pos = 0; pos < chunks_; ++pos) {
	    if (chunks_ > 1) {
		double p = (double)pos / (double)(chunks_ - 1);
		int x = (int)((double)x1_ + (double)xDist_ * p);
		int y = (int)((double)y1_ + (double)yDist_ * p);
		sprite_.MoveTo(x, y);
	    }
	    else
		sprite_.MoveTo(x1_, y1_);
	    
	    try {
		time += delay_;
		long toSleep = time - System.currentTimeMillis();
		if (toSleep > 0)
		    sleep(toSleep);
		else {
		    sleep(delay_);
		    time = System.currentTimeMillis();
		}
	    }
	    catch (InterruptedException e);
	}
	
	if (hide_)
	    sprite_.Hide();
	if (anchor_)
	    sprite_.Anchor();

	if (lock_ != null)
	    lock_.FinishAnimation();
        stop();
    }
}
