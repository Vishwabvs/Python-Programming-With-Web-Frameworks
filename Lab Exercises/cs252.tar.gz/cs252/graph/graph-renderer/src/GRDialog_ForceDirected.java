/*
 *  GRDialog_ForceDirected - controls the force-directed convergence method 
 *  4/14/96 
 *  by Daniel Spirn 
 *
 */
package graphrender;

import java.awt.*;
import java.applet.*;

public class GRDialog_ForceDirected extends Frame {

    // Different controlling sliders 
    GRSlider 	sc1,sc2,sc3,sc4,sc5;

    Button 		default_button;
    Button		perturb_button;

    // reference to the graph area 
    GRGraphArea 	ga_;

    // message area to keep user updated on state of animation
    Label 		update_message_;

    public GRDialog_ForceDirected(String title, GRGraphArea ga) {
	super(title);
	this.setResizable(false);
	ga_ = ga;
    }

    public void addNotify() {
	super.addNotify();
	
	GridBagLayout gridbag = new GridBagLayout();
	GridBagConstraints c = new GridBagConstraints();
	c.fill = GridBagConstraints.BOTH;
	setLayout(gridbag);

        // builds the sliders to control constants of animation
	sc1 = new GRSlider("Attractive Force Constant",0,.0001,0.000001);
	sc2 = new GRSlider("Repulsive Force Constant",0,.0001,0.000001);
	sc3 = new GRSlider("Energy Threshold",0,0.01,0.0001);
	sc4 = new GRSlider("Optimum Length",10,200,10);
	sc5 = new GRSlider("Number of Iterations",0,200,1);

        // build rest of components
	update_message_ = new Label("stable");
	update_message_.setBackground(new Color(34,133,144));
	update_message_.setForeground(new Color(255,255,255));
	perturb_button = new Button("Perturb Graph");
	default_button = new Button("Set Constants to Default");
	perturb_button.setForeground(new Color(122,36,95));
	default_button.setForeground(new Color(122,36,95));

	sc1.setValue(ga_.animator.f_d_attractive_force_constant_);
	sc2.setValue(ga_.animator.f_d_repulsive_force_constant_);
	sc3.setValue(ga_.energy_delta_);
	sc4.setValue(ga_.animator.springLength());
	sc5.setValue(ga_.iterations_);

	c.weightx = 1.0;
	c.weighty = 1.0;
	gridbag.setConstraints(sc1,c);
	add(sc1);
	c.weightx = 1.0;
	c.weighty = 1.0;
	c.gridwidth = GridBagConstraints.REMAINDER;
	gridbag.setConstraints(sc2,c);
	add(sc2);
	c.weightx = 1.0;
	c.weighty = 1.0;
	c.gridwidth = GridBagConstraints.RELATIVE;
	gridbag.setConstraints(sc3,c);
	add(sc3);
	c.weightx = 1.0;
	c.weighty = 1.0;
	c.gridwidth = GridBagConstraints.REMAINDER;
	gridbag.setConstraints(sc4,c);
	add(sc4);
	c.weightx = 1.0;
	c.weighty = 1.0;
	c.gridwidth = GridBagConstraints.REMAINDER;
	gridbag.setConstraints(sc5,c);
	add(sc5);
	c.weightx = 1.0;
	c.weighty = 2.0;
	c.gridwidth = GridBagConstraints.RELATIVE;
	gridbag.setConstraints(perturb_button,c);
	add(perturb_button);
	c.weightx = 1.0;
	c.weighty = 2.0;
	c.gridwidth = GridBagConstraints.REMAINDER;
	gridbag.setConstraints(default_button,c);
	add(default_button);
	c.weightx = 1.0;
	c.weighty = 2.0;
	c.gridwidth = GridBagConstraints.REMAINDER;
	gridbag.setConstraints(update_message_,c);
	add(update_message_);

	pack();
//	positionOnScreen();
	show();
    }

    // moves frame to specific location on screen
    private void positionOnScreen() {
	Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
	this.move(((screen.width / 2)), (screen.height / 3) - (this.size().height));
    }

    public void show(){
	super.show();
	sc1.setValue(ga_.animator.f_d_attractive_force_constant_);
	sc2.setValue(ga_.animator.f_d_repulsive_force_constant_);
	sc3.setValue(ga_.energy_delta_);
	sc4.setValue(ga_.animator.springLength());
	sc5.setValue(ga_.iterations_);
    }

    // gets update message and puts to message board.
    public void setUpdateMessage(String string) 
    {
	update_message_.setText(string);
    }

    /** Respond to user actions. */
    public boolean handleEvent(Event e) {
	boolean handled = false;

	if (e.target instanceof GRSlider) {
		boolean a = sc1.handleEvent(e);
		boolean b = sc2.handleEvent(e);
		boolean c = sc3.handleEvent(e);
		boolean d = sc4.handleEvent(e);
		boolean f = sc5.handleEvent(e);
		ga_.animator.f_d_attractive_force_constant_ = 
			Double.valueOf(sc1.textField.getText()).doubleValue();
		ga_.animator.f_d_repulsive_force_constant_ = 
			Double.valueOf(sc2.textField.getText()).doubleValue();
		ga_.energy_delta_ = Double.valueOf(sc3.textField.getText()).doubleValue();
		ga_.animator.setSpringLength(Double.valueOf(sc4.textField.getText()).doubleValue());
		ga_.iterations_ = Integer.parseInt(sc5.textField.getText()); 

		return (a || b || c || d || f);
	} else if (e.id == Event.ACTION_EVENT) {
		if (e.arg.equals("Set Constants to Default")) {
			ga_.animator.f_d_attractive_force_constant_ = 
				ga_.animator.default_f_d_attractive_force_constant_;
			sc1.setValue(ga_.animator.f_d_attractive_force_constant_);
			ga_.animator.f_d_repulsive_force_constant_ = 
				ga_.animator.default_f_d_repulsive_force_constant_;
			sc2.setValue(ga_.animator.f_d_attractive_force_constant_);
			ga_.energy_delta_ = ga_.default_energy_delta_;
			sc3.setValue(ga_.energy_delta_);		
			ga_.animator.setDefaultSpringLength();
			sc4.setValue(ga_.animator.springLength());
			ga_.iterations_ = ga_.default_iterations_;
			sc5.setValue(ga_.iterations_);
		}
		else if (e.arg.equals("Perturb Graph")) {
			ga_.perturbGraph();
			ga_.resize();
			ga_.repaint();
			ga_.centered = false;
		}
	} else if (e.id == Event.WINDOW_DESTROY) {
		this.hide();
		this.dispose();
	}
	return(handled);
    }
}

