/** Brian Rogers
    cs252
    spring 1996
    Final Project */

import java.awt.*;


/**                             ThreeDCanvas
    This is the canvas where all of the simulation is drawn.  It has a 
    reference to the ThreeDSpace model, and an off_screen image for double
    buffering */

public class ThreeDCanvas extends Canvas {
     public static final int CANVAS_DIMENSION = 460;

     Image off_screen;

     ThreeDSpace _space;

     boolean _add = true;



     public ThreeDCanvas (ThreeDSpace space) {
          setBackground(Color.black);
	  off_screen = this.createImage(size().width, size().height);  
	  _space = space;
     }



     /** This is called when the mouse button is pressed down inside the 
         canvas.  It adds a new vertex at the mouses x, and y coordinates
	 as long as the _add flag is true (the user has control). */
     public boolean mouseDown  (Event evt, int x, int y) {
          if (_add) {
	       int appx = x - CANVAS_DIMENSION/2;
	       int appy = CANVAS_DIMENSION/2 - y;
	       _space.addVert(appx, appy);
	  }
	  return true;
     }


     /** This clears the canvas to it's background color. */
     public void clearCanvas (Graphics grafix) {
	  int width = size().width;
	  int height = size().height;
	  grafix.clearRect(1, 1, width-2, height-2);
     }


     /** This uses double buffering to redraw the contents of space on the
         canvas by using the off screen image to draw everything, and then
	 copying it's contents over the canvas. */
     public void paint (Graphics graphics) {
          if (off_screen == null)
               off_screen = this.createImage(size().width, size().height);
	  else off_screen.flush();

          Graphics grafix = off_screen.getGraphics();
	  
	  grafix.setColor(Color.black);
	  grafix.fillRect(0, 0, CANVAS_DIMENSION, CANVAS_DIMENSION);
	  
	  _space.drawFrame(grafix);
          _space.drawSpace(grafix);
	  
	  graphics.drawImage(off_screen, 0, 0, this);
     }
     
     
     
     /** These set the users ability to add vertices to the canvas */
     public void enableAdd ()    {_add = true;}
     public void disableAdd ()   {_add = false;}



     public Dimension prefferedSize () {
          return new Dimension (CANVAS_DIMENSION, CANVAS_DIMENSION);
     }
     public Dimension minimumSize () {
          return preferredSize();
     }
     public Dimension maximumSize () {
          return preferredSize();
     }	  
}
