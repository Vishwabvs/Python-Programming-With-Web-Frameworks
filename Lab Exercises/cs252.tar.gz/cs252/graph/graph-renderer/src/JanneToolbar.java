/*
 * Copyright (c) 1996 by Jan Andersson, Torpa Konsult AB.
 *
 * Permission to use, copy, and distribute this software for
 * NON-COMMERCIAL purposes and without fee is hereby granted
 * provided that this copyright notice appears in all copies.
 *
 */
package graphrender;

import java.awt.*;
import java.applet.Applet;

/**
 * A class that implements a simple toolbar panel. Based on the
 * JanneButton class.
 *
 * @version     1.5 96/01/24
 * @author      Jan Andersson, Torpa Konsult AB. (janne@torpa.se)
 */
class JanneToolbar extends Panel {
   /**
    * layout manager
    */
   GridBagLayout gridBag;
   GridBagConstraints gridConstraints;

   /**
    * flag to tell if horizontal layout is used
    */
   static boolean horizontal;

   /**
    * shadow and border widths used by the buttons
    */
   static final int shadow = 4;
   static final int border = 4;

   /**
    * flag to tell if string labels are dispayed in the buttons
    */
   static boolean showLabel = true;
  
   /**
    *
    *
    */
   static int buttonnumber = 0;
   static JanneButton[] buttons = new JanneButton[10];

   /**
    * Creates a Toolbar panel with grid layout with the specified
    * rows, columns, horizontal gap, and vertical gap.
    * @param rows the rows; zero means 'any number.'
    * @param cols the columns; zero means 'any number.'  Only one of 'rows'
    * and 'cols' can be zero, not both.
    * @param hgap the horizontal gap variable
    * @param vgap the vertical gap variable
    * @param showLabel true if the button labels should be displayed.
    */
   JanneToolbar(boolean horizontal, int gap, boolean showLabel) {
      this.horizontal = horizontal;
      this.showLabel = showLabel;

      setLayout(new GridLayout(2,5,gap,gap));

   }

   /**
    * Creates a horizontal toolbar panel.
    * Default gap (4) are used. Buttons are displayed without string label.
    */
   JanneToolbar() {
      this(true, 4, false);
   }

   /**
    * Add button.
    * @param image the button image
    * @param label the button label 
    */
   public void addButton(Image image, String label) {
      // Add button to panel. Images are not resized.
      JanneButton button = new JanneButton(
	 image, label, shadow, border, false, showLabel);

      add(button);
      buttons[buttonnumber] = button;
      buttonnumber++;
   }

   /**
    * Add button.
    * @param image the button image
    * @param label the button label 
    * @extraGap extra (leading gap)
    */
   public void addButton(Image image, String label, int extraGap) {
      // create new insets for extra gap

      // Add button to panel.
      addButton(image, label);

   }

   public void addOutsideButton(JanneButton button) {
	add(button);
   }

   public void setSelected(int number, int total)
   {
	for (int i = 0 ; i < total ; i++) {		
		if (number != i)
			buttons[i].setSelected(false);
		else
			buttons[i].setSelected(true);
		buttons[i].repaint();
	}
   }

   /** 
    * Does a (re-)layout on this panel.
    *
    * Called by JanneButton when size is updated. This is a hack to allow
    * the size of the panel to change (when images loaded) and to make sure
    * the toolbar is resized properly.
    */
   public synchronized void layout() {
      // x & y position of toolbar
      int x = 0;
      int y = 0;

      // get toolbar preferred size
      Dimension size = preferredSize();

      // center toolbar in parent (if parent known)
      Container parent = getParent();
      if (parent != null) {
	 Dimension parentSize = parent.size();
	 if (size.width < parentSize.width)
	    x = parentSize.width/2 - size.width/2;
	 if (size.height < parentSize.height)
	    y = parentSize.height/2 - size.height/2;
      }
      
      // reshape toolbar to new size and re-layout 
      reshape(x, y, size.width, size.height);
      super.layout();
   }
}
