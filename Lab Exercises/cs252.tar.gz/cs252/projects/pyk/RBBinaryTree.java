/*
 * RBBinaryTree.java
 *
 * Description:
 *    This class contains the methods and variables for building and drawing a
 *    red-black binary tree.
 */
import java.awt.Font;
import java.awt.Graphics;
import java.awt.FontMetrics;
import java.awt.Color;

class RBBinaryTree extends BinaryTree
{
    // constructor simply calls binary tree's constructor
    RBBinaryTree()
    {
       super();
    }

    // get the root of the red-black tree, this is actually the root of the
    // underlying binary tree
    public RBTreeNode RBGetRoot()
    {
       return (RBTreeNode) getRoot();
    }

    // create a red-black tree node
    public RBTreeNode RBCreate(Object KeyValue, Object Value)
    {
        RBTreeNode node = new RBTreeNode(KeyValue, Value);
        return node;
    }

    // insert the red-black tree node into the red-black tree, perform balancing
    // if necessary
    public void RBInsert(RBTreeNode newNode)
    {
        RBTreeNode tempNode;
        RBTreeNode rbNode;
        boolean unclesValue;

        RBTreeNode node = (RBTreeNode) insert((TreeNode) newNode);
        while((node != getRoot()) && (((RBTreeNode) node.parent).getValue() == true)  &&
              (node.parent.parent != null))
        {
           if (node.parent == node.parent.parent.leftChild)
           {
              tempNode = (RBTreeNode) node.parent.parent.rightChild;
              if (tempNode == null)
              {
                 unclesValue = false;
              }
              else
              {
                 unclesValue = tempNode.getValue();
              }
              if (unclesValue == true)
              {
                 rbNode = (RBTreeNode) node.parent;
                 rbNode.setValue(false);
                 tempNode.setValue(false);
                 rbNode = (RBTreeNode) node.parent.parent;
                 rbNode.setValue(true);
                 node = (RBTreeNode) node.parent.parent;
              }
              else
              {
                 if (node == (RBTreeNode) node.parent.rightChild)
                 {
                    node = (RBTreeNode) node.parent;
                    leftRotate(node);
                 }
                 rbNode = (RBTreeNode) node.parent;
                 rbNode.setValue(false);
                 rbNode = (RBTreeNode) rbNode.parent;
                 if (rbNode != null)
                 {
                    rbNode.setValue(true);
                    rightRotate(rbNode);
                 }
              }
           }
           else
           {
              tempNode = (RBTreeNode) node.parent.parent.leftChild;
              if (tempNode == null)
              {
                 unclesValue = false;
              }
              else
              {
                 unclesValue = tempNode.getValue();
              }
              if (unclesValue == true)
              {
                 rbNode = (RBTreeNode) node.parent;
                 rbNode.setValue(false);
                 tempNode.setValue(false);
                 rbNode = (RBTreeNode) node.parent.parent;
                 rbNode.setValue(true);
                 node = (RBTreeNode) node.parent.parent;
              }
              else
              {
                 if (node == (RBTreeNode) node.parent.leftChild)
                 {
                    node = (RBTreeNode) node.parent;
                    rightRotate(node);
                 }
                 rbNode = (RBTreeNode) node.parent;
                 rbNode.setValue(false);
                 rbNode = (RBTreeNode) rbNode.parent;
                 if (rbNode != null)
                 {
                    rbNode.setValue(true);
                    leftRotate(rbNode);
                 }
              }
           }
        }
        rbNode = (RBTreeNode) getRoot();
        rbNode.setValue(false);
     }

     // left rotate a branch of the red-black tree
     private void leftRotate(RBTreeNode node)
     {
        RBTreeNode rbNode;
        RBTreeNode tempNode;

        tempNode = (RBTreeNode) node.rightChild;
        if (tempNode != null)
        {
           node.rightChild = tempNode.leftChild;
           if (tempNode.leftChild != null)
           {
              tempNode.leftChild.parent = (TreeNode) node;
           }
           tempNode.parent = node.parent;
           if (node.parent == null)
           {
              setRoot(tempNode);
           }
           else
           {
              if (node == (RBTreeNode) node.parent.leftChild)
              {
                 node.parent.leftChild = tempNode;
              }
              else
              {
                 node.parent.rightChild = tempNode;
              }
           }
           tempNode.leftChild = node;
           node.parent = tempNode;
        }
     }

     // right rotate a branch of the red-black tree
     private void rightRotate(RBTreeNode node)
     {
        RBTreeNode rbNode;
        RBTreeNode tempNode;

        tempNode = (RBTreeNode) node.leftChild;
        if (tempNode != null)
        {
           node.leftChild = tempNode.rightChild;
           if (tempNode.rightChild != null)
           {
              tempNode.rightChild.parent = (TreeNode) node;
           }
           tempNode.parent = node.parent;
           if (node.parent == null)
           {
              setRoot(tempNode);
           }
           else
           {
              if (node == (RBTreeNode) node.parent.rightChild)
              {
                 node.parent.rightChild = tempNode;
              }
              else
              {
                 node.parent.leftChild = tempNode;
              }
           }
           tempNode.rightChild = node;
           node.parent = tempNode;
        }
     }

     // delete the node from the red-black tree that has the specified key
     public TreeNode rbDelete(Object keyValue)
     {
    	TreeNode node;
        TreeNode temp;
        TreeNode tempNode;

        node = treeSearchHelper(getRoot(), keyValue);
        if ((node.leftChild == null) || (node.rightChild == null))
 	    {
           temp = node;
	    }
        else
        {
           temp = treeSuccessor(node);
	    }
        if (temp.leftChild != null)
        {
           tempNode = temp.leftChild;
	    }
	    else
        {
	       tempNode = temp.rightChild;
        }
	    if (tempNode != null)
        {
           tempNode.parent = temp.parent;
	    }
	    if (temp.parent == null)
	    {
	       setRoot(tempNode);
	    }
	    else
	    {
	       if (temp == (temp.parent).leftChild)
	       {
	          (temp.parent).leftChild = tempNode;
	       }
	       else
           {
	          (temp.parent).rightChild = tempNode;
	       }
	    }
	    if (temp != node)
        {
           node.data = temp.getData();
           node.key = temp.getKey();
	    }
        RBTreeNode rbNode = (RBTreeNode) temp;
        if (rbNode.getValue() == false)
        {
           rbDeleteFixup(tempNode);
        }
        return temp;
     }

     // determine the coordinates of the nodes prior to drawing them
     public void RBCalculate()
     {
        postOrderPlacement();
     }

     // draw the red-black tree
     public void RBInOrderDrawTraversal(Graphics g)
     {
        inOrderDrawTraversal(g);
        Color savedColor = g.getColor();
        RBInOrderDrawHelper(getRoot(), g);
        g.setColor(savedColor);
     }

     // draw the red-black tree coloring the outlines of the nodes appropiately
     // (red or black)
     private void RBInOrderDrawHelper(TreeNode node, Graphics g)
     {
	    if (node != null)
	    {
	       RBInOrderDrawHelper(node.leftChild, g);
           if (((RBTreeNode) node).getValue() == false)
           {
              g.setColor(Color.black);
           }
           else
           {
              g.setColor(Color.red);
           }
           g.drawOval(node.xPosition - 40, node.yPosition - 40, 80, 80);
 	       RBInOrderDrawHelper(node.rightChild, g);
	    }
     }

     // fix the tree after deleting a node
     public void rbDeleteFixup(TreeNode node)
     {
        TreeNode tempNode;
        RBTreeNode rbNode;

        while ((node != getRoot()) && (((RBTreeNode) node).getValue() == false))
        {
           if (node == node.parent.leftChild)
           {
              tempNode = node.parent.rightChild;
              rbNode = (RBTreeNode) tempNode;
              if (rbNode.getValue() == true)
              {
                 rbNode.setValue(false);
                 rbNode = (RBTreeNode) node.parent;
                 rbNode.setValue(true);
                 leftRotate((RBTreeNode) node.parent);
                 tempNode = node.parent.rightChild;
              }
              if ((((RBTreeNode) tempNode.leftChild).getValue() == false) &&
                  (((RBTreeNode) tempNode.rightChild).getValue() == false))
              {
                 rbNode = (RBTreeNode) tempNode;
                 rbNode.setValue(true);
                 node = node.parent;
              }
              else
              {
                 if (((RBTreeNode) tempNode.rightChild).getValue() == false)
                 {
                    rbNode = (RBTreeNode) tempNode.leftChild;
                    rbNode.setValue(false);
                    rbNode = (RBTreeNode) tempNode;
                    rbNode.setValue(true);
                    rightRotate(rbNode);
                    tempNode = node.parent.rightChild;
                 }
                 rbNode = (RBTreeNode) tempNode;
                 rbNode.setValue(((RBTreeNode) node.parent).getValue());
                 rbNode = (RBTreeNode) node.parent;
                 rbNode.setValue(false);
                 rbNode = (RBTreeNode) tempNode.rightChild;
                 rbNode.setValue(false);
                 leftRotate((RBTreeNode) node.parent);
                 node = getRoot();
             }
          }
          else
          {
             tempNode = node.parent.leftChild;
             rbNode = (RBTreeNode) tempNode;
             if (rbNode.getValue() == true)
             {
                rbNode.setValue(false);
                rbNode = (RBTreeNode) node.parent;
                rbNode.setValue(true);
                rightRotate((RBTreeNode) node.parent);
                tempNode = node.parent.leftChild;
             }
             if ((((RBTreeNode) tempNode.rightChild).getValue() == false) &&
                 (((RBTreeNode) tempNode.leftChild).getValue() == false))
             {
                rbNode = (RBTreeNode) tempNode;
                rbNode.setValue(true);
                node = node.parent;
             }
             else
             {
                if (((RBTreeNode) tempNode.leftChild).getValue() == false)
                {
                   rbNode = (RBTreeNode) tempNode.rightChild;
                   rbNode.setValue(false);
                   rbNode = (RBTreeNode) tempNode;
                   rbNode.setValue(true);
                   leftRotate(rbNode);
                   tempNode = node.parent.leftChild;
                }
                rbNode = (RBTreeNode) tempNode;
                rbNode.setValue(((RBTreeNode) node.parent).getValue());
                rbNode = (RBTreeNode) node.parent;
                rbNode.setValue(false);
                rbNode = (RBTreeNode) tempNode.leftChild;
                rbNode.setValue(false);
                rightRotate((RBTreeNode) node.parent);
                node = getRoot();
             }
          }
        }
     }
};
