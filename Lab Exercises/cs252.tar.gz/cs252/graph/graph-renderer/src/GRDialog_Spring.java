/*
 *  GRDialog_Spring - controls the simple spring convergence method 
 *  4/14/96 
 *  by Daniel Spirn 
 *
 */
package graphrender;

import java.awt.*;
import java.applet.*;

public class GRDialog_Spring extends Frame {

    static final Font 	txtFont = new Font("Times", Font.PLAIN, 18);
    GRSlider 	sc1,sc2,sc3,sc4;
    Label 		update_message_;
    GRGraphArea 	ga_;

    public GRDialog_Spring(String title, GRGraphArea ga) {
	super(title);
	this.setResizable(false);
	ga_ = ga;
    }

    public void addNotify() {
	super.addNotify();

	GridBagLayout gridbag = new GridBagLayout();
	GridBagConstraints c = new GridBagConstraints();
	c.fill = GridBagConstraints.BOTH;
	setLayout(gridbag);
	
	sc1 = new GRSlider("Spring Constant",0.000001,.0001,0.0000001);
	sc2 = new GRSlider("Spring Length",10,500,10);
	sc3 = new GRSlider("Number of Iterations",0,200,1);
	sc4 = new GRSlider("Energy Threshold",0,0.01,0.0001);
	Button default_button = new Button("Set Constants to Default");
	default_button.setForeground(new Color(122,36,95));
	update_message_ = new Label("stable");
	update_message_.setBackground(new Color(34,133,144));
	update_message_.setForeground(new Color(255,255,255));

	c.weightx = 1.0;
	c.weighty = 1.0;
	gridbag.setConstraints(sc1,c);
	add(sc1);
	c.weightx = 1.0;
	c.weighty = 1.0;
	c.gridwidth = GridBagConstraints.REMAINDER;
	gridbag.setConstraints(sc2,c);
	add(sc2);
	c.weightx = 1.0;
	c.weighty = 1.0;
	c.gridwidth = GridBagConstraints.RELATIVE;
	gridbag.setConstraints(sc3,c);
	add(sc3);
	c.weightx = 1.0;
	c.weighty = 1.0;
	c.gridwidth = GridBagConstraints.REMAINDER;
	gridbag.setConstraints(sc4,c);
	add(sc4);
	c.weightx = 1.0;
	c.weighty = 2.0;
	c.gridwidth = GridBagConstraints.REMAINDER;
	gridbag.setConstraints(default_button,c);
	add(default_button);
	c.weightx = 1.0;
	c.weighty = 2.0;
	c.gridwidth = GridBagConstraints.REMAINDER;
	gridbag.setConstraints(update_message_,c);
	add(update_message_);

	sc1.setValue(ga_.animator.springConstant());
	sc2.setValue(ga_.animator.springLength());
	sc3.setValue(ga_.iterations_);
	sc4.setValue(ga_.energy_delta_);

	pack();
	positionOnScreen();
	show();
    }

    private void positionOnScreen() {
	Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
//	this.move(ga_.location().x,ga_.location().y+ga_.size().height);
	this.move(((screen.width / 2)), (screen.height / 3) - (this.size().height));
    }

    public void show(){
	super.show();
	sc1.setValue(ga_.animator.springConstant());
	sc2.setValue(ga_.animator.springLength());
	sc3.setValue(ga_.iterations_);
	sc4.setValue(ga_.energy_delta_);
    }

    public void setUpdateMessage(String string) 
    {
	update_message_.setText(string);
    }

    /** Respond to user actions. */
    public boolean handleEvent(Event e) {
	boolean handled = false;

	if (e.target instanceof GRSlider) {
		boolean a = sc1.handleEvent(e);
		boolean b = sc2.handleEvent(e);
		boolean c = sc3.handleEvent(e);
		boolean d = sc4.handleEvent(e);
		ga_.animator.setSpringConstant(Double.valueOf(sc1.textField.getText()).doubleValue());
		ga_.animator.setSpringLength(Double.valueOf(sc2.textField.getText()).doubleValue());
		ga_.iterations_ = Integer.parseInt(sc3.textField.getText()); 
		ga_.energy_delta_ = Double.valueOf(sc4.textField.getText()).doubleValue();

		return (a || b || c);
	} else if (e.id == Event.ACTION_EVENT) {
		if (e.arg.equals("Set Constants to Default")) {
			ga_.animator.setDefaultSpringConstant();
			sc1.setValue(ga_.animator.springConstant());
			ga_.animator.setDefaultSpringLength();
			sc2.setValue(ga_.animator.springLength());
			ga_.iterations_ = ga_.default_iterations_;
			sc3.setValue(ga_.iterations_);
			ga_.energy_delta_ = ga_.default_energy_delta_;
			sc4.setValue(ga_.energy_delta_);		
		}
	} else if (e.id == Event.WINDOW_DESTROY) {
		this.hide();
		this.dispose();
	}
	return(handled);
    }
}