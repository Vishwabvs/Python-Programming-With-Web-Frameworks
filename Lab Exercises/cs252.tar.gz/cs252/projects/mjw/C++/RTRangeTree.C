/****************************************************************/
/*    NAME: Mike Walczak                                        */
/*    ACCT: mjw                                                 */
/*    FILE: RTRangeTree.C                                       */
/*    ASGN:                                                     */
/*    DATE: Wed Apr 10 16:25:08 1996                            */
/****************************************************************/


#include "RTRangeTree.H"
#include "RTLists.H"
#include "RTVerticalRay.H"
#include "RTPoint.H"
#include "RTEvent.H"
#include "RTNode.H"
#include <assert.h>
#include <fstream.h>

int compareX(const RTPointPtr& point1, const RTPointPtr& point2);
int compareY(const RTPointPtr& point1, const RTPointPtr& point2);

// these defines are from Graphics Group's rtree.h
#define FEPS		(1e-12)
#define FEQ(X,Y)	\
( ((X) > (Y)) ? ( ((X) - (Y)) < FEPS) :	\
                ( ((Y) - (X)) < FEPS) )


#define APPEND_LISTS(item, master_list, list_to_append) \
forall(item, list_to_append)				\
{							\
    (master_list).append(item);				\
}

#define GET_ITEM(i, list)   list[list[i]]

//ofstream fout("tree.log");

/****************************************************************/
/*                                                              */
/* Function Name: RTRangeTree                                   */
/* Parameters:    none                                          */
/* Returns:       nothing                                       */
/* Effects:       Initiailizes default values.                  */
/*                                                              */
/****************************************************************/

RTRangeTree::RTRangeTree(): GTree(), num_nodes_(0), root_(NULL)
{
}


/****************************************************************/
/*                                                              */
/* Function Name: RTRangeTree                                   */
/* Parameters:    RTPointList&                                  */
/* Returns:       nothing                                       */
/* Effects:       Initializes vars with default values.  Given  */
/*                a   list of points, it builds a range tree.   */
/*                                                              */
/****************************************************************/

RTRangeTree::RTRangeTree(RTPointList& points): GTree(), num_nodes_(0), root_(NULL)
{
    if (!build(points)) 
	assert(false);  // :(
}



/****************************************************************/
/*                                                              */
/* Function Name: ~RTRangeTree                                  */
/* Parameters:     none                                         */
/* Returns:        nothing                                      */
/* Effects:        Deallocates the tree.                        */
/*                                                              */
/****************************************************************/

RTRangeTree::~RTRangeTree()
{
    // destroy the tree
    //fout.flush();
    num_nodes_ = 0;
    destroy(root_);
}


bool RTRangeTree::build(list<point>& points)
{
	int count=0;
	point *p;
	RTPoint *rp;
	RTPointList rt_points;

	while (!points.empty())
	{
		p = &points.pop();
		rp = new RTPoint(count++, *p);
		assert(rp);
		rt_points.append(rp);
	}
	if (!rt_points.empty())
		return build(rt_points);
	return false;
}



void clearAndDestroy(RTVerticalRayList vertical_ray_list)
{
	RTVerticalRay *r;
	while (!vertical_ray_list.empty())
	{
		r = vertical_ray_list.pop();
		if (r)
		{
			delete r;
			r = NULL;
		}
	}
}


/****************************************************************/
/*                                                              */
/* Function Name: build                                         */
/* Parameters:    RTPointList& -- list of points                */
/* Returns:       bool -- TRUE if success, FALSE otherwise      */
/* Effects:       Given a set of RTPoints, constructs a range   */
/*                tree.                                         */
/*                                                              */
/****************************************************************/

bool RTRangeTree::build(RTPointList& points)
{
    num_nodes_ = 0;
    clearPoints();
    destroy(root_);
    // also destroy prevoius tree if it exists
    // -- not implemented yet
    points_ = points;
    RTVerticalRayList vertical_ray_list;
    RTVerticalRay    *vertical_ray = NULL;

    points_.sort(compareX);

    RTPoint *sorted_pt; int sx;
    forall(sorted_pt,points_)
	{
	    sx = sorted_pt->getX();
	    if ((vertical_ray_list.length() == 0) || !FEQ(vertical_ray->getX(), sx))
		{
		    vertical_ray = new RTVerticalRay(sx);
		    vertical_ray_list.append(vertical_ray);
		}
	    vertical_ray->addPoint(sorted_pt);
	}
    if (!insert(&root_,vertical_ray_list,0,vertical_ray_list.length()-1))
    {
	clearAndDestroy(vertical_ray_list);
	return false;	
    }
    clearAndDestroy(vertical_ray_list);
    return true;
}



/****************************************************************/
/*                                                              */
/* Function Name: clearPoints                                   */
/* Parameters:    none                                          */
/* Returns:       void                                          */
/* Effects:       removes all points from the list              */
/*                                                              */
/****************************************************************/

void RTRangeTree::clearPoints()
{
    points_.clear();
}




/****************************************************************/
/*                                                              */
/* Function Name: rangeSearch                                   */
/* Parameters:    point *upper_left, *lower_right  -- bounds    */
/*                of a rectangle that defines the query domain. */
/* Returns:       RTEventList&  -- list of events that          */
/*                                 occured while searching for  */
/*                                 points (this is needed for   */
/*                                 animating the search).       */
/* Effects:       Given bounds of a query rectangle, search is  */
/*                initiated.                                    */
/*                                                              */
/****************************************************************/


void
RTRangeTree::rangeSearch(point& upper_left,
			 point& lower_right,
			 RTEventList& event_list)
{
    assert(root_);
    RTPoint pt1(upper_left);
    RTPoint pt2(lower_right);
    
    search(*root_, pt1, pt2, event_list);
}



/****************************************************************/
/*                                                              */
/* Function Name: search                                        */
/* Parameters:                                                  */
/* Returns:                                                     */
/* Effects:                                                     */
/*                                                              */
/****************************************************************/

bool
RTRangeTree::search(RTNode& node,
		    RTPoint& upper_left,
		    RTPoint& lower_right,
		    RTEventList& event_list)
{
    RTEventPtr event;
    RTPointPtr pt;
    int i,length;

    event = new RTEvent(RTEvent::RT_EVENT_CHECK_OVERLAP, &node);
    event_list.append(event);
 
    //fout << "\nRT_EVENT_CHECK_OVERLAP "<<node;
    //fout.flush();

    if ((upper_left.getX() <= node.getBegin())&&(node.getEnd() <= lower_right.getX()))
	/*
	 *	Here the interval [upper_left->getX(), lower_right->getX()]
	 *	overlaps the interval allocated at node.
	 */
	{
	    //event->setType(RTEvent::RT_EVENT_OVERLAP);
	    event = new RTEvent(RTEvent::RT_EVENT_OVERLAP, &node);
	    event_list.append(event);
	    //fout <<"\nRT_EVENT_OVERLAP "<<node;
	    //fout.flush();

	    RTPointList & node_points = node.getPoints();
	    /*
	     * 	Perform binary search at node
	     */
	    i = binarySearch(upper_left.getY()/*lower_right.getY()*/, node_points);
	    if (i < (length= node_points.length()))
		pt = GET_ITEM(i,node_points);

	    //fout << "\ni: "<<i<<" <length:"<<length<<"pt->getY():";
	    //fout <<pt->getY()<<" <=upper_left.getY():"<<upper_left.getY();
	    //fout.flush();

	    while ((i < length) && (pt->getY()<=lower_right.getY()/*upper_left.getY()*/))
		{
		    //fout << "\nRT_EVENT_VISIT_PT "<<node<<" " <<*pt;
		    //fout.flush();
		    event = new RTEvent(RTEvent::RT_EVENT_VISIT_PT, &node, pt);
		    event_list.append(event);
		    i++;
		    if (i<length)
			pt = GET_ITEM(i,node_points);
		}
	}
    else {
	if ((node.getChild(RTNode::LEFT_CHILD) != NULL)
	    && (upper_left.getX() < node.getMedian()))
	    {
		//fout << "\nRT_EVENT_GO_LEFT "<<node;
		//fout.flush();
		event = new RTEvent(RTEvent::RT_EVENT_GO_LEFT, &node);
		event_list.append(event);
		if (!search(*(node.getChild(RTNode::LEFT_CHILD)), upper_left, lower_right, event_list))
		    return false;
	    }
	
	if ((node.getChild(RTNode::RIGHT_CHILD)!=NULL)
	    && (node.getMedian() < lower_right.getX()))
	    {
		//fout << "\nRT_EVENT_GO_RIGHT"<<node;
		//fout.flush();
		event = new RTEvent(RTEvent::RT_EVENT_GO_RIGHT, &node);
		event_list.append(event);
		if (!search(*(node.getChild(RTNode::RIGHT_CHILD)),upper_left,lower_right,event_list))	
		    return false;		
	    }
    }
    return true;
}


/****************************************************************/
/*                                                              */
/* Function Name: insert                                        */
/* Parameters:                                                  */
/* Returns:                                                     */
/* Effects:                                                     */
/*                                                              */
/****************************************************************/

 
bool RTRangeTree::insert(RTNode** node,
			 RTVerticalRayList& vray_list,
			 int l,
			 int r)
{
    //cout << "\nin insert: l="<<l<<" r="<<r;

  int m, num_vertical_rays_;// = vray_list.length();
  RTVerticalRayPtr left_vray;
  RTVerticalRayPtr right_vray;
  RTVerticalRayPtr m_ray;
  RTVerticalRayPtr m1_ray;
  RTPointList point_list;
  assert(*node==NULL);

  left_vray = GET_ITEM(l,vray_list);
  right_vray =GET_ITEM(r,vray_list);

  num_vertical_rays_  =  r - l + 1;
  (*node) = new RTNode();
  (*node)->setID(++num_nodes_);
  (*node)->setBegin(left_vray->getX());
  (*node)->setEnd(right_vray->getX());
  (*node)->setChild(RTNode::LEFT_CHILD, NULL);
  (*node)->setChild(RTNode::RIGHT_CHILD, NULL);

  m = (l + r) / 2;	// take the middle vertical ray
  m_ray = GET_ITEM(m,vray_list);
  int m1 = m+1;
  
  if ((num_vertical_rays_ % 2) == 0)  {
      m1_ray = GET_ITEM(m1,vray_list);
      (*node)->setMedian((m_ray->getX() + m1_ray->getX())/ 2.0);
  }
  else
      (*node)->setMedian(m_ray->getX());

    // IMPORTANT!: set the px (coord of the node), py will be set
    // by the application program using this class.  This assumption
    // can be made since we're building this tree based on the points
    // supplied by the app program.  The x coord thus can be set here
    // but the y coord is app dependent.
  (*node)->setPX((*node)->getMedian());

    
  RTVerticalRayPtr vray;
  RTPoint *pt;
  for (int i = l; i <= r; i++)
      {
	  vray = GET_ITEM(i, vray_list);
	  RTPointList & pts = vray->getPoints();
	  APPEND_LISTS(pt, point_list, pts); 
      }
  (*node)->setPoints(point_list);
  (*node)->sortPoints(compareY);	// sort points by Y
  /*  testing
  RTPointList &lst = (*node)->getPoints();
  int size = lst.length();
  int h=0;
  //fout<<"\n\nGET_ITEM";
  while (h < lst.length())
  {
	RTPoint *pt = GET_ITEM(h++, lst);
	//fout << "\npt#"<<h-1<<" x:"<<pt->getX()<<" y:"<<pt->getY();
  }
  RTPoint *pt2;
  //fout <<"\n\nforall";
  forall(pt2, lst)
  {
	fout << "\npt#"<<i<<" x:"<<pt2->getX()<<" y:"<<pt2->getY();
  }
  */
  if (num_vertical_rays_ > 1)
      {
	  RTNode *left_child = (*node)->getChild(RTNode::LEFT_CHILD);
	  RTNode *right_child = (*node)->getChild(RTNode::RIGHT_CHILD);
	  if (!insert(&left_child, vray_list, l, m))
	      return false;
	  if (!insert(&right_child, vray_list, m+1, r))
	      return false;
	  (*node)->setChild(RTNode::LEFT_CHILD, left_child);
	  (*node)->setChild(RTNode::RIGHT_CHILD, right_child);
      }
  return true;
}







/****************************************************************/
/*                                                              */
/* Function Name: binarySearch                                  */
/* Parameters:    int, RTPointList&                             */
/* Returns:       int                                           */
/* Effects:       Given a y-value and a point list, it performs */
/*                a binary search on the points and returns the */
/*                index of the point that was found.            */
/*                                                              */
/****************************************************************/


int RTRangeTree::binarySearch(int y_coord, RTPointList& points)
{
    int l, r, m;
    bool found = false;
    RTPointPtr pt;
    
    l = 0;
    r = points.length()-1;

    while ((l <= r) && (! found))
	{
	    m = (l + r) / 2;
	    pt = GET_ITEM(m, points);
	    if (y_coord < pt->getY())
		r = m - 1;
	    else if (y_coord > pt->getY())
		l = m + 1;
	    else
		{
		    found = true;
		    //cout << "\n FOUND MATCH !!!\n";
		}
	}
    if (found)
	return m;
    else
	return l; 
}



/****************************************************************/
/*                                                              */
/* Function Name: destroy                                       */
/* Parameters:    RTNodePtr                                     */
/* Returns:       void                                          */
/* Effects:       destroys the node and its children.           */
/*                                                              */
/****************************************************************/

void RTRangeTree::destroy(RTNodePtr& node)
{
    if (!node) return;
    RTNode *left_child = node->getChild(RTNode::LEFT_CHILD);
    if (left_child)
	destroy(left_child);
    RTNode *right_child = node->getChild(RTNode::RIGHT_CHILD);
    if (right_child)
	destroy(right_child);	
    
    delete node;
    node = NULL;
}




/****************************************************************/
/*                                                              */
/* Function Name: getPointsAtNode                               */
/* Parameters:    int node_id                                   */
/*                RTPointList& points                           */
/* Returns:       void                                          */
/* Effects:       Returns a list of points via the reference    */
/*                parameter 'points.'                           */
/*                                                              */
/****************************************************************/

void RTRangeTree::getPointsAtNode(int node_id,
				  RTPointList& points)
{
		

}


static RTNode* findNodeHelper(RTNode* node, int id)
{	
/*	if (node->getID() == id)
		return node;
	
	RTNode* lchild = node->getChild(RTNode::LEFT_CHILD);
	RTNode* rchild = node->getChild(RTNode::RIGHT_CHILD);
	    
	if (lchild)
		findNodeHelper(lchild, id);
	if (rchild)
		findNodeHelper(rchild, id);
*/
	return NULL;
}



RTNode* RTRangeTree::findNode(int id)
{
	return findNodeHelper(root_, id);
}





void RTRangeTree::print(RTNodePtr node, int indentation)
{
    RTPoint *pt;
    
    if (node)
	{	  	    
	    cout.width(indentation);
	    cout << "\n"<< *node;
	    RTPointList & points = node->getPoints();
	    int length = points.length();
	    cout.width(indentation);
	    /*
	     *	Print out the list of points this node has
	     */
	    for (int i=0; i < length; i++)
		{
		    pt = GET_ITEM(i, points);
		    cout << pt->getID() <<" ";
		}
	    RTNode* lchild = node->getChild(RTNode::LEFT_CHILD);
	    RTNode* rchild = node->getChild(RTNode::RIGHT_CHILD);
	    
	    if (lchild)
		print(lchild, indentation);
	    if (rchild)
		print(rchild, indentation);
	}
}




void RTRangeTree::write(ostream &os)
{
    os << tree_marker_<< "\n"<<num_nodes_;
    os << "\n"<<*root_;
    write(os, root_);
    os << "\n";
}	


// pre-order 
void RTRangeTree::write(ostream &os, RTNode *node)
{
    RTNode *lchild, *rchild;
 
    assert(node);
    os <<"\n"<<*node;
    if ((lchild =node->getChild(RTNode::LEFT_CHILD)) != NULL)
	os << "   "<< *lchild;
    
    if ((rchild =node->getChild(RTNode::RIGHT_CHILD)) != NULL)
	os << "   "<< *rchild;

    if (lchild)
	write(os, lchild);
    if (rchild)
	write(os, rchild);
}




/****************************************************************/
/*                                                              */
/* Function Name: compareX                                      */
/* Parameters:    const RTPoint&                                */
/*                const RTPoint&                                */
/* Returns:       int  --  <0 if pt1 < pt2                      */
/*                         =0 if pt1 == pt2                     */
/*                         >0 if pt1 > pt3                      */
/* Effects:       Compares two points by the x coordinate.      */
/*                                                              */
/****************************************************************/

int compareX(const RTPointPtr& point1, const RTPointPtr& point2)
{
    assert(point1);
    assert(point2);
    int x1 = point1->getX();
    int x2 = point2->getX();
    
    if (x1 < x2) return -1;
    if (x1 == x2) return 0;
    if (x1 > x2) return 1;
}


/****************************************************************/
/*                                                              */
/* Function Name: compareY                                      */
/* Parameters:    const RTPoint&                                */
/*                const RTPoint&                                */
/* Returns:       int  --  <0 if pt1 < pt2                      */
/*                         =0 if pt1 == pt2                     */
/*                         >0 if pt1 > pt3                      */
/* Effects:       Compares two points by the y coordinate.      */
/*                                                              */
/****************************************************************/

int compareY(const RTPointPtr& point1, const RTPointPtr& point2)
{
    assert(point1);
    assert(point2);
    
    int y1 = point1->getY();
    int y2 = point2->getY();
    
    if (y1 < y2)  return -1;
    if (y1 == y2) return 0;
    if (y1 > y2)  return 1;
}




