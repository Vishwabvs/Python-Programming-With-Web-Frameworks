import java.awt.*;
import java.io.*;
import java.util.Vector;

//informations about an end point on x:
//(1)sweep hight begin from this point
//(2)rectangle indexes which projects on this
//   interval.
class IntervalInfo{
  public int sweep_height;
  public Vector rect_inds;
  public Vector intervals;
  public Y_Tree y_tree;
  public int left;
  public int right;
  public IntervalInfo(){
    rect_inds=new Vector();
    intervals=new Vector();
  }
}



class Interval{
  int left;
  int right;
  int y;
  RecTangle rect;
  public Interval(int a, int b){
    left=a;
    right=b;
  }
}

public class TreeNode{
  final static int TERMINAL=1;
  final static int NON_TERMINAL=0;
  protected int type=NON_TERMINAL;
  protected int index_for_terminal;
  protected TreeNode left_child;
  protected TreeNode right_child;
  protected TreeNode parent;
  protected int length;
  public int left_most;
  public int right_most;
  Vector hitting_inds;
  Vector rectangles;
  public boolean painted=false; 
               //true if the segments covered by this node
               //is in some interval;
  public boolean len_calculated=false;
  public TreeNode(){}
  public  TreeNode(int a, int b, int i){
    hitting_inds=new Vector();
    type=TERMINAL;
    left_most=a;
    right_most=b;
    length=b-a;
    if(length<=0)
      Debug.print("ERROR here in TreeNode");
    index_for_terminal=i;
  }
  public TreeNode(TreeNode l, TreeNode r){
    hitting_inds=new Vector();
    left_most=l.left_most;
    right_most=r.right_most;
    Debug.print("in TreeNode Constructor, r.right_most is: "
                 +right_most);
    l.parent=this;
    r.parent=this;
    left_child=l;
    right_child=r;
  }
  public void print(){
  }
  public int cal_len(){
    if(type==TERMINAL){
      if(painted)
        return right_most-left_most;
      else
        return 0;
    }
    if(painted)
        return collect_len();
    else
        return left_child.cal_len()+right_child.cal_len();
  }

  protected int collect_len(){
    if(type==TERMINAL){
      return right_most-left_most;
    }
    return left_child.collect_len()+right_child.collect_len();
  }

  //paint used to "paint" a node to indicate that 
  //a interval cover this node.
  public void paint(int l, int r, RecTangle rect){
/*
    if(painted)
      return;
*/
    if(l==left_most && r==right_most){
      painted=true;
      if(rectangles==null)
        rectangles=new Vector();
      if(rect==null)
        System.out.println("[DEBUG] weird");
      rectangles.addElement(rect);
      //set_painted_for_children();
      return;
    }
    if(type==TERMINAL){
      painted=false;
      return;
    }
    int mid=left_child.right_most;
    if(l>=mid){
      right_child.paint(l,r,rect);
      return;
    } 
    else if(r<=mid){
      left_child.paint(l,r,rect);
      return;
    }
    else{
      left_child.paint(l,mid,rect);
      right_child.paint(mid,r,rect);
      return;
    }
  }

  public void set_painted_for_children(){
    if(left_child!=null){
      left_child.painted=true;
      left_child.set_painted_for_children();
    } 
    if(right_child!=null){
      right_child.painted=true;
      right_child.set_painted_for_children();
    }
  }

  //decorate is used to set the inds field of the node
  public void decorate(int l, int r, int i){
    if(l==left_most && r==right_most){
      hitting_inds.addElement(new Integer(i));
      return;
    }
    int mid=left_child.right_most;
    if(l>=mid){
      right_child.decorate(l,r,i);
    }
    else if(r<=mid){
      left_child.decorate(l,r,i);
    }
    else{
      left_child.decorate(l,mid,i);
      right_child.decorate(mid,r,i);
    }
  } 

  //collect_ind collect the inds info for an terminal
  //i.e. find all the intervals that cover the terminal
  //interval.
  public void collect_inds(int l, int r, Vector v){
    add(v, hitting_inds);
    if(type==TERMINAL) //bottom
      return;
    int mid=left_child.right_most;
    if(l>=mid)
      right_child.collect_inds(l,r,v);
    else
      left_child.collect_inds(l,r,v); 
  }

  //add simply add elements in b to a
  public void add(Vector a, Vector b){
    int k=b.size();
    if(k<=0)
      return;
    for(int i=0; i<k; i++){
      a.addElement(b.elementAt(i));
    }
  }

  //get_ind return the index of the base interval cur_pos 
  //locates. return -1 if locates to the left of the region. 
  //return k+1 for the case  to the right of the total region.

  public int get_ind(int cur_pos){
    if(type==TERMINAL){
      if (cur_pos<left_most)
        return index_for_terminal-1;
      if (cur_pos>=right_most)
        return index_for_terminal+1;
      return index_for_terminal;
    }
    int mid=left_child.right_most;
    if(cur_pos<mid)
      return left_child.get_ind(cur_pos);
    else
      return right_child.get_ind(cur_pos);
  }

}


