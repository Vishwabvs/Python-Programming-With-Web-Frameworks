/*
 * IntervalTreeNode.java
 *
 * Description:
 *    This class is the IntervalTreeNode class and has all methods and variables
 *    for creating the node, and setting and retrieving the variables
 */
class IntervalTreeNode extends RBTreeNode
{
    Interval interval;         // a range
    int max;                   // the maximum value of the left subtree
    boolean nodeEncountered;   // node was detected in performing a query
    boolean useNode;           // node was part of answer to query

    // constructor for interval tree node, a node number will be the key
    IntervalTreeNode(Object nodeNum)
    {
       super(nodeNum, nodeNum);
       interval = null;
       nodeEncountered = false;
       useNode = false;
       setMax(-2147483648);
    }

    // set the high value in the range
    public void setHigh(int highValue)
    {
       interval.setHighValue(highValue);
    }

    // set the maximum value of the left subtree
    public void setMax(int maxValue)
    {
       max = maxValue;
    }

    // return the high value of the range
    public int getHigh()
    {
       return interval.getHighValue();
    }

    // return the low value of the range
    public int getLow()
    {
        return interval.getLowValue();
    }

    // return the maximum value of the left subtree
    public int getMax()
    {
       return max;
    }

    // set the bit that says the node was traversed
    public void setEncountered()
    {
       nodeEncountered = true;
    }

    // set the bit that says the node is part of the answer
    public void setUseNode()
    {
       useNode = true;
    }

    // return the bit that says whether the node is in the answer
    public boolean getUseNode()
    {
       return useNode;
    }

    // reset the bit that says the node is in the answer
    public void resetUseNode()
    {
       useNode = false;
    }

    // reset the bit that says the node was traversed
    public void resetEncountered()
    {
       nodeEncountered = false;
    }

    // retrun the state of the traversed bit
    public boolean getEncountered()
    {
       return nodeEncountered;
    }
};
