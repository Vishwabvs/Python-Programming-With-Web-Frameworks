/*
 *  GRGraphRender - parent class of program 
 *  4/14/96 
 *  by Daniel Spirn 
 *
 */
package graphrender;

import java.awt.*;
import java.util.*;
import java.applet.Applet;
import java.net.URL;
import java.io.*;

public class GRGraphRenderer extends Applet {

	// Various icons needed for control panel
	Image images[] = new Image[20]; 

	// MediaTracker regulates how the gifs are loaded
    	MediaTracker tracker;

	// Main control panel for program
	GRGraphControl gc_;


	public void init() {
	
		tracker = new MediaTracker(this);

		// Loads in the needed images
		//
		images[0] = getImage(getDocumentBase(),"graphrender/gifdir/gray_alu.jpg");
		images[1] = getImage(getDocumentBase(),"graphrender/gifdir/Nrotate.gif");
		images[2] = getImage(getDocumentBase(),"graphrender/gifdir/Nnode.gif");
		images[3] = getImage(getDocumentBase(),"graphrender/gifdir/Nedge.gif");
		images[4] = getImage(getDocumentBase(),"graphrender/gifdir/Ndelete.gif");
		images[5] = getImage(getDocumentBase(),"graphrender/gifdir/Nselect.gif");
		images[6] = getImage(getDocumentBase(),"graphrender/gifdir/Nkey.gif");
		images[7] = getImage(getDocumentBase(),"graphrender/gifdir/Nscaling.gif");
		images[8] = getImage(getDocumentBase(),"graphrender/gifdir/Nfilm.gif");
		images[9] = getImage(getDocumentBase(),"graphrender/gifdir/Nproject.gif");
		images[10] = getImage(getDocumentBase(),"graphrender/gifdir/Negraph.gif");
		images[11] = getImage(getDocumentBase(),"graphrender/gifdir/Nnew.gif");
		images[12] = getImage(getDocumentBase(),"graphrender/gifdir/Nfile.gif");

		// Makes sure that all of the images are loaded & ready for use
		//
		for (int i = 0 ; i < 13 ; i++) 
			tracker.addImage(images[i],i);	

		try {
			tracker.waitForAll();
		} catch(InterruptedException e) {
		}

		setLayout(new BorderLayout(0,0));
		
		//  Builds graphing area panel
		Panel cc = new Panel();
		cc.setLayout(new BorderLayout(0,0));
		Label garea = new Label("3D Graph Renderer");
		garea.setAlignment(Label.CENTER);
		setFont(new Font("Helvetica", Font.PLAIN, 14));
		garea.setBackground(new Color(34,133,144));
		garea.setForeground(new Color(255,255,255));
		cc.add("North",garea);
		add("Center", cc);
		gc_ = new GRGraphControl(images, cc, this);
	
		add("South",new blacksquare());
	}	

	public void start() {
		addItem("starting....");
		gc_.show();
	}
	public void stop() {
		addItem("stopping....");
		gc_.hide();
	}
	public void addItem(String string) {
		System.out.println(string);
	}
}


