import Slider;
import AnimatorGeometryClient;


public class AnimatorSlider extends Slider {
protected AnimatorGeometryClient client_;

	public AnimatorSlider(AnimatorGeometryClient client)
	{
		super();
		client_ = client;
	}
};

