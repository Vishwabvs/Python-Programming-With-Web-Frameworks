/*
 * EdgeTree.java
 *
 * Description:
 *    This class is the EdgeTree class and has all methods and variables
 *    for constructing and drawing the Edge Tree.  Any object has an
 *    enter and exit value for x, y, and z ranges.  An object may
 *    have multiple regions (each with an entrance and exit) depending
 *    upon overlaps with other object
 */
import java.awt.Font;
import java.awt.Graphics;
import java.awt.FontMetrics;
import java.awt.Color;
import java.util.Vector;

class EdgeTree extends RBBinaryTree
{
    Vector intervals;  // vector of ranges
    Vector openIds;    // vector of objects whose start has been seen
                       // but corresponding end hasn't been seen

    // constructor for the edge tree, simply call the constructor
    // for a red-black tree
    EdgeTree()
    {
       super();
    }

    // create and insert a node for empty space
    public void spaceInsert(int location)
    {
       Integer place = new Integer(location);
       EdgeTreeNode newNode = edgeCreate(place);
       edgeInsert(newNode);
    }

    // create and insert a node for a pixel
    public void pixelInsert(int location)
    {
       Integer place = new Integer(location);
       EdgeTreeNode newNode = edgeCreate(1, place);
       edgeInsert(newNode);
    }

    // create and insert a node for a viewport
    public void viewPortInsert(int location, boolean enterViewPort)
    {
       Integer place = new Integer(location);
       EdgeTreeNode newNode = edgeCreate(3, place, enterViewPort);
       edgeInsert(newNode);
    }

    // create and insert a node for a Bounding box
    public void boxInsert(int location, boolean enterBox, int identification)
    {
       Integer place = new Integer(location);
       EdgeTreeNode newNode = edgeCreate(2, place, enterBox, identification);
       edgeInsert(newNode);
    }

    // insert the node into the edge tree, simply store the node into
    // the red-black tree
    private void edgeInsert(EdgeTreeNode newNode)
    {
       RBInsert(newNode);
    }

    // create a node for empty space
    private EdgeTreeNode edgeCreate(Integer location)
    {
       EdgeTreeNode node = new EdgeTreeNode(location);
       return node;
    }

    // create a node for a pixel
    private EdgeTreeNode edgeCreate(int type, Integer location)
    {
       EdgeTreeNode node = new EdgeTreeNode(type, location);
       return node;
    }

    // create a node for a viewport
    private EdgeTreeNode edgeCreate(int type, Integer location, boolean enter)
    {
       EdgeTreeNode node = new EdgeTreeNode(type, location, enter);
       return node;
    }

    // create a node for a bounding box
    private EdgeTreeNode edgeCreate(int type, Integer location, boolean enter, int ID)
    {
       EdgeTreeNode node = new EdgeTreeNode(type, location, enter, ID);
       return node;
    }

    // delete the node with the specifed edge value
    public EdgeTreeNode edgeDelete(Object keyValue)
    {
       return (EdgeTreeNode) rbDelete(keyValue);
    }

    // traverse the edge tree calculating the positions of the nodes
    public void edgeTraversal()
    {
       RBCalculate();
    }

    // draw edge tree and indicate edge numbers
    public void edgeInOrderDrawTraversal(Graphics g)
    {
       RBInOrderDrawTraversal(g);
       Color savedColor = g.getColor();
       g.setColor(Color.blue);
       reinitializeValues();
       edgeWalk(getRoot(), g);
       edgeKey(g);
       g.setColor(savedColor);
    }

    // create a legend which will be displayed in show analysis mode
    // to teh popup window
    public void edgeKey(Graphics g)
    {
       Font f = g.getFont();
       FontMetrics fm = g.getFontMetrics(f);
       restoreKeyValues();
       keyYPosition = keyYPosition + 100;
       int initialY = keyYPosition - 10;
       keyXPosition = keyXPosition + 20;
       g.setColor(Color.black);
       g.drawOval(keyXPosition, keyYPosition, 20, 20);
       g.drawString("= Black node of Red-Black Tree",
                    keyXPosition + 125,
                    keyYPosition + 10 + fm.getAscent() / 2);
       g.setColor(Color.red);
       keyYPosition += 30;
       g.drawOval(keyXPosition, keyYPosition, 20, 20);
       g.setColor(Color.black);
       g.drawString("= Red node of Red-Black Tree",
                    keyXPosition + 125,
                    keyYPosition + 10 + fm.getAscent() / 2);
       keyYPosition += 30;
       g.drawString("number",
                    keyXPosition,
                    keyYPosition + 10 + fm.getAscent() / 2);
       g.drawString("= Value of edge",
                    keyXPosition + 125,
                    keyYPosition + 10 + fm.getAscent() / 2);
       keyYPosition += 30;
       g.setColor(Color.blue);
       g.drawString("number<,number...>",
                    keyXPosition,
                    keyYPosition + 10 + fm.getAscent() / 2);
       g.setColor(Color.black);
       String longString = new String("= object or objects [same object multiple times implies line or point]");
       g.drawString(longString,
                    keyXPosition + 125,
                    keyYPosition + 10 + fm.getAscent() / 2);
       g.drawRect(0, initialY, 2 * keyXPosition + 125 + fm.stringWidth(longString),
                  keyYPosition - initialY + 30);
       g.drawString("Key", (2 * keyXPosition + 125 + fm.stringWidth(longString)) / 2 -
                    fm.stringWidth("Key"), initialY - fm.getAscent() / 2);
    }

    // walk the edges getting and displaying the nodes which have the
    // edge
    private void edgeWalk(TreeNode node, Graphics g)
    {
       if (node != null)
       {
          edgeWalk(node.leftChild, g);
          keyXPosition = Math.min(keyXPosition, node.xPosition);
          keyYPosition = Math.max(keyYPosition, node.yPosition);
          setKeyValues();
          StringBuffer IdString = new StringBuffer();
          RBTreeNode rbNode = (RBTreeNode) node;
          EdgeTreeNode edgeNode = (EdgeTreeNode) rbNode;
          IdString.append(edgeNode.Id);
          Vector hitList = node.getMultHitList();
          if (hitList.isEmpty() == false)
          {
             for (int index = 0; index < hitList.size(); index ++)
             {
                IdString.append(", ");
                IdString.append(((EdgeTreeNode) (hitList.elementAt(index))).Id);
             }
          }
          String finalString = IdString.toString();
          Font f = g.getFont();
          FontMetrics fm = g.getFontMetrics(f);
          g.drawString(finalString,
                       node.xPosition  - fm.stringWidth(finalString) / 2,
                       node.yPosition + 3 * (fm.getAscent() / 2));
          edgeWalk(node.rightChild, g);
       }
    }

    // break the edge tree into a vector of ascending regions
    public Vector parseEdgeTree()
    {
       EdgeTreeNode edgeRootNode = (EdgeTreeNode) getRoot();
       intervals = new Vector();
       openIds = new Vector();
       parseEdgeTreeHelper(edgeRootNode);
       return intervals;
    }

    // routine which helps the creation of the vector of ascending
    // regions
    private void parseEdgeTreeHelper(EdgeTreeNode node)
    {
       int index;
       Interval interval;
       EdgeTreeNode hitNode;
       int numberElements;
       int id;

       if (node != null)
       {
          parseEdgeTreeHelper((EdgeTreeNode) (node.leftChild));
          EdgeTreeNode edgeNode = (EdgeTreeNode) node;
          if (edgeNode.getEntered())
          {
             setHighEdges(edgeNode, true);
             interval = new Interval(edgeNode.getEdge(), edgeNode.getId());
             intervals.addElement(interval);
             if (openIds.isEmpty() == false)
             {
                numberElements = openIds.size();
                for (index = 0; index < numberElements; index++)
                {
                   id = ((Integer) openIds.elementAt(index)).intValue();
                   if (edgeNode.getId() != id)
                   {
                      ((Interval) intervals.lastElement()).otherIds.addElement(
                         new Integer(id));
                   }
                }
             }
             openIds.addElement(new Integer(edgeNode.getId()));
          }
          else
          {
              processExit(edgeNode);
          }
          Vector hitList = node.getMultHitList();
          if (hitList.isEmpty() == false)
          {
             for (index = 0; index < hitList.size(); index ++)
             {
                hitNode = (EdgeTreeNode) hitList.elementAt(index);
                if (hitNode.getEntered())
                {
                   interval = (Interval) intervals.lastElement();
                   if (interval.getId() != hitNode.getId())
                   {
                      interval.otherIds.addElement(new Integer(hitNode.getId()));
                   }
                }
                else
                {
                   processExit(hitNode);
                }
             }
          }
          parseEdgeTreeHelper((EdgeTreeNode) (node.rightChild));
       }
    }

    // handle the detection of an exit edge
    private void processExit(EdgeTreeNode edgeNode)
    {
       int index;
       Interval interval;
       EdgeTreeNode hitNode;
       int numberElements;
       int id;

       numberElements = openIds.size();
       if (numberElements > 1)
       {
          openIds.removeElement(new Integer(edgeNode.getId()));
          numberElements--;
          setHighEdges(edgeNode, false);
          interval = new Interval(edgeNode.getEdge() + 1,
                                  ((Integer) openIds.
                                  lastElement()).intValue());
                                  intervals.addElement(interval);
          if (numberElements > 1)
          {
             for (index = 0; index < numberElements; index++)
             {
                id = ((Integer) openIds.elementAt(index)).intValue();
                if (id != ((Interval) intervals.lastElement()).getId())
                {
                   ((Interval) intervals.lastElement()).otherIds.addElement(
                      new Integer(id));
                }
             }
          }
       }
       else
       {
          interval = (Interval) intervals.lastElement();
          interval.setHighValue(edgeNode.getEdge());
          openIds.removeElement(new Integer(edgeNode.getId()));
       }
    }

    // close any intervals which are seen at this point
    private void setHighEdges(EdgeTreeNode edgeNode, boolean keepOpen)
    {
       int index;
       Interval interval;
       int intervalSize;

       if (edgeNode != null)
       {
          if (intervals.isEmpty() == false)
          {
             intervalSize = intervals.size();
             for (index = 0; index < intervalSize; index++)
             {
                interval = (Interval) intervals.elementAt(index);
                if (interval.getHighValue() == -1)
                {
                   if (keepOpen)
                   {
                      interval.setHighValue(edgeNode.getEdge() - 1);
                   }
                   else
                   {
                      interval.setHighValue(edgeNode.getEdge());
                   }
                }
             }
          }
       }
    }
};
