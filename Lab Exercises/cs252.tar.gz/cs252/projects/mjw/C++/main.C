#include <iostream.h>
#include <LEDA/point.h>
#include <LEDA/rat_point.h>
#include <LEDA/graph_alg.h>
#include <LEDA/segment.h>
#include <LEDA/segment_set.h>

#include "RTPoint.H"
#include "RTRangeTree.H"
#include "RTEvent.H"
#include "STSegmentTree.H"
#include "STSegmentList.H"
//#include "STSegment.H"
#include "STSegmentComposite.H"

const MAX_POINTS = 56;

int main()
{
	RTRangeTree tree;
	STSegmentTree stree;
   
   while (1)
   {
    cout << "\n\n write? (y/n):  ";
    char y;
    cin >> y;
    if (!(y=='y'||y=='Y'))
	break;
	
/*
cerr << "\nbefore initting points.";
    RTPoint p1(1, 5, 6);
    RTPoint p2(2, 7, 9);
    RTPoint p3(3, 2, 5);
    RTPoint p4(4, 2, 6);
    RTPoint p5(5, 6, 3);
    RTPoint p6(6, 3, 9);
    RTPoint p7(7, 6, 8);
    RTPoint p8(8, 8, 12);
    RTPoint p9(9, 10,12);
    RTPoint p10(10, 7, 5);
    RTPoint p11(11, 2, 11);

 cerr <<  "\nappending to list.";
    RTPointList list;

    list.append(&p1);
    list.append(&p2);
    list.append(&p3);
    list.append(&p4);
    list.append(&p5);
    list.append(&p6);
    list.append(&p7);
    list.append(&p8);
    list.append(&p9);


cerr<< "\nbuilding the tree.";
    if (!tree.build(list))
	cerr << "\n failed in building the tree";

    else cerr << "\n built tree successfully.";
    cerr << "\nwriting the tree.";
    tree.write();
  }

    point upper_left(4,10);
    point lower_right(8,5);
    RTEventList events;
    tree.rangeSearch(upper_left, lower_right, events);
    RTEvent *evt;
    forall(evt, events)
	cout << "\n" << *evt;
*/

    STSegmentList segments;

    /*cout << "\nbefore creating segments"<<endl;
     segments.append(new STSegment(10,20,60,20));
    segments.append(new STSegment(55,30,70,30));
    segments.append(new STSegment(25,40,50,40));
    STSegmentComposite scomposite;
    scomposite.setSegments(segments);
    
    cout << "after creating segments, creating the tree" << endl;
    cout << "segments: \n" ;//<< segments << endl;
    
    STSegmentTree stree;
    cerr << "building the stree"<<endl;
    stree.build(segments);
    cerr << "\nprinting tree "<<endl;
    stree.write();
    cerr <<"\nand now...";
    seg_item sg;
    forall_seg_items(sg, scomposite)
	{
	    cerr << "\n" << scomposite.key(sg);
	}
	*/

    cerr << "\nbefore initting points.";
    // (56, 343)(86, 343)(130, 366)(160, 366)(221, 405)(251, 405)


    point p1(300, 400);
    point p2(325, 400);
    point p3(325, 425);
    point p4(350, 425);
    point p5(300, 450);
    point p6(325, 450);
    point p7(300, 475);
    point p8(325, 475);
    point p9(275, 450);
    point p10(300, 450);
    point p11(300, 500);
    point p12(325, 500);
    point p13(325, 525);
    point p14(350, 525);
    point p15(225, 550);
    point p16(425, 550);

/*
    point p1( 56, 343);
    point p2( 86, 343);
    point p3( 130, 366);
    point p4( 240, 366);
    point p5( 221, 405);
    
    point p6( 251, 405);
    point p7( 6, 8);
    point p8( 8, 8);
    point p9( 10,12);
    point p10( 15, 12);
    */

 cerr <<  "\nappending to list.";
    list<point> list;

    list.append(p1);
    list.append(p2);
    list.append(p3);
    list.append(p4);
    list.append(p5);
    list.append(p6);
    list.append(p7);
    list.append(p8);
    list.append(p9);
    list.append(p10);
    list.append(p11);
    list.append(p12);
    list.append(p13);
    list.append(p14);
    list.append(p15);
    list.append(p16);

cerr<< "\nbuilding the tree.";
    if (!stree.build(list))
	cerr << "\n failed in building the tree";
    else cerr << "\n built tree successfully.";
    cerr << "\nwriting the tree.";
    stree.write();

    RTEventList event_list;
    STSegment query(315, 430, 315, 494);
    stree.intersection(query, event_list);
    RTEvent *evt;
    forall(evt, event_list)
		cout << "\n" << *evt;

  }
}





