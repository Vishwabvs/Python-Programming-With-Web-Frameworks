
/**
 *
 *	Interface to populate a colony 
 *
 *
 **/

public 
interface WV_Reader {

  public abstract boolean openConnection(String identifier);

  public abstract WV_BoxSpringContainer	readInformation();

  public abstract boolean closeConnection();

}
