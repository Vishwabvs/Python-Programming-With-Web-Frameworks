import java.io.*;
import java.util.*;
class WV_FileReader implements WV_Reader {

  FileInputStream	file_stream_;

  public WV_FileReader() { 

  }

  public boolean openConnection(String identifier) {

    try {
      file_stream_ = new FileInputStream(identifier);
      return (true);
    }
    catch (FileNotFoundException e) {
      System.out.println("FILE NOT FOUND");
      e.printStackTrace();
      return (false);
    }
  }

  public WV_BoxSpringContainer	readInformation() 
  {

    WV_BoxSpringContainer	top_level_container = null;
    WV_BoxSpringContainer	current_container = null;
    WV_Box 			current_unit = null;
    StringTokenizer		tokenizer;

    // 
    DataInputStream 	input_stream_ = new DataInputStream(file_stream_);

    try {
      String current_line_ = input_stream_.readLine();
      tokenizer = new StringTokenizer(current_line_, "\t\n\r:", false);
      System.out.println(current_line_);
      String token = tokenizer.nextToken();

      if (!token.equals("GROUP"))
	return (null);
      else 
	top_level_container = new WV_BoxSpringContainer(false);

	
      while (token != null && current_line_ != null) {
	current_line_ = input_stream_.readLine();
	System.out.println(current_line_);
	if (current_line_ != null)
	  tokenizer = new StringTokenizer(current_line_, "\t\n\r:", false);

	if (tokenizer.hasMoreElements()) {
	  token = tokenizer.nextToken();
	}
	else {
	  continue;
	}

	if (token.equals("END_GROUP")) {
	  continue;
	}
	else if (token.equals("CATEGORY")) {

	  current_container = new WV_BoxSpringContainer(true);
	  top_level_container.add(current_container);
	}
	else if (token.equals("ENTRY")) {
	  current_unit = new WV_Box(new WV_String(tokenizer.nextToken("\n\r")),
				    null);
	  current_container.add(current_unit);
	}
	else if (!token.equals("\n")) {
	  if (tokenizer.hasMoreElements())
	    current_unit.addText(token + tokenizer.nextToken("\n\r"));
	  else
	    current_unit.addText(token);
	}
      }
    }
    catch(IOException e) {
      System.out.println("IO EXECEPTION");
      e.printStackTrace();
    }
    
    //    if (top_level_container != null)
    //      top_level_container.print();

    return (top_level_container);
  }

  public boolean closeConnection() { return (true);}

}
