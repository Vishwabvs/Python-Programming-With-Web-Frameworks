import java.awt.*;

class WV_BoxSpringLayout implements LayoutManager {

  protected static double k_x_ = 1;
  protected static double k_y_ = 1;

  protected   boolean	just_moved_ = false;
  protected   boolean	in_equilibrium_ = true;
  protected   int		num_components_ = 0;
  protected   int		num_passes_ = 0;

  protected   int	num_placements_[];

  // fine tuning

  protected   int	replace_threshold_;
  protected   int	size_threshold_;
  protected   int 	spring_radius_ = 10;
  protected   double	delta_size_;
  protected   int	crash_n_burn_limit_;
  protected   boolean	first_time_;

  public WV_BoxSpringLayout() {
    super();

    replace_threshold_ = 50;
    size_threshold_ = replace_threshold_ * 3;
    delta_size_ = 0.9;
    crash_n_burn_limit_ = 250;
    first_time_ = true;
  }

  public WV_BoxSpringLayout(int replace_threshold, int size_multiplier,
			    double delta_size, int crash_n_burn_limit) {
    super();

    replace_threshold_ = replace_threshold;
    size_threshold_ = replace_threshold_ * size_multiplier;
    delta_size_ = delta_size;
    crash_n_burn_limit_ = crash_n_burn_limit;
    first_time_ = true;
  }
  
  public void addLayoutComponent(String name, Component comp) {

    // we're not gonna use this
  }


  public void removeLayoutComponent(Component comp) {

    // we're not gonna use this

  }

  
  public Dimension preferredLayoutSize(Container parent) {

    return parent.size();

  }

  public Dimension minimumLayoutSize(Container parent) {

//      Calculates the minimum size dimensions for the specified panel
//        given the components in the specified parent container.

    return parent.size();
  }


  protected double calcSqDist(Point center, Component massed_object) {
    Point mo_center = new Point(massed_object.location().x,
				massed_object.location().y);
    mo_center.x += massed_object.size().width / 2; 
    mo_center.y += massed_object.size().height / 2;

    int x1 = center.x;
    int y1 = center.y;

    int x2 = mo_center.x;
    int y2 = mo_center.y;

    //    System.out.println("X values: " + x1 + " and " + x2);
    double dist = ((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));

    return (dist);

  }

  protected void calcSpringForces(WV_SpringLoaded target,
			     Container parent,
			     Point[] force_vectors) {

    WV_ComponentVector connections = target.connections();
    Component parent_components[] = parent.getComponents();

    Point target_center = new Point(((Component) target).location().x,
				    ((Component) target).location().y);

    int target_width = ((Component) target).size().width;
    int target_height = ((Component) target).size().height;

    target_center.x += target_width / 2; 
    target_center.y += target_height / 2;

    
    // LOOP OVER CONNECTIONS

    int radius = spring_radius_ * ((int) Math.sqrt((double) connections.size()));
    
    for (int i = 0; i < connections.size(); i++) {

      Component massed_object = connections.getComponent(i);

      int net_x_force = 0;
      int net_y_force = 0;

      double dist_squared = calcSqDist(target_center, massed_object);
      if (dist_squared == 0) {
	System.out.println("ERROR: Zero dist!");
      }

      Point force_vector = calcForceVec(target_center, massed_object);

      double x_component = calcX(force_vector);
      double y_component = calcY(force_vector);

      double force = 0;

      //      if (dist_squared > 0) {
      double sep_d = 
	  (massed_object.size().width * massed_object.size().width +
	   massed_object.size().height * massed_object.size().height +
	   target_width * target_width +
	   target_height * target_height) / 5.5;

      //      System.out.println("#" + i + ": Dist sq = " + dist_squared + "\t sep_d = " + sep_d);
      //      if (((dist_squared - sep_d) > 0) &&
      if (stopPulling((Component) target, massed_object, radius) == false) {
	if (dist_squared - sep_d < 0) {
	  force = 5;
	}
	else {
	  force = (Math.sqrt(dist_squared - sep_d) * 0.1);
	}
	//	  force = ((dist_squared - sep_d) * 0.2);
	  net_x_force = (int) (force * x_component);
	  net_y_force = (int) (force * y_component);

	  for (int j = 0; j < parent.countComponents(); j++) {
	    if (parent_components[j] == massed_object) {
	      force_vectors[j].x += net_x_force;
	      force_vectors[j].y += net_y_force;
	      System.out.println("SPRING FORCES for OBJECT " + j + " = (" +
				 net_x_force + ", " + net_y_force + ")");
	    }
	  }
	}

	//      }

    }   
  }

  protected Point calcForceVec(Point center, Component massed_object) {
    Point mo_center = new Point(massed_object.location().x,
				massed_object.location().y);
    mo_center.x += massed_object.size().width / 2; 
    mo_center.y += massed_object.size().height / 2;

    int x1 = center.x;
    int y1 = center.y;

    int x2 = mo_center.x;
    int y2 = mo_center.y;

    Point dist = new Point((x1 - x2), (y1 - y2));

    return (dist);

  }

  protected double calcX(Point pt) {

    double x_val = pt.x;
    double len = Math.sqrt(pt.x * pt.x + pt.y * pt.y);
    if (len == 0) 
      return 0;
    else
      return (x_val / len);

  }

  protected double calcY(Point pt) {

    double y_val = pt.y;
    double len = Math.sqrt(pt.x * pt.x + pt.y * pt.y);
    if (len == 0) 
      return 0;
    else
      return (y_val / len);

  }

  protected boolean checkIntersection(Component object1, Component object2) {


    Point o1_top_left = object1.location();
    Point o1_bottom_right = object1.location();
    o1_bottom_right.x += object1.size().width;
    o1_bottom_right.y += object1.size().height;
    
    Point o2_top_left = object2.location();
    Point o2_bottom_right = object2.location();
    o2_bottom_right.x += object2.size().width;
    o2_bottom_right.y += object2.size().height;

    if (o2_top_left.x > o1_bottom_right.x) {
      return false;
    }
    else if (o2_bottom_right.x < o1_top_left.x) {
      return false;
    }
    else if (o2_top_left.y > o1_bottom_right.y) {
      return false;
    }
    else if (o2_bottom_right.y < o1_top_left.y) {
      return false;
    }					
    else {
      return true;
    }
      
  }
  
  protected boolean stopPulling(Component object1, Component object2,
				int radius) {


    Point o1_top_left = object1.location();
    o1_top_left.x -= radius;
    o1_top_left.y -= radius;
    Point o1_bottom_right = object1.location();
    o1_bottom_right.x += object1.size().width + radius;
    o1_bottom_right.y += object1.size().height +radius;
    
    Point o2_top_left = object2.location();
    Point o2_bottom_right = object2.location();
    o2_bottom_right.x += object2.size().width;
    o2_bottom_right.y += object2.size().height;

    if (o2_top_left.x > o1_bottom_right.x) {
      return false;
    }
    else if (o2_bottom_right.x < o1_top_left.x) {
      return false;
    }
    else if (o2_top_left.y > o1_bottom_right.y) {
      return false;
    }
    else if (o2_bottom_right.y < o1_top_left.y) {
      return false;
    }					
    else {
      return true;
    }
      
  }
  
  protected Point calcForces(Component target, Container parent) {

    Point target_center = new Point(target.location().x,
				    target.location().y);

    int target_width = target.size().width;
    int target_height = target.size().height;

    target_center.x += target_width / 2; 
    target_center.y += target_height / 2;

    int net_x_force = 0;
    int net_y_force = 0;
	  
    int num_components = parent.countComponents();

    //    System.out.println("NUMBER OF COMPONENETS = " + num_components);

    for (int i = 0; i < num_components; i++) {
      Component massed_object = parent.getComponent(i);
      if (massed_object == target) {
	continue;
      }
      else {
	double dist_squared = calcSqDist(target_center, massed_object);
	if (dist_squared == 0) {
	  dist_squared = 1;
	  Point p = massed_object.location();
	  massed_object.move(p.x + 1, p.y);
	}
	Point force_vector = calcForceVec(target_center, massed_object);

        double x_component = calcX(force_vector);
        double y_component = calcY(force_vector);

	int force = 0;

	if (dist_squared > 0) {
	  double sep_d = 
	    (massed_object.size().width * massed_object.size().width +
	     massed_object.size().height * massed_object.size().height +
	     target_width * target_width +
	     target_height * target_height) / 3.0;

	  if ((sep_d - dist_squared > 0) &&
	      checkIntersection(massed_object, target)) {

	    force = (int) (Math.sqrt(sep_d - dist_squared) * 1.4);

	    double m1 = target_height * target_width;
	    double m2 = massed_object.size().width *
			massed_object.size().height;

	    force *= (m2 / (m1 + m2));
	    //	    System.out.println("\tActed on by \t" + i);
	  }
	}
	else
	    force = 0;

	if (dist_squared < 0) {
	  System.out.println("NEG DIST SQUARED!");
	}
	//	System.out.println("Force " + force);

	if (Math.abs(x_component) > 1 || Math.abs(y_component) > 1) {
	  System.out.println("ERROR! non-normal vector");
	  System.out.println("X, Y " + x_component + ", " + y_component);
	

	}

	net_x_force += force * x_component;
	net_y_force += force * y_component;

      }

    }

    return new Point(net_x_force, net_y_force);

  }

  public void layoutChildren(Container parent) {

    Graphics g = parent.getGraphics();
    
    int num_components = parent.countComponents();

    for (int i = 0; i < num_components; i++) {
      parent.getComponent(i).update(g);
      parent.getComponent(i).layout();
    }

  }
  
  public void layoutContainer(Container parent) {

    fixedLayoutContainer(parent, null, crash_n_burn_limit_);

  }

  public void fixedLayoutContainer(Container parent, Component fixed) {

    fixedLayoutContainer(parent, fixed, crash_n_burn_limit_);

  }

  public void fixedLayoutContainer(Container parent, Component fixed, 
				   int c_n_b_limit) {

          if (just_moved_) {
            just_moved_ = false;
            return;
          }	

    parent.hide();

    if (in_equilibrium_ || num_components_ != parent.countComponents()) {
      first_time_ = true;
      num_placements_ = new int[parent.countComponents()];
      in_equilibrium_ = false;
      //      num_passes_ = 0;
      //      System.out.println("ADJUSTING INITIAL COND");
      num_components_ = parent.countComponents();
    }
	

    Insets borders = parent.insets();
    System.out.println(borders.toString());

    int crash_n_burn = 0;

    while (!in_equilibrium_) {
      crash_n_burn++;

      if (crash_n_burn > c_n_b_limit) {
	parent.show();
	return;
      }

      in_equilibrium_ = true;
      int num_components = parent.countComponents();
      Point[] force_vectors = new Point[num_components];

      for (int i = 0; i < num_components; i++) {
	force_vectors[i] = calcForces(parent.getComponent(i), parent);
	if (force_vectors[i].x != 0 || force_vectors[i].y != 0) {
	  num_placements_[i]++;
	}
      }

      // Get spring forces
      
      for (int i = 0; i < num_components; i++) {
	boolean spring_loaded = false;
	Component target = parent.getComponent(i);
	WV_SpringLoaded	spring_target = null;
	Class ifaces[] = target.getClass().getInterfaces();
	for (int j = 0; j < ifaces.length; j++) {
	  if (ifaces[j].getName().equals("WV_SpringLoaded")) {
	    spring_loaded = true;
	    spring_target = (WV_SpringLoaded) target;
	  }
	}
	if (spring_loaded) {
	  if (spring_target.isSelected()) {
	    calcSpringForces(spring_target, parent, force_vectors);
	  }
	}
      }
      
      for (int i = 0; i < num_components; i++) {
	Component child = parent.getComponent(i);

	if (child == fixed) {
	  continue;
	}

	Point child_loc = child.location();
      
	child_loc.x += force_vectors[i].x;
	child_loc.y += force_vectors[i].y;

	if (child_loc.x < borders.left) {
	  child_loc.x = (int) (Math.random() * 10.0) + borders.left;	
	}
	else if (child_loc.x + child.size().width > 
		 parent.size().width - borders.right) {
	  child_loc.x = parent.size().width - child.size().width;
	  child_loc.x -= ((int) (Math.random() * 10.0) + borders.right);
	}

	if (child_loc.y < borders.top) {
	  child_loc.y = (int) (Math.random() * 10.0) + borders.top;
	}
	else if (child_loc.y + child.size().height > 
		 parent.size().height - borders.bottom) {
	  child_loc.y = parent.size().height - child.size().height;
	  child_loc.y -= ((int) (Math.random() * 10.0) + borders.bottom);
	}

	if (child.location().x != child_loc.x ||
	    child.location().y != child_loc.y)
	{
	  child.move(child_loc.x, child_loc.y);
	  in_equilibrium_ = false;

	  //	  System.out.println("child #" + i + " moved");
	  //	  child.move(child_loc.x, child_loc.y);
	  //	  num_placements_[i]++;

	  if (num_placements_[i] > size_threshold_) {
	    num_placements_[i] = 0;
	    Dimension size = parent.getComponent(i).size();
	    Dimension min_size = parent.getComponent(i).minimumSize();

	    size.width = (int) ((double) size.width * delta_size_);
	    size.height = (int) ((double) size.height * delta_size_);

	    
	    if (size.width > min_size.width && 
		size.height > min_size.height) {
	      parent.getComponent(i).resize(size);
	      System.out.println("RESIZED #" + i);
	    }
	    else {
	      size = parent.size();
	      size.width = (int) ((double) size.width / delta_size_);
	      size.height = (int) ((double) size.height / delta_size_);

	      parent.resize(size);
	      System.out.println("RESIZED THE PARENT");
	    }
	  }
	  
	  if (num_placements_[i] % replace_threshold_ == 0) {
	    child.move((int) (Math.random() * 
			      (parent.size().width - child.size().width)),
		       (int) (Math.random() * 
			      (parent.size().height - child.size().height)));

	    if (child.location().x < borders.left) {
	      child.move(borders.left, child.location().y);
	    }

	    if (child.location().y < borders.top) {
	      child.move(child.location().x, borders.top);
	    }
	    
	    System.out.println("MAJOR ADJUSTMENT for child #" + i);
	  }
	}
	//	System.out.println(" -> (" + child_loc.x + ", " + child_loc.y + ")" );
      }

      //      System.out.println("-----------\t" + num_passes_++ + 
      //			 "\t-----------------------");
      just_moved_ = true;
    
      //      parent.repaint();
    }
//     if (!in_equilibrium_ || first_time_) {
//       first_time_ = false;
//     }
    //    if (!parent.isValid()) {
      layoutChildren(parent);
      //    }
    
    parent.show();
  }

}
