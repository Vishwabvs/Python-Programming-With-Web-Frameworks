/****************************************************************/
/*    NAME:                                                     */
/*    ACCT: mjw                                                 */
/*    FILE: RTPointComposite.C                                  */
/*    ASGN:                                                     */
/*    DATE: Thu Apr 18 19:49:32 1996                            */
/****************************************************************/



#include "RTPointComposite.H"
#include "RTPoint.H"
#include <assert.h>


RTPointComposite::RTPointComposite()
{}


RTPointComposite::~RTPointComposite()
{
	points_.clear();
}


void RTPointComposite::setPoints(RTPointList& plist)
{
	points_ = plist;	// copy the list
}



/****************************************************************/
/*                                                              */
/* Function Name: addPoint                                      */
/* Parameters:    RTPoint*                                      */
/* Returns:       void                                          */
/* Effects:       Adds the given point to the list.             */
/*                                                              */
/****************************************************************/

void
RTPointComposite::addPoint(RTPoint *pt)
{
    assert(pt!=NULL);
    points_.append(pt);    
}



/****************************************************************/
/*                                                              */
/* Function Name: removePoint                                   */
/* Parameters:    RTPoint* -- point to remove                   */
/* Returns:       void                                          */
/* Effects:       If the given point is on the list, than       */
/*                it is removed from the list.                  */
/*                                                              */
/****************************************************************/

void
RTPointComposite::removePoint(RTPoint *pt)
{
    assert(pt!=NULL);
    list_item item = points_.search(pt);
    points_.del_item(item);
}



/****************************************************************/
/*                                                              */
/* Function Name: sortPoints                                    */
/* Parameters:                                                  */
/* Returns:                                                     */
/* Effects:                                                     */
/*                                                              */
/****************************************************************/

void
RTPointComposite::sortPoints(int (*cmp) (const RTPointPtr& pt1, const RTPointPtr& pt2))
{
	points_.sort(cmp);
}

/****************************************************************/
/*                                                              */
/* Function Name: clearPoints                                   */
/* Parameters:    none                                          */
/* Returns:       void                                          */
/* Effects:       Clears the list and thus makes it empty.      */
/*                                                              */
/****************************************************************/

void
RTPointComposite::clearPoints()
{
    points_.clear();
}
