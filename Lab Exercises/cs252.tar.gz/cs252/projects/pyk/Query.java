/*
 * Query.java
 *
 * Description:
 *    The class that handles the queries
  */
import java.util.Vector;

class Query implements Timed
{
   RangeApp appParent;                // application parent
   EdgeTree edgeTree = null;          // tree of edges
   IntervalTree intervalTree = null;  // tree of interval nodes
   Vector objectsFound;               // objects found in traversing
                                      // trees
   Vector newRects;                   // vector of rectangles used in
                                      // each iteration through the
                                      // query algorithm
   boolean operationDone = false;     // flag set when query is done
   boolean findAllObjects;            // flag which indicates which
                                      // query is bein performed
   Timer timer;                       // a timer object
   int operationType;                 // type of tree walk being
                                      // performed
   final int EDGEX = 0;               // build edge tree of x values
   final int EDGEY = 1;               // build edge tree of y values
   final int EDGEZ = 2;               // build edge tree of z values
   final int INTERVALX = 3;           // build interval tree for x values
   final int INTERVALY = 4;           // build interval tree for y values
   final int INTERVALZ = 5;           // build interval tree for z values
   final int INTERSECTX = 6;          // build tree of x values that intersect camera
   final int INTERSECTY = 7;          // build tree of y values that intersect camera
   final int INTERSECTZ = 8;          // build tree of z values that intersect camera
   final int LOCATEX = 9;             // build tree of x values that contain point
   final int LOCATEY = 10;            // build tree of y values that contain point
   final int LOCATEZ = 11;            // build tree of z values that contain point

   // constructor for query class
   Query(RangeApp parent)
   {
      appParent = parent;
      appParent.drawingCanvas.highLightObjects(false);
   };

   // start a timer, this is used when in show analysis mode, the timer
   // is started when the popup window with the analysis is displayed
   public void startTimer()
   {
      timer = new Timer(this, 700);
      timer.start();
   }

   // stop the timer, this occurs when the user has clicked OK in the
   // the popup analysis window if show analysis mode is on
   public void stopRunning()
   {
      timer.stopRunning();
   };

   // this is the callback which is invoked by the timer every 700 ms
   // when in show analysis mode and the popup window is displayed,
   // when the user clicks the OK button the timer will be stopped,
   // otherwise (while in show analysis mode) the correct operation
   // will be run as a callback
   public void tick(Timer t)
   {
     if (t.operationDone)
     {
        stopRunning();
        if (operationType == EDGEX)
        {
           intervalTreeBuild(true, "X");
        }
        else if (operationType == EDGEY)
        {
           intervalTreeBuild(true, "Y");
        }
        else if (operationType == EDGEZ)
        {
           intervalTreeBuild(true, "Z");
        }
        else if (operationType == INTERVALX)
        {
           doIntersectCamera(true, "X");
        }
        else if (operationType == INTERVALY)
        {
           doIntersectCamera(true, "Y");
        }
        else if (operationType == INTERVALZ)
        {
           doIntersectCamera(true, "Z");
        }
        else if (operationType == INTERSECTX)
        {
           if (findAllObjects)
           {
              nextAxis(true, "Y");
           }
           else
           {
              doIntersectPoint(true, "X");
           }
        }
        else if (operationType == INTERSECTY)
        {
           if (findAllObjects)
           {
              nextAxis(true, "Z");
           }
           else
           {
              doIntersectPoint(true, "Y");
           }
        }
        else if (operationType == INTERSECTZ)
        {
           if (findAllObjects)
           {
              appParent.drawingCanvas.highLightObjects(true);
           }
           else
           {
              doIntersectPoint(true, "Z");
           }
        }
        else if (operationType == LOCATEX)
        {
           nextAxis(true, "Y");
        }
        else if (operationType == LOCATEY)
        {
           nextAxis(true, "Z");
        }
        else if (operationType == LOCATEZ)
        {
           if (objectsFound.isEmpty() == false)
           {
              getRects();
              appParent.drawingCanvas.highLightObjects(true);
              appParent.drawingCanvas.repaint();
           }
        }
        t.stop();
      }
   }

   // perform the specified query in the desired analysis mode,
   // initially the x edge tree is created, if the mode is
   // show analysis the algorithm is performed as a series of
   // callbacks, otherwise build the interval tree for the x edges
   public void doQuery(boolean showAnalysis, boolean allObjects)
   {
      appParent.drawingCanvas.highLightObjects(false);
      appParent.drawingCanvas.repaint();
      edgeTree = new EdgeTree();
      findAllObjects = allObjects;
      buildEdgeTree(edgeTree, appParent.drawingCanvas.rectVector, "X");
      if (showAnalysis)
      {
         edgeTree.edgeTraversal();
         AnalysisFrame analysisWindow = new AnalysisFrame(this, EDGEX,
                                                         "Analysis Window: tree of x edges");
         operationType = EDGEX;
         operationDone = false;
         analysisWindow.show();
         startTimer();
      }
      else
      {
         intervalTreeBuild(showAnalysis, "X");
      }
   }

   // build the interval tree in the specified mode for the desired
   // axis, perform a test of the camera against the interval
   // tree if not in show analysis mode, otherwise perform the
   // rest of the algorithm as callbacks
   public void intervalTreeBuild(boolean showAnalysis, String whichAxis)
   {
      String title;

      Vector intervals = edgeTree.parseEdgeTree();
      intervalTree = new IntervalTree();
      intervalTree.buildIntervalTree(intervals);
      if (showAnalysis)
      {
         intervalTree.intervalTraversal();
         if (whichAxis.equals("X"))
         {
            operationType = INTERVALX;
            title = "Analysis Window: tree of interval nodes for x edges";
         }
         else if (whichAxis.equals("Y"))
         {
            operationType = INTERVALY;
            title = "Analysis Window: tree of interval nodes for y edges";
         }
         else
         {
            operationType = INTERVALZ;
            title = "Analysis Window: tree of interval nodes for z edges";
         }
         AnalysisFrame analysisWindow = new AnalysisFrame(this, operationType,
                                          title);
         operationDone = false;
         analysisWindow.show();
         startTimer();
      }
      else
      {
         doIntersectCamera(showAnalysis, whichAxis);
      }
   }

   // perform an intersect test of the tree against the camera
   // for the specified axis, if query is find all objects then
   // use resulting answer set to build next axis' edge tree (if not z)
   // otherwise, perform intersection test against point of interest
   public void doIntersectCamera(boolean showAnalysis, String whichAxis)
   {
      String title;
      Interval cameraInterval;

      if (whichAxis.equals("X"))
      {
         operationType = INTERSECTX;
         title = "Analysis Window: walked tree of interval nodes for x edges based on position of camera";
         cameraInterval = new Interval(appParent.camera.xPosition -
                                       appParent.camera.viewPortWidth / 2,
                                       -1);
         cameraInterval.setHighValue(appParent.camera.xPosition +
                                     appParent.camera.viewPortWidth / 2);
      }
      else if (whichAxis.equals("Y"))
      {
         operationType = INTERSECTY;
         title = "Analysis Window: walked tree of interval nodes for y edges based on position of camera";
         cameraInterval = new Interval(appParent.camera.yPosition -
                                       appParent.camera.viewPortHeight / 2,
                                       -1);
         cameraInterval.setHighValue(appParent.camera.yPosition +
                                     appParent.camera.viewPortHeight / 2);
      }
      else
      {
         operationType = INTERSECTZ;
         title = "Analysis Window: walked tree of interval nodes for z edges based on position of camera";
         cameraInterval = new Interval(appParent.camera.zPosition, -1);
      }
      if (operationType != INTERSECTZ)
      {
         objectsFound = intervalTree.intersect(cameraInterval);
      }
      else
      {
         objectsFound = intervalTree.inFront(cameraInterval);
         if ((objectsFound.isEmpty() == false) && (findAllObjects))
         {
            appParent.drawingCanvas.highLightObjects(true);
         }
      }
      if (showAnalysis)
      {
         AnalysisFrame analysisWindow = new AnalysisFrame(this, operationType,
                                                          title);
         operationDone = false;
         analysisWindow.show();
         startTimer();
      }
      else
      {
         if (whichAxis.equals("X"))
         {
            if (findAllObjects)
            {
               nextAxis(showAnalysis, "Y");
            }
            else
            {
               doIntersectPoint(showAnalysis, "X");
            }
         }
         else if (whichAxis.equals("Y"))
         {
            if (findAllObjects)
            {
               nextAxis(showAnalysis, "Z");
            }
            else
            {
               doIntersectPoint(showAnalysis, "Y");
            }
         }
         else if (whichAxis.equals("Z"))
         {
            if (findAllObjects)
            {
               appParent.drawingCanvas.highLightObjects(true);
            }
            else
            {
               doIntersectPoint(showAnalysis, "Z");
            }
         }
      }
   }

   // perform point of interest intersection test, if axis is z then
   // resulting objects are the answer set, otherwise feed the answer
   // into the edge test for the next axis
   public void doIntersectPoint(boolean showAnalysis, String whichAxis)
   {
      String title;
      Interval pointInterval;
      Interval cameraInterval;

      appParent.drawingCanvas.highLightObjects(false);
      if (whichAxis.equals("X"))
      {
         operationType = LOCATEX;
         title = "Analysis Window: walked tree of interval nodes for x edges based on position of point of interest";
         pointInterval = new Interval(appParent.pointOfInterest.xPosition -
                                      appParent.pointOfInterest.fatPixelWidth / 2,
                                      -1);
         pointInterval.setHighValue(appParent.pointOfInterest.xPosition +
                                    appParent.pointOfInterest.fatPixelWidth / 2);
         cameraInterval = new Interval(appParent.camera.xPosition -
                                       appParent.camera.viewPortWidth / 2,
                                       -1);
         cameraInterval.setHighValue(appParent.camera.xPosition +
                                     appParent.camera.viewPortWidth / 2);
      }
      else if (whichAxis.equals("Y"))
      {
         operationType = LOCATEY;
         title = "Analysis Window: walked tree of interval nodes for y edges based on position of point of interest";
         pointInterval = new Interval(appParent.pointOfInterest.yPosition -
                                      appParent.pointOfInterest.fatPixelHeight / 2,
                                      -1);
         pointInterval.setHighValue(appParent.pointOfInterest.yPosition +
                                    appParent.pointOfInterest.fatPixelHeight / 2);
         cameraInterval = new Interval(appParent.camera.yPosition -
                                       appParent.camera.viewPortHeight / 2,
                                       -1);
         cameraInterval.setHighValue(appParent.camera.yPosition +
                                     appParent.camera.viewPortHeight / 2);
      }
      else
      {
         operationType = LOCATEZ;
         title = "Analysis Window: walked tree of interval nodes for z edges based on position of point of interest";
         pointInterval = new Interval(0, -1);
         cameraInterval = new Interval(0, -1);
      }
      getRects();
      if (newRects.isEmpty() == false)
      {
         edgeTree = new EdgeTree();
         buildEdgeTree(edgeTree, newRects, whichAxis);
         Vector intervals = edgeTree.parseEdgeTree();
         intervalTree = new IntervalTree();
         intervalTree.buildIntervalTree(intervals);
      }
      intervalTree.clearEncountered((TreeNode) intervalTree.getRoot());
      if (operationType != LOCATEZ)
      {
         objectsFound = intervalTree.intersectPoint(pointInterval);
      }
      else
      {
         objectsFound = intervalTree.closestInFront(pointInterval,
                                                    appParent.camera.zPosition);
      }
      if (showAnalysis)
      {
         intervalTree.intervalTraversal();
         AnalysisFrame analysisWindow = new AnalysisFrame(this, operationType,
                                                          title);
         operationDone = false;
         analysisWindow.show();
         startTimer();
      }
      else
      {
         if (whichAxis.equals("X"))
         {
            nextAxis(showAnalysis, "Y");
         }
         else if (whichAxis.equals("Y"))
         {
            nextAxis(showAnalysis, "Z");
         }
         else if (whichAxis.equals("Z"))
         {
            if (objectsFound.isEmpty() == false)
            {
               getRects();
               appParent.drawingCanvas.highLightObjects(true);
            }
        }
      }
   }

   // build the edge tree for the next axis using the answer set from
   // the previous operation
   private void nextAxis(boolean showAnalysis, String whichAxis)
   {
      String title;

      getRects();
      if (newRects.isEmpty() == false)
      {
         edgeTree = new EdgeTree();
         buildEdgeTree(edgeTree, newRects, whichAxis);
         if (showAnalysis)
         {
            if (whichAxis.equals("Y"))
            {
               operationType = EDGEY;
               title = "Analysis Window: tree of y edges";
            }
            else
            {
               operationType = EDGEZ;
               title = "Analysis Window: tree of z edges";
            }
            edgeTree.edgeTraversal();
            AnalysisFrame analysisWindow = new AnalysisFrame(this, operationType,
                                                             title);
            operationDone = false;
            analysisWindow.show();
            startTimer();
         }
         else
         {
            intervalTreeBuild(showAnalysis, whichAxis);
         }
      }
   }

   // retreive the answer set from the previous step in the algorithm
   private void getRects()
   {
      int index;

      newRects = new Vector();
      for (index = 0; index < objectsFound.size(); index++)
      {
         newRects.addElement((RectangleNode) appParent.drawingCanvas.rectVector.
                             elementAt(((Integer) objectsFound.elementAt(index)).
                             intValue()));
      }
   }

   // build the edge tree for the specified axis
   private void buildEdgeTree(EdgeTree edgeTree, Vector rectangles, String edge)
   {
      int index;
      RectangleNode rectangle;

      if (rectangles.isEmpty() == false)
      {
         for (index = 0; index < rectangles.size(); index++)
         {
            rectangle = (RectangleNode) rectangles.elementAt(index);
            if (edge.equals("X"))
            {
               edgeTree.boxInsert(rectangle.getXPosition(), true, rectangle.getID());
               edgeTree.boxInsert(rectangle.getXPosition() + rectangle.getWidth(),
                                  false, rectangle.getID());
            }
            else if (edge.equals("Y"))
            {
               edgeTree.boxInsert(rectangle.getYPosition(), true, rectangle.getID());
               edgeTree.boxInsert(rectangle.getYPosition() + rectangle.getHeight(),
                                  false, rectangle.getID());
            }
            else if (edge.equals("Z"))
            {
               edgeTree.boxInsert(rectangle.getZPosition(), true, rectangle.getID());
               edgeTree.boxInsert(rectangle.getZPosition(), false, rectangle.getID());
            }
         }
      }
   }
}