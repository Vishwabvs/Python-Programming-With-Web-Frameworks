/*
 * PixelPoint.java
 *
 * Description:
 *    The class that creates, and displays the point of interest
 */
import java.awt.Graphics;
import java.awt.Color;

class PixelPoint
{
   int xPosition = 0;          // the x position of the point
   int yPosition = 0;          // the y position of the point
   int fatPixelWidth = 4;      // the width to draw the point so it is visible
   int fatPixelHeight = 4;     // the height to draw the point so it is visible
   RangeApp appParent = null;  // the parent application
   boolean firstTime;          // has the point been created yet
   boolean ready = false;      // is there a point of interest

   // constructor for the point of interest
   PixelPoint(RangeApp parent)
   {
      appParent = parent;
      firstTime = true;
   }

   // place the point of interest and draw it
   public void place(int x, int y, Graphics g)
   {
      if (firstTime == true)
      {
         firstTime = false;
         ready = true;
      }
      xPosition = x;
      yPosition = y;
      draw(g);
   }

   // draw the point of interest, if a query has been performed, it
   // must be drawn in black since the answer will appear in red,
   // otherwise draw it in red
   public void draw(Graphics g)
   {
      Color oldColor = g.getColor();
      if (appParent.drawingCanvas.highLight)
      {
         g.setColor(Color.black);
      }
      else
      {
         g.setColor(Color.red);
      }
      g.drawOval(xPosition - fatPixelWidth / 2,
                 yPosition - fatPixelHeight / 2,
                 fatPixelWidth, fatPixelHeight);
/*
      g.fillOval(xPosition - fatPixelWidth / 2,
                 yPosition - fatPixelHeight / 2,
                 fatPixelWidth, fatPixelHeight);
*/
      g.setColor(oldColor);
   }

   public void reset(Graphics g)
   {
      if (ready == true)
      {
         g.clearRect(xPosition - fatPixelWidth / 2, yPosition - fatPixelHeight / 2,
                     fatPixelWidth + 2, fatPixelHeight + 2);
         firstTime = true;
         ready = false;
      }
   }
}