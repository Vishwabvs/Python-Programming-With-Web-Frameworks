import java.lang.*;
import java.util.*;
import java.io.StreamTokenizer;
import Prototype;

class AbstractPrototypeFactory {
protected Hashtable registered_prototypes_;

	public AbstractPrototypeFactory()
	{
		registered_prototypes_ = new Hashtable();
	}


	public boolean registerType(String identifier, Prototype p)
	{
		if (identifier == null || p == null)
			return false;
		/*
		 *  Check to see if the given prototype is
		 *  already registered.  If so return.
		 */
		if (isRegistered(identifier)!=null)
		{
			//System.out.println("Type is already registered, returning null.");
			return false;
		}
		/*
		 *  Record the given prototype.
		 */
		registered_prototypes_.put(identifier, p);
		return true;
	}



	public Prototype unregisterType(String identifier)
	{
		if (identifier == null)
			return null;
		Prototype c = isRegistered(identifier);
		if (c != null)
			registered_prototypes_.remove(identifier);
		return c;
	}


	public Prototype isRegistered(String identifier)
	{
		if (!registered_prototypes_.isEmpty())
		{
		    Prototype c = (Prototype) 
			registered_prototypes_.get(identifier);
		    return c;
		}
		return null;
	}

	public Object create(String identifier)
	{
		Prototype o = isRegistered(identifier);
		if (o!=null)
			return o.clone();
		return null;
	}


	public Object create(StreamTokenizer st) 
	{

		int token;
		try {
			token = st.nextToken();
		} catch (java.io.IOException e) {
			//System.out.println("could not create command from the stream " + e.toString()+" "+st.sval);
			return null;
		}

		//System.out.println("read sval: "+st.sval);
		//System.out.println("---- nval: "+st.nval);
		if (token != st.TT_WORD)
		{
			//System.out.println("token is not a word, so null");
			return null;
		}

		Prototype o = isRegistered(st.sval);
		if (o == null)
		{
			//System.out.println(st.sval +" is not registered");
			return null;
		}
		//System.out.println("about to clone a type");
		return o.clone(st);
	}

}




