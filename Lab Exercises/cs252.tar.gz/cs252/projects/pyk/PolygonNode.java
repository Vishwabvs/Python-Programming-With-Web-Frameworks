/*
 * PolygonNode.java
 *
 * Description:
 *    The class that creates, and displays polygonal regions, these
 *    regions make up the 3D axis
 */
import java.awt.Polygon;
import java.awt.Color;
import java.awt.Graphics;

class PolygonNode extends Polygon
{
   Color fillColor;    // color to fill the polygon
   boolean Arrow;      // is the polygon an arrowhead
   String axisName;    // name of the polygon
   int xMove;          // if an arrowhead, the relative x movement if
                       // the mouse is clicked within the region
   int yMove;          // if an arrowhead, the relative y movement if
                       // the mouse is clicked within the region
   int zMove;          // if an arrowhead, the relative z movement if
                       // the mouse is clicked within the region

   // constructor for a polygon node
   PolygonNode(Color colorToUse, String name, boolean polyIsArrow,
               int x, int y, int z)
   {
      fillColor = colorToUse;
      Arrow = polyIsArrow;
      xMove = x;
      yMove = y;
      zMove = z;
      axisName = new String(name);
   }

   // return the name of the polygon
   public String getAxisName()
   {
      return axisName;
   }

   // draw the polygon in the specified color
   public void polyDraw(Graphics g)
   {
      Color savedColor = g.getColor();
      g.setColor(fillColor);
      g.fillPolygon(this);
      g.setColor(savedColor);
   }

   // is the polygon an arrowhead
   public boolean isArrow()
   {
      return Arrow;
   }

   // return the relative x movement
   public int getXMove()
   {
      return xMove;
   }

   // return the relative y movement
   public int getYMove()
   {
      return yMove;
   }

   // return the relative z movement
   public int getZMove()
   {
      return zMove;
   }

   // determine whether the name of the region is the same as a specified
   // name
   public int isSpecificAxis(String name)
   {
      return axisName.compareTo(name);
   }
}