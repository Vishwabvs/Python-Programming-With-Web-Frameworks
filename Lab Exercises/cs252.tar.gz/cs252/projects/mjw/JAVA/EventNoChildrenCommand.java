import TreeAccessible;
import java.lang.*;
import java.io.StreamTokenizer;
import geometry.*;
import ReversibleCommand;
import Prototype;
import java.awt.Image;
import java.awt.image.*;
import RangeSearchAnimationCommand;


/****************************************************************/
/* CLASS NAME :  EventNoChildrenCommand                         */
/*                                                              */
/*                                                              */
/*                                                              */
/*                                                              */
/*                                                              */
/*                                                              */
/****************************************************************/


public class EventNoChildrenCommand extends RangeSearchAnimationCommand {

	public EventNoChildrenCommand(	Image		im,
					GeometryPanel	p,
					TreeAccessible	treeApp,
					Box		input_area)
	{
		super(im, p, treeApp, input_area);
	}

	public EventNoChildrenCommand(	Image		im,
					GeometryPanel	p,
					TreeAccessible	treeApp,
					Box		input_area,
					TreeNode	node)
	{
		super(im, p, treeApp, input_area);
		setNode(node);
	}

	public void execute()
	{
	}

	public void undo()
	{
	}

	public Object clone()
	{
		EventNoChildrenCommand c = new
			EventNoChildrenCommand(	image_,
						panel_,
						tree_app_,
						user_input_bounds_,
						node_);
		c.setBegin(begin_);
		c.setMedian(median_);
		c.setEnd(end_);
		return c;
	}

	public Object clone(StreamTokenizer st)
	{
		TreeNode n = new TreeNode((GeometryStreamTokenizer)st);
		begin_ = ((GeometryStreamTokenizer)st).nextInt();
		median_ = ((GeometryStreamTokenizer)st).nextInt();
		end_ = ((GeometryStreamTokenizer)st).nextInt();
		Tree tree = tree_app_.getTree();
		if (tree == null) return null;
		n = tree.findNode(n.getID());
		EventNoChildrenCommand c = new
			EventNoChildrenCommand(	image_,
						panel_,
						tree_app_,
						user_input_bounds_,
						n);
		c.setReversible(reversible_);
		c.setBegin(begin_);
		c.setMedian(median_);
		c.setEnd(end_);
		return c;
	}

	public String toString()
	{
		return new String("RTEVENTNOCHILDREN");
	}
};

