package sprite.test;

import sprite.*;
import java.awt.*;

class SimpleSprite extends Sprite {
    Color color_;

    SimpleSprite(SpriteArea area, int x, int y, Color color) {
	super(area, x, y);
	color_ = color;
    }
    
    public boolean Inside(int x, int y) {
	return Math.abs(x - x_) < 10 && Math.abs(y - y_) < 10;
    }

    public void Draw(Graphics g) {
	g.setColor(color_);
	g.fillOval(x_ - 10, y_ - 10, 20, 20);
    }

    public void handleEvent(Event e) {
	switch (e.id) {
	case Event.MOUSE_DOWN:
	    Unanchor();
	    ZToTop();
	    break;
	    
	case Event.MOUSE_DRAG:
	    MoveTo(e.x, e.y);
	    break;

	case Event.MOUSE_UP:
	    Anchor();
	    break;
	}
    }
}

class test extends SpriteArea {
    int x1_, y1_;
    
    public test(int width, int height) {
	super(width, height);
    }

    public void HandleBackgroundEvent(Event e) {
	if (e.id == Event.MOUSE_DOWN) {
	    x1_ = e.x;
	    y1_ = e.y;	    
	}
	else if (e.id == Event.MOUSE_UP) {
	    Sprite s = new SimpleSprite(this, x1_, y1_, new Color(
		(int)(Math.round(Math.random() * 255)),
		(int)(Math.round(Math.random() * 255)),
		(int)(Math.round(Math.random() * 255))));
	    s.SlideTo(e.x, e.y, 20, 50, true, false);
	}
    }
    
    public static void main (String args[]) {
	Frame f = new Frame();
	
        f.setLayout(new FlowLayout());
        test area = new test(300, 300);
	f.add(area);
        f.resize(f.preferredSize());
	f.show();
	
	area.WaitForGraphics();
	Graphics back = area.GetBackgroundGraphics();

	for (int loop = 0; loop < 10; ++loop) {
	    back.setColor(new Color(loop * 25, loop * 25, loop * 25));
	    back.fillRect(0, loop * 30, 300, 30);
	}

	area.BackgroundDirty();
    }
}
