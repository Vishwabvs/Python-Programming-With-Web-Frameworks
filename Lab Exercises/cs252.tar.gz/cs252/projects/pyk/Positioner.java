/*
 * Positioner.java
 *
 * Description:
 *    The class that creates, and displays the 3D positioner, and
 *    manipulates objects due to actions on the 3D positioning tool
 */
import java.awt.Graphics;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Event;
import java.awt.Color;
import java.awt.Image;
import java.awt.Insets;
import java.awt.Canvas;
import java.util.Vector;

class Positioner extends Canvas implements Timed
{
   RangeApp appParent;            // application parent
   Image offScreenImage;          // offscreen drawing buffer
   Graphics offScreenGraphics;    // graphics context for the offscreen buffer
   Font f;                        // the font to use for printing
   int clipX;                     // x coordinate for clipping region
   int clipY;                     // y coordinate for clipping region
   int clipWidth;                 // width of clipping region
   int clipHeight;                // height of clipping region
   boolean operationDone = false; // flag that indicates mouse button
                                  // has been released
   Timer timer;                   // timer used for continuous motion
                                  // while mouse button is depressed
   Vector axis = new Vector();    // vector used to store axis
   SphereNode positioningBall;    // sphere used in 3D positioner
   Color darkerColor = new Color(65, 65, 65);     // darkest color
                                                  // of axis
   Color darkColor = new Color(85, 85, 85);       // next darker color
                                                  // of axis
   Color lightColor = new Color(125, 125, 125);   // second lightest
                                                  // color of axis
   Color lighterColor = new Color(185, 185, 185); // lightest color
                                                  // of axis
   PolygonNode zAxis1;            // z axis
   boolean timerStarted = false;  // flag that indicates whether timer
                                  // has started
   PolygonNode polygonNode;       // a polygon node
   boolean growBigger;            // flag that indicates whether the
                                  // sphere (and selected object) can
                                  // grow bigger

   // constructor for positioner
   Positioner(RangeApp parent)
   {
      f = new Font("TimesRoman", Font.PLAIN, 18);
      appParent = parent;
   }

   // create and start the timer
   public void startTimer()
   {
      timer = new Timer(this, 70);
      timerStarted = true;
      timer.start();
   }

   // stop the timer from running, assuming a timer was ever started
   public void stopRunning()
   {
      if (timerStarted)
      {
         timerStarted = false;
         timer.stopRunning();
      }
   };

   // this method is invoked by the timer class every time the timer
   // ticks while the mouse button is still down, the selected object
   // will continue to move until the mouse is released or movement
   // is disallowed
   public void tick(Timer t)
   {
     if (t.operationDone)
     {
        stopRunning();
     }
     else
     {
        moveObject();
        if (growBigger == false)
        {
           stopRunning();
        }
     }
   }

   // set the size of the positioner canvas, build the positioner tool,
   // and position the positioning sphere
   public void setSize(int width, int height)
   {
      resize(width, height);
      offScreenImage = createImage(size().width, size().height);
      offScreenGraphics = offScreenImage.getGraphics();
      offScreenGraphics.setFont(f);
      buildPositioner();
      positioningBall = new SphereNode(135, 115, 30);
      positioningBall.sphereDraw(offScreenGraphics);
      repaint();
   }

   // reset the positioning tool
   public void reset()
   {
      positioningBall.sphereClear(offScreenGraphics);
      positioningBall.reset();
      drawAxis();
      positioningBall.sphereDraw(offScreenGraphics);
      repaint();
   }

   // build a special version of the positioner which only has a z axis and
   // the sphere, this is the depth positioner tool
   public void depthReset()
   {
      positioningBall.sphereClear(offScreenGraphics);
      positioningBall.reset();
      drawSpecificAxis("Z");
      positioningBall.sphereDraw(offScreenGraphics);
      repaint();
   }

   // build the positioner with all 3 axis
   private void buildPositioner()
   {
      Color savedColor = offScreenGraphics.getColor();
      offScreenGraphics.setColor(Color.black);
      offScreenGraphics.fillRect(0, 0, size().width, size().height);
      buildZAxis();
      buildXAxis();
      buildYAxis();
      drawAxis();
      offScreenGraphics.setColor(savedColor);
      growBigger = true;
   }

   // rebuild the positioner including the positioning sphere
   protected void rebuildPositioner()
   {
      growBigger = true;
      axis.removeAllElements();
      Color savedColor = offScreenGraphics.getColor();
      offScreenGraphics.setColor(Color.black);
      offScreenGraphics.fillRect(0, 0, size().width, size().height);
      positioningBall.sphereClear(offScreenGraphics);
      positioningBall.reset();
      buildZAxis();
      buildXAxis();
      buildYAxis();
      drawAxis();
      positioningBall.sphereDraw(offScreenGraphics);
      offScreenGraphics.setColor(savedColor);
      repaint();
   }

   // build the depth positioner
   protected void buildDepthPositioner()
   {
      growBigger = true;
      axis.removeAllElements();
      buildZAxis();
      Color savedColor = offScreenGraphics.getColor();
      offScreenGraphics.setColor(Color.black);
      offScreenGraphics.fillRect(0, 0, size().width, size().height);
      positioningBall.sphereClear(offScreenGraphics);
      positioningBall.reset();
      drawSpecificAxis("Z");
      positioningBall.sphereDraw(offScreenGraphics);
      offScreenGraphics.setColor(savedColor);
      repaint();
   }

   // draw the axis contained in the axis vector
   private void drawAxis()
   {
      int index = 0;
      PolygonNode polygonNode;

      for (index = 0; index < axis.size(); index++)
      {
         polygonNode = (PolygonNode) axis.elementAt(index);
         polygonNode.polyDraw(offScreenGraphics);
      }
   }

   // draw the axis specified by axisName
   private void drawSpecificAxis(String axisName)
   {
      int index = 0;
      PolygonNode polygonNode;

      for (index = 0; index < axis.size(); index++)
      {
         polygonNode = (PolygonNode) axis.elementAt(index);
         if (polygonNode.isSpecificAxis(axisName) == 0)
         {
           polygonNode.polyDraw(offScreenGraphics);
         }
      }
   }

   // build the z axis of the positioner
   private void buildZAxis()
   {
      zAxis1 = new PolygonNode(darkerColor, "Z", false, 0, 0, 0);
      zAxis1.addPoint(25, 180);
      zAxis1.addPoint(185, 75);
      zAxis1.addPoint(45, 200);
      zAxis1.addPoint(25, 180);
      axis.addElement(zAxis1);
      PolygonNode zForwardArrow1 = new PolygonNode(darkerColor, "Z",
                                                   true, 0, 0, 1);
      zForwardArrow1.addPoint(10, 215);
      zForwardArrow1.addPoint(20, 175);
      zForwardArrow1.addPoint(50, 205);
      zForwardArrow1.addPoint(10, 215);
      axis.addElement(zForwardArrow1);
      PolygonNode zBackwardArrow1 = new PolygonNode(darkerColor, "Z",
                                                    true, 0, 0, -1);
      zBackwardArrow1.addPoint(190, 70);
      zBackwardArrow1.addPoint(185, 80);
      zBackwardArrow1.addPoint(180, 75);
      zBackwardArrow1.addPoint(190, 70);
      axis.addElement(zBackwardArrow1);

      PolygonNode zDarkAxis = new PolygonNode(darkColor, "Z", false, 0, 0, 0);
      zDarkAxis.addPoint(28, 183);
      zDarkAxis.addPoint(185, 75);
      zDarkAxis.addPoint(44, 199);
      zDarkAxis.addPoint(28, 183);
      axis.addElement(zDarkAxis);
      PolygonNode zLightAxis = new PolygonNode(lightColor, "Z", false, 0, 0, 0);
      zLightAxis.addPoint(32, 187);
      zLightAxis.addPoint(185, 75);
      zLightAxis.addPoint(43, 198);
      zLightAxis.addPoint(32, 187);
      axis.addElement(zLightAxis);
      PolygonNode zLighterAxis = new PolygonNode(lighterColor, "Z", false, 0, 0, 0);
      zLighterAxis.addPoint(37, 192);
      zLighterAxis.addPoint(187, 75);
      zLighterAxis.addPoint(42, 197);
      zLighterAxis.addPoint(37, 192);
      axis.addElement(zLighterAxis);

      PolygonNode zDarkForward = new PolygonNode(darkColor, "Z", true, 0, 0, 1);
      zDarkForward.addPoint(10, 215);
      zDarkForward.addPoint(25, 180);
      zDarkForward.addPoint(45, 200);
      zDarkForward.addPoint(10, 215);
      axis.addElement(zDarkForward);
      PolygonNode zLightForward = new PolygonNode(lightColor, "Z", true, 0, 0, 1);
      zLightForward.addPoint(10, 215);
      zLightForward.addPoint(28, 183);
      zLightForward.addPoint(44, 199);
      zLightForward.addPoint(10, 215);
      axis.addElement(zLightForward);
      PolygonNode zLighterForward = new PolygonNode(lighterColor, "Z", true, 0, 0, 1);
      zLighterForward.addPoint(10, 215);
      zLighterForward.addPoint(32, 187);
      zLighterForward.addPoint(43, 198);
      zLighterForward.addPoint(10, 215);
      axis.addElement(zLighterForward);

      PolygonNode zDarkBackward = new PolygonNode(darkColor, "Z", true, 0, 0, -1);
      zDarkBackward.addPoint(181, 76);
      zDarkBackward.addPoint(190, 70);
      zDarkBackward.addPoint(184, 79);
      zDarkBackward.addPoint(181, 76);
      axis.addElement(zDarkBackward);
      PolygonNode zLightBackward = new PolygonNode(lightColor, "Z", true, 0, 0, -1);
      zLightBackward.addPoint(182, 77);
      zLightBackward.addPoint(190, 70);
      zLightBackward.addPoint(183, 78);
      zLightBackward.addPoint(182, 77);
      axis.addElement(zLightBackward);


   }

   // build the x axis of the positioner
   private void buildXAxis()
   {
      PolygonNode xAxis1 = new PolygonNode(darkerColor, "X", false, 0, 0,
                                           0);
      xAxis1.addPoint(30, 110);
      xAxis1.addPoint(240, 110);
      xAxis1.addPoint(240, 120);
      xAxis1.addPoint(30, 120);
      xAxis1.addPoint(30, 110);
      axis.addElement(xAxis1);
      PolygonNode xForwardArrow1 = new PolygonNode(darkerColor, "X", true,
                                                   1, 0, 0);
      xForwardArrow1.addPoint(260, 115);
      xForwardArrow1.addPoint(235, 125);
      xForwardArrow1.addPoint(235, 105);
      xForwardArrow1.addPoint(260, 115);
      axis.addElement(xForwardArrow1);
      PolygonNode xBackwardArrow1 = new PolygonNode(darkerColor, "X",
                                                    true, -1, 0, 0);
      xBackwardArrow1.addPoint(10,115);
      xBackwardArrow1.addPoint(35, 105);
      xBackwardArrow1.addPoint(35, 125);
      xBackwardArrow1.addPoint(10, 115);
      axis.addElement(xBackwardArrow1);
      PolygonNode xDarkAxis = new PolygonNode(darkColor, "X", false, 0, 0, 0);
      xDarkAxis.addPoint(30, 112);
      xDarkAxis.addPoint(230, 112);
      xDarkAxis.addPoint(230, 119);
      xDarkAxis.addPoint(30, 119);
      xDarkAxis.addPoint(30, 112);
      axis.addElement(xDarkAxis);
      PolygonNode xLightAxis = new PolygonNode(lightColor, "X", false, 0, 0, 0);
      xLightAxis.addPoint(30, 114);
      xLightAxis.addPoint(225, 114);
      xLightAxis.addPoint(225, 118);
      xLightAxis.addPoint(30, 118);
      xLightAxis.addPoint(30, 114);
      axis.addElement(xLightAxis);
      PolygonNode xLighterAxis = new PolygonNode(lighterColor, "X", false, 0, 0, 0);
      xLighterAxis.addPoint(30, 116);
      xLighterAxis.addPoint(220, 116);
      xLighterAxis.addPoint(220, 117);
      xLighterAxis.addPoint(30, 117);
      xLighterAxis.addPoint(30, 116);
      axis.addElement(xLighterAxis);

      PolygonNode xDarkForward = new PolygonNode(darkColor, "X", true, 1, 0, 0);
      xDarkForward.addPoint(235, 109);
      xDarkForward.addPoint(260, 115);
      xDarkForward.addPoint(235, 124);
      xDarkForward.addPoint(235, 109);
      axis.addElement(xDarkForward);
      PolygonNode xLightForward = new PolygonNode(lightColor, "X", true, 1, 0, 0);
      xLightForward.addPoint(235, 112);
      xLightForward.addPoint(260, 115);
      xLightForward.addPoint(235, 123);
      xLightForward.addPoint(235, 112);
      axis.addElement(xLightForward);
      PolygonNode xLighterForward = new PolygonNode(lighterColor, "X", true, 1, 0, 0);
      xLighterForward.addPoint(235, 115);
      xLighterForward.addPoint(260, 115);
      xLighterForward.addPoint(235, 122);
      xLighterForward.addPoint(235, 115);
      axis.addElement(xLighterForward);

      PolygonNode xDarkBackward = new PolygonNode(darkColor, "X", true, -1, 0, 0);
      xDarkBackward.addPoint(35, 108);
      xDarkBackward.addPoint(10, 115);
      xDarkBackward.addPoint(35, 124);
      xDarkBackward.addPoint(35, 108);
      axis.addElement(xDarkBackward);
      PolygonNode xLightBackward = new PolygonNode(lightColor, "X", true, -1, 0, 0);
      xLightBackward.addPoint(35, 111);
      xLightBackward.addPoint(10, 115);
      xLightBackward.addPoint(35, 123);
      xLightBackward.addPoint(35, 111);
      axis.addElement(xLightBackward);
      PolygonNode xLighterBackward = new PolygonNode(lighterColor, "X", true, -1, 0, 0);
      xLighterBackward.addPoint(35, 115);
      xLighterBackward.addPoint(10, 115);
      xLighterBackward.addPoint(35, 122);
      xLighterBackward.addPoint(35, 115);
      axis.addElement(xLighterBackward);
   }

   // build the y axis of the positioner
   private void buildYAxis()
   {
      PolygonNode yAxis1 = new PolygonNode(darkerColor, "Y", false, 0, 0,
                                           0);
      yAxis1.addPoint(130, 30);
      yAxis1.addPoint(140, 30);
      yAxis1.addPoint(140, 200);
      yAxis1.addPoint(130, 200);
      yAxis1.addPoint(130, 30);
      axis.addElement(yAxis1);
      PolygonNode yForwardArrow1 = new PolygonNode(darkerColor, "Y", true,
                                                   0, 1, 0);
      yForwardArrow1.addPoint(135, 10);
      yForwardArrow1.addPoint(145, 35);
      yForwardArrow1.addPoint(125, 35);
      yForwardArrow1.addPoint(135, 10);
      axis.addElement(yForwardArrow1);
      PolygonNode yBackwardArrow1 = new PolygonNode(darkerColor, "Y",
                                                    true, 0, -1, 0);
      yBackwardArrow1.addPoint(135, 220);
      yBackwardArrow1.addPoint(145, 195);
      yBackwardArrow1.addPoint(125, 195);
      yBackwardArrow1.addPoint(135, 220);
      axis.addElement(yBackwardArrow1);

      PolygonNode yDarkAxis = new PolygonNode(darkColor, "Y", false, 0, 0, 0);
      yDarkAxis.addPoint(132, 30);
      yDarkAxis.addPoint(139, 30);
      yDarkAxis.addPoint(139, 190);
      yDarkAxis.addPoint(132, 190);
      yDarkAxis.addPoint(132, 30);
      axis.addElement(yDarkAxis);
      PolygonNode yLightAxis = new PolygonNode(lightColor, "Y", false, 0, 0, 0);
      yLightAxis.addPoint(134, 30);
      yLightAxis.addPoint(138, 30);
      yLightAxis.addPoint(138, 185);
      yLightAxis.addPoint(134, 185);
      yLightAxis.addPoint(134, 30);
      axis.addElement(yLightAxis);
      PolygonNode yLighterAxis = new PolygonNode(lighterColor, "Y", false, 0, 0, 0);
      yLighterAxis.addPoint(136, 30);
      yLighterAxis.addPoint(137, 30);
      yLighterAxis.addPoint(137, 180);
      yLighterAxis.addPoint(136, 180);
      yLighterAxis.addPoint(136, 30);
      axis.addElement(yLighterAxis);


      PolygonNode yDarkForward = new PolygonNode(darkColor, "Y", true, 0, 1, 0);
      yDarkForward.addPoint(128, 35);
      yDarkForward.addPoint(135, 10);
      yDarkForward.addPoint(144, 35);
      yDarkForward.addPoint(128, 35);
      axis.addElement(yDarkForward);
      PolygonNode yLightForward = new PolygonNode(lightColor, "Y", true, 0, 1, 0);
      yLightForward.addPoint(131, 35);
      yLightForward.addPoint(135, 10);
      yLightForward.addPoint(143, 35);
      yLightForward.addPoint(131, 35);
      axis.addElement(yLightForward);
      PolygonNode yLighterForward = new PolygonNode(lighterColor, "Y", true, 0, 1, 0);
      yLighterForward.addPoint(135, 35);
      yLighterForward.addPoint(135, 10);
      yLighterForward.addPoint(142, 35);
      yLighterForward.addPoint(135, 35);
      axis.addElement(yLighterForward);

      PolygonNode yDarkBackward = new PolygonNode(darkColor, "Y", true, 0, -1, 0);
      yDarkBackward.addPoint(128, 195);
      yDarkBackward.addPoint(135, 220);
      yDarkBackward.addPoint(144, 195);
      yDarkBackward.addPoint(128, 195);
      axis.addElement(yDarkBackward);
      PolygonNode yLightBackward = new PolygonNode(lightColor, "Y", true, 0, -1, 0);
      yLightBackward.addPoint(131, 195);
      yLightBackward.addPoint(135, 220);
      yLightBackward.addPoint(143, 195);
      yLightBackward.addPoint(131, 195);
      axis.addElement(yLightBackward);
      PolygonNode yLighterBackward = new PolygonNode(lighterColor, "Y", true, 0, -1, 0);
      yLighterBackward.addPoint(135, 195);
      yLighterBackward.addPoint(135, 220);
      yLighterBackward.addPoint(142, 195);
      yLighterBackward.addPoint(135, 195);
      axis.addElement(yLighterBackward);

   }

   // handle the mouse down event
   public boolean mouseDown(Event evt, int x, int y)
   {
      boolean found = false;
      int index = 0;
      int xMove;
      int yMove;
      int zMove;
      int tempSelected;
      String zString = new String("Z");

      appParent.drawingCanvas.highLight = false;
      if ((appParent.actionChoice.isEnabled() == true) &&
          (appParent.actionChoice.getSelectedItem().equals("3D Positioning")) ||
          (appParent.actionChoice.getSelectedItem().equals("Change Depth")))
      {
         if (((appParent.controllerOptions.getSelectedItem().equals("Camera Placement")) &&
             (appParent.cameraSeen == false)) ||
             ((appParent.controllerOptions.getSelectedItem().equals("Camera Placement")) &&
             (appParent.actionChoice.getSelectedItem().equals("Change Depth"))) ||
             ((appParent.controllerOptions.getSelectedItem().equals("Camera Placement") == false) &&
             (appParent.drawingCanvas.rectSelected == -1)))
         {
         }
         else
         {
            for (index = 0; (index < axis.size()) && (found == false); index++)
            {
               polygonNode = (PolygonNode) axis.elementAt(index);
               if (polygonNode.isArrow() == true)
               {
                  if (polygonNode.inside(x, y) == true)
                  {
                     found = true;
                     if (polygonNode.getZMove() == -1)
                     {
                        growBigger = true;
                     }
                     startTimer();
                  }
               }
            }
         }
      }
      return true;
   }

   // move the sphere and the selected object
   private void moveObject()
   {
      int xMove;
      int yMove;
      int zMove;
      int tempSelected;
      String zString = new String("Z");

      xMove = polygonNode.getXMove();
      yMove = polygonNode.getYMove();
      zMove = polygonNode.getZMove();
      if ((zMove > 1) && (growBigger == false))
      {
      }
      else
      {
         positioningBall.sphereClear(offScreenGraphics);
         positioningBall.sphereMove(xMove, yMove, zMove);
         if (appParent.changeDepth)
         {
            drawSpecificAxis(zString);
            positioningBall.sphereDraw(offScreenGraphics);
         }
         else
         {
            if (positioningBall.getRelativeZ() < 0)
            {
               if ((positioningBall.getRelativeX() > 135) &&
                   (positioningBall.getRelativeY() < 115))
               {
                  drawSpecificAxis(zString);
                  positioningBall.sphereDraw(offScreenGraphics);
                  drawSpecificAxis("X");
                  drawSpecificAxis("Y");
               }
               else
               {
                  positioningBall.sphereDraw(offScreenGraphics);
                  drawAxis();
               }
            }
            else
            {
               if ((positioningBall.getRelativeX() < 140) &&
                   (positioningBall.getRelativeY() > 120))
               {
                  drawSpecificAxis("X");
                  drawSpecificAxis("Y");
                  positioningBall.sphereDraw(offScreenGraphics);
                  drawSpecificAxis(zString);
               }
               else
               {
                  drawAxis();
                  positioningBall.sphereDraw(offScreenGraphics);
               }
            }
         }
         repaint();
         if (appParent.controllerOptions.getSelectedItem().
             equals("Latest Placement") == true)
         {
            if (appParent.changeDepth == false)
            {
               appParent.drawingCanvas.moveLatest(xMove, yMove, zMove);
            }
            else
            {
               if (appParent.actionChoice.getSelectedItem().
                   equals("Change Depth"))
               {
                  appParent.drawingCanvas.changeLatest(xMove, yMove, zMove, true);
               }
               else
               {
                  appParent.drawingCanvas.changeLatest(xMove, yMove, zMove, false);
               }
            }
         }
         else if (appParent.controllerOptions.getSelectedItem().
                  equals("Camera Placement") == true)
         {
            appParent.camera.move(xMove, yMove, zMove,
                                  appParent.drawingCanvas.offScreenGraphics);
            appParent.drawingCanvas.repaint();
         }
         else if (appParent.controllerOptions.getSelectedItem().
                  equals("Cycled Placement From First Object"))
         {
            tempSelected = appParent.drawingCanvas.getRectSelected();
            if ((tempSelected >= 0) &&
                (tempSelected <= appParent.drawingCanvas.getLastRectID()))
            {
               if (appParent.changeDepth == false)
               {
                  appParent.drawingCanvas.moveSelected(xMove, yMove, zMove);
               }
               else
               {
                  if (appParent.actionChoice.getSelectedItem().
                      equals("Change Depth"))
                  {
                     appParent.drawingCanvas.changeSelected(xMove, yMove, zMove, true);
                  }
                  else
                  {
                     appParent.drawingCanvas.changeSelected(xMove, yMove, zMove, false);
                  }
               }
               if (tempSelected == appParent.drawingCanvas.getLastRectID())
               {
                  appParent.nextButton.disable();
               }
               if (tempSelected > 0)
               {
                  if (appParent.previousButton.isEnabled() == false)
                  {
                     appParent.previousButton.enable();
                  }
               }
            }
         }
         else if (appParent.controllerOptions.getSelectedItem().
                  equals("Cycled Placement From Latest Object"))
         {
            tempSelected = appParent.drawingCanvas.getRectSelected();
            if ((tempSelected >= 0) &&
                (tempSelected <= appParent.drawingCanvas.getLastRectID()))
            {
               if (appParent.changeDepth == false)
               {
                  appParent.drawingCanvas.moveSelected(xMove, yMove, zMove);
               }
               else
               {
                  if (appParent.actionChoice.getSelectedItem().
                      equals("Change Depth"))
                  {
                     appParent.drawingCanvas.changeSelected(xMove, yMove, zMove, true);
                  }
                  else
                  {
                     appParent.drawingCanvas.changeSelected(xMove, yMove, zMove, false);
                  }
               }
               if (tempSelected == 0)
               {
                  appParent.previousButton.disable();
               }
               if (appParent.drawingCanvas.getLastRectID() == 0)
               {
                  appParent.previousButton.disable();
                  if (appParent.nextButton.isEnabled() == true)
                  {
                     appParent.nextButton.disable();
                  }
               }
               else if (appParent.nextButton.isEnabled() == false)
               {
                  appParent.nextButton.enable();
               }
            }
         }
         else if (appParent.controllerOptions.getSelectedItem().
                  equals("Selected Placement"))
         {
            if (appParent.changeDepth == false)
            {
               appParent.drawingCanvas.moveSelected(xMove, yMove, zMove);
            }
            else
            {
               if (appParent.actionChoice.getSelectedItem().
                   equals("Change Depth"))
               {
                  appParent.drawingCanvas.changeSelected(xMove, yMove, zMove, true);
               }
               else
               {
                  appParent.drawingCanvas.changeSelected(xMove, yMove, zMove, false);
               }
            }
         }
      }
   }

   // handle the mouse up event, this causes the timer to stop running
   public boolean mouseUp(Event evt, int x, int y)
   {
      stopRunning();
      return true;
   }

   // set the flag which enables the growth of the object
   public void allowGrowth(boolean growth)
   {
      if (growth)
      {
         growBigger = true;
      }
      else
      {
         growBigger = false;
      }
   }

   // update the positioning canvas
   public void update(Graphics g)
   {
      paint(g);
   }

   // draw the offscreen image to the screen
   public void paint(Graphics g)
   {
      g.drawImage(offScreenImage, 0, 0, this);
   }

   // insets from the edge of the canvas
   public Insets insets()
   {
      return new Insets(10, 10, 0, 0);
   }
}
