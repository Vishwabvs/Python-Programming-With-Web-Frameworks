import java.awt.*;
import java.util.*;

class WV_BoxSpringContainer extends Panel implements WV_SpringLoaded {

  protected int		last_x_ = 0;
  protected int		last_y_ = 0;

  protected boolean 	is_nested_ = false;
  protected boolean 	resizing_ = false;
  protected boolean 	moving_ = false;

  protected Color	border_color_;	

  WV_BoxSpringLayout	bsl_;
  Component		current_component_ = null;

  int			border_ = 5;
  int			title_border_ = 15;

  Image			back_buffer_;
  Graphics		back_graphics_;

  Graphics		graphics_;	

  protected WV_ComponentVector	connections_;
  protected boolean		selected_ = false;

  WV_BoxSpringContainer(boolean is_nested) {

    is_nested_ = is_nested;

    bsl_ = new WV_BoxSpringLayout();
    setLayout(bsl_);

    border_color_ = new Color((int) (Math.random() * 128),
			      (int) (Math.random() * 128),
			      (int) (Math.random() * 128));

    back_buffer_ = createImage(size().width, size().height);
    if (back_buffer_ != null) {
      back_graphics_ = back_buffer_.getGraphics();
    }
    setBackground(Color.white);
    graphics_ = getGraphics();
    connections_ = new WV_ComponentVector();

    resize(50, 50);
  }

  public void resize(Dimension d) {
    resize(d.width, d.height);
  }

  public void resize(int w, int h) {
    if (back_buffer_ != null) {
      back_buffer_.flush();
      back_graphics_.dispose();
    }
    back_buffer_ = createImage(w, h);
    if (back_buffer_ != null) {
      back_graphics_ = back_buffer_.getGraphics();
      paint(back_graphics_);
    }

    //    repaint();
    
    super.resize(w, h);

  }
  
  public Insets insets() {
    Insets isets = super.insets();
 
    return new Insets(isets.top + border_ + title_border_,
		      isets.bottom + border_,
		      isets.left + border_,
		      isets.right + border_);

  }

  public void repaint() {

    if (graphics_ != null)
      update(graphics_);
    else
      graphics_ = getGraphics();

    //    System.out.println("REPAINT CALLED");
  }

  public void update(Graphics g) {

    if (back_buffer_ == null) {
      back_buffer_ = createImage(size().width, size().height);
      if (back_buffer_ != null)
	back_graphics_ = back_buffer_.getGraphics();

    }
    int my_height = size().height;
    int my_width = size().width;
      

    for (int i = 0; i < countComponents() ; i++) {
      int component_h = getComponent(i).size().height;
      int component_w = getComponent(i).size().width;

      if (component_w > (my_width - (2 * border_))) {
	resize(component_w + 2 * border_,my_height);
	System.out.println("DELTA W");
      }
      if (component_h > (my_height - (2 * border_)+ title_border_)) {
	resize(my_width, component_h + 2 * border_ + title_border_);
	System.out.println("DELTA H");
      }
    }

    g.drawImage(back_buffer_, 0, 0, this);

  }


  public void paint(Graphics g) {

     if (back_graphics_ == null) {
       if (back_buffer_ == null)
 	back_buffer_ = createImage(size().width, size().height);
       back_graphics_ = back_buffer_.getGraphics();
     }
    
    back_graphics_.setColor(Color.white);
    back_graphics_.fillRect(0,0, size().width, size().height);
    if (is_nested_)
    {
      back_graphics_.setColor(border_color_);
      back_graphics_.drawRect(0,0, size().width - border_,
			      size().height - border_);
      back_graphics_.setColor(border_color_.brighter().brighter());
      back_graphics_.fillRect(0,0, size().width - border_ + 1, title_border_);
      back_graphics_.fillOval(size().width - 2 * border_,
			      size().height - 2 * border_, 2 * border_,
			      2 * border_);
    }
    else {
      back_graphics_.setColor(Color.red);
      back_graphics_.drawRect(0,0, size().width - 1, size().height - 1);
      back_graphics_.setColor(Color.red.brighter().brighter());
      back_graphics_.fillRect(0,0, size().width, title_border_);

    }

    // draw the connections
    
    boolean spring_loaded;
    //    if (!moving_) {
      for (int i = 0; i < countComponents(); i++) {
	spring_loaded = false;
	Component comp = getComponent(i);
	Class ifaces[] = comp.getClass().getInterfaces();
	for (int j = 0; j < ifaces.length; j++) {
	  if (ifaces[j].getName().equals("WV_SpringLoaded")) {
	    spring_loaded = true;
	  }
	}

	if (spring_loaded) {
	  WV_SpringLoaded wvs = (WV_SpringLoaded) comp;
	  if (wvs.isSelected()) {

	    Enumeration e = wvs.connections().elements();
	    Point comp_center = comp.location();
	    comp_center.x += (comp.size().width / 2);
	    comp_center.y += (comp.size().height / 2);
	    back_graphics_.setColor(border_color_);
	    while (e.hasMoreElements()) {
	      Component conn = (Component) e.nextElement();
	      Point conn_center = conn.location();
	      conn_center.x += (conn.size().width / 2);
	      conn_center.y += (conn.size().height / 2);

	      back_graphics_.drawLine(comp_center.x, comp_center.y,
				      conn_center.x, conn_center.y);
	    }
	  }
	}
      }
      //    }

    g.drawImage(back_buffer_, 0, 0, this);

    //    System.out.println("PAINT CALLED");
    
  }

  public void paintAll(Graphics g) {

     if (back_graphics_ == null) {
       if (back_buffer_ == null)
 	back_buffer_ = createImage(size().width, size().height);
       back_graphics_ = back_buffer_.getGraphics();
     }
    
    back_graphics_.setColor(Color.white);
    back_graphics_.fillRect(0,0, size().width, size().height);
    if (is_nested_)
    {
      back_graphics_.setColor(border_color_);
      back_graphics_.drawRect(0,0, size().width - 4, size().height - 4);
      back_graphics_.fillOval(size().width - 10, size().height - 10, 10 , 10);
    }
    else {
      back_graphics_.setColor(Color.red);
      back_graphics_.drawRect(0,0, size().width - 1, size().height - 1);
    }


    for(int i = 0; i < countComponents(); i++) {
      getComponent(i).paintAll(back_graphics_);
    }

    g.drawImage(back_buffer_, 0, 0, this);

  }


  public void layout(int crash_n_burn) {

    bsl_.fixedLayoutContainer(this, null, crash_n_burn);

  }

/****************************************************************/
/*                                                              */
/* Function Name: mouseDown                                     */
/* Parameters:                                                  */
/* Returns:                                                     */
/* Effects:                                                     */
/*                                                              */
/****************************************************************/

  public boolean mouseDown(Event e, int x, int y) {

    if (is_nested_) {
      if ((x > size().width - 10 &&  x < size().width) &&	
	  (y > size().height - 10 &&  y < size().height)) {
	last_x_ = x;
	last_y_ = y;
	resizing_ = true;
	System.out.println("IN THE CIRCLE");

	for (int i = 0; i < countComponents(); i++) {
	  getComponent(i).hide();
	}
	Container parent_container = getParent();
	parent_container.remove(this);
	parent_container.add(this, 0);

	current_component_ = null;
	
	return true;
      }
    }

    last_x_ = x;
    last_y_ = y;

     for (int i = 0; i < countComponents(); i++) {
       Component temp_component = getComponent(i);
       if ((x > temp_component.location().x && 
	    x < (temp_component.location().x + temp_component.size().width)) &&
	   (y > temp_component.location().y && 
	    y < (temp_component.location().y + temp_component.size().height)))
	 {
	   current_component_ = temp_component;
	   remove(current_component_);
	   add(current_component_, 0);
	   moving_ = true;
	   return true;
	 }
     }
     current_component_ = null;
     moving_ = false;

     if (is_nested_)
       return false;
     else
       return true;
  }

  public boolean mouseDrag(Event e, int x, int y) {


    int delta_x = x - last_x_;
    int delta_y = y - last_y_;

    if (is_nested_ && resizing_) {
      resize((size().width + delta_x), (size().height + delta_y));
      last_x_ = x;
      last_y_ = y;
      repaint();
      return true;
    }

    if (current_component_ == null) {
      if (is_nested_)
	return false;
      else	
	return true;
    }

    Point cur_loc = current_component_.location();

    cur_loc.x += delta_x;
    cur_loc.y += delta_y;

    current_component_.move(cur_loc.x, cur_loc.y);

    last_x_ = x;
    last_y_ = y;

    return true;
  }

  public boolean mouseUp(Event e, int x, int y) {

    if (current_component_ != null || resizing_) {
      if (current_component_ != null) {
	current_component_.layout();
	current_component_.layout();
      }
      bsl_.fixedLayoutContainer(this, current_component_);
      bsl_.fixedLayoutContainer(this, current_component_);
      repaint();
      current_component_ = null;
    }

    if (resizing_) {
      for (int i = 0; i < countComponents(); i++) {
	getComponent(i).show();
      }
    }

    resizing_ = false;
    moving_ = false;
    return super.mouseUp(e, x, y);
  }

  public boolean mouseEnter(Event evt, int x, int y) {

    requestFocus();
    return true;
  }

  public boolean mouseExit(Event evt, int x, int y) {

    if (is_nested_ && resizing_) {
      resize((size().width + x - last_x_), 
	     (size().height + y - last_y_));
      last_x_ = x;
      last_y_ = y;
      repaint();
      return true;
    }
    else {
      return false;
    }
  }


  public boolean keyDown (Event evt, int key) {

    if (!is_nested_) {
      return true;
    }
    
    Dimension d = size();

    System.out.println("KEY " + key);
    
    switch (key) {
    case '+': 
      d.width = (int) (d.width * 1.1);
      d.height = (int) (d.height * 1.1);
      break;
    case '-':
      d.width = (int) (d.width * 0.9);
      d.height = (int) (d.height * 0.9);
      break;
    case 1004:			// UP ARROW
      d.height = (int) (d.height * 0.9);
      break;
    case 1005:			// DOWN ARROW
      d.height = (int) (d.height * 1.1);
      break;
    case 1006:			// LEFT ARROW
      d.width = (int) (d.width * 0.9);
      break;
    case 1007:			// RIGHT ARROW
      d.width = (int) (d.width * 1.1);
      break;
    default:
      return false;
    }


    resize(d);
    return true;
    
  }
  
  /**********************************************/
  /*						*/
  /*	WV_SpringLoaded functions		*/
  /*						*/
  /**********************************************/

  public boolean isSelected() {return selected_;}
  public void	 select() {selected_ = true;}
  public void	 deselect() {selected_ = false;}

  public int	 getSpringForce(Component c) {return 3;}
  public WV_ComponentVector connections() {return connections_;}

  public boolean addConnection(Component c) {

    if (!connections_.contains(c)) {
      connections_.addElement(c);
    }

    return true;
  }
  public boolean removeConnection(Component c) {

    if (connections_.contains(c)) {
      connections_.removeElement(c);
    }

    return true;
  }


}
