import java.util.*;
import java.awt.Component;

class WV_ComponentVector extends Vector {

  public Component getComponent(int index)
  {return (Component) elementAt(index);}

}
