/** Brian Rogers
    cs252
    spring 1996
    Final Project */

import java.awt.*;
import java.applet.*;



/**                                 ThreeD
    This is the applet for ThreeD that manages the GUI and it's connections
    to the other parts of the program */

public class ThreeD extends Applet {

     /** The panel at the top of the applet where the user controls what the
          applet is doing */
     Panel top_panel;
     CheckboxGroup checkbox_group; // a group to make the checkboxes radio
     Checkbox add_box;      // The check boxes      
     Checkbox vert_box;    // to control what
     Checkbox pair_box;   // the applet is doing    
    
     ThreeDSpace _space;    // The space where the simulation takes place 
     ThreeDCanvas _canvas;  // The canvas where it is drawn
     
     /** The panel at the bottom where what the applet is doing is shown */
     Panel bottom_panel;  
     CardLayout card_layout;
     
     /** The panel visible when the add_box is active. */ 
     Panel add_panel;
     Button zoom_in_button;       // Buttons to control the users
     Button zoom_out_button;     // pespective on space
     Button reset_button;    // button to reset all vertices  
     Button clear_button;  // The button to clear space of all vertices
     
     /** The panel visible while an algorithm is running. */
     Panel alg_panel; 
     Label alg_label;
     Button abort_button;
     Scrollbar speed_slider;


     public void init () {
          /* Mostly all layout stuff */
          setLayout(new BorderLayout());
          setBackground(Color.darkGray);
	  setForeground(Color.white);
      
          checkbox_group = new CheckboxGroup();
          add_box = new Checkbox(" Add Vertices", checkbox_group, true);
	  vert_box = new Checkbox(" All Nearest-Neighbors", checkbox_group, 
	                          false);
	  pair_box = new Checkbox(" Closest Pair", checkbox_group,
                                 false);
				 
	  top_panel = new Panel();
	  top_panel.add(add_box);
	  top_panel.add(vert_box);
	  top_panel.add(pair_box);
	  
	  add("North", top_panel);
		
	  _space = new ThreeDSpace();	
	  _canvas = new ThreeDCanvas(_space);
	  _space.setCanvas(_canvas);
	  
	  add("Center", _canvas);
	  
	  zoom_in_button = new Button("Zoom In");
	  zoom_out_button = new Button("Zoom Out");
	  reset_button = new Button("Reset");
	  clear_button = new Button("Clear");
	  
	  add_panel = new Panel();
	  add_panel.add(zoom_in_button);
	  add_panel.add(zoom_out_button);
	  add_panel.add(reset_button);
	  add_panel.add(clear_button);
	  
	  Panel sliderpanel = new Panel();
	  sliderpanel.setLayout(new BorderLayout());
	  Label minlabel = new Label("  0");
	  speed_slider = new Scrollbar(Scrollbar.HORIZONTAL, 300, 30, 0, 600);
	  Label maxlabel = new Label("600");
	  sliderpanel.add("West", minlabel);
	  sliderpanel.add("Center", speed_slider);
	  sliderpanel.add("East", maxlabel);
	  
	  alg_panel = new Panel();
	  alg_panel.setLayout(new BorderLayout());
	  alg_label = new Label("Pause Time = 300");
	  abort_button = new Button("Abort");
	  alg_panel.add("West", alg_label);
	  alg_panel.add("Center", sliderpanel);
	  alg_panel.add("East", abort_button);

	  bottom_panel = new Panel();
	  card_layout = new CardLayout();
	  bottom_panel.setLayout(card_layout);

	  card_layout.addLayoutComponent("add", add_panel);
	  card_layout.addLayoutComponent("alg", alg_panel);

	  bottom_panel.add(add_panel);
	  bottom_panel.add(alg_panel);

	  add("South", bottom_panel);
     }


     /** Take care of all of the events */
     public boolean action (Event evt, Object what) {
          if (evt.target == add_box) 
	       card_layout.show(bottom_panel, "add");
	  else if (evt.target == vert_box) {
	       card_layout.show(bottom_panel, "alg");
	       disableUser();
	       _space.startNearestNeighbors(this);
	       _space.setPauseTime(speed_slider.getValue());
	  }     
	  else if (evt.target == pair_box) {
	       card_layout.show(bottom_panel, "alg");
               disableUser();
	       _space.startClosestPair(this);
	       _space.setPauseTime(speed_slider.getValue());
	  }

          else if (evt.target == zoom_in_button) 
	       _space.zoomIn();
	  else if (evt.target == zoom_out_button) 
	       _space.zoomOut();
	  else if (evt.target == reset_button)
	       _space.resetSpace();
	  else if (evt.target == clear_button) 
	       _space.clearSpace();
	  else if (evt.target == abort_button) {
	       _space.abortAlgorithm();
	       finishedSweep();
	  }
	  return true;
     }
     
     
     public boolean handleEvent (Event evt) {
          if (evt.target instanceof Scrollbar) {
	       int pausetime = speed_slider.getValue();
	       alg_label.setText("pause time = " +
                                  String.valueOf(pausetime));
	       _space.setPauseTime(pausetime);
	  }
	  return super.handleEvent(evt);
     }



     /** This is called when one of the algorithm ends or is aborted.  It 
         resets the Interface to the add state, and gives control back to the 
	 user */
     public void finishedSweep() {
          enableUser();
	  add_box.setState(true);
	  vert_box.setState(false);
	  pair_box.setState(false);
	  card_layout.show(bottom_panel, "add");
     }
     


     /** This gives control back to the user by enabling the checkboxes in 
         the top panel. */
     public void enableUser () {
          add_box.enable();
	  vert_box.enable();
	  pair_box.enable();
	  _canvas.enableAdd();
     }
     /** This takes control from user by disabling the checkboxes in the top
         panel while an algorithm is running. */
     public void disableUser () {
          add_box.disable();
	  vert_box.disable();
	  pair_box.disable();
	  _canvas.disableAdd();
     }



     public String getAppletInfo () {
          return ("ThreeD written by Brian Rogers");
     }

     public String[][] getParameterInfo () {
          String[][] info = {{"We", "don't", "need"},
	                     {"no", "stinking", "parameters!"}};
	  return info;
     }
}
