
import java.awt.*;
import java.io.*;
import java.util.Vector;

//Demorithm to calculate the sweep width of some given
//rectangls
//give rectangles to this class and it should set up the
//intervals on x_axis with sweep width on the end point.
//notice: instance of this class should be created after
//        sweep button clicked.
public class Demo extends java.applet.Applet implements Runnable{
  Interface inf;
  DemoArea demo_area;
  LineArea line_area;
  D_Tree d_tree;
  boolean no_rec=false;
  int pre_ind=0;
  int pre_area=0;
  int pre_pos;
  int pre_sweep_h=0;
  int cur_pos=0;
  int total_area=0;
  int left_most=0;
  int right_most=99999; 
  Thread runner;
  Vector bars;

  int h_control=0;
  float area;
  float sweep_h;
  Vector cur_recs=new Vector();
  IntervalInfo[] info;
  Graphics graphic;
  Vector intervals;


  public Demo(Interface a, Graphics graph, Vector inters ){
    inf=a;
    int k=rects.size();
    intervals=new Vector();
    RecTangle rec;

/*
    RecTangle rec1=new RecTangle(0,0,4,4);
    RecTangle rec2=new RecTangle(2,2,4,4); 
    RecTangle rec3=new RecTangle(8,8,4,4);
    RecTangle rec4=new RecTangle(1,1,7,6);
    RecTangle rec5=new RecTangle(1,2,1,3);

    Vector recs=new Vector();
    recs.addElement(rec1);
    recs.addElement(rec2);
    recs.addElement(rec3);
    recs.addElement(rec4);
    recs.addElement(rec5);
    rects=recs;
    k=5;
*/
    

/*
    Interval interval;
    for(int i=0; i<k; i++){
      rec= (RecTangle)rects.elementAt(i);
      interval=new Interval(rec.y, rec.y+rec.h);
      intervals.addElement(interval);
    }
*/
    intervals=inters;

    graphic=graph;
    GridBagLayout gridbag=new GridBagLayout();
    GridBagConstraints c=new GridBagConstraints();
    setLayout(gridbag);

    Label label=new Label("Demostration of the"+
      " algorithm for caculating the total lenght"+
      "of overlapped segments(sweep height)");
    c.weightx=1;
    c.gridwidth=GridBagConstraints.REMAINDER;
    gridbag.setConstraints(label,c);
    add(label);

    //add an area to show all the segements.
    line_area=new LineArea(this);
    c.weightx=1;
    c.weighty=3;
    c.gridwidth=GridBagConstraints.REMAINDER;
    c.fill=GridBagConstraints.BOTH;
    gridbag.setConstraints(line_area,c);
    add(line_area);

    //add the demo area
    c.weighty=10;
    c.gridheight=GridBagConstraints.RELATIVE;
    demo_area=new DemoArea(this);
    gridbag.setConstraints(demo_area,c);
    add(demo_area);
    d_tree=new D_Tree(graphic, intervals);
    demo_area.repaint();
    
    c.gridheight=1;
    c.weighty=1;
    ControlP control_p=new ControlP(this);
    gridbag.setConstraints(control_p,c);
    add(control_p);

  }

  public void start(){
    if(runner==null){
      runner=new Thread(this);
      runner.start();
    }
  }

  public void run(){
     int k=intervals.size();
     for(int i=0; i<k; i++){
       line_area.set_twinkle(i);
       Interval s=(Interval)intervals.elementAt(i);
       Bar bar=new Bar(s.left,s.right,d_tree.root.position_x-80,
         d_tree.root.position_x+80, d_tree.root.position_y);
       bar.graph_length=32;
       bar.status=Bar.ACTIVE;
       d_tree.root.addBar(bar);
       bars=new Vector();
       while(d_tree.root.set_falling_bars(bars)){
         System.out.println("[DEBUG2] AT least once");
         demo_area.repaint();
         line_area.repaint();
         System.out.println("[DEBUG5] after repaint");
         //bars=new Vector();
         try{
           Thread.sleep(10);
         }catch (InterruptedException e){
          break;
         }
       }
       d_tree.root.reset();
       demo_area.repaint();
       line_area.repaint();
     } 
    line_area.set_twinkle(-1);
    line_area.repaint();
    while(true){
      demo_area.flash_on=true;
      demo_area.repaint();
      try{
        Thread.sleep(500);
      }catch(InterruptedException e){
       break;
      }
    }
  }

  //show the process of a line drop the tree.
  public void animate(Graphics graph){
      d_tree.root.show_self(graph);
      int k=bars.size();
      System.out.println("[DEBUG1] k is :"+k);
      for(int i=0; i<k; i++){
        Bar bar1=(Bar)bars.elementAt(i);
        graph.setColor(Color.blue);
        graph.drawLine(bar1.l, bar1.y, bar1.r, bar1.y);
      }
  }


}

class D_TreeNode{
  final static int TERMINAL=1;
  final static int NON_TERMINAL=0;
  private int type=NON_TERMINAL;

  public int left_most;
  public int right_most;
  private int length;

  Graphics graphic;
  int position_x;
  int position_y;

  Bar bar;

  private D_TreeNode l_child;
  private D_TreeNode r_child;
  public D_TreeNode parent;

  Color color=Color.green;

  public void addBar(Bar b){
    if(bar!=null && bar.status==Bar.DEAD)
      return;
    bar=b;
  }

  public D_TreeNode(Graphics graph, int a, int b, int p_x,
    int p_y){
    left_most=a;
    right_most=b;
    length=b-a;
    type=TERMINAL;
    graphic=graph;
    position_x=p_x;
    position_y=p_y;
  }
  
  public  D_TreeNode(Graphics graph,D_TreeNode l,D_TreeNode r){
    graphic=graph;
    left_most=l.left_most;
    right_most=r.right_most;
    l.parent=this;
    r.parent=this;
    l_child=l;
    r_child=r;
    position_x=(l_child.position_x+r_child.position_x)/2;
    position_y=l_child.position_y+D_Tree.DIST_BETWEEN_NODE;
  }

  public void reset(){
    if(bar==null)
      return;
    if(bar.status!=Bar.DEAD){
      bar=null;
      color=Color.green;
    }
    if(l_child!=null)
      l_child.reset();
    if(r_child!=null)
      r_child.reset(); 
  }
  public void show_self(Graphics graphic){
    graphic.setColor(Color.red);
    graphic.drawString("("+left_most, position_x-30,
      position_y-5);
    graphic.drawString(right_most+")", position_x+10,
      position_y-5);

    if(bar!=null && bar.status==Bar.ACTIVE){
      System.out.println("[Debug10] node: "+left_most+
        " "+right_most);
      graphic.setColor(Color.blue);
      graphic.drawLine(bar.l, bar.y, bar.r, bar.y);
      graphic.drawString(""+bar.left, bar.l-7, bar.y+5);
      graphic.drawString(""+bar.right,bar.r+3, bar.y+5);
    }
    if(type==TERMINAL){
      graphic.setColor(color);
      graphic.fillRect(position_x-5, position_y-5,
        10, 10);
    }
    else{
      graphic.setColor(Color.black);
      graphic.drawLine(position_x, position_y,
         l_child.position_x, l_child.position_y);
      graphic.drawLine(position_x, position_y,
        r_child.position_x, r_child.position_y);
      graphic.setColor(color);
      graphic.fillOval(position_x-5, position_y-5, 10,10);
      l_child.show_self(graphic);
      r_child.show_self(graphic);
    }
   
  } 

  public int get_result(){
    if(bar==null || bar.status!=Bar.DEAD){
      if(l_child!=null && r_child!=null)
        return l_child.get_result()+r_child.get_result();
      else
        return 0;
    }
    if(bar.status==Bar.DEAD)
      return bar.right-bar.left;
    return 0;
  }
  public void flash_self(Graphics graphic){
      if(bar==null){
        if(l_child!=null)
          l_child.flash_self(graphic);
        if(r_child!=null)
          r_child.flash_self(graphic);
      }
      else if (bar.status==Bar.DEAD){
        if(type!=TERMINAL)
          graphic.fillOval(position_x-5, position_y-5, 10,10);
        else
          graphic.fillRect(position_x-5, position_y-5,
            10,10);
      }
      else{
        if(l_child!=null)
          l_child.flash_self(graphic);
        if(r_child!=null)
          r_child.flash_self(graphic);

      }
  }

  public boolean set_falling_bars(Vector bars){ 
    System.out.println("\n[Debug 9] in set _falling bars,"
      +"node: ("+left_most+" "+right_most+")");
    if(bar==null){
      System.out.println("[?ERROR] in set_falling_bars"
        +"node: ("+left_most+right_most+")"); 
      return false; 
      } 
    if(bar.status==Bar.DEAD){ 
      System.out.println("return bar.dead, cur node bar: "+
          bar.left+"  "+bar.right);
      bars.addElement(bar); 
      return  false; 
    } 
    else if(bar.status==Bar.WAIT){ 
      System.out.println("return bar.wait, cur node bar: "+
          bar.left+"  "+bar.right);
      int mid=l_child.right_most; 
      if(!l_child.set_falling_bars(bars)){ 
        return r_child.set_falling_bars(bars);
      }
      return true; 
    }
    else if(bar.status==Bar.ACTIVE){
      System.out.println("return bar.active, cur node bar: "+
          bar.left+"  "+bar.right);
      if(bar.y>position_y){
        bar.y--;
        int center=((bar.y-position_y)*
                   (parent.position_x-position_x))
                   /(parent.position_y- position_y)+
                   position_x;
        bar.l=center-bar.graph_length;
        bar.r=center+bar.graph_length;
        System.out.println("[Debug 11], add one element");
        bars.addElement(bar);
        System.out.println("[Debug 12], num of ele is "+
          bars.size());
        return true;
      }
      if(bar.y!=position_y){
        System.out.println("[ERROR] in set_falling_bars");
        return true;
      }
      if(bar.left==left_most && bar.right==right_most){
        bar.status=Bar.DEAD;
        color=Color.red;
        bars.addElement(bar);
        //color=red;
        return true;
      }
      if(l_child==null || r_child==null){
        System.out.println("[ERROR] in set_falling_bars 2");
        return true;
      }
      int mid=l_child.right_most;
      System.out.println("[DEBUG 4] mid is "+mid);
      color=Color.blue;
      if(bar.right>mid){
        bar.status=Bar.WAIT;
        int end_p=Math.max(bar.left,mid);
        Bar bar1=new Bar(end_p, bar.right, position_x-30,
          position_x+30,position_y);
        bar1.status=Bar.ACTIVE;
        if(bar.left<mid)
          bar1.graph_length=bar.graph_length/2;
        else
          bar1.graph_length=bar.graph_length;
        r_child.addBar(bar1);
      }
      if(bar.left<mid){
        bar.status=Bar.WAIT;
        int end_p=Math.min(mid, bar.right);
        Bar bar1=new Bar(bar.left, end_p, position_x-30,
          position_x+30, position_y);
        bar1.status=Bar.ACTIVE;
        if(bar.right>mid)
          bar1.graph_length=bar.graph_length/2;
        else
          bar1.graph_length=bar.graph_length;
        l_child.addBar(bar1);
        l_child.set_falling_bars(bars);
        return true;
      }
      else
        r_child.set_falling_bars(bars);
      return true;
    }//end of case ACTIVE
    return true; //false;
  }
} 

class Bar{
  static final int ACTIVE=1;
  static final int DEAD=2;
  static final int WAIT=3;
  int status;

  int left;                 //interval left end;
  int right;                //interval right endl;
  int l;                    //graph left end;
  int r;                    //graph right end;
  int y;                    //graph y_cor;
  int graph_length;


  public Bar(int a, int b, int c, int d, int e){
    left=a;
    right=b;
    l=c;
    r=d;
    y=e;
  }

}
class D_Tree{
  static final int DIST_BETWEEN_NODE=60;
  static final int BASE_MARGIN_X=60;
  static final int BASE_MARGIN_Y=50;
  Vector temp1=new Vector();
  Vector temp2=new Vector();
  int total_length;
  Vector intervals=new Vector();
  int[] end_points;
  D_TreeNode root;
  

  public D_Tree(Graphics graph, Vector a){
    intervals=a;
    int k=intervals.size();
    System.out.print("intervals,size is: "+k);
    int cur_pos_x= BASE_MARGIN_X;
    int cur_pos_y=BASE_MARGIN_Y;
    end_points=new int[2*k];
    for(int i=0; i<k ; i++){
      Interval interval=(Interval)intervals.elementAt(i);
      end_points[2*i]=interval.left;
      end_points[2*i+1]=interval.right;
    }
    MyMethod.sort(end_points,2*k);
    System.out.println("[Debug] in  D_Tree 1");
    k=2*k-1;
    //now, set up the tree:

    //first, the leaves:
    for(int i=0; i<k; i++){
     if(end_points[i]!=end_points[i+1]){
      D_TreeNode new_node=new D_TreeNode(graph,end_points[i],
        end_points[i+1], cur_pos_x, cur_pos_y);
      cur_pos_x+=DIST_BETWEEN_NODE;
      temp1.addElement(new_node);
     }
    }
    k=temp1.size();
    int r=k-(k/2)*2;
    k=k/2;
    System.out.print("now k is: "+k);
    //next, other part of the tree
    while(true){
      System.out.println("[Debug] in  D_Tree 2");
      for(int i=0; i<k; i++){
        temp2.addElement(new D_TreeNode(graph,(D_TreeNode)temp1.
          elementAt(2*i), (D_TreeNode)temp1.elementAt(2*i+1)));
      }
      if(r==1)
        temp2.addElement(temp1.elementAt(temp1.size()-1));
      temp1=temp2;
      temp2=new Vector();
      k=temp1.size();
      System.out.println("k is: "+k);
      if(temp1.size()==1)
        break;
      else{
        r=k-(k/2)*2;
        k=k/2;
      }
    }
  root=(D_TreeNode)temp1.elementAt(0);
  }
  public void show_result(Graphics graphic){
    int k=root.get_result();
    graphic.drawString("the sum of the lenght on the"+
      " flashing nodes is the lengh of the overlapped"+
      " segment: "+k, 30, root.position_y+20);
  }
}

class DemoArea extends Canvas{
  Image offscreenImage;
  Graphics offscreenGraphics;
  Demo demo;
  boolean sswitch=true;
  boolean flash_on=false;
  Dimension old_dim;
 
  DemoArea(Demo a){
    demo=a;
    old_dim=size();
  } 
  public void paint(Graphics g){
    Dimension d=size();
    if((offscreenImage==null)||
       (d.width!=old_dim.width)|| (d.height!=old_dim.height)){
      offscreenImage=createImage(d.width, d.height);
      offscreenGraphics = offscreenImage.getGraphics();
      old_dim=d;
    }
    offscreenGraphics = offscreenImage.getGraphics();
    offscreenGraphics.setColor(Color.white);
    offscreenGraphics.fillRect(0, 0, d.width, d.height);
    offscreenGraphics.fillRect(0, 0, d.width, d.height);
    //demo.animate(offscreenGraphics); 
    demo.d_tree.root.show_self(offscreenGraphics);
    
    if(flash_on){
      demo.d_tree.show_result(offscreenGraphics);
      if(sswitch)
        offscreenGraphics.setColor(Color.green);
      else if(sswitch)
        offscreenGraphics.setColor(Color.red);
      demo.d_tree.root.flash_self(offscreenGraphics);
      sswitch=!sswitch;
    }

    System.out.println("[Debug 7] before draw");
    g.drawImage(offscreenImage,0,0,null);
    System.out.println("[Debug 8] after draw");

  }

 public void update(Graphics g){
  System.out.println("[Debug 6 ] in update");
  paint(g);
 }
}
class LineArea extends Canvas{
  Demo demo;
  Vector intervals;
  Image offscreenImage;
  Graphics offscreenGraphics;
  Dimension old_dim;
  boolean flash_on=false;

  int rate=20;
  int vertical=10;
  int twinkle=-1;
  int twinkle_control=0;
  int twinkle_freq=20;

  public LineArea(Demo a){
    demo=a;
  }

  public void set_twinkle(int a){
    twinkle=a;
  }

  public void paint(Graphics g){
    int k=0;
    int v=10;
    int add_just=60;
    intervals=demo.intervals;
    int end_points[];

    Dimension d=size();
    if((offscreenImage==null)||
       (d.width!=old_dim.width)|| (d.height!=old_dim.height)){
      offscreenImage=createImage(d.width, d.height);
      offscreenGraphics = offscreenImage.getGraphics();
      old_dim=d;
    }
    offscreenGraphics = offscreenImage.getGraphics();
    offscreenGraphics.setColor(Color.yellow);
    offscreenGraphics.fillRect(0, 0, d.width, d.height);

    if(intervals!=null)
      k=intervals.size();
    for(int i=0; i<k; i++){
      System.out.println("[Debug 11], i is: "+i);
      Interval inter=(Interval)intervals.elementAt(i);
      System.out.println("[Debug 12], end points: "+
        inter.left+" "+inter.right);
      offscreenGraphics.setColor(Color.black);
      if(i==twinkle){
        if(twinkle_control>=10)
          twinkle_control=0;
        if(twinkle_control<5){
          offscreenGraphics.setColor(Color.blue);
          offscreenGraphics.fillRect(inter.left*rate+add_just,
            v-2,  (inter.right-inter.left)*rate, 4);
        }
        else{
          offscreenGraphics.setColor(Color.black);
          offscreenGraphics.drawLine(inter.left*rate+add_just, v,
            inter.right*rate+add_just,v);
        }
        twinkle_control++;
      }
      else
       offscreenGraphics.drawLine(inter.left*rate+add_just, v, 
         inter.right*rate+add_just,v);

      v+=vertical;
      offscreenGraphics.setColor(Color.black);
    }

    end_points=new int[2*k];
    for(int i=0; i<k ; i++){
      Interval interval=(Interval)intervals.elementAt(i);
      end_points[2*i]=interval.left;
      end_points[2*i+1]=interval.right;
    }

    MyMethod.sort(end_points,2*k);

    v+=vertical;
    offscreenGraphics.setColor(Color.black);
    for(int i=0; i<2*k-1; i++){
      if(end_points[i]!=end_points[i+1]){
        offscreenGraphics.drawLine(end_points[i]*rate+add_just,v,
          end_points[i+1]*rate+add_just,v);
        offscreenGraphics.drawLine(end_points[i]*rate+add_just,v,
          end_points[i]*rate+add_just, v-5);
        offscreenGraphics.drawLine(end_points[i+1]*rate+add_just,v,
          end_points[i+1]*rate+add_just, v-5);
        offscreenGraphics.drawString(""+end_points[i],end_points[i]*rate+add_just
          , v+10);
        offscreenGraphics.drawString(""+end_points[i+1],end_points[i+1]*rate+add_just
          , v+10);
      }
    }

    g.drawImage(offscreenImage, 0,0,null);
  }
 
  public void update(Graphics g){
    paint(g);
  } 
}

class ControlP extends java.applet.Applet{
  Button play_b;
  Button quit_b;
  CheckboxGroup cbg;
  Checkbox pause_b;
  Checkbox continue_b;
  Demo demo;

  public ControlP(Demo d){
    demo=d;
    setLayout(new FlowLayout());
    play_b=new Button("PLAY");
    quit_b=new Button("QUIT");
    add(play_b);
    add(quit_b);
    cbg=new CheckboxGroup();
    continue_b=new Checkbox("CONTINUE",cbg,true);
    pause_b=new Checkbox("PAUSE",cbg, false);
    add(continue_b);
    add(pause_b);
  }
  public boolean action(Event evt, Object arg){
    if(evt.target==play_b)
      play();
    else if(evt.target==quit_b)
      quit();
    else set_runner((String)(cbg.getCurrent().getLabel()));
    return true;
  }
  public void play(){
    if(demo.runner!=null)
      return;
    demo.start();
  }
  public void quit(){
    if(demo.runner!=null)
      demo.runner.stop();
    demo.runner=null;
    demo.inf.win2.hide();
  }
  public void set_runner(String str){
    if(str.equals("CONTINUE"))
      demo.runner.resume();
    else if(str.equals("PAUSE"))
      demo.runner.suspend();
  }

}
