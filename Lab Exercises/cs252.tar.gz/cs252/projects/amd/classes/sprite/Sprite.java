package sprite;

import java.awt.*;

abstract public class Sprite {
    public SpriteArea area_;
    public int x_, y_;
    private int oldX_, oldY_;
    
    boolean anchored_, visible_;
    
    public Sprite(SpriteArea area, int x, int y) {
	this(area, x, y, true);
    }

    public Sprite(SpriteArea area, int x, int y, boolean visible) {
	area_ = area;
	x_ = x;
	y_ = y;
	oldX_ = -1;
	oldY_ = -1;
	visible_ = visible;
	anchored_ = false;
//	area_.AddSprite(this);
    }

    public void Add() {
	area_.AddSprite(this);
    }
    
    public void Remove() {
	area_.RemoveSprite(this);
	area_ = null;
    }

    public void Redraw() {
	if (anchored_) {
	    anchored_ = false;
	    area_.DirtyAnchor();
	}
	else
	    area_.Update();
    }

    public void MoveTo(int x, int y) {
	x_ = x;
	y_ = y;
	if (visible_) {
	    if (anchored_) {
		anchored_ = false;
		area_.DirtyAnchor();
	    }
	    else
		area_.Update();
	}
    }

    public void SetX(int x) {
	x_ = x;
	if (visible_) {
	    if (anchored_) {
		anchored_ = false;
		area_.DirtyAnchor();
	    }
	    else
		area_.Update();
	}
    }

    public void SetY(int y) {
	y_ = y;
	if (visible_) {
	    if (anchored_) {
		anchored_ = false;
		area_.DirtyAnchor();
	    }
	    else
		area_.Update();
	}
    }

    public void Show() {
	if (!visible_) {
	    visible_ = true;
	    if (anchored_)
		area_.DirtyAnchor();
	    else
		area_.Update();
	}
    }

    public void Hide() {
	if (visible_) {
	    visible_ = false;
	    if (anchored_)
		area_.DirtyAnchor();
	    else
		area_.Update();
	}
    }

    public boolean IsVisible() {
	return visible_;
    }

    public void Anchor() {
	if (!anchored_) {
	    anchored_ = true;
	    area_.DirtyAnchor();
	}
    }

    public void Unanchor() {
	if (anchored_) {
	    anchored_ = false;	
	    area_.DirtyAnchor();
	}
    }

    public void ZToTop() {
	area_.ZToTop(this);	
    }

    public void ZToBottom() {
	area_.ZToBottom(this);
    }
    
    public AnimationLock Flash(int delay, boolean synch) {
	AnimationLock lock = new AnimationLock();
	new AnimationThread(lock, this, x_, y_, 1, delay, true, false);
	if (synch) {
	    lock.WaitUntilDone();
	    return null;
	}
	else
	    return lock;
    }

    public AnimationLock SlideTo(int x, int y, int chunks, int delay,
				 boolean anchor, boolean synch) {
	AnimationLock lock = new AnimationLock();
	new AnimationThread(lock, this, x,y, chunks, delay, false, anchor);
	if (synch) {
	    lock.WaitUntilDone();
	    return null;
	}
	else
	    return lock;
    }

    public void handleEvent(Event e) { ; }
    
    abstract public boolean Inside(int x, int y);
    abstract public void Draw(Graphics g);
}
