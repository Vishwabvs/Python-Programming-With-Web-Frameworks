package sprite;

import java.awt.*;

public class CheckboxSprite extends Sprite {
    CheckboxOwner owner_;
    
    Color fore_;
    Font font_;
    String title_;
    int xAdd_, yAdd_, width_, height_;
    boolean enabled_, checked_, lastInside_, oldState_;
    
    public CheckboxSprite(SpriteArea area, int x, int y, String title) {
	this(null, area, x, y, title);
    }
    
    public CheckboxSprite(CheckboxOwner owner, SpriteArea area,
			  int x, int y, String title) {
	super(area, x, y);
	owner_ = owner;
	fore_ = Color.black;
	font_ = new Font("Dialog", Font.PLAIN, 10);
	title_ = title;
	enabled_ = true;
	checked_ = false;
	Add();
	Anchor();
	RecomputeSize();
    }

    public void SetState(boolean state) {
	checked_ = state;
	Redraw();
    }

    public boolean GetState() {
	return checked_;
    }
    
    public void SetFore(Color color) {
	fore_ = color;
	Redraw();
    }

    public void SetFont(Font font) {
	font = font_;
	RecomputeSize();
	Redraw();
    }

    public void SetTitle(String title) {
	title_ = title;
	RecomputeSize();
	Redraw();
    }

    public void Enable() {
	if (!enabled_) {
	    enabled_ = true;
	    Redraw();
	}
    }
    
    public void Disable() {
	if (enabled_) {
	    enabled_ = false;
	    Redraw();
	}
    }

    public boolean Inside(int x, int y) {
        int xOff = x - x_;
        int yOff = y - y_;
        return (xOff > 0 && xOff < width_ &&
		yOff > 0 && yOff < height_);
    }
    
    public void Draw(Graphics g) {
	if (enabled_) {
	    g.setColor(Color.black);
	    g.drawRect(x_, y_, BOX_SIZE, BOX_SIZE);
	    g.setColor(Color.white);
	    g.fillRect(x_ + 1, y_ + 1, BOX_SIZE - 2, BOX_SIZE - 2);	
	}
	else {
	    g.setColor(Color.lightGray);
	    g.fillRect(x_, y_, BOX_SIZE, BOX_SIZE);	    
	}

	if (checked_) {
	    g.setColor(Color.black);
	    g.drawLine(x_, y_, x_ + BOX_SIZE, y_ + BOX_SIZE);
	    g.drawLine(x_ + BOX_SIZE, y_, x_, y_ + BOX_SIZE);	    
	}
	
	g.setFont(font_);
	g.setColor(fore_);
	g.drawString(title_, x_ + xAdd_, y_ + yAdd_);
    }

    public void handleEvent(Event e) {
        switch (e.id) {
        case Event.MOUSE_DOWN:
	    if (enabled_) {
		oldState_ = checked_;
		checked_ = !checked_;
		lastInside_ = true;
		Redraw();
	    }
            break;
            
        case Event.MOUSE_DRAG:
	    if (enabled_) {
		boolean inside = Inside(e.x, e.y);
		if (inside != lastInside_) {
		    checked_ = !checked_;
		    lastInside_ = inside;
		    Redraw();
		}
	    }
            break;

        case Event.MOUSE_UP:
	    if (enabled_ && oldState_ != checked_) {
		if (owner_ == null)
		    Action(checked_);
		else
		    owner_.CheckboxChanged(this, checked_);
	    }
	    
            break;
        }
    }

    void RecomputeSize() {
	FontMetrics m = area_.getFontMetrics(font_);
	width_ = BOX_SIZE + BUFFER + m.stringWidth(title_);
	height_ = BOX_SIZE;
	xAdd_ = BOX_SIZE + BUFFER;
	yAdd_ = (height_ + m.getAscent()) / 2;
    }

    public void Action(boolean state) { ; }

    public final static int BOX_SIZE = 12;
    private final static int BUFFER = 4;    
}
