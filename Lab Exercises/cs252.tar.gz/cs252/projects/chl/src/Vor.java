
import java.util.Vector;
import java.lang.Object;
import java.awt.Point;
import java.lang.Math;


class Vec2 
{
public double x=0, y=0;
public Vec2(){x=0; y=0;}

public Vec2(double x, double y){
    this.x=x;
    this.y=y;
}

public Vec2(Point p){
    this.x=p.x;
    this.y=p.y;
}

public boolean equals(Object obj) {
    if (obj instanceof Vec2) {
	Vec2 pt = (Vec2)obj;
	return (x == pt.x) && (y == pt.y);
    }
    return false;
}

public Vec2 minus(Vec2 v){
    double x1=this.x-v.x;
    double y1=this.y-v.y;
    return new Vec2(x1, y1);
}

public Vec2 normalize(){
    double d=x*x+y*y;
    d=Math.sqrt(d);
    double x1=this.x/d;
    double y1=this.y/d;
    return new Vec2(x1, y1);
}

}

class Line extends Object
{
public   Vec2 pt1=new Vec2(1,1), pt2=new Vec2(1,1);  //two end points.
public   Vec2 pb1=new Vec2(1,1), pb2=new Vec2(1,1);//perpendicular bisector.
public static final int INF=5000; //used to define a far pt.
public   Vec2 interPt=new Vec2(1,1);
public   double ds=0;
public   Vec2  onePt=new Vec2();
public   Vec2  slope=new Vec2();
public   boolean hasEnd=false;
    
public Line(){}

//directed line. p1->p2.
public Line(Vec2 p1, Vec2 p2){
    this.pt1=p1; 
    this.pt2=p2;
    this.pb1=pbPt(1);
    this.pb2=pbPt(2);
    Vec2 dir=new Vec2(p1.x-p2.x, p1.y-p2.y);
    this.slope=dir.normalize();
}

public Vec2 pbPt(int i){ 
    double x=pt1.x-pt2.x;
    double y=pt1.y-pt2.y;
    if(y!=0) {
	Vec2 k=pbSlope();
	x=(pt1.x+pt2.x)/2.0+k.x*INF;
	y=(pt1.y+pt2.y)/2.0+k.y*INF;
	pb1=new Vec2(x,y);
	
	x=(pt1.x+pt2.x)/2.0-k.x*INF;
	y=(pt1.y+pt2.y)/2.0-k.y*INF;
	pb2=new Vec2(x,y);
    }
    else{
	x=(pt1.x+pt2.x)/2;
	pb1=new Vec2(x,INF);
	pb2=new Vec2(x,-INF);
    }

    if(i==1) return pb1;
    else return pb2;
 }


public Vec2 getPt(int i){ 
    if(i==1)   return pt1;
    else return pt2;
 }

public void setPt(int i, Vec2 p){ 
    if(i==1)   pt1=new Vec2(p.x, p.y);
    else pt2=new Vec2(p.x, p.y);
 }

///////////////

// get PB info.

///////////////


//this is a perp line thru pb1 & pb2, obtained from fr1 & fr2.
private Line(Vec2 p1,  Vec2 p2, 
	     Vec2 fr1, Vec2 fr2){
    this.pt1=p1;
    this.pt2=p2;
    this.pb1=fr1;
    this.pb2=fr2;
}

public Line PB(){ //pbs are computed from Line(pt,pt).

    return new Line(pb1, pb2,  pt1, pt2);
 }


//a pb line is obtained from ...
public Vec2 getFr(int i){
    if(i==1) return pb1;
    else return pb2;
}

public void setFr(int i, Vec2 p){
    if(i==1) pb1=p;
    else pb2=p;
}

public Vec2 slope(){//the slope is stored as a unit vector 1->2. Don't flip y
    double x1=pt2.x-pt1.x, y1=pt2.y-pt1.y;
    double d=Math.sqrt(x1*x1+y1*y1);
    return new Vec2(x1/d, y1/d);
}

public Vec2 pbSlope(){//the slope of the pb. Left turn from line to pb.
    double x1=pt2.y-pt1.y, y1=-(pt2.x-pt1.x); //flip sign.(x, y)->(y, -x).
    double d=Math.sqrt(x1*x1+y1*y1);
    return new Vec2(x1/d, y1/d);
}


public Vec2 mid(){
    return new Vec2((pt1.x+pt2.x)/2.0, (pt1.y+pt2.y)/2.0);
}


////////////////////////////////////

//determines if two lines intersects.

////////////////////////////////////

//this just gives the intersection point of two straight lines.
//which is not necessarily inside the two segments.

public Vec2 interPoint(){ //with current line.
    return interPt;
}

public double interDs(){
    return ds;
}


public boolean intersect(Vec2 p, Vec2 v){//Line(p,v).

//parallel or colinear lines means no intersection. 
//degenerate cases are hard to deal with.

/*****************************************************
  	x  y  1
	x0 y0 1  =0.  ===> Equations of lines.
	x1 y1 1	
******************************************************/

    double x0, y0, x1, y1, bx, by, b;

    x0=pt1.x; y0=pt1.y; x1=pt2.x; y1=pt2.y;
    bx=y0-y1; by=-(x0-x1); b=-(x0*y1-y0*x1);

//line p+t*v. bx*(p.x+t*v.x)+by*(p.y+t*v.y)=b.

    x0=bx*v.x+by*v.y;
    y0=b-bx*p.x-by*p.y;
    double t;

    //equation x0*t=y0.
    
    if(x0==0) { //also a serious error! colinear.
	//System.out.print("cof==0. "+x0);
	return false; //parallel or colinear(?).
    }
    else t=y0/x0;
    
    // if(t>=0 && t<0.001) System.out.print("t<=0.001 "+t);
    // if(t<0) System.out.print(" t<0. "+t);
    if(t<1e-30)return false; //p+t*v. 0.001 too close.
    

    else{
	x0=p.x+t*v.x;   //the interPoint.
	y0=p.y+t*v.y;
	interPt=new Vec2(x0, y0);

/******************************************************
   
Next, determine if the point is inside the segment.

******************************************************/

	b=pt2.x-pt1.x;
	t=x0-pt1.x;

	if(b==0){
	    b=pt2.y-pt1.y;
	    t=y0-pt1.y;
	}

	t=t/b;
	//since the denominator will not be zero.

	// the ratio should be in (0...1) .
	if(0<=t && t<=1){
	    x1=p.x-x0;
	    y1=p.y-y0;
	    ds=x1*x1+y1*y1;
	    return true;
	}
	else {
	    //if(x0>1000 || y0>1000)
	    // System.out.println("0..1 range: "+" "+(int)x0+" "+(int)y0);
	    return false;
	}
    }   
    
}
    
}


class Voronoi //extends Object
{
//Data member.
    Vector v=new Vector(); //vertices.
    Vector conv=new Vector(); //convex hull.
    Vector pb=new Vector(); //perpendicular bisectors.
    Line support1=new Line();
    Line support2=new Line();
    Vector sep=new Vector(); //the dividing chain.
    boolean found=true;
    Vector totalRem=new Vector(); //all the removed lines. in the order.
    int remSide[]=new int[10];

//Methods.
public Voronoi(){};

public Voronoi(Vector v){
    this.v=v;
    int s=v.size();
    Vector vp=new Vector();
    //deal with special cases.
    if(s==1){//no pb actually. But for convenience later, give it a far one.
	int i=10000, j=20000;
	Line far=new Line(new Vec2(i, i), new Vec2(j, j));	
	vp.addElement(far);
	this.conv.addElement(v.elementAt(0));
	this.pb.addElement(vp); //for s==1, actually won't need this.
    }
    if(s==2){
	Line line=new Line((Vec2)v.elementAt(0), (Vec2)v.elementAt(1));
	//store points.
	this.conv.addElement(v.elementAt(0));
	this.conv.addElement(v.elementAt(1));
	vp.addElement(line.PB());
	this.pb.addElement(vp);
	this.pb.addElement(vp);
    }
}

public Voronoi simple34(int w){

    //find the point w/ max x.
    
    int s=v.size(), i, j=0;    
    double xi, x0=((Vec2)v.elementAt(0)).x;
    for(i=0; i<s; i++){
	xi=((Vec2)v.elementAt(i)).x;
	if(xi>x0) {x0=xi; j=i;}
    }
    
    Vector v1=new Vector(), v2=new Vector();
    v2.addElement((Vec2)v.elementAt(j));

    for(i=0; i<s; i++) 
	if(i!=j) v1.addElement(v.elementAt(i));
    
    Voronoi V1=new Voronoi(v1), V2=new Voronoi(v2);
    
    if(w==3) {
	V1.conv=convexHull(v1, v2);
	Vec2 p0=(Vec2)v.elementAt(0);
	Vec2 p1=(Vec2)v.elementAt(1);
	Vec2 p2=(Vec2)v.elementAt(2);
	if(isColinear(p0, p1, p2)){
	    //System.out.println("Colinear? "+isColinear(p0, p1, p2));
	    V1.pb=colinearPB(V1, V2);
	}

        else V1.pb=PB(V1, V2);	
	if(w==3 && !found) V1.conv=sort(p0, p1, p2);

	V1.v.addElement((Vec2)v.elementAt(j));
	return V1;
    }
    
    if(w==4) V1=V1.simple34(3); //simple recursive step.    
    return new Voronoi(V1, V2);
}


public Voronoi(Voronoi v1, Voronoi v2){

    int s1=v1.v.size();
    int s2=v2.v.size();
    for(int i=0; i<s1+s2; i++){
	if(i<s1) this.v.addElement(v1.v.elementAt(i));
	else this.v.addElement(v2.v.elementAt(i-s1));
    }
    this.conv=convexHull(v1.conv, v2.conv); 
    this.pb=PB(v1, v2);
}

public Line support(int i){
    if(i==1) return support1;
    else return support2;
}

public double distSq(Vec2 v1, Vec2 v2){
    double x=v1.x-v2.x, y=v1.y-v2.y;
    return x*x+y*y;
}


private boolean isPositive(Vec2 p0, Vec2 p1, Vec2 p2){//orientation:p0->p1->p2.
    double x0, x1, y0, y1;

    x0=p1.x-p0.x;
    y0=p1.y-p0.y;

    x1=p2.x-p0.x;
    y1=p2.y-p0.y;

    /*
      x0 y0 1
      x1 y1 1  >0.
      x2 y2 1      

     */

    double det=x0*y1-y0*x1;

    if(det<=0) return true; //<-the Coord system is not the math one.
    else return false; 
}

private boolean isColinear(Vec2 p0, Vec2 p1, Vec2 p2){
    double x0, x1, y0, y1;

    x0=p1.x-p0.x;
    y0=p1.y-p0.y;

    x1=p2.x-p0.x;
    y1=p2.y-p0.y;

    double det=x0*y1-y0*x1;
    if(det==0) return true; 
    else return false; 
}

//this returns the Vector of points in the increasing order of x or y.
private Vector sort(Vec2 p0, Vec2 p1, Vec2 p2){
    Vector Points=new Vector();
    
    Points.addElement(p0);
    Points.addElement(p1);
    Points.addElement(p2);
    
    double x0, y0;
    int i, j, k;
    Vec2 pp1, pp2;

    for(i=0; i<3; i++){
	x0=((Vec2)Points.elementAt(i)).x;
	y0=((Vec2)Points.elementAt(i)).y;
	
	k=i;
	for(j=i+1; j<3; j++){
	    pp1=(Vec2)Points.elementAt(j); 
	    if(pp1.x<x0){k=j; x0=pp1.x;}
	    else if(pp1.x==x0 && pp1.y<y0){
		x0=pp1.x; y0=pp1.y; k=j;}
	}
	pp2=(Vec2)Points.elementAt(k);
	Points.removeElementAt(k);
	Points.insertElementAt(pp2,i);
    }
    
    return Points;

}


//this method determines if line is on the same side of p0->p1 with given dir.
//here assumes at least one of the end points of line is not equal to p0 0r p1.
//the above method doesn't work for this purpose.

private boolean sameSide(Vec2 p0, Vec2 p1, Line line, boolean turn){
    Vec2 e1=line.getPt(1), e2=line.getPt(2);
    if(e1.equals(p0)||e1.equals(p1)) 
	return isPositive(p0, p1, e2)==turn;
    else if(e2.equals(p0)||e2.equals(p1)) 
	return isPositive(p0, p1, e1)==turn;
    else return( (isPositive(p0, p1, e1)==turn) &&
		 (isPositive(p0, p1, e2)==turn) );
}

    
//the angle of p-at w.r.t. X axis. 
public double angle(Vec2 p, Vec2 at)
{
    double x=p.x-at.x, y=-(p.y-at.y);
    double ang=Math.atan2(y, x);
    if(ang<0) ang=2*Math.PI+ang;  //atan2: -PI --> PI.
    return ang;
}


//counterclockwise rotate p1-at to p2-at. 
double rotAng(Vec2 p1, Vec2 p2, Vec2 at)
{
    double a, a1, a2;
    a1=angle(p1, at);
    a2=angle(p2, at);
    a=a2-a1;
    if(a<0) a=a+2*Math.PI;
    return a;
}


public Vector convexHull(Vector p, Vector q){

//here assume p & q are both convex and linearly separate.
//assume size>=2+1.
//also assume points are ordered counterclockwise.

    Vector cv=new Vector();
    if(p.size()==2 && q.size()==1){
	Vec2 x=(Vec2)p.elementAt(0);
	Vec2 y=(Vec2)p.elementAt(1);
	Vec2 z=(Vec2)q.elementAt(0);

	cv.addElement(x);
	if(isColinear(x, y, z)){
	    Vector vv=sort(x, y, z);
	    for(int tn=0; tn<3; tn++)
		cv.addElement((Vec2)vv.elementAt(tn));
	}

	else {
	    if(isPositive(x, y, z)) {
		cv.addElement(y);
		cv.addElement(z);
		support1=new Line(z, x);
		support2=new Line(y, z);
	    }
	    else{
		cv.addElement(z);
		cv.addElement(y);
		support1=new Line(z, y);
		support2=new Line(x, z);	   
	    }
	}
    }

    else if(p.size()>2 && q.size()>0){
	double x[]=new double[3], y[]=new double[3];
	x[0]=((Vec2)p.elementAt(0)).x; y[0]=((Vec2)p.elementAt(0)).y;
	x[1]=((Vec2)p.elementAt(1)).x; y[1]=((Vec2)p.elementAt(1)).y;
	x[2]=((Vec2)p.elementAt(2)).x; y[2]=((Vec2)p.elementAt(2)).y;

	double cx=(x[0]+x[1]+x[2])/3.0;
	double cy=(y[0]+y[1]+y[2])/3.0;
	Vec2 c=new Vec2(cx, cy);

/********************************************************************

  the point c = (cx,cy) is in p, not in q, so remove some edges of q.
  those whose orientation w.r.t. c is negative will be discarded.
  
  *********************************************************************/    
	int n=0, n1=0, n2=0;
        int s=q.size();
	Vec2 c1, c2, c3;
	for(int i=0; i<s; i++){
	    c1=(Vec2)q.elementAt(i);
	    c2=(Vec2)q.elementAt((i+1)%s);
	    c3=(Vec2)q.elementAt((i+2)%s);
	
	    if( isPositive(c, c1, c2) != isPositive(c, c2, c3) ){
		n++;
		if(n==1) n1=i+1;
		else { //two extreme point.
		    n2=i+1; 
		    i=s; //end the for loop.
		}
	    }
	}
	c1=(Vec2)q.elementAt(n1%s);
	c2=(Vec2)q.elementAt(n2%s);
	if(!isPositive(c, c1, c2)) {//n2->n1+s;
	    n=n1+s; 
	    n1=n2; 
	    n2=n; //then n1 is always <n2.	
	} //then both cases can be dealt with by the following loop.
        for(n=n1; n<=n2; n++) cv.addElement((Vec2)q.elementAt(n%s));

//Remark: This solves the special case q.size()==1,2 elegantly.

/*****************************************************
  
  Remove all points of p in the wedge (n1->n2). 
  Compare angles.

  *****************************************************/
	c1=(Vec2)q.elementAt(n1%s);
	c2=(Vec2)q.elementAt(n2%s);
					
	double ang, a=-1;
	int sp=p.size(), m=0; //to denote the pt w/ maximal angle.
	ang=rotAng(c1, c2, c);
	double an[]=new double[sp];
	
	//add those whose rotAng >ang. Start from the biggest angle.
	
	for(n=0; n<sp; n++){	
	    Vec2 pt=(Vec2)p.elementAt(n);
	    an[n]=rotAng(pt, c2, c);
	    if(an[n]>a && an[n]!=2*Math.PI) {a=an[n]; m=n;}
	}
    
	for(n=m; n<m+sp; n++)
	    if(an[n%sp]>ang) cv.addElement((Vec2)p.elementAt(n%sp));

	
/*****************************************************
  
  Then apply Graham scan to the sorted list cv.
  
  *****************************************************/
	
		
	sp=cv.size();
	//start from the right most point.
	m=0;
	double d1, d2;
	d1=((Vec2)cv.elementAt(0)).x;

        for(n=0; n<sp; n++){
	    d2=((Vec2)cv.elementAt(n)).x;
	    if(d2>d1) {d1=d2; m=n;}
	}

        c1=(Vec2)cv.elementAt(m);
        c2=(Vec2)cv.elementAt((m+1)%sp);
        c3=(Vec2)cv.elementAt((m+2)%sp);
	c=c1;

	int nt=0;
        while(!c2.equals(c) || nt>0){	    
	    if(isPositive(c1, c2, c3)) {
		m++;
		nt=0;
	    }
	    else{
		nt++;
		cv.removeElement(c2);
		m--;
		if(m==-1) m=cv.size()-1;
	    }

	    sp=cv.size();
	    c1=(Vec2)cv.elementAt(m%sp);
	    c2=(Vec2)cv.elementAt((m+1)%sp);
	    c3=(Vec2)cv.elementAt((m+2)%sp);
	}
		    

/*****************************************************

  compare to find the new edge on the convex hull.
  
  *****************************************************/
	sp=cv.size();
	m=0;
	for(n=0; n<sp; n++){
	    c1=(Vec2)cv.elementAt(n);
	    c2=(Vec2)cv.elementAt((n+1)%sp);

	    if(p.contains(c2) && q.contains(c1)){
		support1=new Line(c1, c2);
		m++;
	    }
	    else if(p.contains(c1) && q.contains(c2)){ 
		support2=new Line(c1, c2);
		m++;
	    }
	    if(m==2) n=sp; //end the loop. 
	}
    }
    return cv;	
}


private Vector colinearPB(Voronoi V1, Voronoi V2){

    //here assume the 3 points are colinear.
    Vec2 p0, p1, p2;

    p0=(Vec2)V1.v.elementAt(0);
    p1=(Vec2)V1.v.elementAt(1);
    p2=(Vec2)V2.v.elementAt(0);

    Vector vv=sort(p0, p1, p2);
    Vec2 v0, v1, v2;
    v0=(Vec2)vv.elementAt(0);
    v1=(Vec2)vv.elementAt(1);
    v2=(Vec2)vv.elementAt(2);
	    
    Vector pbs=new Vector(), pb[]=new Vector[3];
    for(int i=0; i<3; i++)
	pb[i]=new Vector();
    Line line1=new Line(v0, v1);
    pb[0].addElement(line1.PB());
    pb[1].addElement(line1.PB());
    Line line2=new Line(v1, v2);
    pb[1].addElement(line2.PB());
    pb[2].addElement(line2.PB()); 

    for(int i=0; i<3; i++)
	pbs.addElement(pb[i]);
    return pbs;
    
}


public Vector PB(Voronoi v1, Voronoi v2){


    //assume v1 is on left and v2 right.
    //first start from the upper support line.
    Vector pbs=new Vector(); //new pbs, which is a Vector of Vectors.
    Vector rem=new Vector(); //to store the removed lines each time.

    Line sp1=support(1), sp2=support(2),
	 line=new Line(), pbHt=new Line(), pbLn=new Line();
    Vec2 sp1Pt1=sp1.getPt(2), sp1Pt2=sp1.getPt(1),//1<-2.
	  sp2Pt1=sp2.getPt(1), sp2Pt2=sp2.getPt(2),
	  walkHt=new Vec2(0,0);
    Vec2 mp=sp1.mid();
    Vec2 slp=sp1.pbSlope(); 
    double INF=5000; 
    Vec2 far=new Vec2(mp.x-INF*slp.x, mp.y-INF*slp.y);
    Vec2 walk=new Vec2(far.x, far.y);
    

    boolean travel=true, leave=true;
    double d, d0=1e+100; //a long distance.

    //first need to know the region where the initial point lies.
    //this can be found by the first hit line. just need to check 
    //the lines which the supports have.
    
    int in1=0, in2=0, in=0, out=0;
    in1=v1.v.indexOf(sp1Pt1);
    in2=v2.v.indexOf(sp1Pt2);

    if(v1.pb.size()>0 && v2.pb.size()>0)
	{
	    Vector pb1=(Vector)v1.pb.elementAt(in1);
	    Vector pb2=(Vector)v2.pb.elementAt(in2);

	    Vector pbIn=new Vector(), pbOut=new Vector();
	    Vector pbIncreIn=new Vector(), pbIncreOut=new Vector();
    
	    //find which lines will be hit. 
	    int i=pb1.size(), j=pb2.size(), k;
	
	    Vec2 inside=new Vec2(0,0), outside=new Vec2(0,0); 
	    //the point inside a Voronoi polygon.
	    int side=1; //means which side the inside point lies.

	    boolean ft=false; 
	    boolean found=false;
	    
	    for(k=0; k<i+j; k++){
		if(k<i) pbLn=(Line)(pb1.elementAt(k)); 
		else pbLn=(Line)(pb2.elementAt(k-i));
		ft=pbLn.intersect(walk, slp);
		if(ft) found=true;

		if(pbLn.intersect(walk, slp)){
		    ft=pbLn.intersect(walk, slp);
		    d=pbLn.interDs();
		    if(d!=0 && d<d0){
			d0=d; in=k;
			walkHt=pbLn.interPoint();
			pbHt=pbLn; //ref.
			
		    }
		}
	    }

	   
	    if(in<i){inside=sp1Pt1; outside=sp1Pt2; side=1;} 
	    else {inside=sp1Pt2; outside=sp1Pt1; side=2;}
	    
	    if(!found){
		//System.out.println("initial walkHt not found! Sizes "+
		//		   v1.v.size()+" "+v2.v.size());
		if(v1.v.size()+v2.v.size()==3) return colinearPB(v1, v2);
		else return pbs;
		//System.out.println("won't go here.");
	    }

	    int M=-1; int nt=i+j+2; //so that for it won't affect the 1st time.
	    while(travel && M<v1.v.size()+v2.v.size()){
		//After two pts of sp2 are travesd, the loop will end.
		M++;
		if( (inside.equals(sp2Pt1) && outside.equals(sp2Pt2)) ||
		    (inside.equals(sp2Pt2) && outside.equals(sp2Pt1)) ) 
		    travel=false;

		in=(side==1)?v1.v.indexOf(inside):v2.v.indexOf(inside);	
		
		pbIn=new Vector();
		pbIn=(side==1)?(Vector)v1.pb.elementAt(in) :
		    (Vector)v2.pb.elementAt(in);

		Vec2 oldIn=new Vec2(1,1), oldOut=new Vec2(1,1);
		int oldSide=0;

		//find which lines of pbIn will be hit.
			
		out=(side==2)?v1.v.indexOf(outside):v2.v.indexOf(outside);
		pbOut=new Vector();
		pbOut=(side==2)?(Vector)v1.pb.elementAt(out) :
		    (Vector)v2.pb.elementAt(out);
		i=pbIn.size(); j=pbOut.size();
		d0=1e+30; 
		
		ft=false;
		found=false;

		//System.out.println("totalLines:"+(i+j));
		if(travel) for(k=0; k<i+j; k++){
		    if(k!=i+nt) {
			if(k<i) pbLn=(Line)(pbIn.elementAt(k)); 
			else pbLn=(Line)(pbOut.elementAt(k-i));

			ft=pbLn.intersect(walk, slp);
			if(ft) found=true;

			d=pbLn.interDs();
			//in1=pbLn.getPt(1).x;
			//in2=pbLn.getPt(2).x;
			//System.out.println("hitOne? "+ft+" dist="+d+" ");
			//		   +in1+" "+in2);

		        if(ft){    // pbLn.intersect(walk, slp)){
			    d=pbLn.interDs();
			    if(d!=0 && d<d0){
				d0=d; in=k;
				walkHt=pbLn.interPoint();
				pbHt=pbLn;    
			    }
			}	    
		    }
		}
		else {
		    walkHt=new Vec2(walk.x-1500*sp2.pbSlope().x, 
				    walk.y-1500*sp2.pbSlope().y); 
		    ft=true;
		    oldIn=inside; oldOut=outside; oldSide=side;
		}
		if(found==false) M=v1.v.size()+v2.v.size();
		
           
		Line newPb=new Line(walk, walkHt); 
		newPb.setFr(1, inside);
		newPb.setFr(2, outside);
		sep.addElement(newPb);
		
		pbIncreIn.addElement(newPb); //reference established here. 
		pbIncreOut.addElement(newPb); 

		if(travel){
		    
		    Vec2 fr1=pbHt.getFr(1), fr2=pbHt.getFr(2);
		    
		    if(outside.equals(fr1)||outside.equals(fr2)){ 
			oldIn=inside;		    
			oldOut=outside; 
			leave=false; 
		    	oldSide=side;
			if(outside.equals(fr1)) outside=fr2;
			else outside=fr1;
		    }
		    else {
			oldIn=inside;  
			oldOut=outside;
			leave=true; 
			oldSide=side;  
			side=3-side;
			
			if(inside.equals(fr1))  outside=fr2;
			else if(inside.equals(fr2)) outside=fr1; 
			inside=oldOut; 
		    }
		}

		boolean tf=true; //CCW or CW.
		Vec2 Pt=outside;
		
		int ti=0, ni=0, si=0;
		Vec2 end1=new Vec2(1,1), end2=new Vec2(1,1);

		if(leave==false || travel==false){
		    //the outside point has been passed by, 
		    //didn't become an inside pt.
		    //then just need to add one line and remove some.
		    //need to know the index of the current hit line.
	    
		    tf=(oldSide==1)?true:false; //if out in 2, then true.
	    
		    j=2;        
		    if(!travel) {Pt=oldOut; j=1;}
		    for(i=0; i<j; i++){
			//also set the same point of another pb.
			if(i==1) Pt=oldOut;
			out=(oldSide==2)?v1.v.indexOf(Pt):v2.v.indexOf(Pt);
			pbOut=new Vector();
			pbOut=(oldSide==2)?(Vector)v1.pb.elementAt(out) :
			    (Vector)v2.pb.elementAt(out) ;	
		
			ti=pbOut.indexOf(pbHt); 
			if(ti==-1 && !travel) ti=0;

			if(i==0) nt=ti;  
		    }
  
		    

		    if(travel){
			rem=new Vector();
			remSide[M]=3-oldSide;

			if(ti==-1){
			    // System.out.println("ti==-1.Wrong.noLv.");
			    // System.out.println(pbHt.getPt(1)+" "+
				//	       pbHt.getPt(2));
			    //System.out.println(pbHt.getFr(1)+" "+
				//	       pbHt.getFr(2));
			//System.out.println(inside+" "+outside);
			}
			//good reference relationship. Just need to do it once.
			line=(Line)pbOut.elementAt(ti);
			end1=line.getPt(1);	    end2=line.getPt(2);
			
			if(isPositive(walk, walkHt, end1)==tf&& 
			   isPositive(walk, walkHt, end2)!=tf){
			    rem.addElement(new Line(end2, walkHt));
			    line.setPt(2, walkHt);
			}
			else if(isPositive(walk, walkHt, end2)==tf && 
				isPositive(walk, walkHt, end1)!=tf){
			    rem.addElement(new Line(end1, walkHt));
			    line.setPt(1,walkHt);
			}
			
		    }
		    
		    si=pbOut.size();
		    
		    for(ni=ti; ni<ti+si; ni++){
			line=(Line)pbOut.elementAt(ni%si);
			if(sameSide(walk, walkHt, line, tf))
			    pbIncreOut.addElement(line);
			else if(travel) rem.addElement(line);
		    }
		    
		    if(travel) totalRem.addElement(rem);

		    if(oldSide==2) v1.pb.setElementAt(pbIncreOut, out);
		    else v2.pb.setElementAt(pbIncreOut, out);
		    pbIncreOut=new Vector();
		    
		}
		
		//end of if(leave==false).
		
		if(leave==true || travel==false){
		    //exit from an inside point.
		    //deal with the inside one and 
		    //make the old outside the new inside.

		    j=2;        
		    if(!travel) {Pt=oldIn; j=1;}
		    tf=(oldSide==2)?true:false;
	    
		    for(i=0; i<j; i++){
			if(i==1) Pt=oldIn; 
			in=(oldSide==1)?v1.v.indexOf(Pt):v2.v.indexOf(Pt);
			pbIn=new Vector();
			pbIn=(oldSide==1)?(Vector)v1.pb.elementAt(in) :
			    (Vector)v2.pb.elementAt(in) ;
			ti=pbIn.indexOf(pbHt);
			if(i==0) nt=ti;
			if(ti==-1 && !travel) ti=0;
		    }

		    if(travel){
			rem=new Vector();
			remSide[M]=oldSide;
			if(ti==-1){
			    // System.out.println("ti==-1. Wrong. Lv.");
			    //System.out.println(pbHt.getPt(1)+" "+
			    //		       pbHt.getPt(2));
			    //System.out.println(pbHt.getFr(1)+" "+
			    //		       pbHt.getFr(2));
			    //System.out.println(inside+" "+outside);
			}

			line=(Line)pbIn.elementAt(ti);
			end1=line.getPt(1);  end2=line.getPt(2);
			
			if(isPositive(walk, walkHt, end1)==tf&& 
			   isPositive(walk, walkHt, end2)!=tf){
			    rem.addElement(new Line(end2, walkHt));
			    line.setPt(2, walkHt);
		        }
			else if(isPositive(walk, walkHt, end2)==tf && 
				isPositive(walk, walkHt, end1)!=tf){
			    rem.addElement(new Line(end1, walkHt));
			    line.setPt(1, walkHt);
		        }
		    }
		    
		    si=pbIn.size(); 
		    int sz=pbIncreIn.size();
		    Vector oldInc=new Vector();
		    for(i=0; i<sz; i++) //copy data one by one.
			oldInc.addElement((Line)pbIncreIn.elementAt(i));
		    
		    for(ni=ti; ni<ti+si; ni++){
			line=(Line)pbIn.elementAt(ni%si);
			for(j=0; j<sz; j++){
			    Line jl=(Line) oldInc.elementAt(j);
			    end1=jl.getPt(1); end2=jl.getPt(2); //wk->wt.
			    if(!sameSide(end1, end2, line, tf)){
				j=sz;
				if(travel) rem.addElement(line);
			    }
			}
			if(j!=sz+1){ pbIncreIn.addElement(line);
			//System.out.println("lineAdd.");
			}
		    }	
		    
		    if(travel) totalRem.addElement(rem);

		    if(oldSide==1) v1.pb.setElementAt(pbIncreIn, in);
		    else v2.pb.setElementAt(pbIncreIn, in);
		    pbIncreIn=pbIncreOut;
		    pbIncreOut=new Vector();
		}
	
		//new direction of the next walk.
				
		line=new Line(inside, outside);
		mp=line.pbSlope();
		
		Vec2 ptTry=new Vec2(walkHt.x+100*mp.x, walkHt.y+100*mp.y);

		boolean dir=(side==2)?true:false;

		if(isPositive(walk, walkHt, ptTry)==dir) slp=mp;
		else slp=new Vec2(-mp.x, -mp.y);
		
		walk=walkHt; //start here next.	

	    }
	    
	    //end of while.

	    //concatenate the two arrays to return.
	    i=v1.pb.size(); j=v2.pb.size();
	    for(k=0; k<i+j; k++){
		if(k<i) pbs.addElement(v1.pb.elementAt(k));
		else pbs.addElement(v2.pb.elementAt(k-i));
	    }
    
	}
	//end of if(size >0).		
   
    return pbs;
   }

}








