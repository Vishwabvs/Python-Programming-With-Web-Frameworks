/****************************************************************/
/*    NAME:                                                     */
/*    ACCT: mjw                                                 */
/*    FILE:  GNode.C                                            */
/*    ASGN:                                                     */
/*    DATE: Wed Apr 10 17:50:10 1996                            */
/****************************************************************/

#include "GNode.H"
#include <assert.h>




/****************************************************************/
/*                                                              */
/* Function Name: GNode                                        */
/* Parameters:    void                                          */
/* Returns:       nothing                                       */
/* Effects:       init member vars                              */
/*                                                              */
/****************************************************************/

GNode::GNode(): RTGraphic()
{
    begin_ = end_ = median_ = 0;
    left_selected_ = right_selected_ = false;
    parent_     = NULL;
    left_child_ = NULL;
    right_child_= NULL;
}



/****************************************************************/
/*                                                              */
/* Function Name: ~GNode                                       */
/* Parametesr:     none                                         */
/* Returns:        nothing                                      */
/* Effects:        Clears the list and sets pointers to NULL.   */
/*                                                              */
/****************************************************************/

GNode::~GNode()
{
	left_child_	= NULL;
	right_child_	= NULL;
	parent_		= NULL;
}



/****************************************************************/
/*                                                              */
/* Function Name: setChildSelected                              */
/* Parameters:    CHILD -- specifying which child to select     */
/*                bool --  whether to select or deselect        */
/* Returns:       void                                          */
/* Effects:       Either selects or deselects the specified     */
/*                child.                                        */
/*                                                              */
/****************************************************************/  

void
GNode::setChildSelected(CHILD which, bool select)
{
    switch (which) {
     case LEFT_CHILD: 	left_selected_ = select; 	    break;
     case RIGHT_CHILD:  right_selected_ = select;	    break;
     default: assert(false);
     }; 
}



/****************************************************************/
/*                                                              */
/* Function Name:  setParent                                    */
/* Parameters:     GNode* -- new parent                        */
/* Returns:        void                                         */
/* Effects:        Sets the parent_ field to the new node.      */
/*                                                              */
/****************************************************************/  

void
GNode::setParent(GNode *node)
{
    assert(node != NULL);
    parent_ = node;
}



/****************************************************************/
/*                                                              */
/* Function Name: isChildSelected                               */
/* Parameters:    CHILD -- which child to check                 */
/* Returns:       bool -- true if selected, false otherwise     */
/* Effects:       see above...                                  */
/*                                                              */
/****************************************************************/

bool GNode::isChildSelected(CHILD which) const
{
     switch (which) {
     case LEFT_CHILD: 	return left_selected_;
     case RIGHT_CHILD:  return right_selected_;
     default: assert(false);
     };
}





// does not print \n char
ostream& operator<<(ostream& out, const GNode& node)
{
    out <<node.getID()<< " "<< node.getPX()<<" "<<node.getPY()<<" ";
    out <<node.getBegin()<<" "<<node.getMedian()<<" "<<node.getEnd()<<"  ";
    return out;
}

istream& operator>>(istream& in, GNode& node)
{
    return in;
}

