/*
 *  FileIO - loads figures from a figure library
 *  4/14/96 
 *  by Daniel Spirn 
 *
 */
package graphrender;

import java.io.*;
import java.net.*;
import java.applet.Applet;

// exception class
//
class GRFileFormatException extends Exception {
    public GRFileFormatException(String s) {
	super(s);
    }
}

// basic routine for loading a file into a GRGraph graph structure
// 
class GRFileIO {
    InputStream fis = null;
    Applet applet_;

    GRFileIO(Applet applet) {
	applet_ = applet;
    }

    public GRGraph readInGraph(String filename, GRGraphArea ga) 
		throws IOException, GRFileFormatException {

	GRGraph newgraph = new GRGraph(ga);

	// Connect with the file
	try {
		fis = new URL(applet_.getDocumentBase(), filename).openStream();

	} catch (Exception e) {
		System.err.println(e.toString());
		return null;
	} 

	// Parse shape into new graph
	StreamTokenizer st = new StreamTokenizer(fis);
	st.eolIsSignificant(true);
	st.commentChar('#');
scan:
	while (true) {
	    switch (st.nextToken()) {
	      default:
		break scan;
	      case StreamTokenizer.TT_EOL:
		break;
	      case StreamTokenizer.TT_WORD:
		if ("v".equals(st.sval)) {
		    double x = 0, y = 0, z = 0;
		    if (st.nextToken() == StreamTokenizer.TT_NUMBER) {
			x = st.nval;
			if (st.nextToken() == StreamTokenizer.TT_NUMBER) {
			    y = st.nval;
			    if (st.nextToken() == StreamTokenizer.TT_NUMBER)
				z = st.nval;
			}
		    }
		    newgraph.addNode((double) x, (double) y, (double) z);	    
		    while (st.ttype != StreamTokenizer.TT_EOL &&
			    st.ttype != StreamTokenizer.TT_EOF)
			st.nextToken();
		} else if ("f".equals(st.sval) || "fo".equals(st.sval) || "l".equals(st.sval)) {
		    int start = -1;
		    int prev = -1;
		    int n = -1;
		    int numedges = 0;
		    while (true)
			if (st.nextToken() == StreamTokenizer.TT_NUMBER) {
			    n = (int) st.nval;
			    if (prev >= 0) {
				numedges++;
				newgraph.addEdge(newgraph.nodes()[prev - 1],
					 	 newgraph.nodes()[n - 1]);
			    }
			    if (start < 0)
				start = n;
			    prev = n;
			} else if (st.ttype == '/')
			    st.nextToken();
			else
			    break;
		    if ((start >= 0) && (numedges != 1))
			newgraph.addEdge(newgraph.nodes()[start - 1],
					 newgraph.nodes()[prev - 1]);
		    if (st.ttype != StreamTokenizer.TT_EOL)
			break scan;
		} else {
		    while (st.nextToken() != StreamTokenizer.TT_EOL
			    && st.ttype != StreamTokenizer.TT_EOF);
		}
	    }
	}
	fis.close();
	if (st.ttype != StreamTokenizer.TT_EOF)
	    throw new GRFileFormatException(st.toString());

	if (ga.gc.autoscale() == false) {
		ga.gc.autoscaling_ = true;
		newgraph.calculateViewFactor();
		ga.gc.autoscaling_ = false;
	}
	else {
		newgraph.calculateViewFactor();
	}		
	double factor = newgraph.viewfactor();
	System.out.println("VIEWFACTOR = " + factor);
	for (int i = 0 ; i < newgraph.numnodes() ; i++) {
		newgraph.nodes()[i].setx(newgraph.nodes()[i].x() * factor);
		newgraph.nodes()[i].sety(newgraph.nodes()[i].y() * factor);
		newgraph.nodes()[i].setz(newgraph.nodes()[i].z() * factor);	
	}
	return (newgraph);   
    }
}





