import java.awt.*;
import java.util.*;
public class WV_Box extends Canvas implements WV_SpringLoaded {

  protected String		id_;
  protected WV_String		title_;
  protected WV_ComponentVector	connections_;
  protected WV_StringVector	info_;
  protected Color		color_;
  protected int			last_x_;
  protected int			last_y_;
  protected int			min_h_;
  protected int			min_w_;
  protected int			border_;
  protected boolean		resizing_ = false;
  protected boolean		selected_ = false;

/****************************************************************/
/*                                                              */
/* Function Name: WV_Box                                        */
/* Parameters:                                                  */
/* Returns:                                                     */
/* Effects:                                                     */
/*                                                              */
/****************************************************************/
  public WV_Box(WV_String title, WV_Box parent) 
  {
    title_ = title;
    color_ = new Color((int) (Math.random() * 255),
		       (int) (Math.random() * 255),
		       (int) (Math.random() * 255));
    move(0, 0);

    min_h_ = -1;
    min_w_ = -1;
    resize(25, 10);
    connections_ = new WV_ComponentVector();
    info_ = new WV_StringVector();

    border_ = 5;
  }

  public WV_Box(WV_String title, WV_Box parent,
		Point location, Dimension size) 
  {
    title_ = title;
    move(location.x, location.y);
    resize(size.width, size.height);

    min_h_ = -1;
    min_w_ = -1; 
    border_ = 5;

    connections_ = new WV_ComponentVector();
    info_ = new WV_StringVector();
    color_ = new Color((int) (Math.random() * 128 + 128),
		       (int) (Math.random() * 128 + 128),
		       (int) (Math.random() * 128 + 128));
  }


/****************************************************************/
/*                                                              */
/* Function Name: Accessor methods                              */
/* Parameters:                                                  */
/* Returns:                                                     */
/* Effects:                                                     */
/*                                                              */
/****************************************************************/
  
  public WV_String getTitle()			{ return (title_); }
  public void setTitle(WV_String new_title)	{title_ = new_title; }

  
  public synchronized boolean isIn(int x, int y) {
    return (x-location().x >= 0) && 
      ((x-location().x) < size().width) && 
      (y-location().y >= 0) && 
      ((y-location().y) < size().height);
  }

/****************************************************************/
/*                                                              */
/* Function Name: addText                                       */
/* Parameters:                                                  */
/* Returns:                                                     */
/* Effects:                                                     */
/*                                                              */
/****************************************************************/
  public boolean addText(String s) {
    info_.addElement(new WV_String(s));
    return true;
  }


/****************************************************************/
/*                                                              */
/* Function Name: minimumSize                                   */
/* Parameters:                                                  */
/* Returns:                                                     */
/* Effects:                                                     */
/*                                                              */
/****************************************************************/
  public Dimension minimumSize() {

    return (new Dimension(min_w_, min_h_));
    
  }
  
/****************************************************************/
/*                                                              */
/* Function Name: update                                        */
/* Parameters:                                                  */
/* Returns:                                                     */
/* Effects:                                                     */
/*                                                              */
/****************************************************************/

  public void update(Graphics g) {

    if (min_h_ == -1) {
      if (g != null) {
	FontMetrics fm = g.getFontMetrics(g.getFont());
  
	min_w_ = (int) (fm.stringWidth(title_.string_) * 1.1) + border_ * 3;
	min_h_ = (int) (fm.getHeight() * 1.1) + border_ * 2;

	System.out.println("MIN D = " + min_w_ + "," + min_h_);

	resize(min_w_, min_h_);


	getParent().invalidate();
	getParent().layout();
      }
    }    
  }
  
/****************************************************************/
/*                                                              */
/* Function Name: paint                                         */
/* Parameters:                                                  */
/* Returns:                                                     */
/* Effects:                                                     */
/*                                                              */
/****************************************************************/

  public void paint(Graphics g) {

    if (min_h_ == -1)
      update(g);
    
    g.setColor(Color.white);
    g.fillRect(0, 0, size().width, size().height);

    g.setColor(color_);
    g.fillRect(0, 0, size().width - border_, size().height - border_);
    g.fillOval(size().width - (2 * border_), size().height - (2 * border_),
	       2 * border_, 2 * border_);

    g.setColor(Color.black);

    if (selected_) {
    }


    g.clipRect(0, 0, size().width - (2 * border_), size().height - border_);
    g.drawString( title_.string_, border_, 15 );

    int h = size().height;
    
    for (int i = 0; i < info_.size(); i++) {

      if (i * 15 + 30 < h - border_)
	g.drawString( info_.getString(i).string_, 6, i * 15 + 30);

    }

    g.drawString( title_.string_, border_, 15 );
   }


  public boolean mouseDown(Event e, int x, int y) {


    if ((x > size().width - 10 &&  x < size().width) &&	
	(y > size().height - 10 &&  y < size().height)) {
      last_x_ = x;
      last_y_ = y;
      resizing_ = true;
      System.out.println("IN THE CIRCLE");

      Container parent_container = getParent();
      parent_container.remove(this);
      parent_container.add(this, 0);

      return true;
    }

    return super.mouseDown(e, x, y);
  }

  public boolean mouseDrag(Event e, int x, int y) {
    if (resizing_) {

      resize((size().width + x - last_x_), (size().height + y - last_y_));
      //      resize(x + 5, y + 5);
      last_x_ = x;
      last_y_ = y;
      repaint();
      return true;

    }

    return super.mouseDrag(e, x, y);
  }
  
  public boolean mouseExit(Event evt, int x, int y) {

    if (resizing_) {
      resize((size().width + x - last_x_), 
	     (size().height + y - last_y_));
      last_x_ = x;
      last_y_ = y;
      repaint();
      return true;
    }
    return false;

  }


  public boolean mouseUp(Event e, int x, int y) {

    resizing_ = false;
    getParent().layout();
    return false;
    //    return super.mouseUp(e, x, y);

  }

  /**********************************************/
  /*						*/
  /*	WV_SpringLoaded functions		*/
  /*						*/
  /**********************************************/

  public boolean isSelected() {return selected_;}
  public void	 select() {selected_ = true;}
  public void	 deselect() {selected_ = false;}

  public int	 getSpringForce(Component c) {return 3;}
  public WV_ComponentVector connections() {return connections_;}
  
  public boolean addConnection(Component c) {

    if (!connections_.contains(c)) {
      connections_.addElement(c);
    }

    return true;
  }

  public boolean removeConnection(Component c) {

    if (connections_.contains(c)) {
      connections_.removeElement(c);
    }

    return true;
  }
}


