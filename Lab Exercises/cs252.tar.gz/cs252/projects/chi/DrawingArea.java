import java.awt.*; 
import java.util.*;
import java.lang.*; 

class DrawingArea extends Canvas {
   private int WIDTH; 
   private int HEIGHT; 
   private int LINERESOLUTION; 

   private ClosestPairDiagram controller = null; 
   private int R; 
   public DrawingArea(ClosestPairDiagram c) {
      controller = c; 
      LINERESOLUTION = controller.LINERESOLUTION; 
      R = controller.NODERADIUS; 
      setBackground(Color.white); 
   }
	  
   public void paint(Graphics g) {
      Rectangle r = bounds();
      g.setColor(Color.white);  
      g.fillRect(r.x, r.y, r.width, r.height); 
      HEIGHT = r.height; 
      WIDTH = r.width; 
   }

   public boolean mouseMove(Event e, int x, int y) {
      controller.diagramMouseMove(e, x, y); 
      return true; 
   }

   public boolean mouseDown(Event e, int x, int y) { 
      controller.diagramMouseDown(e, x, y); 
      return true; 
   }

   public boolean mouseDrag(Event e, int x, int y) {   
      controller.diagramMouseDrag(e, x, y); 
      return true; 
   }

   public boolean mouseUp(Event e, int x, int y) {
      controller.diagramMouseUp(e, x, y); 
      return true; 
   }
}

