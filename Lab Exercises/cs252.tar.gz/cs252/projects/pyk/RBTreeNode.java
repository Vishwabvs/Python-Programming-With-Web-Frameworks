/*
 * RBTreeNode.java
 *
 * Description:
 *    This class contains the methods and variables for a red-black binary tree
 *    node.
 */
class RBTreeNode extends TreeNode
{
    protected boolean redNode;  // red-black tree node is the same as the binary
                                // tree node with the addition of a flag that
                                // indicates the color of the node

    // constructor for the red-black tree node, simply call the constructor of
    // the binary tree node and initialize the color to red
    RBTreeNode(Object KeyValue, Object Value)
    {
       super(KeyValue, Value);
       setValue(true);
    }

    // set the color of the node to the specified color (red = true, black = false)
    public void setValue(boolean value)
    {
       redNode = value;
    }

    // return the color of the node
    public boolean getValue()
    {
       return redNode;
    }
};
