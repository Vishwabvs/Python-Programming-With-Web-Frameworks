/****************************************************************/
/*    NAME:                                                     */
/*    ACCT: mjw                                                 */
/*    FILE: STSegment.C                                         */
/*    ASGN:                                                     */
/*    DATE: Tue Jun 11 21:05:49 1996                            */
/****************************************************************/



#include "STSegment.H"

STSegment::STSegment(point& p1, point& p2):segment(p1,p2)
{}
STSegment::STSegment(point& p1, vector& v):segment(p1,v)
{}
STSegment::STSegment(double x1, double y1, double x2, double y2)
    :segment(x1,y1,x2,y2)
{}
STSegment::STSegment(const segment& s)
    :segment(s)
{}
STSegment::~STSegment()
{}

int
STSegment::getBegin()
{
    return xcoord1();
}

int
STSegment::getEnd()
{
    return xcoord2();
}

// this only makes sense for horizonatal segments
int
STSegment::getHeight()
{
    return ycoord1();
}


