package cs252;

import graph.*;
import sprite.*;
import java.util.*;
import java.awt.*;

public class OrderNode extends Node {
    String leftS_, rightS_;
    int left_, right_;
    boolean showLeft_, showRight_;

    Color original_;
    boolean visited_;
    Edge sorted_[];
    int below_, counter_;
    
    int leftAdd_, rightAdd_;
    Vector reachable_;

    OrderNode mirrors_[];
    
    public OrderNode(GraphArea area, OrderNode other) {
	super(area, other.x_, other.y_, other.IsSquare(), other.GetNumber());
	original_ = other.original_;
	rightAdd_ = Node.RADIUS + 2;
	showLeft_ = false;
	showRight_ = false;
	Add();
	ShowNumber();
    }

    public OrderNode(GraphArea area, int x, int y, boolean square) {
	super(area, x, y, square);
	visited_ = false;
	rightAdd_ = Node.RADIUS + 2;
	showLeft_ = false;
	showRight_ = false;
	mirrors_ = new OrderNode[2];
	Add();
	ShowNumber();
    }

    public void ClearMirrors() {
	mirrors_[0] = null;
	mirrors_[1] = null;	
    }

    public int GetLeft() {
	return left_;
    }
    
    public int GetRight() {
	return right_;
    }

    public void SetShowPos(boolean showPos) {
	showLeft_ = false;
	showRight_ = false;
	Redraw();
    }

    public void Prepare() {
	visited_ = true;
	sorted_ = SortEdges();
	below_ = 0;
	for (int i = 0; i < all_.size(); ++i) {
	    Edge edge = (Edge)all_.elementAt(i);
	    OrderNode other = (OrderNode)edge.GetOther(this);
	    if (other.y_ > y_)
		++below_;
	    if (!other.visited_)
		other.Prepare();
	}
	counter_ = below_;
    }
    
    public int LeftOrder(int value, OrderNode parent,
			 boolean compact, SpanGraph span) {
	SetLeft(value, true);
	span.AddEdge(parent, this);
	area_.Delay(DominanceGraph.SHOW_DELAY);
	counter_ = below_;

	if (!compact)
	    ++value;
	boolean backup = true;
	for (int i = 0; i < sorted_.length; ++i) {
	    OrderNode current = (OrderNode)(sorted_[i].GetOther(this));
	    current.counter_--;
	    if (current.counter_ == 0) {
		value = current.LeftOrder(value, this, compact, span);
		backup = false;
	    }
	}
	return compact ? (backup ? value + 1 : value) : value;
    }

    public int RightOrder(int value, OrderNode parent,
			  boolean compact, SpanGraph span) {
	if (compact && parent != null &&
	    parent.left_ == left_ && parent.right_ == value)
	    ++value;
	SetRight(value, true);
	span.AddEdge(parent, this);
	area_.Delay(DominanceGraph.SHOW_DELAY);
	
	if (!compact)
	    ++value;
	boolean backup = true;
	for (int i = sorted_.length - 1; i >= 0; --i) {
	    OrderNode current = (OrderNode)(sorted_[i].GetOther(this));
	    current.counter_--;
	    if (current.counter_ == 0) {
		value = current.RightOrder(value, this, compact, span);
		backup = false;
	    }
	}
	return compact ? (backup ? value + 1 : value) : value;	
    }

    public void ClearVisited() {
	visited_ = false;
    }

    public Vector Reachable() {
	if (visited_)
	    return reachable_;
	Vector reachable = new Vector();
	reachable.addElement(this);
	visited_ = true;
	for (int loop = 0; loop < outgoing_.size(); ++loop) {
	    Edge current = (Edge)(outgoing_.elementAt(loop));
	    OrderNode other = (OrderNode)(current.GetOther(this));
	    Vector otherReachable = other.Reachable();
	    for (int add = 0; add < otherReachable.size(); ++add) {
		OrderNode currentNode =
		    (OrderNode)(otherReachable.elementAt(add));
		if (!reachable.contains(currentNode)) 
		    reachable.addElement(currentNode);
	    }
	}
	reachable_ = reachable;
	return reachable;
    }

    public void TransitiveEdges(Vector transitive) {
	visited_ = true;
	OrderNode nodes[] = new OrderNode[outgoing_.size()];
	for (int loop = 0; loop < outgoing_.size(); ++loop) {
	    Edge current = (Edge)(outgoing_.elementAt(loop));
	    nodes[loop] = (OrderNode)(current.GetOther(this));
	}

	for (int loop = 0; loop < nodes.length; ++loop) {	
	    if (!nodes[loop].visited_)
		nodes[loop].TransitiveEdges(transitive);
	    for (int loopB = 0; loopB < nodes.length; ++loopB)
		if (loop != loopB)
		    if (nodes[loopB].reachable_.contains(nodes[loop])) {
			Edge edge = (Edge)(outgoing_.elementAt(loop));
			if (!transitive.contains(edge))
			    transitive.addElement(edge);
		    }
	}
    }

    public void SetLeft(int left, boolean changeColor) {
	left_ = left;
	leftS_ = "" + left;
	leftAdd_ = -(Node.RADIUS + metrics_.stringWidth(leftS_) + 2);
	showLeft_ = true;
	original_ = color_;
	if (changeColor)
	    SetColor(Color.magenta);	
	Redraw();
    }
    
    public void SetRight(int right, boolean changeColor) {
	right_ = right;
	rightS_ = "" + right;
	showRight_ = true;
	if (changeColor)
	    SetColor(original_);
	Redraw();
    }

    public Edge[] SortEdges() {
	Vector above = new Vector();

	for (int loop = 0; loop < all_.size(); ++loop) {
	    Edge current = (Edge)(all_.elementAt(loop));
	    if (current.GetOther(this).y_ < y_)
		above.addElement(current);
	}
	Edge result[] = new Edge[above.size()];
	above.copyInto(result);
	SortEdgeArray(result);
	return result;
    }

    public static boolean LessThan(Edge a, Edge b) {
	double slopeA = -a.GetSlope();
	double slopeB = -b.GetSlope();
	return (slopeA * slopeB < 0) ? slopeA < slopeB : slopeB < slopeA;
    }
    
    public static void SortEdgeArray(Edge edges[]) {
	for (int i = edges.length - 1; i > 0; --i)
	    for (int j = 0; j < i; ++j)
		if (!LessThan(edges[j], edges[j + 1])) {
		    Edge temp = edges[j];
		    edges[j] = edges[j + 1];
		    edges[j + 1] = temp;
		}
    }
    
    public void JumpMirrors(int x, int y) {
	mirrors_[0].MoveTo(x, y);
	mirrors_[1].MoveTo(x, y);
    }
    
    public void Draw(Graphics g) {
	super.Draw(g);
	g.setColor(Color.red);
	if (showLeft_)
	    g.drawString(leftS_, x_ + leftAdd_, y_ + yAdd_);
	if (showRight_)
	    g.drawString(rightS_, x_ + rightAdd_, y_ + yAdd_);
    }
}
