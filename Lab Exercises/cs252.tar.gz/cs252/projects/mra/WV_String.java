class WV_String {
  
  public String string_;
  public int	size_;

  public WV_String(String s) {string_ = s;}	

}
