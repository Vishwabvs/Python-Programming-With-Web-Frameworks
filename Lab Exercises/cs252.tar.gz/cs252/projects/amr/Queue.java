import java.util.Vector;

class Queue extends Vector {


// CONSTRUCTOR ///////////////////////////////////////////////////
   
   Queue () {}


// CONSTRUCTOR //////////////////////////////////////////////////
   
   Queue(int initialCapacity, int capacityIncrement) {
      super(initialCapacity, capacityIncrement);
   }

   
// INSERT ///////////////////////////////////////////////////////
   
   void insert(Object o) {
      addElement(o);
   }


// REMOVE ///////////////////////////////////////////////////////
   
   Object remove() {
      if (isEmpty()) return null;
      Object o = firstElement();
      removeElement(o);
      return o;
   }


// PEEK /////////////////////////////////////////////////////////
   
   Object peek() {
      if (isEmpty()) return null;
      return firstElement();
   }
   
}


