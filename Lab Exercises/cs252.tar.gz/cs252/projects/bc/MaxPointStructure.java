import java.awt.*; 
import java.util.*;

class MaximumTree extends RedBlackTree {
	Node n, n_rec;
   	
	public  void addMaxPoint(Node node) {
		Key k= node.getKey().exchange();
		n = new Node(k);
		collectTrash(n);
		treeInsert(n);
	}	

	public void deleteMaxPoint(Node node){
		Key k= node.getKey().exchange();
		n = (Node)treeSearch(k);
		treeDelete(n); 					
		if (n!=null) 
			dumpTrash(n);
	}
	

	public void collectTrash(Node n){
		if (getRoot()!=null) {
			n_rec=getMaximum();
			while (n_rec.getKey().getX() > n.getKey().getX() ) {
				Node n_new= new Node(0,0);
				n_new.setKey(n_rec.getKey());
				n_new.setTrash(n_rec.getTrash());
				n.addTrash(n_new);
				treeDelete(n_rec);
				if (getRoot()==null) return;
				n_rec =getMaximum();
			}
		}
	}
	
	public void dumpTrash(Node n) {
		if (n!=null) { 
			Node n_new = new Node(0,0);
			n_new.setKey(n.getKey());
			n_new.setTrash(n.getTrash());		
			Vector tr =  n_new.getTrash();		
			for (int i=0; i < tr.size(); i++) {
				n_rec = (Node)tr.elementAt(i);
				treeInsert(n_rec);
			}
		}
	}

	public MaximumTree(){
		super();
	}

	public MaximumTree(Key k){
		super(k.exchange());
	}

	public MaximumTree(int x, int y){
		super(y,x);
	}
}

class RangeTree extends RedBlackTree {
	final static int RIGHT_END = 100000;
	final static int LEFT_END = -100000;

	private Node curMark;
	public Node getCurMarkNode(){
		return curMark;
	}

	public void resetCurMark() {
		curMark=null;
	}
	
	public int getCurMark(){
		if (curMark==null)
			return LEFT_END;
		else
			return curMark.getKey().getX();
	}

	private Node n;
	private Node n_old;

	public int getRightMark(){
		if (curMark==null) 
			return (int)getMinimum().getKey().getX();
		n_old = curMark;			
		n=curMark.getNext();
		if (n==null) return RIGHT_END;		
		while(n.getKey().getX()==n_old.getKey().getX()){
			n_old = n;
			n = n.getNext();
			if (n==null) return RIGHT_END;
		} 
		return (int) n.getKey().getX();			
	}
	
	
	public void rightSweepMarkUpdate() {
		if (curMark == null) 
			n =(Node)getMinimum();
		else {
			n = curMark.getNext();
			while(n.getKey().getX()==curMark.getKey().getX()) {
				curMark = n;
				n = curMark.getNext();	
			}
		}
		curMark = n;
	}

	public void leftSweepMarkUpdate() {
		n = curMark.getPrev();
		if (n==null) 
			curMark=null;
		else {
			do{
				n_old = n;		
				n = n.getPrev();
				if (n == null) {
					curMark = n_old;
					return;
				}
			}while(n_old.getKey().getX()==n.getKey().getX()); 
			curMark= n_old;			
		}
		
	}
	
	public  RangeTree() {
		super();
		curMark = null;	
	}

	public  RangeTree(Node n) {
		super(n);
		curMark = null;	
	}

	public  RangeTree(int x, int y) {
		super(x,y);
		curMark = null;	
	}

	public  RangeTree(Key k) {
		super(k);
		curMark = null;	
	}
}

public class MaxPointStructure {
	final static int RIGHT_END = RangeTree.RIGHT_END;
	final static int LEFT_END = RangeTree.LEFT_END;
	private RangeTree theRangeTree;
	private MaximumTree theMaxTree;

	public void rightSweep() {
		theRangeTree.rightSweepMarkUpdate();
		Node n = (Node)theRangeTree.getCurMarkNode();
		theMaxTree.addMaxPoint(n);
	}

	public void leftSweep() {
		Node n = (Node)theRangeTree.getCurMarkNode();
		theMaxTree.deleteMaxPoint(n);
		theRangeTree.leftSweepMarkUpdate();
	}

	public  MaxPointStructure() {
		theMaxTree = new MaximumTree();
		theRangeTree = new RangeTree();
	}

	public  MaxPointStructure(int x, int y ) {
		theMaxTree = new MaximumTree();
		theRangeTree = new RangeTree(x,y);
	}

	public void setMaxTree(int x, int y) {
		theMaxTree = new MaximumTree(x,y);		
	}

	public void setRangeTree(int x, int y) {
		theRangeTree = new RangeTree(x,y);		
	}

	public MaximumTree getMaxTree() {
		return theMaxTree;
	}

	public RangeTree getRangeTree() {
		return theRangeTree;
	}

	public int getCurMark(){
		if (theRangeTree==null)
			return LEFT_END;
		else
			return (int)theRangeTree.getCurMark();
	}

	public int getRightMark(){
		if (theRangeTree==null)
			return RIGHT_END; 
		else
			return theRangeTree.getRightMark();
	}

	public Node getCurMarkNode(){
		if (theRangeTree==null) 
			return null;
		else
			return (Node)theRangeTree.getCurMarkNode();
	}

	public void addPoint(Node n) {
		theRangeTree.treeInsert(n);
	}

	public void deletePoint(Node node) {
		theRangeTree.treeDelete(node);
	}

	public void addPoint(int x, int y) {
		Node n= new Node(x,y);
		theRangeTree.treeInsert(n);
	}

	public void deletePoint(int x, int y) {
		Node n= new Node(x,y);
		theRangeTree.treeDelete(n);
	}
}






























































