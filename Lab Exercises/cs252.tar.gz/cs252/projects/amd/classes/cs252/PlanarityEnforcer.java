package cs252;

import java.awt.*;
import java.util.Vector;
import sprite.*;
import graph.*;

public class PlanarityEnforcer extends Enforcer {
    final private static int CLOSE_THRESHOLD = 9;
    
    Vector nodes_;
    
    public PlanarityEnforcer(DominanceGraph area, int id) {
	super(area, id);
    }
    
    public void Enforce(Vector nodes, Vector edges, OrderNode lowest) {
	nodes_ = new Vector();
	FindAndFixOne();
    }

    public void FindAndFixOne() {
	Edge edges[] = area_.GetEdgeArray();
	Vector copy = new Vector();
	for (int loop = 0; loop < edges.length; ++loop) {
	    Node nodeA = edges[loop].GetA();
	    Node nodeB = edges[loop].GetB();
	    int dX = nodeA.x_ - nodeB.x_; int dY = nodeA.y_ - nodeB.y_;
	    int distance = dX * dX + dY * dY;
	    if (distance >= CLOSE_THRESHOLD)
		copy.addElement(edges[loop]);
	}
	edges = new Edge[copy.size()];
	copy.copyInto(edges);

	for (int loop1 = 0; loop1 < edges.length - 1; ++loop1)
	    for (int loop2 = loop1 + 1; loop2 < edges.length; ++loop2)
		if (edges[loop1].SharedNode(edges[loop2]) == null) {
		    Point i = edges[loop1].GetIntersection(edges[loop2]);
		    if (i != null) {
			edges[loop1].Remove();
			edges[loop2].Remove();
			area_.RemoveDelay();

			Node node = new OrderNode(area_, i.x, i.y, true);
			node.SetColor(Color.red);
			nodes_.addElement(node);
			area_.AddDelay();

			Edge a = CreateEdge(node, edges[loop1].GetA());
			Edge b = CreateEdge(node, edges[loop1].GetB());
			InformAllSplit(edges[loop1], a, node, b);
			a = CreateEdge(node, edges[loop2].GetA());
			b = CreateEdge(node, edges[loop2].GetB());
			InformAllSplit(edges[loop2], a, node, b);
			
			FindAndFixOne();
			return;
		    }
		}
    }

    public Edge CreateEdge(Node a, Node b) {
	Edge e;
	if (a.y_ > b.y_)
	    e = new Edge(area_, a, b);
	else
	    e = new Edge(area_, b, a);
	area_.AddDelay();
	return e;
    }
    
    public boolean DidAnything() {
	return nodes_.size() > 0;
    }

    public void Restore() {
 	for (int loop = 0; loop < nodes_.size(); ++loop) {
 	    Node center = (Node)(nodes_.elementAt(loop));
	    center.Hide();
 	    area_.RemoveDelay();
 	}
    }

    public void Undo() {
 	for (int loop = 0; loop < nodes_.size(); ++loop) {
 	    Node center = (Node)(nodes_.elementAt(loop));
	    center.Hide();
	    Edge[] four = center.GetAllArray();
	    Node a = four[0].GetOther(center);
	    Node b = four[1].GetOther(center);
	    Node c = four[2].GetOther(center);
	    Node d = four[3].GetOther(center);
	    if (!DoIntersect(a, b, c, d)) {
		if (DoIntersect(a, c, b, d)) {
		    Node temp = b; b = c; c = temp;
		}
		else if (DoIntersect(a, d, b, c)) {
		    Node temp = b; b = d; d = temp;
		}
	    }
	    center.Remove();
 	    area_.RemoveDelay();
	    CreateEdge(a, b);
	    CreateEdge(c, d);
 	}
    }

    public boolean DoIntersect(Node na1, Node na2, Node nb1, Node nb2) {
	int x1, y1, x2, y2, x3, y3, x4, y4;
	int a1, a2, b1, b2, c1, c2;
	int r1, r2;
	int denom, offset, num;

	x1 = na1.x_; y1 = na1.y_; x2 = na2.x_; y2 = na2.y_;
	x3 = nb1.x_; y3 = nb1.y_; x4 = nb2.x_; y4 = nb2.y_;	
	
	a1 = y2 - y1;
	b1 = x1 - x2;
	c1 = x2 * y1 - x1 * y2;

	r1 = a1 * x3 + b1 * y3 + c1;
	r2 = a1 * x4 + b1 * y4 + c1;	
	if (r1 != 0 && r2 != 0 && r1 * r2 >= 0)
	    return false;

	a2 = y4 - y3;
	b2 = x3 - x4;
	c2 = x4 * y3 - x3 * y4;
	
	r1 = a2 * x1 + b2 * y1 + c2;
	r2 = a2 * x2 + b2 * y2 + c2;	
	if (r1 != 0 && r2 != 0 && r1 * r2 >= 0)
	    return false;

	denom = a1 * b2 - a2 * b1;
	if (denom == 0)
	    return false;
	else
	    return true;
    }
    
    
}
