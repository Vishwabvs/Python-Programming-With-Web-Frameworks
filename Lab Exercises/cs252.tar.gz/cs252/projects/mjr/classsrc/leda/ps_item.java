/*
 * @(#)ps_item.java	1.0 5/5/96 Michael John Radwin
 */

package leda;

/**
 * Class description goes here.
 *
 * @version 1.0 5/5/96
 * @author <A HREF="http://www.cs.brown.edu/people/mjr/">Michael John Radwin</A>
 */
public class ps_item {
    protected int x_val;
    protected int y_val;
    protected int split_val[];
    protected int gr;

    ps_item sohn[];

    // mjr
    public Object client_data = null;
    public ps_item left_child() { return sohn[left]; }
    public ps_item right_child() { return sohn[right]; }

    public int x_value()           { return x_val; }
    public int y_value()           { return y_val; }
    public int split_value_x()     { return split_val[0]; }
    public int split_value_y()     { return split_val[1]; }

    public boolean blatt()             { return (gr==1); }
    public int groesse()           { return gr; }


    public double bal()
    {
	if (blatt()) return 0.5;
	else return (double)((double)(sohn[left].groesse())/(double)gr);
    }

    public ps_item(int x_v, int y_v, int split_v_0, int split_v_1)
    {
	this(x_v, y_v, split_v_0, split_v_1, leaf, null, null);
    }

    public ps_item(int x_v, int y_v,
		   int split_v_0, int split_v_1,
		   int ln,
		   ps_item ls, ps_item rs)
    {
	sohn = new ps_item[2];
	split_val = new int[2];
	x_val = x_v;
	y_val = y_v;
	split_val[0] = split_v_0;
	split_val[1] = split_v_1;
	sohn[left] = ls;
	sohn[right] = rs;
	if (ln==leaf)
	    gr=1;
	else gr = ls.groesse()+rs.groesse();
    }

    public ps_item(ps_item p)
    {
	x_val = p.x_value();
	y_val = p.y_value();
	split_val[0] = p.split_value_x();
	split_val[1] = p.split_value_y();
	gr = p.groesse();
	sohn[left] = p.sohn[left];
	sohn[right] = p.sohn[right];
    }

    public String toString()
    {
	return "ps_item (" + String.valueOf(split_value_x()) +
            "," + String.valueOf(split_value_y()) +
            "):(" + String.valueOf(x_value()) +
            "," + String.valueOf(y_value()) + ")";
    }

    // enum children     { left = 0 , right = 1 };
    public static final int left = 0;
    public static final int right = 1;
    
    // enum leaf_or_node { leaf = 0 , node = 1 } ;
    public static final int leaf = 0;
    public static final int node = 1;
}    
