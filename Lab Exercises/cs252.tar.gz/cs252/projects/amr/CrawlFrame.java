import java.awt.*;
import java.net.*;
import java.io.*;
import WebTree;

class CrawlFrame extends Frame {
   
   Label l;
   WebTree webtree_;
   TextField tf_, tf1_, tf2_;
   Button btn_, btn2_;

// CONSTRUCTOR /////////////////////////////////////////////////////
   
   CrawlFrame (String title, WebTree webtree)
   {

      super(title);
      setLayout(new FlowLayout());
      l = new Label("URL:");
      add(l);
      webtree_ = webtree;
      tf_ = new TextField(40);
      add(tf_);
    
      Label l2 = new Label("Crawl Depth: ");
      add(l2);
    
      tf1_ = new TextField("1", 2);
      add(tf1_);
    
      Label l3 = new Label("Max Nodes: ");
      add (l3);
    
      tf2_ = new TextField("20",3);
      add(tf2_);

      btn_ = (new Button("Start!"));
      btn_.resize(100, 100);
      add(btn_);

      btn2_ = (new Button("Close"));
      add(btn2_);
    
  }


// ACTION /////////////////////////////////////////////////////////   
   
public boolean action (Event evt, Object arg)
   {
      
      if (evt.target instanceof Button) {
         
         String label = (String) arg;
         
         if (label.equals("Start!")) {
       
            if (webtree_.selectedNode_ == null) webtree_.clear();
            
            try {
               
               webtree_.rootURL_ = new URL(tf_.getText());
               URLConnection urlConnection =
                  webtree_.rootURL_.openConnection();
               
               urlConnection.connect();

               // If the file does not exist then the following will
               // throw an exception.
               
               InputStream is = urlConnection.getInputStream();
               int foo = is.read();
               webtree_.crawlDepth_ = (new Integer(tf1_.getText())).intValue();
               webtree_.crawlMaxNodes_ =
                  (new Integer (tf2_.getText())).intValue();
               webtree_.thread1_ = new FirstThread(webtree_);
               webtree_.getAppletContext().showStatus("Crawler Started...");
               webtree_.thread1_.start();
               webtree_.isCrawl_ = true;
               webtree_.btn1.disable();
               webtree_.btn4.disable();
               webtree_.deleteButton_.disable();
               this.hide();

            } catch (MalformedURLException e) {

               System.out.println("Malformed URL!");
               webtree_.error_.setError("Malformed URL!");
            } catch (IOException e) {
               
               webtree_.error_.setError("URL does not exist!");
            } catch (SecurityException e) {
               
               webtree_.error_.setError("Security exception!");
            }
            
         } else if (label.equals("Close")) {
            
            webtree_.change_ = true;
            this.hide();
            
         }

         return true;
         
      }

      else return false;
   } 

}
