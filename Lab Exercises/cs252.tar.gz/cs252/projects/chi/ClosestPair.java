import java.util.*;
import java.lang.*; 

class QueryNode extends BRNode  {
   final static int INFTY=1000000; 

   private Vector closest_pair;
   public Vector getClosestPair() {
      return closest_pair;
   }
   protected void setClosestPair(Vector cp) {
      closest_pair=cp;
   }

   private double min_distance;
   public double getMinDistance() {
      return min_distance;
   }
   protected void setMinDistance(double d) {
      min_distance=d;
   }

   protected void copyDataOf(QueryNode node) {
      closest_pair=node.closest_pair;
      min_distance=node.min_distance;
   }

   public QueryNode(Key k) {
      super(k);
      closest_pair = new Vector(); 
      min_distance = INFTY; 
   }

   public QueryNode(int x, int y) {
      super(x, y);
      closest_pair = new Vector(); 
      min_distance = INFTY; 
   }

   public QueryNode next() {
      return (QueryNode)super.getNext();
   }

   public QueryNode prev() {
      return (QueryNode)super.getPrev();
   }
}

/* nodeTree stores the virtual points.  What it contains are QueryNode
instead of BRNode.  bandTree contains BRNode instead of QueryNode.  It 
only records the coord of a node.  The first member of the key is the 
y_coord and the second one is the x_coord.  */

public class ClosestPair extends Object {
   public static final int RIGHT = 0; 
   public static final int LEFT = 1; 

   private BRTree nodeTree; 
   public BRTree getNodeTree() {
      return nodeTree; 
   } 
   private BRTree bandTree; 
   public BRTree getBandTree() {
      return bandTree; 
   } 

   private QueryNode closestPairFirstNode; 
   public QueryNode getClosestPairFirstNode() {
      return closestPairFirstNode; 
   }

   private QueryNode closestPairSecondNode; 
   public QueryNode getClosestPairSecondNode() {
      return closestPairSecondNode; 
   }

   public double getMinDistance() {
      return closestPairSecondNode.getMinDistance(); 
   }

   final static int INFTY=1000000; 

   /* The first node in the band tree*/
   private QueryNode head;
   public QueryNode getHead() {
      return head; 
   }
   protected void setHead(QueryNode h) {
      head = h; 
   }

   /* The last node in the band tree*/
   private QueryNode tail;
   public QueryNode getTail() {
      return tail; 
   }
   protected void setTail(QueryNode t) {
      tail = t; 
   }

   /* The first node in the band tree which shares the same x coordinate with
   tail*/
   private QueryNode fiberHead; 
   public QueryNode getFiberHead() {
      return fiberHead; 
   }

   private Vector lastFiber; 

   public QueryNode pointAt(Key k) {
      return (QueryNode)nodeTree.treeSearch(k);
   }

   public void deletePoint(QueryNode node) {
      nodeTree.treeDelete(node); 
   } 

   public void addPoint(QueryNode node) {
      nodeTree.treeInsert(node);
   } 
  
   public Vector nodesBetween(double l, double r) {
      return nodeTree.nodesBetween(l, r); 
   } 

   public ClosestPair() {
      start(); 
   }

   public void start() {
      nodeTree = new BRTree(); 

      QueryNode n = new QueryNode(new Key(-2*INFTY, -INFTY));
      nodeTree.treeInsert(n); 
      
      n = new QueryNode(new Key(-INFTY, 0));
      nodeTree.treeInsert(n); 
 
      n = new QueryNode(new Key(INFTY, INFTY));
      nodeTree.treeInsert(n); 
      
      reSet(); 
   }
  
   public void reSet() {
      bandTree = new BRTree();
      
      Vector closest_pair_=new Vector(); 
      Key extreme = new Key(-2*INFTY, -INFTY); 
      closestPairFirstNode = (QueryNode)nodeTree.treeSearch(extreme); 
      closest_pair_.addElement(closestPairFirstNode); 

      extreme = new Key(-INFTY, 0); 
      closestPairSecondNode = (QueryNode)nodeTree.treeSearch(extreme); 
      closest_pair_.addElement(closestPairSecondNode); 

      QueryNode n = closestPairSecondNode; 
      n.setClosestPair(closest_pair_); 
      n.setMinDistance(1.414*INFTY); 
      lastFiber = new Vector(); 
      lastFiber.addElement(n);
      head = n; 
      tail = n; 
      fiberHead = n; 
      bandTree.treeInsert(new BRNode(n.getKey().exchange())); 
   }
   
   public void sweepLineQuery(int sweep) {
      if(sweep==RIGHT)  {
         int rightTarget = tail.next().getKey().getX(); 
         rightSweepLineQuery(rightTarget);
      } else {
         Vector fiber = fiberAt(tail); 
         fiberHead = (QueryNode)fiber.firstElement(); 
         int leftTarget = fiberHead.prev().getKey().getX(); 
         if(leftTarget<=-INFTY) {
            reSet();
            return; 
         } 
         leftSweepLineQuery(leftTarget);
      }
   }
   
   private void rightSweepLineQuery(int rightTarget) {
      if(rightTarget>=INFTY) {  
         return;
      }
      double min_distance; 
      Vector fiber = fiberAt(tail.next()); 

      lastFiber = fiber;
      fiberHead = (QueryNode)lastFiber.firstElement(); 
      // Go through all the nodes on the fiber and update the closest pair.
      while(tail.next().getKey().getX()==rightTarget) {
         tail=tail.next();
         tail.setClosestPair(tail.prev().getClosestPair()); 
         min_distance = tail.prev().getMinDistance(); 
         tail.setMinDistance(min_distance); 

         // Update the tree of nodes which fall into the band 
         BRNode band_tail_=new BRNode(tail.getKey().exchange());
         bandTree.treeInsert(band_tail_); 
         while(head.getKey().getX()<rightTarget-min_distance) {
            Key key_ = head.getKey().exchange(); 
            bandTree.treeDelete(bandTree.treeSearch(key_));
            head=head.next();
         }

         // Find the nodes in the band that lie in the "query box".  There 
         // are at most six such nodes.  
         // Note that the key of a node in the bandTree has the same member
         // as its corresponding node but with different order.     
         int y_coord_ = tail.getKey().getY(); 
         double low = y_coord_- min_distance; 
         double up = y_coord_+ min_distance; 
         Vector b_section_=bandTree.nodesBetween(low, up);  
         int x_tail_ = tail.getKey().getX(); 
         int y_tail_ = tail.getKey().getY(); 
         for(int i=0; i<b_section_.size(); i++) {
            BRNode b_node_=(BRNode)b_section_.elementAt(i);
            Key q_key_ = b_node_.getKey().exchange(); 
            QueryNode q_node_ = (QueryNode)nodeTree.treeSearch(q_key_); 
            double td_= min_distance; 
            if(!q_node_.getKey().equals(tail.getKey())) {
               int x_node_=q_node_.getKey().getX(); 
               int y_node_=q_node_.getKey().getY(); 
               double dx_ = x_node_-x_tail_; 
               double dy_ = y_node_-y_tail_; 
               td_=Math.sqrt(dx_*dx_ + dy_*dy_);
               // if the distance is really smaller, saved d and the nodes
               // in fiber_node 
               if(td_<min_distance) {
                  min_distance = td_; 
                  tail.setMinDistance(td_); 
                  Vector data_=new Vector(); 
                  data_.addElement(q_node_);
                  data_.addElement(tail);
                  tail.setClosestPair(data_); 
               }
            }
         }
      } 
      upDateClosestPair(); 
   }

   private void leftSweepLineQuery(int leftTarget) {
      int linePosition = leftTarget; 
      double min_distance; 
      tail=fiberHead.prev(); 

      int currentLinePosition = fiberHead.getKey().getX(); 
      QueryNode node_=fiberHead; 
      while(node_.getKey().getX()==currentLinePosition) {
         Key b_key_=node_.getKey().exchange(); 
         bandTree.treeDelete(bandTree.treeSearch(b_key_));
         node_=node_.next(); 
      }
 
      Vector fiber = fiberAt(tail); 
      fiberHead = (QueryNode)fiber.firstElement(); 
      lastFiber = fiber; 
      min_distance=tail.getMinDistance(); 
  
      /* Update the bandTree and the queryList */
      while(head.prev().getKey().getX()>=linePosition-min_distance) {
         head=head.prev(); 
         Key b_key_=head.getKey().exchange(); 
         bandTree.treeInsert(new BRNode(b_key_));
      }
      upDateClosestPair(); 
   } 

   public void upDateClosestPair() {
     Vector pair = tail.getClosestPair(); 
     closestPairFirstNode=(QueryNode)(pair.firstElement());
     closestPairSecondNode=(QueryNode)(pair.lastElement());
   }

   public Vector fiberAt(QueryNode node) { 
      Vector fiber = new Vector(); 
      if(node==null) {
         return fiber;
      } 
      QueryNode n = node; 
      int x_coord=node.getKey().getX(); 
      while(node!=null&&node.getKey().getX()==x_coord) {
            fiber.addElement(node);
            node=node.next();
      }
      node = n.prev(); 
      while(node!=null&&node.getKey().getX()==x_coord) {
            fiber.insertElementAt(node, 0);
            node=node.prev();
      }
      return fiber;
   } 

} 
