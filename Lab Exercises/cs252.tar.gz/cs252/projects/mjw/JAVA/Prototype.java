import java.io.StreamTokenizer;


public interface Prototype extends Cloneable {

	public Object clone(StreamTokenizer st);
	public Object clone(); // one in java.Object is protected
}
