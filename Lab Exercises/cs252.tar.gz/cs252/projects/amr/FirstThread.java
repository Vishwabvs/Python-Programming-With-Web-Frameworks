import WebCrawler;
import WebTree;

public class FirstThread extends Thread {
  WebTree webTree_;
  WebCrawler webCrawler_;


  FirstThread(WebTree webTree) {
   
    webTree_ = webTree;
    webCrawler_ = webTree_.webCrawler_;
  }
    
public void run(){

  
   System.out.println("URL = " + webTree_.rootURL_.toString() + " Depth " + webTree_.crawlDepth_); 
  int depth;
  if (webTree_.selectedNode_ != null) 
    depth = webTree_.crawlDepth_+ webTree_.selectedNode_.getDepth();
  else
    depth = webTree_.crawlDepth_;

  webCrawler_.startCrawl(webTree_.rootURL_, webTree_.selectedNode_, depth,
			 webTree_.crawlMaxNodes_);

}


}


  
