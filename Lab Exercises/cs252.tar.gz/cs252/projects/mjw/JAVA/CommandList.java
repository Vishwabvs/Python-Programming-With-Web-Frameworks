import ReversibleCommand;
import java.util.*;

public class CommandList {
protected Vector commands_;
protected int    num_commands_;
protected int    current_command_;


	public CommandList()
	{
		commands_ = new Vector();
		num_commands_ = 0;
		current_command_ = -1;	
	}


	public void reset()
	{
		current_command_ = -1;
	}


	public void addCommand(ReversibleCommand c)
	{
		if (c == null)
			return;
		commands_.addElement(c);
		num_commands_++;
	}


	public boolean executeNext()
	{
		if (commands_.isEmpty())
			return false;
		current_command_++;
		if (current_command_ < num_commands_)
		{
			ReversibleCommand c = (ReversibleCommand)
				commands_.elementAt(current_command_);
			if (c == null)
				return false;
			c.execute();
			if (current_command_ ==  num_commands_-1)
				return false;
			return true;
		}
		current_command_--; 
		return false;
	}
	

	public boolean unexecuteNext()
	{
		if (commands_.isEmpty())
			return false;
		if (current_command_ > -1)
		{		
			ReversibleCommand c = (ReversibleCommand)
				commands_.elementAt(current_command_);
			c.undo();
			current_command_--;
			if (current_command_>=0)
				return true;
		}
		return false;
	}


	public int numElements()
	{
		return commands_.size();
	}

}


