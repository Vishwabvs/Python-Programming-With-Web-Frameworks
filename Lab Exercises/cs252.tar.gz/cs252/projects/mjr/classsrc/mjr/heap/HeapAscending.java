/*
 * @(#)HeapAscending.java	1.0 2/23/96 Michael J. Radwin
 */

package mjr.heap;

import java.util.Vector;
import java.util.NoSuchElementException;
import mjr.treegraphics.*;

/**
 * An implementation of a priority queue according to Cormen,
 * Leiserson and Rivest.  Sorts in ascending order.
 *
 * @version 1.0 2/23/96
 * @author <A HREF="http://www.cs.brown.edu/people/mjr/">Michael J. Radwin</A> */
public
class HeapAscending extends Vector implements HeapImpl {
    /**
     * Constructs the heap in O(N) time, using a technique similar to
     * bottom-up construction.
     */
    public HeapAscending(Heapable anArray[])
    {
	super(anArray.length);
	setSize(anArray.length);

	for (int i = 0; i < anArray.length; i++)
	    setElementAt(anArray[i], i);
	
	for (int i = (int)Math.floor(size() / 2) - 1; i >= 0; i--)
	    heapify(i);
    }

    /**
     * Constructs a heap with no elements.
     */
    public HeapAscending()
    {
	super(0);
    }
    
    /**
     * Returns the Vector index of the left child
     */
    protected int left(int i)
    {
	return ((i + 1) << 1) - 1;
//	return (2 * (i + 1)) - 1;
    }

    /**
     * Returns the Vector index of the right child
     */
    protected int right(int i)
    {
	return ((i + 1) << 1);
//	return (2 * (i + 1));
    }

    /**
     * Returns the Vector index of the parent
     */
    protected int parent(int i)
    {
	return ((i + 1) >> 1) - 1;
//	return (int)Math.floor((i + 1) / 2) - 1;
    }

    /**
     * Exchanges the elements stored at the two locations
     */
    protected synchronized void exchange(int i, int j)
    {
	Object temp = elementAt(j);
	setElementAt(elementAt(i), j);
	setElementAt(temp, i);
    }

    /**
     * Also known as downheap, restores the heap condition
     * starting at node i and working its way down.
     */
    protected synchronized void heapify(int i)
    {
	int l = left(i);
	int r = right(i);
	int smallest;

	if (l < size() &&
	    ((Heapable)elementAt(l)).lessThan(elementAt(i)))
	    smallest = l;
	else
	    smallest = i;

	if (r < size() &&
	    ((Heapable)elementAt(r)).lessThan(elementAt(smallest)))
	    smallest = r;

	if (smallest != i) {
	    exchange(i, smallest);
	    heapify(smallest);
	}
    }

    /**
     * Removes the minimum (top) element from the Heap, decreases the
     * size of the heap by one, and returns the minimum element.
     */
    public synchronized Heapable extractMin() throws NoSuchElementException
    {
	if (size() == 0)
	    throw new NoSuchElementException();

	Object min = elementAt(0);

	// move the last key to the top, decrease size, and downheap
	setElementAt(lastElement(), 0);
	removeElementAt(size() - 1);
	heapify(0);

	return (Heapable)min;
    }

    /**
     * Removes an element from the heap.
     */
    public Heapable remove() throws NoSuchElementException
    {
	return extractMin();
    }


    /**
     * Inserts key into the heap, and then upheaps that key to a
     * position where the heap property is satisfied.
     */
    public synchronized void insert(Heapable key)
    {
	int i = size();
	setSize(size() + 1);

	// upheap if necessary
	while (i > 0 && ((Heapable)elementAt(parent(i))).greaterThan(key)) {
	    setElementAt(elementAt(parent(i)), i);
	    i = parent(i);
	}
	
	setElementAt(key, i);
    }

    /**
     * Performs a preorder traversal of the heap, calling
     * tg.DrawInternal on every key and tg.DrawLeaf for every child
     * that exceeds the length of the heap (and is therefore a "leaf")
     */
    public void preorder(int i, TreeGraphics tg)
    {
	if (i >= size()) {
	    tg.DrawLeaf("red");
	    return;
	}
	
	tg.DrawInternal(elementAt(i).toString(), "blue");
	preorder(left(i), tg);
	preorder(right(i), tg);
    }
}
