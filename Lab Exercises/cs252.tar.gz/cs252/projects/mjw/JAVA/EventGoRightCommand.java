import TreeAccessible;
import java.lang.*;
import java.io.StreamTokenizer;
import geometry.*;
import ReversibleCommand;
import Prototype;
import java.awt.Image;
import java.awt.Color;
import java.awt.image.*;
import RangeSearchAnimationCommand;



/****************************************************************/
/* CLASS NAME :  EventGoRightCommand                            */
/*                                                              */
/*                                                              */
/*                                                              */
/*                                                              */
/*                                                              */
/*                                                              */
/****************************************************************/

public class EventGoRightCommand extends RangeSearchAnimationCommand {

	public EventGoRightCommand(Image	 im,
				   GeometryPanel p,
				   TreeAccessible treeApp,
				   Box		 input_area)
	{
		super(im, p, treeApp, input_area);
		range_color_ = Color.blue;
	}

	public EventGoRightCommand(Image	 im,
				   GeometryPanel p,
				   TreeAccessible treeApp,
				   Box		 input_area,
				   TreeNode	 node)
	{
		super(im, p, treeApp, input_area);
		setNode(node);
		range_color_ = Color.blue;
	}


	public void execute()
	{
		if (node_ != null)
		{	
			node_.setRightEdgeSelected(true);
			//drawRange(node_.getMedian(),-1, node_.getEnd(), range_color_);
			panel_.repaint();
			reversible_ = true;
		}
		else reversible_ = false;
	}

	public void undo()
	{
		if (reversible_)
		{
			node_.setRightEdgeSelected(false);
			panel_.repaint();
		}
	}

	public Object clone()
	{
		EventGoRightCommand c = new
			EventGoRightCommand(image_,
					    panel_,
					    tree_app_,
					    user_input_bounds_,
					    node_);
		c.setBegin(begin_);
		c.setMedian(median_);
		c.setEnd(end_);
		return c;
	}
	
	public Object clone(StreamTokenizer st)
	{
		TreeNode n = new TreeNode((GeometryStreamTokenizer)st);
		begin_ = ((GeometryStreamTokenizer)st).nextInt();
		median_ = ((GeometryStreamTokenizer)st).nextInt();
		end_ = ((GeometryStreamTokenizer)st).nextInt();
		Tree tree = tree_app_.getTree();
		if (tree == null) return null;
		n = tree.findNode(n.getID());
		EventGoRightCommand c = new
			EventGoRightCommand(image_,
					    panel_,
					    tree_app_,
					    user_input_bounds_,
					    n);
		c.setReversible(reversible_);
		c.setBegin(begin_);
		c.setMedian(median_);
		c.setEnd(end_);
		return c;
	}

	public String toString()
	{
		return new String("RTEVENTGORIGHT");
	}
};

