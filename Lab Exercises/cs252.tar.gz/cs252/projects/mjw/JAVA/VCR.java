import java.util.*;
import java.lang.*;
import java.awt.*;
import CommandList;


public class VCR extends Observable {
protected boolean      empty_ = true; 
protected CommandList  frames_;
protected int	       delay_;

public final static String END = "End";
public final static String BEGINNING ="Beginning";
public final static String ACTIVATE = "a";
public final static String DEACTIVATE = "d";



	public VCR()
	{
	}

	public boolean play(int direction)
	{
		if ((frames_ == null) ||
			(frames_.numElements()==0))
		{
			notifyObservers(DEACTIVATE);
			return false;
		}


		if (direction >= 0)  // forward
		{
			if (!frames_.executeNext())
			{
				notifyObservers(END);
				return false;
			}
			else return true;
		}

		else if (direction < 0)  //backward
		{
			if (!frames_.unexecuteNext())
			{
				notifyObservers(BEGINNING);
				return false;
			}
			else return true;
		}
		return false;
	}


	
	public void insert(CommandList frames)
	{
	  //System.out.println("insert: Notifying observers");
		frames_ = frames;
		frames_.reset();
		notifyObservers(ACTIVATE);
		notifyObservers(BEGINNING);
	}

	public CommandList eject()
	{
		CommandList temp;

		//System.out.println("eject: Notifying observers");
		temp = frames_;
		frames_ = null;
		notifyObservers(DEACTIVATE);
		return temp;
	}

	public synchronized void notifyObservers(Object arg)
	{
		setChanged();
		super.notifyObservers(arg);
		clearChanged();
	}


};
