/****************************************************************/
/*    NAME:                                                     */
/*    ACCT: mjw                                                 */
/*    FILE: STSegmentComposite.C                                  */
/*    ASGN:                                                     */
/*    DATE: Thu Apr 18 19:49:32 1996                            */
/****************************************************************/


//#include <LEDA/segment_set.h>
#include "STSegmentComposite.H"
//#include "STSegment.H"
#include "STSegmentList.H"
#include <assert.h>


STSegmentComposite::STSegmentComposite()
{
}


STSegmentComposite::~STSegmentComposite()
{
}


void STSegmentComposite::setSegments(STSegmentList& slist)
{
    double num_segments = slist.length();
    STSegmentPtr sg;
    forall (sg, slist)	// copy the list
	    addSegment(sg);
}



/****************************************************************/
/*                                                              */
/* Function Name: addSegment                                    */
/* Parameters:    STSegment*                                    */
/* Returns:       void                                          */
/* Effects:       Adds the given segm. to the list.             */
/*                                                              */
/****************************************************************/

void
STSegmentComposite::addSegment(STSegmentPtr sg)
{
    double num_segments = numSegments();
    assert(sg!=NULL);
    //segments_.insert(*(segment*)sg, num_segments);
    segments_.append(sg);
}



/****************************************************************/
/*                                                              */
/* Function Name: removeSegment                                 */
/* Parameters:    STSegment* -- segm.to remove                  */
/* Returns:       void                                          */
/* Effects:       If the given segm. is on the list, than       */
/*                it is removed from the list.                  */
/*                                                              */
/****************************************************************/

void
STSegmentComposite::removeSegment(STSegmentPtr sg)
{
  //assert(sg!=NULL);
    //segments_.del(*sg);
}


int
STSegmentComposite::numSegments()
{
    return segments_.size();
}


STSegmentList&
STSegmentComposite::getSegments()
{
	return segments_;
}
