import GeometryLine;
import java.awt.*;
import java.awt.image.*;

public class Segment extends GeometryLine {

protected boolean selected_;
protected Image unselected_im_, selected_im_;
protected ImageObserver im_observer_;
protected Color selected_color_ = Color.red;
protected Color unselected_color_ = Color.blue;



	public Segment()
	{
		super();
	}           
	
	public Segment(Point s, Point e, int width)
	{
	 	super(s, e, width);
	}   
	
	public void setSelected(boolean b)
	{
		selected_ = b;
	}                 

	public void setSelectedColor(Color c)
	{
		selected_color_ = c;
	}
	public void setUnselectedColor(Color c)
	{
		unselected_color_ = c;
	}

	public boolean isSelected()
	{
	 	return selected_;
	}

	public void setEndPointImg(	Image sel_dot,
					Image unsel_dot,
					ImageObserver obs)
	{
		unselected_im_ = unsel_dot;
		selected_im_ = sel_dot;
		im_observer_ = obs;
	}

	public Image getSelectedEndPointImg()
	{
		return selected_im_;
	}
	public Image getUnselectedEndPointImg()
	{
		return unselected_im_;
	}
	public ImageObserver getImgObserver()
	{
		return im_observer_;
	}
	public void draw(Graphics g)
	{
		if (selected_)
			color_ = selected_color_;
		else
			color_ = unselected_color_; 
			
		super.draw(g);
		// draw two end points
	      	if (selected_im_ != null & unselected_im_ != null && im_observer_ != null)
	      	{
			Image im;
			if (selected_)
				im = selected_im_;
			else
				im = unselected_im_;

		      	g.drawImage(im, startX_,
					startY_ - im.getHeight(im_observer_)/2,
					im_observer_);
		      	g.drawImage(im, endX_ - im.getWidth(im_observer_),
				        endY_ - im.getHeight(im_observer_)/2,
					im_observer_);
	      	}
	}

	public boolean inside(int x, int y)
	{

		Image im;
		if (selected_im_ != null & unselected_im_ != null && im_observer_ != null)
		{
			if (selected_)
				im = selected_im_;
			else 	im = unselected_im_;

			return ((startX_< x && x < endX_) &&
				((startY_-(im.getHeight(im_observer_)/2)) <=y &&
				y<=(startY_+(im.getHeight(im_observer_)/2))));
		}
		else 
		 	return ((startX_< x && x < endX_) &&
				((startY_-(thickness_/2)) <=y && y<=(startY_+(thickness_/2))));
	}
		

};













	

