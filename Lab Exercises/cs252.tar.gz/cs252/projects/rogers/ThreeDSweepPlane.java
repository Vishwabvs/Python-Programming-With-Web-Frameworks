/** Brian Rogers
    cs252
    spring 1996
    Final Project */

import java.awt.*;



/** This is the sweep plane that sweeps from left to right as an algorithm
    runs it has a color that it draws itself in various shades of, and an 
    x value that it currently is at. */

public class ThreeDSweepPlane {

     public static final int CANVAS_DIMENSION = ThreeDCanvas.CANVAS_DIMENSION;

     ThreeDSpace _space;

     Color _color;
     Color _darker;
     Color _darkest;
     Color pretty_damn_dark;
     Color really_damn_dark;

     int x_value;
     int x_mod;
     int y_mod;

     float _modifier;


     public ThreeDSweepPlane (ThreeDSpace space, Color color) {
          _space = space;

          /* Get the primary color, and make different shades of it */
          _color = color;
	  _darker = _color.darker();
	  _darkest = _darker.darker();
	  pretty_damn_dark = _darkest.darker();
	  really_damn_dark = pretty_damn_dark.darker();

	  _modifier = _space.calcModifier(CANVAS_DIMENSION);
	  x_value = 0;
	  x_mod = calcXMod();
	  y_mod = (int)((CANVAS_DIMENSION/2) * (1 - _modifier));
     }



     /** Move the plane one pixel right if there is space. */
     public boolean move () {
          if (x_value < CANVAS_DIMENSION) {
	       x_value++;
	       x_mod = calcXMod();
	       return true;
	  }
	  else return false;
     }
     /** Calculate the plane's new perspective modifier in the x direction */
     private int calcXMod () {
          return CANVAS_DIMENSION/2 + 
	                    (int)((x_value-CANVAS_DIMENSION/2)*_modifier);
     }



     /** draw the plane in it's current position. */
     public void draw (Graphics grafix) {
          /* draw the plane's shading */
          grafix.setColor(really_damn_dark);
          int xcoords[] = {x_value, x_mod, x_mod, x_value};
	  int ycoords[] = {0, y_mod, CANVAS_DIMENSION - y_mod, 
	                                            CANVAS_DIMENSION};
	  grafix.fillPolygon(xcoords, ycoords, 4);

	  /* draw the frame in space so it can be seen through the shading */
	  _space.drawFrame(grafix);

	  /* draw the background vertical line */
          grafix.setColor(_darkest);
	  grafix.drawLine(x_mod, y_mod, x_mod, CANVAS_DIMENSION - y_mod);

          /* draw the two lines on the top and bottom of the plane */
          grafix.setColor(_darker);
	  grafix.drawLine(x_value, 0, x_mod, y_mod);
	  grafix.drawLine(x_value, CANVAS_DIMENSION, 
	                             x_mod, CANVAS_DIMENSION - y_mod);

          /* draw the contents of space */
          _space.drawSpace(grafix);

	  /* draw the foreground vertical line */
	  grafix.setColor(_color);
	  grafix.drawLine(x_value, 0, x_value, CANVAS_DIMENSION);
     }  



     public int xValue () {return x_value - CANVAS_DIMENSION/2;}
}
