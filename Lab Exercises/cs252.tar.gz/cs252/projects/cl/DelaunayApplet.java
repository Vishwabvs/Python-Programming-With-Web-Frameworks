
/****************************************************************
 * This java applet shows an incremental algorithm for Delaunay *
 * Triangulations. It can also find Voronoi Diagrams and Convex *
 * Hulls.                                                       *
 *                                                              *
 * Author : Conglin Lu.                                         *
 * Date: 6/25/96                                                *
 *                                                              *
 ***************************************************************/


import java.awt.*;
import java.applet.*;
import java.util.*;

/****************************************************************
*    Applet class. Defines the interface.                       *
*	- init(): 	Starts the applet and sets the layouts; *
*	- updateText(): Show mouse positions and running status.*
****************************************************************/

public class DelaunayApplet extends Applet {
    DrawingArea drawArea;	//Drawing canvas;
    Image appletImg;		//Background image;
    Graphics appletG;		//Background graphics context;
    Label pos, hint, emptyL;	//Labels;
    Button restart, incre;		//Restart button;
    Checkbox delTriang, vorDiag, convHull, animation; //Checkboxs;

    public void init() {
	GridBagLayout gridBag = new GridBagLayout();
	GridBagConstraints c = new GridBagConstraints();
	setLayout(gridBag);

	drawArea = new DrawingArea(this);
	c.fill = GridBagConstraints.BOTH;
	c.weightx = 1.0;
	c.weighty = 1.0;
	c.gridwidth = GridBagConstraints.RELATIVE;
	c.gridheight = 6;
	gridBag.setConstraints(drawArea, c);
	add(drawArea);	

	delTriang = new Checkbox("View Delaunay Triangulation");
	c.fill = GridBagConstraints.HORIZONTAL;
	c.weighty = 0.0;
	c.gridwidth = GridBagConstraints.REMAINDER;
	c.gridheight = 1;
	gridBag.setConstraints(delTriang, c);
	add(delTriang);
	delTriang.setState(true);

	vorDiag = new Checkbox("View Voronoi Diagram");
	gridBag.setConstraints(vorDiag, c);
	add(vorDiag);
	vorDiag.setState(true);

	convHull = new Checkbox("View the Convex Hull");
	gridBag.setConstraints(convHull, c);
	add(convHull);
	convHull.setState(true);

	emptyL = new Label("");
	gridBag.setConstraints(emptyL, c);
	add(emptyL);

	animation = new Checkbox("Show Animation");
	gridBag.setConstraints(animation, c);
	add(animation);
	animation.setState(false);

	restart = new Button("Restart");
	c.fill = GridBagConstraints.NONE;
	c.gridwidth = GridBagConstraints.RELATIVE;
	gridBag.setConstraints(restart, c);
	add(restart);

	incre = new Button("Show all");
	c.gridwidth = GridBagConstraints.REMAINDER;
	gridBag.setConstraints(incre, c);
	add(incre);

	pos = new Label("Click!");
	c.fill = GridBagConstraints.HORIZONTAL;
	c.weightx = 1.0;
	c.weighty = 0.0;
	c.gridheight = GridBagConstraints.RELATIVE;
	c.gridwidth = GridBagConstraints.REMAINDER;
	gridBag.setConstraints(pos, c);
	add(pos);

	hint = new Label("Click to add point; SHIFT-click to delete point; " 
				+ "Drag to move point.");
	gridBag.setConstraints(hint, c);
	add(hint);

	//Initialize background image here...
	appletImg = createImage(size().width, size().height);
	appletG = appletImg.getGraphics();

	setBackground(Color.white);
        }

    public void updateText(String text) {
	pos.setText(text);
	}

    //Reacts to user inputs
    public boolean action(Event evt, Object arg) {
	if (evt.target == restart) {
	    	drawArea.initialize();	   
	    	drawArea.repaint();
	    	return true;
		}

	if (evt.target == delTriang) {
		drawArea.setDelaunayState(delTriang.getState());
		drawArea.repaint();
		return true;
		}

	if (evt.target == convHull) {
		drawArea.setHullState(convHull.getState());
		drawArea.repaint();
		return true;
		}

	if (evt.target == vorDiag) {
		drawArea.setVoronoiState(vorDiag.getState());
		drawArea.repaint();
		return true;
		}

	if (evt.target == animation) {
	    	drawArea.setAnimationState(animation.getState());
	    	return true;
		}

	return false;
        }

    public Image getBufImage() {
	return appletImg;
	}

    public Graphics getBufGraphics() {
	return appletG;
	}
    }

/****************************************************************
*    Canvas class. Accpets inputs and draws the graph.		*
*	- initialize():	Initializes the whole graph;		*
*	- mouseDown():	Reacts to clicks or shift-clicks;	*
*	- mouseDrag():  Reacts to mouse drags;			*
*	- addPoint():	Add a point and update display;		*
*	- deletePoint():Delete a point and update display;	*
*	- run():	Show animation;				*
*	- paint():	Draw graphs.				*
****************************************************************/

class DrawingArea extends Canvas implements Runnable{
    DelaunayApplet theApplet;	//Applet associated with this canvas
    DelaunayGraph graph;	//Underlying graph
    Nodes nodes; 		//Point sets
    Thread animation, addPnt;	//Animation threads
    Point prev;			//Used to keep track of mouse position
    boolean showA, drawD, drawV, drawH; //drawing modes
    boolean prepared;		//Indicate whether the animation is done
    boolean passby;

    public DrawingArea(DelaunayApplet app) {
	super();
	theApplet = app;
	showA = false; //Animation mode off
	drawD = drawV = drawH = true;
	passby = false;
	initialize();
	setBackground(Color.orange);
	}

    // Initialize all. Start from beginning...
    void initialize() {
	if (graph == null)
	    graph = new DelaunayGraph();
	else {
	    graph.removeAllElements();
	    graph.init(); 
	    }
	   
	if (nodes == null)
	    nodes = new Nodes();
	else 
	    nodes.removeAllElements();
	}

    //Change drawing modes
    public void setAnimationState(boolean state) {showA = state;}
    public void setDelaunayState(boolean state) {drawD = state;}
    public void setVoronoiState (boolean state) {drawV = state;}
    public void setHullState(boolean state)     {drawH = state;}

    public boolean mouseDown(Event event, int x, int y) {
	boolean found = false;
	Point pt = null;

	passby = false;

	FIND: for (Enumeration e = nodes.elements(); 
			e.hasMoreElements();) {
	    	pt = (Point) e.nextElement();
	    	if (Math.abs(pt.x - x) < 3 &&
	    	    Math.abs(pt.y - y) < 3) 
		    {
		    found = true;
		    break FIND;
		    }
		}

	if (event.shiftDown()) { 	//Deleting point 
	    if (found && pt != null) {
	    	theApplet.updateText("Deleting point at (" + x 
					+ "," + y + ").");
	    	deletePoint(pt);
		}
	    }
	else {				//adding point
	    if (!found) {
	    	theApplet.updateText("Adding point at (" + x 
					+ "," + y + ").");
		Point pnt = new Point(x, y);
		if (!showA || animation == null) {
		    Graphics g = getGraphics();
		    g.setColor(Color.red);
		    g.fillOval(x - 3, y - 3, 6, 6);
		    }		
		if (showA) {		//show animation
		    if (animation != null || addPnt != null)
		        return false;
		    prepared = false;
		    addPnt = new AddPointThread(this, pnt);
		    addPnt.start();
		    animation = new Thread(this);
		    animation.start();
		    }
		 else
	    	    addPoint(pnt);
	    	prev = pnt;
	    	}
	    else 
		prev = pt;
	    }

	return true;
	}

    public boolean mouseDrag(Event event, int x, int y) {
	Point pt, newPt;

	//if deleting or showing animation, stop here 
	if (event.shiftDown() || showA) 
	    return false;

	int xx = Math.max(Math.min(x, size().width-3), 3);
	int yy = Math.max(Math.min(y, size().height-3), 3);

	if (prev != null && xx == prev.x && yy == prev.y)
	    return true;

	theApplet.updateText("(" + xx + ", " + yy + ")");

	if (passby) {		//passing an existing point
	    newPt = new Point(xx, yy);
	    addPoint(newPt);
	    prev = newPt;
	    passby = false;
	    return true;
	    }

	FIND: for (Enumeration e = nodes.elements(); 
			e.hasMoreElements();) {
	    	pt = (Point) e.nextElement();
	    	if (pt.x == xx && pt.y == yy) 
		    {
		    passby = true;
		    break FIND;
		    }
		}

	if (prev != null)
	    deletePoint(prev);
	if (!passby) {
	    newPt = new Point(xx, yy);
	    addPoint(newPt);
	    prev = newPt;
	    }

	repaint();
	return true;
	}

    //Show mouse position
    public boolean mouseMove(Event event, int x, int y) {
	theApplet.updateText("(" + x + ", " + y + ")");	
	return true;
	} 

    public boolean mouseExit(Event event, int x, int y) {
	theApplet.updateText("");
	return true;
	}

    void addPoint(Point pt) {
	nodes.addElement(pt);
	graph.InsertSite(new CPoint(pt.x, pt.y), false);
	
	repaint();
	}

    void deletePoint(Point point) {
	nodes.removeElementAt(nodes.indexOf(point));

	if (graph == null)
	    graph = new DelaunayGraph();
	else {
	    graph.removeAllElements();
	    graph.init(); 
	    }
	for (Enumeration e = nodes.elements(); e.hasMoreElements();) {
	    Point pt = (Point) e.nextElement();
	    CPoint cpt = new CPoint(pt.x, pt.y);
	    graph.InsertSite(cpt, false);
	    }

	repaint();
	}

    public void run() {
        while (addPnt != null)		//not ready
	    Thread.yield();

	if (prepared) {
	    Vector te = graph.testEdges;
	    Graphics g = getGraphics();
	    for (Enumeration e = te.elements(); e.hasMoreElements();) {
	        DrawEdge dg = (DrawEdge) e.nextElement();
		for (int j=1; j<=2; j++) {
		    dg.draw(g, getBackground(), 150);
		    dg.draw(g, Color.blue, 150);
	            }
		}

	    try {
		Thread.sleep(500);
 		} catch (InterruptedException ie) {
		    return;
		    }

	    Vector newEdges = graph.newEdges;
	    for (Enumeration e = newEdges.elements(); e.hasMoreElements();) {
	        DrawEdge dg = (DrawEdge) e.nextElement();
		dg.draw(g, Color.red, 300);
	        }

	    try {
		Thread.sleep(500);
 		} catch (InterruptedException ie) {
		    return;
		    }

	    Vector updateEdges = graph.testGroup;
	    for (Enumeration e = updateEdges.elements(); e.hasMoreElements();){
		CircleTest egGroup = (CircleTest) e.nextElement();
		for (int i=1; i<=2; i++) {
		    egGroup.draw(g, getBackground(), getBackground(), 300);
		    egGroup.draw(g, Color.red, Color.blue, 300);
		    }
		if (egGroup.changed) {
		    DrawEdge oldEdge = (DrawEdge) e.nextElement();
		    oldEdge.draw(g, Color.cyan, 700);
		    oldEdge.draw(g, getBackground());
		    DrawEdge newEdge = (DrawEdge) e.nextElement();
		    newEdge.draw(g, Color.red, 700);
		    }
		}

	    try {
		Thread.sleep(1000);
 		} catch (InterruptedException ie) {
		    return;
		    }

	    }

	animation = null;
	repaint();
        }

    public void update(Graphics g) {
	paint(g);
	}

    public void paint(Graphics g) {
        if (animation != null)
	    return;

	Image bufImage = theApplet.getBufImage();
	Graphics bufG = theApplet.getBufGraphics();

	//double buffering to avoid flickering
	bufG.setColor(getBackground());
 	bufG.fillRect(0, 0, size().width, size().height);
	bufG.setColor(getForeground());

	graph.draw(bufG, Color.blue, Color.magenta, new Color(0, 192, 64),
			drawD, drawV, drawH);
	nodes.draw(bufG, Color.black);

	g.drawImage(bufImage, 0, 0, this);
	}
    }

/************************************************************************
*   AddPointThread. Add a point to the current graph. Must be completed	*
*			before showing animations.			*
*	- run():	call add-point prodecure in graph		*
************************************************************************/

class AddPointThread extends Thread {
    DrawingArea theCanvas;	//associated canvas object
    Point addedPoint;		//point being added

    public AddPointThread(DrawingArea canvas, Point pt) {
        theCanvas = canvas;
	addedPoint = pt;
        }

    public void run() {
        theCanvas.prepared = false;

	theCanvas.nodes.addElement(addedPoint);
	theCanvas.graph.InsertSite(new CPoint(addedPoint.x, addedPoint.y),
				   true);

	theCanvas.addPnt = null;
	theCanvas.prepared = true;
        }
    }

/******************************************************************
*    Edge class. Defines a quadedge structure, which contains the *	
*		information of endpoints, various adjacent edges, *	
*		and dual edges.					  *
*	- isValidEdge():	whether it's visible		  *
******************************************************************/

class Edge extends Object {
    CPoint org = null;		//Origin
    Edge Onext = null;		//next counterclockwise edge
    Edge Rot = null;		//dual edge

    //setting edge properties
    public void SetOrg(CPoint pt)  {org = pt;}
    public void SetDest(CPoint pt) {Sym().org = pt;}	
    public void SetRot(Edge e)     {Rot = e;}
    public void SetSym(Edge e)     {Rot.Rot = e;}
    public void SetRot3(Edge e)    {Rot.Rot.Rot = e;}
    public void SetOnext(Edge e)   {Onext = e;}
    public void SetLnext(Edge e)   {Rot3().Onext.Rot = e;}
    public void SetOprev(Edge e)   {Rot.Onext.Rot = e;}
    public void SetRnext(Edge e)   {Edge rn = Rot.Onext.Rot3(); rn = e;}

    //getting information
    public CPoint GetOrg()  {return org;}
    public CPoint GetDest() {return Sym().org;}
    public Edge GetRot()    {return Rot;}
    public Edge Sym()       {return Rot.Rot;}
    public Edge Rot3()      {return Rot.Rot.Rot;}
    public Edge GetOnext()  {return Onext;}
    public Edge GetLnext()  {return Rot3().Onext.Rot;}
    public Edge GetOprev()  {return Rot.Onext.Rot;}
    public Edge GetRnext()  {return Rot.Onext.Rot3();}
    public Edge GetDprev()  {return Rot3().Onext.Rot3();}
    public Edge GetLprev()  {return Onext.Sym();}

    public boolean isValidEdge() {
	CPoint og = GetOrg();
	CPoint dt = GetDest();

	if (og == null || og.isInf || dt == null || dt.isInf)
	    return false;
	else
	    return true;
	}
    }

/************************************************************************
*    Graph class. Base class for general graphs using quadedge 		*
*			representation.					*
*	- MakeQEdge(): 	Generates a new edge;				*
*	- Splice():	Changes the topological relationships between	*
*			two edges;					*
************************************************************************/

class Graph extends Vector {
    public Edge MakeQEdge() {
	Edge e[] = new Edge[4];
	for (int i=0; i<4; i++) 
	    e[i] = new Edge();

	//set initial relationships
	e[0].SetRot(e[1]);
	e[1].SetRot(e[2]);
	e[2].SetRot(e[3]);
	e[3].SetRot(e[0]);
	e[0].SetOnext(e[0]);
	e[1].SetOnext(e[3]);
	e[2].SetOnext(e[2]);
	e[3].SetOnext(e[1]);

	for (int i=0; i<4; i++) 
	    addElement(e[i]);

	return e[0];
	}

    public void Splice(Edge a, Edge b) {
	Edge aa = a.GetOnext().GetRot();
	Edge bb = b.GetOnext().GetRot();

	Edge tmp = a.GetOnext();
	a.SetOnext(b.GetOnext());
	b.SetOnext(tmp);

	tmp = aa.GetOnext();
	aa.SetOnext(bb.GetOnext());
	bb.SetOnext(tmp);
	}
    }

/***************************************************************************
*    DelaunayGraph class. Computes Delaunay Triangulation, Voronoi Diagram *
*				and Convex Hull.			   *
*	- init():	adds 3 points at "infinity";			   *
*	- Connect():	connects two points and update edge structures;	   *
*	- DeleteEdge(): deletes an existing edge, inverse of Connect();	   *
*	- Swap():	makes changes in a certain quadrilateral;	   *
*	- setAnimation(): prepare for animation				   *
*	- InsertSite():	inserts a new point in the graph;		   *
*	- Locate():	locates a new point;				   *
*	- GetVoronoiDiagram():	computes the dual graph -- Voronoi Diagram *
*	- draw():	draws the graph;				   *
***************************************************************************/

class DelaunayGraph extends Graph {
    Vector testEdges, newEdges, testGroup;

    public DelaunayGraph() {
	init();
	}

    public void init() {
	Edge e1 = MakeQEdge();
	Edge e2 = MakeQEdge();
	Edge e3 = MakeQEdge();

	//Three points at infinity
	e1.SetOrg(new CPoint(0, -8192));
	e2.SetOrg(new CPoint(-16384, 8192));
	e3.SetOrg(new CPoint(16384, 8192));

	e1.SetDest(e2.GetOrg());
	e1.GetOrg().isInf = true;
	e2.SetDest(e3.GetOrg());
	e2.GetOrg().isInf = true;
	e3.SetDest(e1.GetOrg());
	e3.GetOrg().isInf = true;

	e1.SetOnext(e3.Sym());
	e1.GetRot().SetOnext(e2.GetRot());
	e1.Sym().SetOnext(e2);
	e1.Rot3().SetOnext(e2.Rot3());

	e2.SetOnext(e1.Sym());
	e2.GetRot().SetOnext(e3.GetRot());
	e2.Sym().SetOnext(e3);
	e2.Rot3().SetOnext(e3.Rot3());

	e3.SetOnext(e2.Sym());
	e3.GetRot().SetOnext(e1.GetRot());
	e3.Sym().SetOnext(e1);
	e3.Rot3().SetOnext(e1.Rot3());
	}

    public Edge Connect(Edge a, Edge b) {
	Edge e = MakeQEdge();
	e.SetOrg(a.GetDest());
	e.SetDest(b.GetOrg());
	Splice(e, a.GetLnext());
	Splice(e.Sym(), b);
	return e;
	}

    public void DeleteEdge(Edge e) {
	Splice(e, e.GetOprev());
	Splice(e.Sym(), e.Sym().GetOprev());
	
	Edge eRot;
	for (int i=0; i<3; i++) {
	    eRot = e.GetRot();
	    removeElement(e);
	    e = eRot;
	    }
	removeElement(e);
	}

    public void Swap(Edge e) {
	Edge a = e.GetOprev();
	Edge b = e.Sym().GetOprev();
	Splice(e, a);
	Splice(e.Sym(), b);
	Splice(e, a.GetLnext());
	Splice(e.Sym(), b.GetLnext());
	e.SetOrg (a.GetDest());
	e.SetDest(b.GetDest());
	}

    //prepare for animation
    public void setAnimation() {
	if (testEdges == null)
	    testEdges = new Vector();
	else
	    testEdges.removeAllElements();

	if (newEdges == null)
	    newEdges = new Vector();
	else
	    newEdges.removeAllElements();	

	if (testGroup == null)
	    testGroup = new Vector();
	else
	    testGroup.removeAllElements();
	}

    public void InsertSite(CPoint X, boolean bAnimation) {
        if (bAnimation)
	    setAnimation();

	Edge e = Locate(X, bAnimation);	//where is X?
	
	if (X.isOn(e)) {	//on a edge
	    Edge t = e.GetOprev();
	    DeleteEdge(e);
	    e = t;
	    }

	// connects X to existing points
	Edge newEdge = MakeQEdge();	
	CPoint StartPnt = e.GetOrg();
	newEdge.SetOrg(StartPnt);
	newEdge.SetDest(X);
	Splice(newEdge, e);
	if (bAnimation)
	    newEdges.addElement(new DrawEdge(newEdge));
	do {
	    newEdge = Connect(e, newEdge.Sym());
	    if (bAnimation)
	        newEdges.addElement(new DrawEdge(newEdge));
	    e = newEdge.GetOprev();
	    }
	while (e.GetDest() != StartPnt);

	//makes necessary changes in the graph
	while (true) {
	    Edge t = e.GetOprev();
	    boolean passTest = X.isInCircle(e.GetOrg(), 
				t.GetDest(), e.GetDest());
	    if (bAnimation) {
	        CircleTest egGroup = new CircleTest(X, e, t, passTest);
	        testGroup.addElement(egGroup);
	        }
	    if (t.GetDest().isRightOf(e) && passTest) {
		//X is in the circle. Should delete an old edge and add a 
		//new one.
	        if (bAnimation)
		    testGroup.addElement(new DrawEdge(e));
		Swap(e);
		if (bAnimation) 
		    testGroup.addElement(new DrawEdge(e));
		e = e.GetOprev();
		}
	    else if (e.GetOrg() == StartPnt) 
		return;
	    else
		e = e.GetOnext().GetLprev();
	    }
	}

    public Edge Locate(CPoint X, boolean bAnimation) {
	Edge e = (Edge) firstElement();

 	while(true) {
	    if (bAnimation && e.isValidEdge()) {
		DrawEdge de = new DrawEdge(e);
	    	testEdges.addElement(de);
		}

	    if ((X == e.GetOrg()) || (X == e.GetDest())) {
		return e;
		}
	    else if (X.isRightOf(e))
		e = e.Sym();
	    else if (!(X.isRightOf(e.Onext)))
		e = e.Onext;
	    else if (!(X.isRightOf(e.GetDprev())))
		e = e.GetDprev();
	    else 
		return e;
	    }
	}

    void GetVoronoiDiagram() {
	CPoint pl, pr;

	for (int i=12; i<size(); i+=4) {
	    Edge e = (Edge) elementAt(i);
	    
	    if (e.isValidEdge()) {
		pl = getVoronoiVertex(e, e.GetOnext());
		pr = getVoronoiVertex(e, e.GetOprev());

		e.Rot.SetOrg (pr);
		e.Rot.SetDest(pl);
		}
	    }
	}

    //Computes the Voronoi vertices, which are the intersecting points of
    //the dual edges of Delaunay Triangulation.
    CPoint getVoronoiVertex(Edge e1, Edge e2) {
	CPoint pnt = new CPoint(0, 0);
	long x2 = (long) e1.GetOrg().x;
	long y2 = (long) e1.GetOrg().y;
	long x1 = (long) e1.GetDest().x;
	long y1 = (long) e1.GetDest().y;
    	long x3 = (long) e2.GetDest().x;
    	long y3 = (long) e2.GetDest().y;

	long det = (y2-y3)*(x2-x1) - (y2-y1)*(x2-x3);
	long c1 = (x1+x2)*(x2-x1)/2 + (y2-y1)*(y1+y2)/2;
	long c2 = (x2+x3)*(x2-x3)/2 + (y2-y3)*(y2+y3)/2;
	pnt.x = (int) ((c1*(y2-y3) - c2*(y2-y1)) / det);
	pnt.y = (int) ((c2*(x2-x1) - c1*(x2-x3)) / det);
	pnt.isInf = false;

	return pnt;
	}

    public void draw(Graphics g, Color dcl, Color vcl, Color hcl,
			boolean drawD, boolean drawV, boolean drawH) {
	if (drawD || drawH) {
	    for (int i=0; i<this.size(); i+=4) {
	        Edge e = (Edge) elementAt(i);
	    	    
	        g.setColor(dcl);
		if (e.isValidEdge()) {
		    if (e.GetLnext().isValidEdge() && 
			    e.GetRnext().isValidEdge()) {
		    	if (drawD)  //draw Delaunay Triangulation
		            g.drawLine(e.GetOrg().x, e.GetOrg().y,
			        e.GetDest().x, e.GetDest().y);
		        }
		    else {
		    	if (drawH) //draw Convex Hull
	    	            g.setColor(hcl);
	    		    g.drawLine(e.GetOrg().x, e.GetOrg().y,
			    	e.GetDest().x, e.GetDest().y);
		    	}
		    }
		}
	    }

	if (drawV) { //draw Voronoi Diagram
	    GetVoronoiDiagram();
	    g.setColor(vcl);
	    for (int i=1; i<this.size(); i+=4) {
	        Edge e = (Edge) elementAt(i);
	        if (e.isValidEdge()) 
		    g.drawLine(e.GetOrg().x, e.GetOrg().y,
			e.GetDest().x, e.GetDest().y);
	        }
	    }
	}
    }

/****************************************************************
*   CPoint class. 						*
* 	- isOn():	Whether it's on an edge;		*
*	- isRightOf():	Whether it's to the right of an edge;	*
*	- isLeftOf():	Whether it's to the left of an edge;	*
*	- isInCircle(): Whether it's in a circle		*
*	- draw():	draws the point;			*
****************************************************************/

class CPoint extends Object {
    int x, y;			//point coordinates
    boolean isInf = false;	//is it visible?

    public CPoint(int x, int y) {
	this.x = x;
	this.y = y;
	}

    public boolean isOn(Edge e) {
	CPoint pts = e.GetOrg();
	CPoint pte = e.GetDest();
	return (Area(pts, this, pte) == 0);
	}

    public boolean isRightOf(Edge e) {
	CPoint pts = e.GetOrg();
	CPoint pte = e.GetDest();

	return (Area(this, pts, pte) > 0);
	}

    public boolean isLeftOf(Edge e) {
	CPoint pts = e.GetOrg();
	CPoint pte = e.GetDest();
	return (Area(this, pts, pte) < 0);
	}

    //Computes the sign of the orientable area. Used to determine whether
    //a point is to the left, right, or on an give edge.
    int Area(CPoint p1, CPoint p2, CPoint p3) {
	return((p2.x - p1.x) * (p3.y - p1.y) 
		- (p3.x - p1.x) * (p2.y - p1.y));
	}
   
    public boolean isInCircle(CPoint p1, CPoint p2, CPoint p3)
	{
	long x4 = (long) this.x;
	long y4 = (long) this.y;
	long x1 = (long) p1.x;
	long y1 = (long) p1.y;
	long x2 = (long) p2.x;
	long y2 = (long) p2.y;
	long x3 = (long) p3.x;
	long y3 = (long) p3.y;

	long a =  (x2-x1)*(y3-y1)*(x4*x4+y4*y4-x1*x1-y1*y1)
		+ (x3-x1)*(y4-y1)*(x2*x2+y2*y2-x1*x1-y1*y1)
		+ (x4-x1)*(y2-y1)*(x3*x3+y3*y3-x1*x1-y1*y1)
		- (x2-x1)*(y4-y1)*(x3*x3+y3*y3-x1*x1-y1*y1)
		- (x3-x1)*(y2-y1)*(x4*x4+y4*y4-x1*x1-y1*y1)
		- (x4-x1)*(y3-y1)*(x2*x2+y2*y2-x1*x1-y1*y1);

	return (a > 0);
	}

    public void draw(Graphics g, Color clPoint) {
	g.setColor(clPoint);
	g.fillOval(x - 3, y - 3, 6, 6);
	}
    }

/************************************************
*    Nodes class. Contains the input points.    *
*	- draw():	draws the input points. *
************************************************/

class Nodes extends Vector {
    public void draw(Graphics g, Color clr) {
	g.setColor(clr);
	for (Enumeration em = elements(); em.hasMoreElements();) {
	    Point pt = (Point) em.nextElement();
	    g.fillOval(pt.x - 3, pt.y - 3, 6, 6);
	    }
	}
    }

/************************************************************************
 *  CircleTest class. Determines which edge(s) to show during animation *
 *        - draw():      draws the point and edges being tested         *
 ***********************************************************************/

class CircleTest extends Object {
    CPoint pt;
    DrawEdge eg1, eg2, eg3;
    boolean changed;

    public CircleTest(CPoint X, Edge e, Edge t, boolean pass) {
	pt = X;
	eg1 = new DrawEdge(t);
	eg2 = new DrawEdge(e);
	eg3 = new DrawEdge(t.GetLnext());
	changed = pass;
	}

    public void draw(Graphics g, Color clPoint, Color clEdge, int lastTime) {
	boolean b1 = eg1.draw(g, clEdge);
	boolean b2 = eg2.draw(g, clEdge);
	boolean b3 = eg3.draw(g, clEdge);
	if (b1 || b2 || b3) {
	    pt.draw(g, clPoint);
	    try {
	        Thread.sleep(lastTime);
 	        } catch (InterruptedException ie) {
		    return;
		    }
	    }
	}
    }

/********************************************************************
 *    DrawEdge class. Draws an edge and lets it last for a certain  *
 *                    period of time. Used in animation.            *
 *        - draw():    draw this edge.                              *
 *******************************************************************/

class DrawEdge extends Object {
    Point start, end;
    boolean valid;

    public DrawEdge(Edge e) {
	start = new Point(e.GetOrg().x, e.GetOrg().y);
	end   = new Point(e.GetDest().x, e.GetDest().y);
	valid = e.isValidEdge();
	}

    public boolean draw(Graphics g, Color cl) {
	g.setColor(cl);

	if (valid)  
	    g.drawLine(start.x, start.y, end.x, end.y);
	return valid;
	}

    public boolean draw(Graphics g, Color cl, int lastTime) {
	draw(g, cl);
	if (valid)
	    try {
	        Thread.sleep(lastTime);
	        } catch (InterruptedException e) {
		    return valid;
		    }
	return valid;
	}
    }
	


























