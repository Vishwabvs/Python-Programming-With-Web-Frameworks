package sprite;

public class AnimationLock {
    private boolean locked_;

    AnimationLock() {
	locked_ = false;
    }

    public synchronized void WaitUntilDone() {
        while (locked_) {
	    try
		wait();
	    catch (InterruptedException e);
        }
    }
    
    void StartAnimation() {
        locked_ = true;
    }

    synchronized void FinishAnimation() {
        locked_ = false;
        notifyAll();
    }
}
