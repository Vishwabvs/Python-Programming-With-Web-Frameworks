import java.util.*; 

/***************************************************************/
/*This is the key class in the tree node. Here the x and y     */
/*are the x-coordinate and y-coordinate of a point respectivly.*/
/***************************************************************/  

class Key {
      private int x; 
      private int y; 
  
      public Key(int x, int y) {
         this.x = x; 
         this.y = y;
      }

      public int getX() {
         return x;
      }
      protected void setX(int x){
         this.x = x;
      }

      public int getY() {
         return y;
      }
      protected void setY(int y){
         this.y = y;
      }

      public boolean lessThan(Key k) {
         if(x<k.x ||(x==k.x && y<k.y)) 
		return true;
         else 
		return false; 
      }

      public boolean largerThan(Key k) {
         if(x>k.x ||(x==k.x && y>k.y)) 
		return true;
         else 
		return false; 
      }

      public boolean equals(Key k) {
         if(x==k.x && y==k.y) 
		return true;
         else 
		return false; 
      }
     
      public Key exchange() {
         return new Key(y, x);
      } 
}
/***************************************************************/
/* This is the node class in the tree.			       */
/***************************************************************/
class Node{
      private Key key; 

      public Key getKey() {
         return key;
      }

      public void setKey(Key k) {
         key = k; 
      }

      public void setKey(int x, int y) {
         key = new Key(x, y); 
      }
      
      private Vector trash;
      public Vector getTrash() {
      	return trash;
      }
      public void setTrash(Vector tr) {
      	trash= new Vector();
	for (int i=0; i<tr.size(); i++)
		trash.addElement(tr.elementAt(i));
      }
      public void addTrash(Node node) {
      	trash.addElement(node);
      }
      public void showTrash(){
	if (trash.size()==0) 
		System.out.println(key.getY()+"has no trash");
     	else
		for (int i=0; i<trash.size(); i++){ 	
		Node n = (Node)trash.elementAt(i);
		System.out.println("The "+i+"th trash of "+key.getY()+" is"+ n.getKey().getY());
	}
      }
      
      private Node parent; 
      public Node getParent() {
         return parent;
      }
      protected void setParent(Node n) {
         parent = n; 
      }
      
      private Node left; 
      public Node getLeft() {
         return left;
      }
      protected void setLeft(Node n) {
         left = n; 
      }

      private Node right; 
      public Node getRight() {
         return right;
      }
      protected void setRight(Node n) {
         right = n; 
      }

      private Node prev;
      public Node getPrev() {
         return prev;
      }
      protected void setPrev(Node n) {
         prev = n; 
      }

      private Node next; 
      public Node getNext() {
         return next;
      }

      protected void setNext(Node n) {
         next = n; 
      }

      public Node exchange(){
         return new Node(key.exchange());
      }
		
      public static final int RED = 0; 
      public static final int BLACK = 1; 
      private int color; 
      public int getColor() {
         return color; 
      }
      protected void setColor(int c) {
         color = c; 
      }
/**********************************************************************/
/* black height: number of black nodes on the path from a node to     */
/* leaves (including this node itself if it is black and excluding    */
/* leaves)                                                            */
/**********************************************************************/
      private int bheight; 
      public int getBHeight() {
         return bheight; 
      } 
      protected void setBHeight(int h) {
         bheight = h; 
      }

      public Node(Key k) {
         key = k; 
	 trash = new Vector();
         parent = null; 
         left = null; 
         right = null; 
         prev = null; 
         next = null; 
         color = RED; 
         bheight = 0; 
      }

      public Node(int x, int y) {
         key = new Key(x, y);
	 trash = new Vector();
         parent = null; 
         left = null; 
         right = null; 
         prev = null; 
         next = null; 
         color = RED; 
         bheight = 0; 
         
      }

      public void inOrderWalk() {
         if(left != null)  left.inOrderWalk(); 
         try{  
            System.out.println("X-coord, Y-coord, color, black-height: "+key.getX()+" "+ key.getY()+" "+getColor()+ " "+getBHeight()); 
         }
         catch(NullPointerException e){
            System.out.println("inOrderWalk error: null tree.");
            return;
         }
         if(left != null) { 
            Key k = left.getKey(); 
            System.out.println("Left: "+k.getX()+" "+k.getY()+" "+left.getColor() + " " + left.getBHeight()); 
         }
         if(right != null) { 
            Key k = right.getKey(); 
            System.out.println("Right: "+k.getX()+" "+k.getY()+" "+right.getColor()+" "+ right.getBHeight()); 
         }
         if(prev != null) { 
            Key k = prev.getKey(); 
            System.out.println("Prev: "+k.getX()+" "+k.getY()+" "+prev.getColor()+" "+ prev.getBHeight()); 
         }
         if(next != null) { 
            Key k = next.getKey(); 
            System.out.println("Next: "+k.getX()+" "+k.getY()+" "+next.getColor()+" "+ next.getBHeight()); 
         }
         System.out.println(" "); 
         if(right != null) right.inOrderWalk(); 
      }

/* do not use k = key directly */
      public Node treeSearch(Key k) {
         if(k==null) {
            return null;
         } 
         if(k.equals(key))
            return this; 
         if(k.lessThan(key)) {
            if(left == null) return null; 
            return left.treeSearch(k); 
         }  else {
            if(right==null) return null;
            return right.treeSearch(k); 
         }
      }

      public Node getMinimum() {
         if(left == null) return this; 
         else return left.getMinimum(); 
      }

      public Node getMaximum() {
         if(right == null) return this; 
         else return right.getMaximum(); 
      }

      public Node getSuccessor() {
         if (right != null) return right.getMinimum();
         Node x = this; 
         Node y = this.parent; 
         while(y!=null && y.right == x) {
            x = y; 
            y = y.parent;
         }
         return y; 
      }
 
      public Node getPredecessor() {
            if (left!= null) return left.getMaximum();
            Node x = this; 
            Node y = this.parent;   
            while(y!=null && y.left == x) {
                  x = y; 
                  y = y.parent;
            }
            return y; 
      }
/* a function checking if a tree is balanced; */ 
         
      public int countBHeight() {
         int lc=1;
         int rc=1; 
         int c=1; 

         if(left!=null) lc = left.countBHeight(); 
         if(right!=null) rc = right.countBHeight(); 
         if(lc!=rc) return 0; 
         if(color==BLACK) {
            c = lc+1; 
         } else {
            c = lc; 
         }
         return c;  
      }
   
      protected void copyDataOf(Node n) {
         ; 
      }
   
     public boolean isBetween(Object x, Object y) {
        return true; 
     }

     public boolean isBetween(double x, double y) {
        int a = key.getX(); 
        if(a>=x&&a<=y) { 
           return true; 
        }
        return false; 
     }

/****************************************************************/
/* a function checking if every red node's two children a black.*/
/****************************************************************/
      public boolean checkRed() {
         if(left!=null) {
            if(left.checkRed()==false) 
               return false; 
         }
         if(right!=null) {
            if(right.checkRed()==false) 
               return false; 
         }
         if(color==RED) {
            if(left!=null) {
               if(left.getColor()==RED) {
                  return false;
               }
            }
            if(right!=null) {
               if(right.getColor()==RED) {
                  return false;
               }
            }
         }
         return true; 
      }
}

public class RedBlackTree {
      public static final int RIGHT = 0; 
      public static final int LEFT = 1; 
      public static final int RED = Node.RED; 
      public static final int BLACK = Node.BLACK; 
      private Node root;

      public Node getRoot() {
         return root; 
      }
      public void setRoot(Node n){
	root=n;
      }
		
      public RedBlackTree() {
         root = null; 
      }

      public RedBlackTree(Node n) {
         root = n; 
      }

      public RedBlackTree(int x, int y) {
         root = new Node(x, y); 
      }

      public RedBlackTree(Key k) {
         root = new Node(k); 
      }
 
/* RedBlackTree.treeContains */
      public boolean treeContains(Node x) {
         if(x==null) {
            System.out.println("treeContains error: null node."); 
            return false; 
         }
         Node y = root.treeSearch(x.getKey()); 
         if(x==y) return true; 
         else return false; 
      }

/* RedBlackTree.treeSearch */
      public Node treeSearch(Key k) {
         return root.treeSearch(k); 
      }

      public Node getMinimum() {
         if(root == null) { 
            System.out.println("error: root is null."); 
            return null;
         }
         return root.getMinimum(); 
      }

      public Node getMaximum() {
         if(root == null) { 
            System.out.println("error: root is null."); 
            return null;
         }
         return root.getMaximum(); 
      }

      public Vector nodesBetween(double l, double r) {
         if(root == null) {
            System.out.println("error: root is null."); 
            return null;
         }
         Vector v = new Vector();  
         if(l>r) {
            return v;
         }
         Node n = root; 
         if(n.getKey().getX()>=l) {
            Node prev_=n.getPrev(); 
            while(prev_!=null&&prev_.getKey().getX()>=l) {
               n=prev_; 
               prev_=n.getPrev();
            }
         } else { 
            n = n.getNext(); 
            while(n!=null&&n.getKey().getX()<l) {
               n = n.getNext();
            } 
         }
         if(n==null||n.getKey().getX()>r) {
            return v;
         }
         while(n!=null&&n.getKey().getX()<=r) {
            v.addElement(n);
            n = n.getNext();
         }
         return v;
      }
     
      public Vector allNodes() {
         if(root == null) {
            System.out.println("error: root is null."); 
            return null;
         }
         Vector v = new Vector();  
         Node node = getMinimum(); 
         while(node!=null) {
            v.addElement(node); 
            node = node.getNext(); 
         }
         return v; 
      }

      public void inOrderWalk() {
         if(root!=null) {
            root.inOrderWalk();
         }
      }

      public void leftRotate(Node x) {
         if(x==null) {  
            System.out.println("leftRotate error: null node."); 
            return; 
         }
         Node y = x.getRight(); 
         if(y==null) {
            System.out.println("leftRotate error: null right child node."); 
            return; 
         }
         x.setRight(y.getLeft()); 
         if(y.getLeft()!=null) {
            y.getLeft().setParent(x); 
         }
         y.setParent(x.getParent()); 
         if(x.getParent()==null) {
            root = y; 
         }  else if(x==x.getParent().getLeft()) {
            x.getParent().setLeft(y); 
         }  else {
            x.getParent().setRight(y);
         }
         y.setLeft(x); 
         x.setParent(y); 
      }

      public void rightRotate(Node x) {
         if(x==null) {  
            System.out.println("rightleftRotate error: null node."); 
            return; 
         }
         Node y = x.getLeft(); 
         if(y==null) {
            System.out.println("rightRotate error: null left child node."); 
            return; 
         }
         x.setLeft(y.getRight()); 
         if(y.getRight()!=null) {
            y.getRight().setParent(x); 
         }
         y.setParent(x.getParent()); 
         if(x.getParent()==null) {
            root = y; 
         }  else if(x==x.getParent().getRight()) {
            x.getParent().setRight(y); 
         }  else {
            x.getParent().setLeft(y);
         }
         y.setRight(x); 
         x.setParent(y); 
      }

      public boolean treeInsert(Node z) {
         if(z==null) {
            return false;
         }
         if(root == null) { 
            root = z; 
            root.setParent(null); 
            root.setLeft(null); 
            root.setRight(null); 
            root.setPrev(null); 
            root.setNext(null); 
            root.setColor(Node.BLACK); 
            root.setBHeight(1); 
            return true; 
         }
         if(treeSearch(z.getKey())!=null) {
            return false; 
         } 
         Node x = root; 
         Node y = null; 
         while(x != null){
            y = x; 
            if(z.getKey().lessThan(x.getKey())) {
               x = x.getLeft(); 
            }else if(z.getKey().largerThan(x.getKey())) {
               x = x.getRight(); 
            }else {
               return false; 
            }  
         }
         z.setParent(y); 
         if(y==null) {
            root = z; 
         }  else { 
            if(z.getKey().lessThan(y.getKey())) { 
               y.setLeft(z); 
            }  else {
               y.setRight(z); 
            } 
         } 
         Node w=z.getPredecessor(); 
         z.setPrev(w); 
         if(w!=null) w.setNext(z);  
         Node v=z.getSuccessor(); 
         z.setNext(v); 
         if(v!=null) v.setPrev(z);  
/**************************************************************************/
/* Fixup the black-red tree.  z.getParent() cannot be null because then z */
/* would be the root. However in that case the initial root must be null  */
/* and the method returns true before getting here.                       */
/**************************************************************************/
         z.setColor(RED);
         while(z!=root && z.getParent().getColor()==RED) {
            Node p = z.getParent(); 
            Node pp = p.getParent(); 
            z.setBHeight(p.getBHeight()); 
            if(p==pp.getLeft()) {
               y=pp.getRight(); 
               int c = RED; 
               if(y==null) {
                  c = BLACK;
               }  else {
                  c = y.getColor(); 
               }
               if(c==RED) {
                  p.setColor(BLACK); 
                  p.setBHeight(p.getBHeight()+1); 
                  y.setColor(BLACK); 
                  y.setBHeight(y.getBHeight()+1); 
                  pp.setColor(RED); 
                  z = pp; 
               }  else {
                  if(z==p.getRight()) {
                     z = p; 
                     leftRotate(z); 
                     p=z.getParent();
                  }
                  p.setColor(BLACK); 
                  p.setBHeight(p.getBHeight()+1); 
                  pp.setColor(RED); 
                  pp.setBHeight(pp.getBHeight()-1); 
                  rightRotate(pp); 
               }
            }  else {
               y=pp.getLeft(); 
               int c = RED;
               if(y==null) {
                  c = BLACK;
               }  else {
                  c = y.getColor(); 
               }
               if(c==RED) {
                  p.setColor(BLACK); 
                  p.setBHeight(p.getBHeight()+1); 
                  y.setColor(BLACK); 
                  y.setBHeight(y.getBHeight()+1); 
                  pp.setColor(RED); 
                  z = pp; 
               }  else {
                  if(z==p.getLeft()) {
                     z = p; 
                     rightRotate(z); 
                     p=z.getParent();
                  }
                  p.setColor(BLACK); 
                  p.setBHeight(p.getBHeight()+1); 
                  pp.setColor(RED); 
                  pp.setBHeight(pp.getBHeight()-1); 
                  leftRotate(pp); 
               }
            }
         }   
         if(root.getColor()==RED) {
            root.setColor(BLACK); 
            root.setBHeight(root.getBHeight()+1);
         }
         return true;  
      }

      public boolean treeDelete(Node z) {
         Node x; 
         Node y; 
         int side = LEFT; 
         if(z==null) {
            return false;
         }
         if(root == null) { 
            System.out.println("treeDelete error: empty tree"); 
            return false; 
         }
         if(treeContains(z)==false) {
            System.out.println("treeDelete error: node not in the tree");
            return false; 
         } 
         if(root.getLeft()==null&&root.getRight()==null) {
            root = null; 
            //System.out.println("The tree is completely deleted."); 
            return true; 
         }
         boolean by_succ = false; 
         boolean by_pred = false; 
         boolean index_ = false; 
         if(z.getRight()!=null) {
            y = z.getNext(); 
            if(y==z.getRight()) 
               index_ = true; 
            by_succ = true; 
         } else if(z.getLeft()!=null) {
            y = z.getPrev();
            if(y==z.getLeft()) 
               index_ = true; 
            by_pred = true; 
         } else { 
            y = z; 
         }  
 
         if(y.getLeft()!=null) {
            x = y.getLeft(); 
            side = LEFT; 
         }  else { 
            x = y.getRight();
            side = RIGHT; 
         }
         if(x!=null) {
            if(!index_) 
               x.setParent(y.getParent()); 
         }
         if(!index_) {
            // y.getParent() can not be null..., if it were the case, then
            // z = y = root, then tree only contains root, but then
            // the function should have already returned. 
            if(y==y.getParent().getLeft()) {
               y.getParent().setLeft(x); 
               side = LEFT; 
            }  else {
               y.getParent().setRight(x);
               side = RIGHT; 
            }
         } 
            
         // What is going to do is to drop z out of the tree and put y
         // to where z used to be.  y copies z's color and blackheight.
         // If z was the root, y is the new root of the tree.  
         // Before changing the parent and color of y, made a record of them. 
         Node old_p_ = null; 
         if(index_) {
            old_p_ = y; 
         } else {
            old_p_ = y.getParent();         
         } 
         int old_color_ = y.getColor(); 

         if(y!=z) {
            Node p_ = z.getParent(); 
            Node l_ = z.getLeft(); 
            Node r_ = z.getRight(); 
            y.setParent(p_); 
            if(p_!=null) {
               if(z==p_.getLeft()) {
                  p_.setLeft(y); 
               } else {
                  p_.setRight(y); 
               }
            }
            if(by_succ) {
               y.setLeft(l_); 
               if(l_!=null) {
                  l_.setParent(y); 
               }
               if(!index_) {
                   y.setRight(r_); 
                   if(r_!=null) {
                      r_.setParent(y); 
                   }
               } 
               Node p = z.getPrev();
               y.setPrev(p);
               if(p!=null) {
                  p.setNext(y);
               }
            } else if(by_pred) {
               // This time r_ must be null. 
               y.setRight(null); 
               if(!index_) {
                   y.setLeft(l_); 
                   if(l_!=null) {
                      l_.setParent(y); 
                   }
               } 
               Node n = z.getNext();
               y.setNext(n);
               if(n!=null) {
                  n.setPrev(y);
               } 
            } 
            y.setBHeight(z.getBHeight()); 
            y.setColor(z.getColor()); 
            if(root==z) 
               root = y; 
         } else {
            Node p = z.getPrev(); 
            Node n = z.getNext(); 
            if(p!=null) {
               p.setNext(n); 
            } 
            if(n!=null) {
               n.setPrev(p); 
            } 
         }

         if(old_color_==BLACK) {
            RBDeleteFixUp(x, side, old_p_); 
         } 
         return true; 
      }


       private void RBDeleteFixUp(Node x, int s, Node px) {
         int color;
         int lc; 
         int rc; 
         int side; 
         Node p; 

         if(x==null) {
            color=BLACK; 
         }  else {
            color = x.getColor(); 
         }
         while(x!=root && color==BLACK) {
            if(x==null) {
               side = s; 
               p = px; 
            }  else {
               p = x.getParent(); 
               if(x==p.getLeft()) {
                  side = LEFT; 
               }  else {
                  side = RIGHT; 
               }
            }
            if(side==LEFT) {
               Node w = p.getRight(); 
/* Case 1 */
               if(w.getColor()==RED) {
                  w.setColor(BLACK); 
                  w.setBHeight(w.getBHeight() + 1) ; 
                  p.setColor(RED); 
                  p.setBHeight(p.getBHeight() - 1) ; 
                  leftRotate(p); 
                  w = p.getRight(); 
               }
               if(w.getLeft()==null) {
                  lc = BLACK; 
               }  else {
                  lc = w.getLeft().getColor(); 
               }
               if(w.getRight()==null) {
                  rc = BLACK; 
               }  else {
                  rc = w.getRight().getColor(); 
               }
/* Case 2 */ 
               if(lc==BLACK && rc==BLACK) {
                  w.setColor(RED); 
                  w.setBHeight(w.getBHeight()-1); 
                  p.setBHeight(p.getBHeight()-1); 
                  x = p;
               }  else {
/* Case 3 */ 
                     if(rc==BLACK) {
                        w.getLeft().setColor(BLACK); 
                        w.setColor(RED); 
                        w.setBHeight(w.getBHeight()-1); 
                        rightRotate(w); 
                        w = p.getRight();
                        w.setBHeight(w.getBHeight()+1); 
                     }
/* Case 4 */ 
                  w.setColor(p.getColor());
                  w.getRight().setColor(BLACK); 
                  if(p.getColor()==BLACK) {
                     p.setBHeight(p.getBHeight()-1); 
                     w.setBHeight(w.getBHeight()+1);
                  }
                  p.setColor(BLACK); 
                  w.getRight().setBHeight(w.getRight().getBHeight()+1);
                  leftRotate(p); 
                  x = root; 
               }  
            }  else {  
               Node w = p.getLeft(); 
/* Case 1 */ 
               if(w.getColor()==RED) {
                  w.setColor(BLACK); 
                  w.setBHeight(w.getBHeight() + 1); 
                  p.setColor(RED); 
                  p.setBHeight(p.getBHeight() - 1); 
                  rightRotate(p); 
                  w = p.getLeft(); 
               }
               if(w.getLeft()==null) {
                  lc = BLACK; 
               }  else {
                  lc = w.getLeft().getColor(); 
               }
               if(w.getRight()==null) {
                  rc = BLACK; 
               }  else {
                  rc = w.getRight().getColor(); 
               }
/* Case 2 */ 
               if(lc==BLACK && rc==BLACK) {
                  w.setColor(RED); 
                  w.setBHeight(w.getBHeight()-1); 
                  p.setBHeight(p.getBHeight()-1); 
                  x = p;
               }  else {
/* Case 3 */ 
                     if(lc==BLACK) {
                        w.getRight().setColor(BLACK); 
                        w.setColor(RED); 
                        w.setBHeight(w.getBHeight()-1); 
                        leftRotate(w); 
                        w = p.getLeft();
                         w.setBHeight(w.getBHeight()+1); 
                     }
/* Case 4 */ 
                  w.setColor(p.getColor());
                  w.getLeft().setColor(BLACK); 
                  if(p.getColor()==BLACK) {
                     p.setBHeight(p.getBHeight()-1);
                     w.setBHeight(w.getBHeight()+1); 
                  } 
                  p.setColor(BLACK); 
                  w.getLeft().setBHeight(w.getLeft().getBHeight()+1); 
                  rightRotate(p); 
                  x = root; 
               }  
            }
/******************************************************************
 Update color 
*******************************************************************/ 
            if(x==null) {
               color = BLACK; 
            }  else {
               color = x.getColor(); 
            } 
         }
         if(x.getColor()==RED) {
            x.setColor(BLACK); 
            x.setBHeight(x.getBHeight()+1);
         }
      }
     
/***************************************************************/  
      public boolean checkHeight() {
         Node x = root; 
         boolean visit=false; 
         int lh; 
         int rh; 

         while(x!=null) {
            if(x.getLeft()!=null && visit!=true)  x = x.getLeft(); 
            else if(x.getRight()!=null && visit!=true) x = x.getRight();
            else if(x==root) x = null;  
            else {
               if(x.getLeft()==null) {
                  lh = 0; 
               } else {
                  lh = x.getLeft().getBHeight();
               }
               if(x.getRight()==null) {
                  rh = 0; 
               } else {
                  rh = x.getRight().getBHeight();
               }
               if(lh!=rh) {
                  System.out.println("lh not equal to rh"); 
                  return false; 
               } 
               if(x.getColor()==RED) {
                  if(x.getBHeight()<lh) {
                     System.out.println("red: bh less than expected"); 
                     return false; 
                  } else if(x.getBHeight()>lh) {
                     System.out.println("red: bh larger than expected"); 
                     return false; 
                  }
               } else {
                  if(x.getBHeight()<lh+1) {
                     System.out.println("black: bh less than expected"); 
                     return false; 
                  } else if(x.getBHeight()>lh+1) {
                     System.out.println("black: bh larger than expected"); 
                     return false; 
                  }
               }
               if(x == x.getParent().getLeft()) {
                  if(x.getParent().getRight()!=null) {
                     x = x.getParent().getRight(); 
                     visit = false; 
                  } else {
                     x = x.getParent(); 
                     visit = true; 
                  }
               } else {
                  x = x.getParent(); 
                  visit = true; 
               }
            }
         }
         return true; 
      }   
/***************************************************************/
      public boolean isInOrder() {
         if(root==null) {
            return true; 
         } 
         Node min = root.getMinimum();
         Key key = min.getKey(); 
         Key new_key = null; 
         Node n = min.getNext(); 
         while(n!=null) {
            new_key = n.getKey(); 
            if(key.largerThan(new_key)||key.equals(new_key)) {
               return false; 
            }
            key = new_key; 
            n = n.getNext();
         } 

         Node max = root.getMaximum();
         key =max.getKey(); 
         n = max.getPrev();
         while(n!=null) {
            new_key = n.getKey(); 
            if(key.lessThan(new_key)||key.equals(new_key)) {
               return false; 
            }
            key = new_key; 
            n = n.getPrev(); 
         } 
         return true; 
      } 

      public boolean checkTree() {
         boolean c = true; 
         if(!isInOrder()) {
            System.out.println("The tree is not in order."); 
            c = false; 
         } 
         if(!root.checkRed()) {
            System.out.println("Soem red nodes have red children"); 
            c = false; 
         }
         if(!checkHeight()) {
            System.out.println("The tree is not balanced in bheight."); 
            c = false; 
         }
         return c; 
     } 
} 
