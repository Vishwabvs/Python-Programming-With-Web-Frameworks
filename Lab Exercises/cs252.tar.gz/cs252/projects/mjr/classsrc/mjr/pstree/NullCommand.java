/*
 * @(#)NullCommand.java 1.0 1/13/96 Michael John Radwin
 */
 
package mjr.pstree;
 
import leda.*;
 
public class NullCommand extends PSTCommand {
    public Object _execute(ps_item p)
    {
	return null;
    }
    public static void mjr() { ; }
}
