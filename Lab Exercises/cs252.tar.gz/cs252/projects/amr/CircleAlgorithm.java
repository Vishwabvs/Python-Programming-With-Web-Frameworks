import java.util.*;
import java.awt.*;

import LayoutAlgorithm;
import Node;
import WebTree;

public class CircleAlgorithm extends LayoutAlgorithm {

   final private int RADIUS = 10;

   final private int INITIAL_INTERVAL = 50;

   final private boolean DEBUG = false;
   
   private Vector intervalList_;

   private WebTree wt_;

   private int width_, height_;

   private int centerX_, centerY_;
   


// CONSTRUCTOR ///////////////////////////////////////////////////////
   
   CircleAlgorithm (WebTree wt)
   {
      
      wt_ = wt;

      width_ = wt_.getOffScreenWidth();
      height_ = wt_.getOffScreenHeight();

      centerX_ = width_ / 2;
      centerY_ = height_ / 2;
      
   }


// EXECUTE ///////////////////////////////////////////////////////////
   
public void execute (Vector nodeList)
  {

    if (DEBUG) System.out.println("circle algorithm execute called");

    int total = nodeList.size();
    
    if (DEBUG) System.out.println("total nodes: " + total);
    
    if (total == 0) return; // make sure there is a graph

    // Sort the list by depth.

    InsertionSort(nodeList);

    // The maximum depth is the depth of the last element in the sorted list.

    int maxDepth = getMaxDepth(nodeList);

    if (DEBUG) System.out.println("max depth: " + maxDepth);


    
    Vector depthList = new Vector();

    int currentDepth = 0; // the depth of the root is zero
    int nodeCount = 0;

    for (int j = 0; j < total; j++) {

      Node tempNode = (Node)nodeList.elementAt(j);

      int depth = tempNode.getDepth();

      if (depth == currentDepth) nodeCount++;

      else { // do this only if we down (or up?!) a level

        depthList.addElement(new Integer(nodeCount));
        nodeCount = 1;
        currentDepth++;

      }

    }

    depthList.addElement(new Integer(nodeCount)); // add the last count

    if (DEBUG) {

       // Print out the depth list.

       for (int j = 0; j < depthList.size(); j++) {

          int count = ((Integer)(depthList.elementAt(j))).intValue();
          System.out.print(count + " ");
           
       }
        
       System.out.println();

    }


    
    // Adjust the intervals based upon the number of nodes on each level.

    intervalList_ = new Vector();

    int totalRadius = 0;
    
    for (int j = 0; j < depthList.size(); j++) {

       int numNodes = ((Integer)(depthList.elementAt(j))).intValue();

       int circumference = (int)(2 * Math.PI * INITIAL_INTERVAL);

       int totalLength = 2 * RADIUS * numNodes;

       int interval;

       if (j == 0) interval = 0;
       else interval = INITIAL_INTERVAL;
       
       if (circumference < totalLength) {

          interval = (int)(totalLength / (2 * Math.PI));

       }

       intervalList_.addElement(new Integer(interval));

       totalRadius += interval;
       
    }

    if (DEBUG) {

       // Print out the interval list.

       System.out.println("Interval list:");

       for (int j = 0; j < intervalList_.size(); j++) {
          
          int interval = ((Integer)(intervalList_.elementAt(j))).intValue();
          System.out.print(interval + " ");
          
       }
       
      System.out.println();

    }

    if (DEBUG) System.out.println("total radius: " + totalRadius);
    
    // Adjust the interval based upon the maximum depth.

    int maxRadius = (width_ - 2 * RADIUS) / 2;
    
    if (totalRadius > maxRadius) {

       double adjust = (double)maxRadius / (double)totalRadius;

       if (DEBUG) System.out.println("adjust: " + adjust);
       
       for (int j = 0; j < intervalList_.size(); j++) {
          
          int interval = ((Integer)(intervalList_.elementAt(j))).intValue();

          interval *= adjust;

          intervalList_.setElementAt(new Integer(interval), j);

        }

       if (DEBUG) {

          // Print out the interval list.

          System.out.println("Adjusted interval list:");

          for (int j = 0; j < intervalList_.size(); j++) {
          
             int interval = ((Integer)(intervalList_.elementAt(j))).intValue();
             System.out.print(interval + " ");
          
          }
       
          System.out.println();

       } 

    }

    int radius = 0;

    int depthCounter = -1;
    int nodeCounter = -1;

    while (++nodeCounter < total) {

      Node tempNode = (Node)nodeList.elementAt(nodeCounter);

      depthCounter++;

      int numNodes = ((Integer)(depthList.elementAt(depthCounter))).intValue();

      double delta = 360.0 / (double)numNodes;


      radius += ((Integer)(intervalList_.elementAt(depthCounter))).intValue();

      if (DEBUG) System.out.println("radius: " + radius);

      
      double theta = 270.0; // the screen is upside down

      // For each page on the current level.

      int counter = 0;

      while (counter < numNodes) {

        theta += delta;

        if (DEBUG) System.out.println("theta: " + theta);

        double radians = (theta * Math.PI) / 180.0;

        int newX = (int)(centerX_ + Math.cos(radians) * radius);
        int newY = (int)(centerY_ + Math.sin(radians) * radius);

        tempNode.setPosition(new Point(newX, newY));

        counter++;
        
        if (counter < numNodes) {
          nodeCounter++;
          tempNode = (Node)nodeList.elementAt(nodeCounter);
        }

      }

    }

    wt_.snapTo(new Point(centerX_, centerY_));
      
  }


// GET INTERVAL ///////////////////////////////////////////////////////

public Vector getInterval () { return intervalList_; }


// INSERTION SORT /////////////////////////////////////////////////////
   
final private void InsertionSort (Vector list)
   {

      int k, j, n;
      Node itemToInsert;
      boolean stillLooking;

      n = list.size();

      for (k = 1; k < n; k++) {

         itemToInsert = (Node)list.elementAt(k);
         j = k - 1;
         stillLooking = true;
      
         while (j >= 1 && stillLooking)

            if (itemToInsert.getDepth() <
                ((Node)(list.elementAt(j))).getDepth()) {

               list.setElementAt(list.elementAt(j), j + 1);
               j--;

            } else stillLooking = false;

         list.setElementAt(itemToInsert, j + 1);
         
      }
   }

public final int getMaxDepth(Vector nodeList){
  int temp =0;
  for (int i=0; i<nodeList.size(); i++){
    if (((Node)nodeList.elementAt(i)).getDepth() >  temp)
      temp =((Node)nodeList.elementAt(i)).getDepth(); 
  }
  return temp;


}
}
