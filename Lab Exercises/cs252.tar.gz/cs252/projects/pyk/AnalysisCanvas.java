/*
 * AnalysisCanvas.java
 *
 * Description:
 *    This class is the canvas on the popup window used in "Show
 *    Analysis" mode
 */
import java.awt.Canvas;
import java.awt.Graphics;
import java.awt.Font;
import java.awt.Color;
import java.awt.Image;
import java.awt.FontMetrics;

class AnalysisCanvas extends Canvas
{
   private int dx = 0;            // scrolled x value
   private int dy = 0;            // scrolled y vale
   AnalysisFrame parentFrame;     // parent window
   Font f;                        // font to use for writing
   int width = 577;               // width of the canvas
   int height = 524;              // height of the canvas

   // states for the tree walking algorithms
   final int EDGEX = 0;
   final int EDGEY = 1;
   final int EDGEZ = 2;
   final int INTERVALX = 3;
   final int INTERVALY = 4;
   final int INTERVALZ = 5;
   final int INTERSECTX = 6;
   final int INTERSECTY = 7;
   final int INTERSECTZ = 8;
   final int LOCATEX = 9;
   final int LOCATEY = 10;
   final int LOCATEZ = 11;

   // constructor for Analysis Canvas
   public AnalysisCanvas(AnalysisFrame parent)
   {
      parentFrame = parent;
      setBackground(new Color(200, 200, 200));
      f = new Font("TimesRoman", Font.PLAIN, 18);
   }

   // set the size of the canvas
   public void setSize()
   {
      resize(width, height);
   }

   // save new position and repaint after scrolling has occurred
   public void translate(int x, int y)
   {
      dx = x;
      dy = y;
      repaint();
   }

   // paint the canvas according to the scrolled position and the
   // current state
   public void paint(Graphics g)
   {
      g.clearRect(0, 0, width, height);
      g.translate(-dx, -dy);
      if ((parentFrame.treeType == EDGEX) ||
          (parentFrame.treeType == EDGEY) ||
          (parentFrame.treeType == EDGEZ))
      {
         parentFrame.queryParent.edgeTree.edgeInOrderDrawTraversal(g);
      }
      else if ((parentFrame.treeType == INTERVALX) ||
               (parentFrame.treeType == INTERVALY) ||
               (parentFrame.treeType == INTERVALZ))
      {
         parentFrame.queryParent.intervalTree.intervalDrawTraversal(g);
      }
      else if ((parentFrame.treeType == INTERSECTX) ||
               (parentFrame.treeType == INTERSECTY) ||
               (parentFrame.treeType == INTERSECTZ))
      {
         parentFrame.queryParent.intervalTree.intersectDrawTraversal(g);
      }
      else if ((parentFrame.treeType == LOCATEX) ||
               (parentFrame.treeType == LOCATEY) ||
               (parentFrame.treeType == LOCATEZ))
      {
         parentFrame.queryParent.intervalTree.intersectDrawTraversal(g);
      }
   }
}