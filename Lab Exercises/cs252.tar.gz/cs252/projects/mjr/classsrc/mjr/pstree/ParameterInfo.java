/*
 * @(#)ParameterInfo.java	1.0 5/21/96 Michael John Radwin
 */

package mjr.pstree;

import java.applet.*;
import java.awt.*;
import java.util.*;
import java.net.*;

/**
 * This class stores all of the parameter information for the PST
 * applet.
 *
 * @version $Revision: 1.5 $ 5/21/96
 * @author <A HREF="http://www.cs.brown.edu/people/mjr/">Michael John Radwin</A>
 */
public class ParameterInfo {
    public int UNVISITED = PSTNode.UNVISITED;
    public int VISITED_SUCCESS = PSTNode.VISITED_SUCCESS;
    public int VISITED_FAILURE = PSTNode.VISITED_FAILURE;
    public Color LEFT_EDGE = Color.black;
    public Color RIGHT_EDGE = Color.red;
    public Color MEDIAN = Color.yellow;
    public Color SEARCH = Color.darkGray;
    public Color INSTRUCTIONS = Color.black;
    public String BACKGROUND;
    public String IMAGEBASE;
    public String GRAPHBASE;
    public String SAVE_CGI;
    public boolean DEBUG = false;
    
    public ParameterInfo(Applet applet)
    {
	int i = 0;
	int image;
	Color candidate;

	String args[] = getParameters(applet);

	// image base
	if (args[i] != null) {
	    IMAGEBASE = args[i];
	    if (IMAGEBASE.charAt(IMAGEBASE.length() - 1) != '/')
		IMAGEBASE += '/';
	}
	else
	    IMAGEBASE = applet.getCodeBase().toString() + "mjr/pstree/images/";
	i++;
	
	// graph base
	if (args[i] != null) {
	    GRAPHBASE = args[i];
	    if (GRAPHBASE.charAt(GRAPHBASE.length() - 1) != '/')
		GRAPHBASE += '/';
	}
	else
	    GRAPHBASE = applet.getCodeBase().toString() + "mjr/pstree/graphs/";
	i++;


	// save_as CGI script
	if (args[i] != null)
	    SAVE_CGI = args[i];
	else {
	    URL u = null;
	    try
		u = new URL(applet.getCodeBase().getProtocol(),
			    applet.getCodeBase().getHost(),
			    "/cgi-bin/mjr-cs252.pl");
	    catch (MalformedURLException e) { ; }
	    SAVE_CGI = u.toString();
	}
	i++;


	// background image URL
	if (args[i] != null)
	    BACKGROUND = args[i];
	else
	    BACKGROUND = applet.getCodeBase().toString() + "mjr/pstree/images/wheat.gif";
	i++;

	// the 3 point colors
	if ((image = parsePointColor(args[i++])) != -1)
	    UNVISITED         = image;
	if ((image = parsePointColor(args[i++])) != -1)
	    VISITED_SUCCESS   = image;
	if ((image = parsePointColor(args[i++])) != -1)
	    VISITED_FAILURE   = image;

	// left/right edges, search box, median line colors
	if ((candidate = parseColor(args[i++])) != null)
	    LEFT_EDGE = candidate;
	if ((candidate = parseColor(args[i++])) != null)
	    RIGHT_EDGE = candidate;
	if ((candidate = parseColor(args[i++])) != null)
	    SEARCH = candidate;
	if ((candidate = parseColor(args[i++])) != null)
	    MEDIAN = candidate;
	if ((candidate = parseColor(args[i++])) != null)
	    INSTRUCTIONS = candidate;

	// debugging info on/off
	DEBUG = (args[i] != null && args[i].equalsIgnoreCase("true"));
	i++;

	if (DEBUG)
	    for (int j = 0; j < args.length; j++)
		if (args[j] != null)
		    System.err.println("Parameter " + j + ": " + args[j]);
    }

    static protected String[] getParameters(Applet applet)
    {
	String result[] = new String[13];
	int i = 0;
	
	result[i++] = applet.getParameter("imagebase");
	result[i++] = applet.getParameter("graphbase");
	result[i++] = applet.getParameter("save_cgi");
	result[i++] = applet.getParameter("background");
	result[i++] = applet.getParameter("unvisited");
	result[i++] = applet.getParameter("success");
	result[i++] = applet.getParameter("failure");
	result[i++] = applet.getParameter("leftedge");
	result[i++] = applet.getParameter("rightedge");
	result[i++] = applet.getParameter("search");
	result[i++] = applet.getParameter("median");
	result[i++] = applet.getParameter("instructions");
	result[i++] = applet.getParameter("debug");

	return result;
    }
    
    
    protected Color parseColor(String arg)
    {
	if (arg == null) return null;
	StringTokenizer tokens = new StringTokenizer(arg, " \t\r\n|,");
	int r, g, b;
	
	if (tokens.countTokens() != 3) {
	    System.err.println("Bad argument: " + arg);
	    return null;
	}
	
	try {
	    r = Integer.parseInt(tokens.nextToken());
	    g = Integer.parseInt(tokens.nextToken());
	    b = Integer.parseInt(tokens.nextToken());

	} catch (Exception e) {
	    System.err.println("Execption while parsing argument " + arg + ": " + e);
	    return null;
	}

	return new Color(r, g, b);
    }

	
    protected int parsePointColor(String arg)
    {
	if (arg == null) return -1;

	if (arg.equalsIgnoreCase("blue")) return GIFNode.BLUE;
	if (arg.equalsIgnoreCase("yellow")) return GIFNode.YELLOW;
	if (arg.equalsIgnoreCase("red")) return GIFNode.RED;
	if (arg.equalsIgnoreCase("magenta")) return GIFNode.MAGENTA;
	if (arg.equalsIgnoreCase("green")) return GIFNode.GREEN;
	if (arg.equalsIgnoreCase("cyan")) return GIFNode.CYAN;

	return -1;
    }

    public static final String pinfo[][] = {
	{"imagebase",  "url",                                     "the base url of point images"},
	{"graphbase",  "url",                                     "the base url of graph files"},
	{"save_cgi",   "url",                                     "the url of the save_as cgi processing script"},
	{"background", "url",                                     "the absolute location of background image"},
	{"unvisited",  "{blue|yellow|red|magenta|green|cyan}",    "color of unvisited points"},
	{"success",    "{blue|yellow|red|magenta|green|cyan}",    "color of success points"},
	{"failure",    "{blue|yellow|red|magenta|green|cyan}",    "color of failure points"},
	{"leftedge",   "[0-255],[0-255],[0-255]",                 "red, green, and blue components of left edge color"},
	{"rightedge",  "[0-255],[0-255],[0-255]",                 "red, green, and blue components of right edge color"},
	{"search",     "[0-255],[0-255],[0-255]",                 "red, green, and blue components of search box color"},
	{"median",     "[0-255],[0-255],[0-255]",                 "red, green, and blue components of median line color"},
	{"debug",      "boolean",                                 "toggles debugging information"}
    };
	
}
