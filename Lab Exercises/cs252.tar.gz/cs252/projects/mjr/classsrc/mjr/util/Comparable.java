/*
 * @(#)Comparable.java	1.0 1/13/96 Michael John Radwin
 */

package mjr.util;

/**
 * A comparable object is one that can be compared to others.
 *
 * @version 1.0 1/13/96
 * @author <A HREF="http://www.cs.brown.edu/people/mjr/">Michael John Radwin</A>
 */
public interface Comparable {
    /**
     * Determines if this object is greater than another.
     * @return true if this object is greater than the other
     * @param other the object on the right-hand side of the comparison
     */
    public boolean greaterThan(Object other);
    
    /**
     * Determines if this object is less than another.
     * @return true if this object is less than the other
     * @param other the object on the right-hand side of the comparison
     */
    public boolean lessThan(Object other);
    
    /**
     * Determines if this object is equal to another.
     * @return true if this object is equal to the other
     * @param other the object on the right-hand side of the comparison
     */
    public boolean equalTo(Object other);    
}
