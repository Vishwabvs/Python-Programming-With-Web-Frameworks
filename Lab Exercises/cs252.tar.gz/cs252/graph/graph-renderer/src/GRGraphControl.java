/*
 *  GRGraphControl - control panel for program, regulates graph actions
 *  4/14/96 
 *  by Daniel Spirn 
 *
 */
package graphrender;

import java.awt.*;
import java.applet.*;

public class GRGraphControl extends Frame
{  
    // Access to the graphing area
    static protected GRGraphArea 	ga_;

    // Various Dialog Boxes that pop up, all of whom have GRGraphControl as their parent
    static Frame		method_dialog_;
    static GRDialog_Spring	spring_dialog_;
    static GRDialog_SA		s_a_dialog_;
    static GRDialog_ForceDirected	force_directed_dialog_;
    static GRDialog_New		new_dialog_;
    static GRDialog_Load	load_dialog_;

    //  Pop up graph of the energy vs. iteration
    static GREnergyGraph		energy_graph_;

    // Components of the control panel
    static Panel		panel_;
    static Panel 		controlbar_;
    static JanneToolbar		editbar_;
    static JanneButton 		autoscale_;
    static JanneButton 		animate_;
    static JanneButton 		new_;
    static JanneButton 		load_;
    static JanneButton 		project_;
    static JanneButton		energygraph_button_;
    static Image 		backgrd;
    static Container		container_;
    static Choice 		choice;

    // One of six modes (Rotate, Delete, Edge, Node, Lock, Select)
    static Label		mode1_label_;
   
    // Whether or not Autoscaling is on
    static Label		mode2_label_;

    // One of six modes as above
    static int 			status_ = 0;
    static int 			NUM_BUTTONS = 6;
    
    // Modal states of program 
    static boolean 		autoscaling_ = false;
    static boolean 		animating_ = false;

    // Convergence Method
    final static int SPRING_METHOD = 0, FORCE_DIRECTED_METHOD = 1, SIMULATED_ANNEALING_METHOD = 2; 
    static int method_ = SPRING_METHOD;

    GRGraphControl(Image[] images, Container container, Applet applet)
    {
	super("Control Panel");
	container_ = container;
	positionOnScreen();
	
	GridBagLayout gridbag = new GridBagLayout();
	GridBagConstraints c = new GridBagConstraints();
	c.fill = GridBagConstraints.BOTH;
	setLayout(gridbag);
	setBackground(Color.lightGray);

	backgrd = images[0];	

	// ADD CONTROL PANEL LABEL
	//
	Label title = new Label("3D Graph Renderer Control Panel");
	title.setFont(new Font("Courier", Font.PLAIN, 18));
	title.setAlignment(Label.CENTER);
	title.setBackground(new Color(34,133,144));
	title.setForeground(new Color(255,255,255));

	// ADD CONTROL BARS
	//
	autoscale_ = new JanneButton(images[7],"autoscale",4,4,false,true);
	animate_ = new JanneButton (images[8],"animate",4,4, false, true);
	new_ = new JanneButton (images[11],"new",4,4, false, true);
	load_ = new JanneButton (images[12],"load",4,4, false, true);
	project_ = new JanneButton (images[9],"project",4,4, false, true);
	energygraph_button_ = new JanneButton (images[10],"energy graph", 4,4,false,true);

	setFont(new Font("Times", Font.PLAIN, 12));
	editbar_ = new JanneToolbar(false, 4, true);
	editbar_.addButton(images[1],"rotate");
	editbar_.addButton(images[2],"node");
	editbar_.addButton(images[3],"edge");
	editbar_.addOutsideButton(autoscale_);
	editbar_.addOutsideButton(energygraph_button_);
	editbar_.addOutsideButton(new_);

	editbar_.addButton(images[5],"select");
	editbar_.addButton(images[4],"delete");
	editbar_.addButton(images[6],"lock");
	editbar_.addOutsideButton(animate_);
	editbar_.addOutsideButton(project_);
	editbar_.addOutsideButton(load_);

	panel_ = new Panel();
	panel_.setBackground(new Color(34,133,144));
	panel_.add("Center",editbar_);

	// ADD METHOD CHOICE BOX
	//
	Panel choicepanel = new Panel();
	choicepanel.setLayout(new GridLayout(4,1));
	choicepanel.setForeground(new Color(122,36,95));
	choice = new Choice();
	choice.addItem("Spring Method");
	choice.addItem("Force-Directed Method");
	choice.addItem("Simulated Annealing Method");
	Label label = new Label("Convergence Method");
	label.setAlignment(Label.CENTER);
	label.setBackground(new Color(34,133,144));
	label.setForeground(new Color(255,255,255));
	label.setFont(new Font("Times", Font.PLAIN, 14));
	mode1_label_ = new Label("Current Mode: Rotate");
	mode1_label_.setAlignment(Label.CENTER);
	mode1_label_.setBackground(new Color(34,133,144));
	mode1_label_.setForeground(new Color(255,255,255));
	mode1_label_.setFont(new Font("Times", Font.PLAIN, 12));
	mode2_label_ = new Label("Autoscale: Off");
	mode2_label_.setAlignment(Label.CENTER);
	mode2_label_.setBackground(new Color(34,133,144));
	mode2_label_.setForeground(new Color(255,255,255));
	mode2_label_.setFont(new Font("Times", Font.PLAIN, 12));
	choicepanel.add(label);
	choicepanel.add(choice);
	choicepanel.add(mode1_label_);
	choicepanel.add(mode2_label_);

	// Lays out components with the nifty GRIDBAG layout manager
	//
	c.weightx = 1.0;
	c.gridheight = GridBagConstraints.RELATIVE;
	c.gridwidth = GridBagConstraints.REMAINDER;
	gridbag.setConstraints(title,c);
	add(title);
	c.weightx = 2.0;
	c.gridheight = GridBagConstraints.REMAINDER;
	c.gridwidth = GridBagConstraints.RELATIVE;
	gridbag.setConstraints(panel_,c);
	add(panel_);
	c.weightx = 1.0;
	c.gridheight = GridBagConstraints.REMAINDER;
	c.gridwidth = GridBagConstraints.REMAINDER;
	gridbag.setConstraints(choicepanel,c);
	add(choicepanel);
	pack();

	// Build Graph Area to display actual graphs
	//
	ga_ = new GRGraphArea(this, container, applet);

	// Build all of the dialog boxes - hide all except default (spring) method
	//
	spring_dialog_ = new GRDialog_Spring("Spring System Method",ga_);
	spring_dialog_.show();
	force_directed_dialog_ = new GRDialog_ForceDirected("Force Directed Method",ga_);
	force_directed_dialog_.hide();
	s_a_dialog_ = new GRDialog_SA("Simulated Annealing Method",ga_);
	s_a_dialog_.hide();
	new_dialog_ = new GRDialog_New("New Graph", ga_);
	new_dialog_.hide();
	load_dialog_ = new GRDialog_Load("Load Graph", ga_);
	load_dialog_.hide();
	method_dialog_ = spring_dialog_;
	
	// Build energy graph
	//
	energy_graph_ = new GREnergyGraph();
	energy_graph_.hide();
    }

    // Positions the control panel for the first time
    //
    private void positionOnScreen() {
	Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
	this.move((screen.width / 2) - (this.size().width), (screen.height / 3) - (this.size().height));
    }

    // Hides the control panel and all dialogs which have the control panel as its parent
    //  (which is all of them!) .. important for iconifying netscape or changing websites
    //
    public void hide(){
	if (method_dialog_ != null)
		method_dialog_.hide();
	new_dialog_.hide();
	load_dialog_.hide();
	energy_graph_.hide();
	super.hide();
    }

    // Shows the control panel and only the current iteration method dialog -> this is because there is 
    // too much to track to see if the New or Load dialog should be visible.  Note that in the future ,
    // it may be better to keep the Energy Graph always visible.
    //
    public void show() {
	if ((method_dialog_ != null))
		method_dialog_.show();
	super.show();
    }

    public boolean autoscale()
    {
	return autoscaling_;
    }

    public boolean animate()
    {
	return animating_;
    }	

    public int method()
    {
	return method_;
    }


   public boolean action(Event evt, Object arg)
   {
	if ("rotate".equals(arg)) {
		mode1_label_.setText("Current Mode: Rotate");
	 	status_ = 0;
		editbar_.setSelected(0,NUM_BUTTONS);	
		ga_.resize();
		ga_.repaint();
		return true;
	}	
	else if ("node".equals(arg)) {
		mode1_label_.setText("Current Mode: Add Node");
		status_ = 1;
		editbar_.setSelected(1,NUM_BUTTONS);	
		ga_.repaint();
		return true;
	}
	else if ("edge".equals(arg)) {
		mode1_label_.setText("Current Mode: Add Edge");
	 	status_ = 2;
		editbar_.setSelected(2,NUM_BUTTONS);	
		ga_.repaint();
		return true;
	}
	else if ("select".equals(arg)) {
		mode1_label_.setText("Current Mode: Select Node/Edge");
		status_ = 3;
		editbar_.setSelected(3,NUM_BUTTONS);	
		ga_.repaint();
		return true;
	}
	else if ("delete".equals(arg)) {
		mode1_label_.setText("Current Mode: Delete Node/Edge");
	 	status_ = 4;
		editbar_.setSelected(4,NUM_BUTTONS);	
		ga_.repaint();
		return true;
	}
	else if ("lock".equals(arg)) {
		mode1_label_.setText("Current Mode: Lock Node");
		status_ = 5;
		editbar_.setSelected(5,NUM_BUTTONS);
		ga_.repaint();
		return true;
	}
	else if ("autoscale".equals(arg)) {
		if  (autoscaling_ == false) {	
			mode2_label_.setText("Autoscale: On");
			autoscaling_ = true;
		}
		else {				
			mode2_label_.setText("Autoscale: Off");
			autoscaling_ = false;
		}
		ga_.recenter();
		ga_.repaint();
		return true;
	}
	else if ("animate".equals(arg)) {
		if  (animating_ == false) {
			animating_ = true;
			ga_.startAnimation();
		}
		else {
			animating_ = false;
			setUpdateMessage("animation stopped");
			ga_.stopAnimation();
		}
		ga_.resize();
		ga_.repaint();
		return true;
	}
	else if ("new".equals(arg)) {
		new_dialog_.show();
		new_.setSelected(false);
		repaint();
		return true;
	}
	else if ("load".equals(arg)) {
		load_dialog_.show();
		load_.setSelected(false);
		repaint();
		return true;
	}
	else if ("project".equals(arg)) {
		energy_graph_.hide();
		ga_.project();
		project_.setSelected(false);
		return true;
	}
	else if ("energy graph".equals(arg)) {
		energy_graph_.show();
		energygraph_button_.setSelected(false);
		return true;
	}
	else if (evt.target instanceof Choice) {
//		setLabelText(choice.getSelectedIndex(), (String) arg);
		ga_.repaint();
		repaint();
		if ("Spring Method".equals(arg))
			setMethod(SPRING_METHOD);
		else if ("Force-Directed Method".equals(arg))
			setMethod(FORCE_DIRECTED_METHOD);
		else if ("Simulated Annealing Method".equals(arg))
			setMethod(SIMULATED_ANNEALING_METHOD);
		return true;
	}
	ga_.resize();
	ga_.repaint();
	return false;
    }

   private void setMethod(int method) {
	if (method == method_) return;

	Point point = method_dialog_.location();
	method_dialog_.hide();

	if (method == SPRING_METHOD) 
		method_dialog_ = spring_dialog_;
	else if (method == FORCE_DIRECTED_METHOD) 
		method_dialog_ = force_directed_dialog_;
	else if (method == SIMULATED_ANNEALING_METHOD) 
		method_dialog_ = s_a_dialog_;
	
	
	method_ = method;

	method_dialog_.move(point.x, point.y);		
	method_dialog_.pack();
	method_dialog_.show();
   }

   public void setUpdateMessage(String string) {
	if (method_ == SPRING_METHOD) 
		spring_dialog_.setUpdateMessage(string);
	else if (method_ == FORCE_DIRECTED_METHOD) 
		force_directed_dialog_.setUpdateMessage(string);
	else if (method_ == SIMULATED_ANNEALING_METHOD) 
		s_a_dialog_.setUpdateMessage(string);
   }

    private void load(){
	FileDialog fd_ = new FileDialog(this,"Loading Graph",FileDialog.LOAD);
	fd_.setDirectory("/u/dps/thesis/development/models");
	fd_.show();
	String filename = fd_.getFile();
	if (filename == null) {
		System.out.println("No file chosen");
		return;
	}		
	String directory = fd_.getDirectory();
	fd_.hide();
	ga_.load(filename);
    }

    private void newGraph() {
	ga_.newGraph();
	ga_.repaint();
    }

    private void newRandomGraph(boolean addedges,int numnodes) {
	ga_.newRandomGraph(addedges, numnodes);
	ga_.resize();
	ga_.repaint();
    }

    public void drawEnergyGraph() {
	energy_graph_.DrawGraph();
	energy_graph_.show();
	energy_graph_.repaint();
    }

    public void updateEnergyGraph() {
	energy_graph_.DrawGraph();
	energy_graph_.repaint();
    }

    public int status() {
	return status_;
    }
}

