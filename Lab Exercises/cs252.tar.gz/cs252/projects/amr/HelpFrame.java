import java.awt.*;
import WebTree;

public class HelpFrame extends Frame {

   Label l;
   WebTree webtree_;
   TextArea textArea_;
   Button closeButton_;
   
   HelpFrame (String title, WebTree webtree)
   {
      
      super(title);
      setLayout(new FlowLayout());
      webtree_ = webtree;
      textArea_ = new TextArea(25, 70);

      String help =
         
         "WebTree is a graphing program designed with the World Wide Web in\n" +
         "mind. It is written completely in Java.\n\n" +

         "CREATING A GRAPH\n\n" +

         "A graph can be built in several ways: by browsing the WWW or by\n" +
         "independently constructing one.\n\n" +

         "Initially, clicking on the scrollable canvas creates a single,\n" +
         "numbered node.  Clicking on a node selects it.  Once a node is\n" +
         "selected, clicking on the canvas creates a child.  By employing\n" +
         "these constraints the user can only create a single acyclic\n" +
         "graph.\n\n" +

         "Alternatively, a graph can be created from the WWW. Clicking on\n" +
         "the \"Crawl\" button brings up a dialog box which asks for a\n" +
         "starting URL, a maximum numbers of pages, and a maximum depth\n" +
         "for the scan. Once these have been entered a separate thread is\n" +
         "spawned and begins to parse the HTML at the specified URL. The\n" +
         "WebCrawler continues to parse the HTML at each of the outgoing\n" +
         "links in a breadth-first search. The crawl stops once all the\n" +
         "HTML pages in the queue have been exhausted, the constraints\n" +
         "place on the crawl have been met, or the user has clicked\n" +
         "the \"Stop\" button.\n\n" +

         "Once the parser has finished with a particular page, it hands\n" +
         "the information back to the graphing component of the\n" +
         "application.  The page is represented by a node, and its links\n" +
         "are drawn as edges.  The parser keeps track of all the URLs it\n" +
         "parses and compares each outgoing link with the list of unique\n" +
         "URLs to detect any cycles in the crawl. Cyclical edges are\n" +
         "removed from the final graph in this way.\n\n" +

         "NETWORK SECURITY ISSUES\n\n" +

         "Since the WebCrawler must connect to external machines to\n" +
         "retrieve pages, Java security often restricts the scope of the\n" +
         "crawl. If the applet is run within certain browsers it may be\n" +
         "possible to temporarily turn off network security so that pages\n" +
         "on foreign machines can be scanned. Otherwise, web crawls must\n" +
         "be contained within the the applet's local machine. Netscape's\n" +
         "security cannot be turned off (as far a I know), but HotJava's\n" +
         "can, and so can the Appletviewer's.\n\n" +

         "LAYOUT AND COLORING ALGORITHMS\n\n" +

         "The user may choose from several different layout and coloring\n" +
         "algorithms to more clearly display the graph. If a layout or\n" +
         "coloring button is down when a new node is added, the algorithm\n" +
         "will automatically recompute the configuration of the resulting\n" +
         "graph.\n\n" +

         "The two simplest algorithms are the \"Random\" position and color\n" +
         "algorithms, and they are fairly self-explanatory.\n\n" +

         "The \"Depth\" color algorithm linearly interpolates the color of\n" +
         "nodes on each level of the graph. Closer to the root is shaded\n" +
         "black, while nodes which are farther away are shaded blue.\n\n" +

         "The \"Site\" color algorithm picks a random color for each\n" +
         "unique site on the graph and colors all nodes belonging to that\n" +
         "site with that color. This is useful for spotting pages which\n" +
         "are on different machines at a glance.\n\n" +

         "The \"Circle\" layout algorithm positions each level of the tree\n" +
         "on concentric circles radiating outwards from the root. The nodes\n" +
         "are evenly spaced around the circle, starting at the top. The\n" +
         "radius of each circle is adjusted so that the nodes contained on\n" +
         "it do not overlap, and that the entire graph does not exceed the\n" +
         "bounds of the canvas. This algorithm is usually more\n" +
         "comprehensible with the edges turned off (to prevent messy\n" +
         "crossings). It allows the user to see how many clicks it takes to\n" +
         "reach a certain page (from the root).\n\n" +

         "\"Centered\" is probably not the best name for the third layout\n" +
         "algorithm. It arranges the nodes on the graph into a\n" +
         "more-or-less traditional tree structure- the root at the top,\n" +
         "and the leaves at the bottom. Each level is arranged to prevent\n" +
         "crossings. To minimize the area of the graph, children are not\n" +
         "necessaryily centered beneath their parents (hence, the\n" +
         "misnomer).\n\n" +

         "The fourth layout algorithm, \"Compressed\", recursively\n" +
         "traverses\n" +
         "the graph and computes bounding boxes for each node (based upon\n" +
         "the bounding boxes of their children). It positions the children\n" +
         "centered directly beneath their parents. This strategy results in\n" +
         "wider levels, but displays symmetry nicely.\n\n" +

         "EDITING COMMANDS\n\n" +

         "Their are two basic editing commands at the user's disposal:\n" +
         "\"Delete\" and \"Make root\". These both perform operations on\n" +
         "the selected node.\n\n" +

         "\"Delete\" removes the selected node from the graph and then\n" +
         "recursively removes all its children. This is useful for\n" +
         "clearing up unwanted links, and generally reducing screen\n" +
         "clutter. It keeps the graph at a managable size (which is\n" +
         "difficult to do when crawling through the WWW).\n\n" +

         "\"Make root\" deletes everything above the selected node,\n" +
         "effectively making the selected node the root of the remaing\n" +
         "graph. Again, this is useful for pruning the tree.\n\n" +

         "A third command, \"Clear\", wipes the canvas clean by deleting\n" +
         "all nodes in the current graph- effectively starting anew.\n\n" +

         "ADDITIVE WEBCRAWLS\n\n" +

         "Webcrawls can be cummulative, which allows them to be more\n" +
         "focused. The user can start a cummulative crawl simply by\n" +
         "selecting a node and clicking on \"Crawl\". The node's URL will\n" +
         "be automatically put in the dialogue box as the root URL. The\n" +
         "resulting pages will be added into the current graph. For the\n" +
         "best results, a cumulative crawl should start from a leaf.\n\n" +

         "One of the most interesting abilities of WebTree is its capacity\n" +
         "to perform multiple crawls to build a single graph. Unwanted\n" +
         "pathways can be deleted, and the user can direct the WebCrawler\n" +
         "to wherever they're interested (one level at a time). WebTree\n" +
         "becomes a navigation tool, storing the history of a survey of\n" +
         "the WWW.\n\n" +

         "VIEWING URLS\n\n" +

         "The contents of a particular node can also be viewed. By holding\n" +
         "down Control and clicking on a node, the user can retrieve the\n" +
         "source code at that node's URL. The HTML is displayed in a\n" +
         "pop-up text box. Also, if the applet is running within a browser\n" +
         "(such as Netscape or HotJava), the user can Shift-click on a node\n" +
         "to actually redirect the browser to view that page.\n\n" +

         "MISCELLANEOUS COMMANDS\n\n" +

         "The \"Refresh\" button redraws the canvas. If the canvas looks\n" +
         "odd, then it probably hasn't refreshed yet. This button gives\n" +
         "the user manual control over the redrawing routine.\n\n" +

         "The \"Help\" button will evently bring up a useful help message.\n" +
         "This has not been implemented yet.\n\n" +

         "There are two radio button groups which control the visibility\n" +
         "of edges and algorithm animation respectively. The latter is\n" +
         "for possible future versions of the applet, and is not currently\n" + 
         "implemented.\n\n";


      textArea_.setFont(new Font("TimesRoman", Font.PLAIN, 14));  
      textArea_.appendText(help);

      add(textArea_);

      closeButton_ = (new Button("Close"));
      add(closeButton_);
      
   }
   
public boolean action(Event evt, Object arg)
   {

      if (evt.target instanceof Button) {

         String label = (String) arg;

         if (label.equals("Close")) this.hide();

         return true;
         
      }

      else return false;
      
   } 
}




