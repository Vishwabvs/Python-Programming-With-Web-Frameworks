/** Brian Rogers
    cs252
    spring 1996
    Final PRoject */

import java.awt.*;



/** This is the closest pair algorithm.  It is responsible for controlling 
    what goes on in one step of the process of finding the closest pair. */

public class ThreeDClosestPairAlgorithm extends ThreeDSweepAlgorithm {

     public static final int CANVAS_DIMENSION = ThreeDCanvas.CANVAS_DIMENSION;
     public static final Color COLOR = Color.magenta;

     /** The coordinates of the current vertex */
     int curr_x;
     int curr_y;
     int curr_z;

     /** The coordinates that define the bounding box that we need to look
         inside to find closer vertices */
     int left_x;
     int right_x;
     int top_y;
     int bottom_y;
     int close_z;
     int far_z;

     /** The closest vertices we have found so far */
     ThreeDVertex closest_1;
     ThreeDVertex closest_2;

     /** The distance between them */
     double _dist;

     /** an edge between them. */
     ThreeDEdge closest_edge;


     public ThreeDClosestPairAlgorithm (ThreeDSpace space, ThreeDCanvas canvas,
                                     ThreeD applet,
				     ThreeDVertex verts[], int numverts) {
          super(space, canvas, applet, COLOR, verts, numverts);
     }



     public void step () {
          try {
               current_vert.setColor(COLOR);

               /* If we are at the first vertex in the array */
               if (vert_index == 0) {
	            closest_1 = _verts[vert_index];    // make it one of the pair.
	            closest_1.setColor(Color.cyan);
	       } 

	       /* If we are at the second vertex in the array */
	       else if (vert_index == 1) {
	            /* Make it part of the initial closest pair with the first .*/
	            closest_2 = _verts[vert_index];
	            closest_2.setColor(Color.cyan);

	            /* calculate distance between them, and connect with an edge. */
	            _dist = calcDistance(closest_1, closest_2);
	            closest_edge = new ThreeDEdge(closest_1, closest_2, Color.cyan);
		    closest_edge.draw(_canvas.getGraphics());
		    closest_1.addEdge(closest_edge);
		    sleep(calc_step);
	       }

               else {
	            /* get the coordinates of this vertex */
		    curr_x = current_vert.xCoord();
		    curr_y = current_vert.yCoord();
		    curr_z = current_vert.zCoord();

                    /* The the fancy bounding box tht we need to look inside to 
		    find closer vertices */
		    drawBoundingBox();
		    sleep(calc_step);

                    /* look for closer vertices */
		    checkBoundingBox(vert_index);
	       }
	  }
	  
	  catch (InterruptedException e) System.out.println(e);
     }



     /** This looks to the left (backward in the array) for vertices that 
         are within the bounding box.  If it finds a vertex in the box,
	 it calculates the distance to it.  If it is less than the distance
	 between the current closest pair, these become the new closest pair,
	 and the whole thing recurses. */
     private void checkBoundingBox (int index) {
          try {
               /* if there are any vertices to the right */
               if (index > 0) {

	            /* Get the next vertex and it's coordinates */
		    ThreeDVertex checkvert = _verts[index-1];
		    int checkx = checkvert.xCoord();
		    int checky = checkvert.yCoord();
		    int checkz = checkvert.zCoord();

                    /* if this vertex is inside the bounding box */
                    if (checkx >= left_x) {
	                 if ((checky >= bottom_y) && (checky <= top_y) && 
		             (checkz >= far_z) && (checkz <= close_z)) {

                              /* draw an edge so we can see we've checked it */
			      ThreeDEdge temp = new ThreeDEdge(checkvert, 
			                          current_vert, Color.green);
						  temp.draw(_canvas.getGraphics());

                              /* calculate the distance between them */ 
			      double dist = calcDistance(checkvert, current_vert);
			 
			      sleep(calc_step);

		              /* If this one is closer, save it as such */
			      if (dist < _dist) {
		                   _dist = dist;
				   closest_1.setColor(COLOR);
				   closest_2.setColor(COLOR);
				   closest_1.removeEdge();
			 
			           closest_1 = checkvert;
				   closest_2 = current_vert;

                                   closest_1.setColor(Color.cyan);
				   closest_2.setColor(Color.cyan);

			           closest_edge = temp;
				   closest_edge.setColor(Color.cyan);
				   closest_edge.draw(_canvas.getGraphics());
				   sleep(calc_step);
				   closest_1.addEdge(closest_edge);
		              }
                         }
		    
		         /* check the next vertex backwards */
			 checkBoundingBox(index-1);
	            }
	      }
	 }
	 
	 catch (InterruptedException e) System.out.println(e);
     }


     /** This draws a pretty bounding box _dist wide, and twice _dist high
         and deep with the current_vertex centered on it's right face.  
	 It's pretty much all ugly math */
     private void drawBoundingBox () {

          right_x = curr_x;
	  left_x = curr_x - (int)(_dist+1);

	  top_y = curr_y + (int)(_dist+1);
	  bottom_y = curr_y - (int)(_dist+1);

	  close_z = curr_z + (int)(_dist+1);
	  far_z = curr_z - (int)(_dist+1);

	  float closemod = _space.calcModifier(CANVAS_DIMENSION/2 - close_z);
	  float farmod = _space.calcModifier(CANVAS_DIMENSION/2 - far_z);

	  int ctrx = CANVAS_DIMENSION/2 + (int)(closemod*right_x);
	  int ctry = CANVAS_DIMENSION/2 - (int)(closemod*top_y); 

	  int ctlx = CANVAS_DIMENSION/2 + (int)(closemod*left_x);
	  int ctly = CANVAS_DIMENSION/2 - (int)(closemod*top_y);

	  int cbrx = CANVAS_DIMENSION/2 + (int)(closemod*right_x); 
	  int cbry = CANVAS_DIMENSION/2 - (int)(closemod*bottom_y);

	  int cblx = CANVAS_DIMENSION/2 + (int)(closemod*left_x);
	  int cbly = CANVAS_DIMENSION/2 - (int)(closemod*bottom_y);

	  int ftrx = CANVAS_DIMENSION/2 + (int)(farmod*right_x);
	  int ftry = CANVAS_DIMENSION/2 - (int)(farmod*top_y);

	  int ftlx = CANVAS_DIMENSION/2 + (int)(farmod*left_x);
	  int ftly = CANVAS_DIMENSION/2 - (int)(farmod*top_y);

	  int fbrx = CANVAS_DIMENSION/2 + (int)(farmod*right_x);
	  int fbry = CANVAS_DIMENSION/2 - (int)(farmod*bottom_y);

	  int fblx = CANVAS_DIMENSION/2 + (int)(farmod*left_x);
	  int fbly = CANVAS_DIMENSION/2 - (int)(farmod*bottom_y);

	  Graphics grafix = _canvas.getGraphics();
	  grafix.setColor(Color.orange);

	  grafix.drawLine(ftrx, ftry, fbrx, fbry);
	  grafix.drawLine(ftlx, ftly, fblx, fbly);
	  grafix.drawLine(fblx, fbly, fbrx, fbry);
          grafix.drawLine(ftrx, ftry, ftlx, ftly);

	  grafix.drawLine(ftrx, ftry, ctrx, ctry);
	  grafix.drawLine(ftlx, ftly, ctlx, ctly);
	  grafix.drawLine(fbrx, fbry, cbrx, cbry);
	  grafix.drawLine(fblx, fbly, cblx, cbly);

	  grafix.drawLine(ctrx, ctry, ctlx, ctly);
	  grafix.drawLine(ctrx, ctry, cbrx, cbry);
	  grafix.drawLine(ctlx, ctly, cblx, cbly);
	  grafix.drawLine(cblx, cbly, cbrx, cbry);
     }



     /** This calculates the distance between the two vertices by getting
         their coordinates, and returning the square root of the sum of the
	 squares of the differences between them. */
     private double calcDistance(ThreeDVertex vert1, ThreeDVertex vert2) {
          int x1 = vert1.xCoord();
	  int y1 = vert1.yCoord();
	  int z1 = vert1.zCoord();

	  int x2 = vert2.xCoord();
	  int y2 = vert2.yCoord();
	  int z2 = vert2.zCoord();

	  int deltax = x1 - x2;
	  int deltay = y1 - y2;
	  int deltaz = z1 - z2;

	  return Math.sqrt(deltax*deltax + deltay*deltay + deltaz*deltaz);
     }
}
