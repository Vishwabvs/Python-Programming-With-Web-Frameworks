import java.applet.*;


public class ReversibleCommand {
protected boolean reversible_ = false;


	public ReversibleCommand()
	{
	}

	public void execute()
	{
	}

	public void undo()
	{
	}

	public boolean isReversible()
	{
		return reversible_;
	}

	// this is ugly, but is needed by the clone
	// operation
	public void setReversible(boolean b)
	{
		reversible_ = b;
	}
};



