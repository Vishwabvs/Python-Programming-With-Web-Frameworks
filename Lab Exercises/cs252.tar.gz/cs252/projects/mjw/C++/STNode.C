/****************************************************************/
/*    NAME:                                                     */
/*    ACCT: mjw                                                 */
/*    FILE: STNode.C                                            */
/*    ASGN:                                                     */
/*    DATE: Wed Apr 10 17:50:10 1996                            */
/****************************************************************/

#include "STNode.H"
#include <assert.h>




/****************************************************************/
/*                                                              */
/* Function Name: STNode                                        */
/* Parameters:    void                                          */
/* Returns:       nothing                                       */
/* Effects:							*/
/*                                                              */
/****************************************************************/

STNode::STNode(): GNode(), STSegmentComposite()
{
}



/****************************************************************/
/*                                                              */
/* Function Name: ~STNode                                       */
/* Parameters:     none                                         */
/* Returns:        nothing                                      */
/* Effects:							*/
/*                                                              */
/****************************************************************/

STNode::~STNode()
{
}


/****************************************************************/
/*                                                              */
/* Function Name: setChild                                      */
/* Parameters:    CHILD which -- which child to set             */
/*                STNode node -- new node                       */
/* Returns:       void                                          */
/* Effects:       Sete the specified child node to the given    */
/*                node                                          */
/*                                                              */
/****************************************************************/

void
STNode::setChild(CHILD which, STNode *node)
{
    //assert(node != NULL);
    switch (which) {
    case LEFT_CHILD:  left_child_ = node; break;
    case RIGHT_CHILD: right_child_ = node; break;
    default: assert(false);
    };
}


/****************************************************************/
/*                                                              */
/* Function Name: getChild                                      */
/* Parameters:    CHILD -- specifying which child to retrieve   */
/* Returns:       STNode*                                       */
/* Effects:       If the specified child exists than a pointer  */
/*                to it is returned.  Otherwise, NULL is        */
/*                returned.                                     */
/*                                                              */
/****************************************************************/

STNode*
STNode::getChild(CHILD which) const
{
    switch (which) {
    case LEFT_CHILD: 	return (STNode*)left_child_; 
    case RIGHT_CHILD:   return (STNode*)right_child_;
    default: assert(false);
    };
    return NULL;
}



/****************************************************************/
/*                                                              */
/* Function Name: getParent                                     */
/* Parameters:    none                                          */
/* Returns:       STNode* -- pointer to the parent              */
/* Effects:       If the parent exists, a pointer to it is      */
/*                returned.  Otherwise, NULL is returned.       */
/*                                                              */
/****************************************************************/


STNode* STNode::getParent() const
{
    return (STNode*)parent_;
}


