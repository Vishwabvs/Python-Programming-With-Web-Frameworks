/****************************************************************/
/*    NAME: Mike Walczak                                        */
/*    ACCT: mjw                                                 */
/*    FILE: RTEvent.C                                           */
/*    ASGN:                                                     */
/*    DATE: Sun Apr 21 22:20:35 1996                            */
/****************************************************************/

#include "RTEvent.H"
//#include "RTNode.H"
#include "RTPoint.H"
#include <assert.h>
#include <LEDA/point.h>
#include "GNode.H"


RTEvent::RTEvent(RT_EVENT_TYPE etype, GNode* node)
{
    assert(node);
    init(etype, node, NULL);
}


RTEvent::RTEvent(RT_EVENT_TYPE etype, GNode* node, RTPoint* pt)
{
    assert(node);
    assert(pt);
    init(etype, node, pt);
}

RTEvent::~RTEvent()
{
    if (segment_pt1_)
	delete segment_pt1_;
    if (segment_pt2_)
	delete segment_pt2_;
}

const char* RTEvent::getEventTypeStr()  const
{
    switch (type_) {
    case RT_EVENT_VISIT_PT:	return "RTEVENTVISITPT";
    case RT_EVENT_VISIT_SEGMENT:return "RTEVENTVISITSEGMENT";
    case RT_EVENT_CHECK_OVERLAP:return "RTEVENTCHECKOVERLAP";
    case RT_EVENT_NO_CHILDREN:  return "RTEVENTNOCHILDREN";
    case RT_EVENT_GO_LEFT:	return "RTEVENTGOLEFT";
    case RT_EVENT_GO_RIGHT:	return "RTEVENTGORIGHT";
    case RT_EVENT_OVERLAP:	return "RTEVENTOVERLAP";
    default: return NULL;
    };
}



void
RTEvent::init(RT_EVENT_TYPE etype, GNode* node, RTPoint* pt)
{
    type_ = etype;
    node_ = node;
    point_ = pt;
    segment_pt1_ = NULL;
    segment_pt2_ = NULL;
}



ostream& operator<<(ostream& out, const RTEvent& evt)
{
    out << evt.getEventTypeStr()<<" ";
    // write out the node, as well as its range (begin, median, end)
    if (evt.node_)
	out << *(evt.node_)<<" "<<evt.node_->getBegin()<<" "<<evt.node_->getMedian()<<" "<<evt.node_->getEnd()<<" ";
    if (evt.point_) out << evt.point_->getX()<< " "<<evt.point_->getY();
    else
	{
	    if (evt.segment_pt1_)
		out << " "<< evt.segment_pt1_->xcoord() << " "<<evt.segment_pt1_->ycoord();
	    if (evt.segment_pt2_)
		out << " "<< evt.segment_pt2_->xcoord() << " "<<evt.segment_pt2_->ycoord()<<" ";
	}
    return out;
}
