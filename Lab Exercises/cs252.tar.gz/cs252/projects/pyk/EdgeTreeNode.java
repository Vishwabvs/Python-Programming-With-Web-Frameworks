/*
 * EdgeTreeNode.java
 *
 * Description:
 *    This class is the EdgeTreeNode class and has all methods and variables
 *    for constructing an edge tree node.
 */
class EdgeTreeNode extends RBTreeNode
{
    int objectType;                // type of object whose edge this is
    int value;                     // edge value
    int enter;                     // state variable which indicates the
                                   // type of edge
    int Id;                        // unique edge id
    final int EMPTYSPACE = 0;      // edge is for empty space
    final int PIXEL = 1;           // edge is for a point
    final int BOUNDINGBOX = 2;     // edge is for a bounding box
    final int VIEWPORT = 3;        // edge is for the viewport

    final int NOTAPPLICABLE = -1;  // edge type is not applicable
    final int ENTER = 0;           // an enter edge
    final int EXIT = 1;            // an exit edge
    final int ENTERANDEXIT = 2;    // exit and enter edge (used for points)

    // constructor for empty space edge node
    EdgeTreeNode(Integer location)
    {
       super(location, location);
       objectType = EMPTYSPACE;
       value = location.intValue();
       Id = -1;
       enter = ENTER;
    }

    // constructor for pixel edge node
    EdgeTreeNode(int objectType, Integer location)
    {
       super(location, location);
       objectType = PIXEL;
       value = location.intValue();
       Id = -1;
       enter = ENTERANDEXIT;
    }

    // constructor for viewport edge node
    EdgeTreeNode(int objectType, Integer location, boolean enterViewPort)
    {
       super(location, location);
       objectType = VIEWPORT;
       value = location.intValue();
       Id = -1;
       if (enterViewPort)
       {
          enter = ENTER;
       }
       else
       {
          enter = EXIT;
       }
    }

    // constructor for Bounding box edge node
    EdgeTreeNode(int objectType, Integer location, boolean enterBox, int identification)
    {
       super(location, location);
       objectType = BOUNDINGBOX;
       value = location.intValue();
       Id = identification;
       if (enterBox)
       {
          enter = ENTER;
       }
       else
       {
          enter = EXIT;
       }
    }

    // return the edge from the edge node
    public int getEdge()
    {
       return value;
    }

    // was the edge node an enter type node
    public boolean getEntered()
    {
       if (enter == ENTER)
       {
          return true;
       }
       else
       {
          return false;
       }
    }

    // get the id of the node
    public int getId()
    {
       return Id;
    }
};
