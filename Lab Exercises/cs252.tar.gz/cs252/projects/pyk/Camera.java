/*
 * Camera.java
 *
 * Description:
 *    This class is the Camera class and has all methods for creating,
 *    moving, and placing the camera, as well as the Camera variables
 */
import java.awt.Graphics;
import java.awt.Color;

class Camera
{
   int xPosition = 0;         // x coordinate of the camera
   int yPosition = 0;         // y coordinate of the camera
   int zPosition = 25;        // z coordinate of the camera, initially
                              // set to 25 (above the plane where
                              // objects are initially placed)
   int viewPortWidth = 100;   // width of the viewport
   int viewPortHeight = 80;   // height of the viewport
   RangeApp appParent = null; // the parent (which is the application)
   boolean firstTime;         // is this the first time the camera
                              // has been placed (it can only occur
                              // one time)
   boolean ready = false;     // the camera is ready to take a picture
                              // after it has been placed
   boolean minSeen = false;   // the camera can only be moved to within
                              // 10 units of the cube initial placement
                              // plane, use this flag to determine
                              // if the minimum has been encountered

   // constructor for the camera
   Camera(RangeApp parent)
   {
      appParent = parent;
      firstTime = true;
   }

   // initial placement routine for the camera
   public void place(int x, int y, Graphics g)
   {
      if (firstTime == true)
      {
         firstTime = false;
         ready = true;
         minSeen = false;
      }
      xPosition = x;
      yPosition = y;
      draw(g);
   }

   // routine to reposition the camera
   public void move(int x, int y, int z, Graphics g)
   {
      if ((z >= 0) || (zPosition > 10))
      {
         if (minSeen == true)
         {
           appParent.statusLine.setText(
               "Depress arrowheads in 3D Positioning tool to position camera and viewport");
         }
         clear(g);
         xPosition = xPosition + (x * 4);
         yPosition = yPosition - (y * 4);
         viewPortWidth = viewPortWidth + (z * 4);
         viewPortHeight = viewPortHeight + (z * 4);
         zPosition = zPosition + z;
         draw(g);
      }
      else
      {
         minSeen = true;
         appParent.statusLine.setText("Camera can not be moved closer to the scene");
      }
   }

   // draw the camera at the specified location, grey rectangle with
   // blue outline
   public void draw(Graphics g)
   {
      Color oldColor = g.getColor();
      g.setColor(Color.blue);
      g.draw3DRect(xPosition - viewPortWidth / 2,
                   yPosition - viewPortHeight / 2,
                   viewPortWidth, viewPortHeight, true);
      if (appParent.debugMode == true)
      {
         g.drawString("Camera",
                   xPosition - appParent.drawingCanvas.fm.stringWidth("Camera") / 2,
                   yPosition + (appParent.drawingCanvas.fm.getAscent() / 2));
      }
      g.setColor(oldColor);
   }

   // clear the viewport's rectangle
   public void clear(Graphics g)
   {
      if (viewPortWidth > appParent.drawingCanvas.fm.stringWidth("Camera"))
      {
         g.clearRect(xPosition - viewPortWidth / 2, yPosition - viewPortHeight / 2,
                     viewPortWidth + 2, viewPortHeight + 2);
      }
      else
      {
         g.clearRect(xPosition - appParent.drawingCanvas.fm.stringWidth("Camera") / 2,
                     yPosition - viewPortHeight / 2,
                     appParent.drawingCanvas.fm.stringWidth("Camera") + 2,
                     viewPortHeight + 2);
      }
   }

   // reset routine to be used when the camera is to be removed
   public void reset(Graphics g)
   {
      clear(g);
      ready = false;
      firstTime = true;
      minSeen = false;
   }
}