/*
 * @(#)Heapable.java	1.0 2/23/96 Michael J. Radwin
 */

package mjr.heap;

/**
 * An interface for keys in the heap.  Allows the heap to make
 * comparisons to upheap or downheap.
 *
 * @see Heap
 * @version 1.0 2/23/96
 * @author <A HREF="http://www.cs.brown.edu/people/mjr/">Michael J. Radwin</A>
 */
public
interface Heapable {
    /**
     * Determines if this key is greater than the other key.
     * For example, to compare keys that are subclasses of
     * Integer:
     * <pre>
     *     return (intValue() > ((Integer)other).intValue());
     * </pre>
     *
     * @return true if this key is greater than the other key
     * @param other the key to compare this key to.
     */
    public boolean greaterThan(Object other);

    /**
     * Determines if this key is less than the other key.
     * For example, to compare keys that are subclasses of
     * Integer:
     * <pre>
     *     return (intValue() < ((Integer)other).intValue());
     * </pre>
     *
     * @return true if this key is less than the other key
     * @param other the key to compare this key to.
     */
    public boolean lessThan(Object other);

    /**
     * Determines if this key is equal to the other key.
     * For example, to compare keys that are subclasses of
     * Integer:
     * <pre>
     *     return (intValue() == ((Integer)other).intValue());
     * </pre>
     *
     * @return true if this key is equal to the other key
     * @param other the key to compare this key to.
     */
    public boolean equalTo(Object other);    
}
