/*
 *  GRDialog_Load - controls the loading of graphs from a graph library 
 *  4/14/96 
 *  by Daniel Spirn 
 *
 */
package graphrender;

import java.awt.*;
import java.applet.*;

public class GRDialog_Load extends Frame {
 
    // Handle to graph area to load graphs
    GRGraphArea 	ga_;

    // Build choice box of different figures
    Choice 		choice;

    // Figure library choices
    final static int	CUBE = 0, 
			TRUNCATED_CUBE = 1, 
			PYRAMID = 2,
			TETRAHEDRON = 3, 
			DODECAHEDRON = 4, 
			ICOSAHEDRON = 5, 
			BUCKMINSTERFULLERENE = 6;

    // Current object types -> default Cube
    int 		object_type_ = 0;
	
    public GRDialog_Load(String title, GRGraphArea ga) {
	super(title);
	this.setResizable(false);
	ga_ = ga;
    }

    public void addNotify() {
	super.addNotify();

	GridBagLayout gridbag = new GridBagLayout();
	GridBagConstraints c = new GridBagConstraints();
	c.fill = GridBagConstraints.BOTH;
	setLayout(gridbag);
	
	// ADD LIBRARY CHOICE BOX
	//
	choice = new Choice();
	choice.setFont(new Font("Times", Font.PLAIN, 14));
	choice.addItem("Cube");
	choice.addItem("Truncated Cube");
	choice.addItem("Pyramid");
	choice.addItem("Tetrahedron");
	choice.addItem("Dodecahedron");
	choice.addItem("Icosahedron");
	choice.addItem("Buckminsterfullerene");
	
	Label label = new Label("Figure Library");
	label.setAlignment(Label.CENTER);
	label.setBackground(new Color(34,133,144));
	label.setForeground(new Color(255,255,255));
	label.setFont(new Font("Times", Font.PLAIN, 14));

	Button cancelbutton = new Button("cancel");
	Button loadbutton = new Button("load");
	cancelbutton.setFont(new Font("Times", Font.PLAIN, 14));
	loadbutton.setFont(new Font("Times", Font.PLAIN, 14));

	c.weightx = 1.0;
	c.weighty = 1.0;
	c.gridwidth = GridBagConstraints.REMAINDER;
	gridbag.setConstraints(label,c);
	add(label);
	c.weightx = 1.0;
	c.weighty = 1.0;
	c.gridwidth = GridBagConstraints.REMAINDER;
	gridbag.setConstraints(choice,c);
	add(choice);
	c.weightx = 1.0;
	c.weighty = 1.0;
	c.gridwidth = GridBagConstraints.RELATIVE;
	gridbag.setConstraints(cancelbutton,c);
	add(cancelbutton);
	c.weightx = 1.0;
	c.weighty = 1.0;
	c.gridwidth = GridBagConstraints.REMAINDER;
	gridbag.setConstraints(loadbutton,c);
	add(loadbutton);

    	pack();
	positionOnScreen();
	show();
    }

    private void positionOnScreen() {
	Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
	this.move(((screen.width / 2))-(this.size().height), (screen.height / 3) - (this.size().height));
    }

    public boolean handleEvent(Event e) {
	boolean handled = false;

	if (e.id == Event.ACTION_EVENT) {
		if (e.arg.equals("cancel"))
			this.hide();
		else if (e.arg.equals("load")) {
			String completefilename = new String("graphrender/models/");
			switch(object_type_) {
				case CUBE:
					completefilename = completefilename.concat("cube.obj");
					break;
				case TRUNCATED_CUBE:
					completefilename = completefilename.concat("truncated_cube.obj");
					break;
				case PYRAMID:
					completefilename = completefilename.concat("pyramid.obj");
					break;
				case TETRAHEDRON:
					completefilename = completefilename.concat("tetrahedron.obj");
					break;
				case DODECAHEDRON:
					completefilename = completefilename.concat("dodecahedron.obj");
					break;
				case ICOSAHEDRON:
					completefilename = completefilename.concat("icosahedron.obj");
					break;
				case BUCKMINSTERFULLERENE:
					completefilename = completefilename.concat("buckminsterfullerene.obj");
					break;
				default:
					completefilename = completefilename.concat("cube.obj");
					break;
			}
			ga_.load(completefilename);	
			ga_.repaint();		
			this.hide();
		}
		else if (e.arg.equals("Cube"))
			object_type_ = CUBE;
		else if (e.arg.equals("Truncated Cube"))
			object_type_ = TRUNCATED_CUBE;
		else if (e.arg.equals("Pyramid")) 
			object_type_ = PYRAMID;
		else if (e.arg.equals("Tetrahedron"))
			object_type_ = TETRAHEDRON;
		else if (e.arg.equals("Dodecahedron")) 
			object_type_ = DODECAHEDRON;
		else if (e.arg.equals("Icosahedron")) 
			object_type_ = ICOSAHEDRON;
		else if (e.arg.equals("Buckminsterfullerene")) 
			object_type_ = BUCKMINSTERFULLERENE;

	} else if (e.id == Event.WINDOW_DESTROY) {
		this.hide();
		this.dispose();
	}
	return(handled);
    }
}




