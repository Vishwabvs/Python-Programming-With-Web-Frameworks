import java.awt.Graphics;
import java.applet.AudioClip;

public class AudioLoop extends java.applet.Applet
  implements Runnable{
  
  AudioClip bgsound;
  AudioClip beep;
      Thread runner;

      public void start(){
	if(runner ==null){
	  runner = new Thread(this);
	  runner.start();
        }
      }

      public void stop(){
	  if(runner!=null){
	    if(bgsound!=null) bgsound.stop();
	    runner.stop();
	    runner=null;
          }
      }

      public void init(){
	  bgsound = getAudioClip(getCodeBase(),"audio/loop.au");
	  beep=getAudioClip(getCodeBase(),"audio/beep.au");
          bong=getAudioClip(getCodeBase(),"audio/beep.au");
          bubble1=getAudioClip(getCodeBase(),"audio/beep.au");
          chirp1=getAudioClip(getCodeBase(),"audio/beep.au");
          computer=getAudioClip(getCodeBase(),"audio/beep.au");
          dah=getAudioClip(getCodeBase(),"audio/beep.au");
          ooh=getAudioClip(getCodeBase(),"audio/beep.au");
          rreturn=getAudioClip(getCodeBase(),"audio/beep.au");


      }
     
     public void run(){
       if(bgsound!=null)bgsound.loop();
       while(runner!=null){
	 try{Thread.sleep(500);}
	 catch(InterruptedException e){}
	 if (bgsound!=null) {
            System.out.print("playing");
            beep.play();
         }
         else System.out.print("empty");
       }
     }

     public void paint(Graphics g){
       g.drawString("Playing Sounds...",10,10);
     }
}
