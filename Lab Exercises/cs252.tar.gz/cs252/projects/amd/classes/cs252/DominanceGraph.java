package cs252;

import java.awt.*;
import sprite.*;
import graph.*;
import java.applet.Applet;
import java.util.Vector;

public class DominanceGraph extends GraphArea implements ButtonOwner,
                                                         Runnable
{
    Thread kicker_;
    ButtonSprite solve_, clear_, undo_;
    CheckboxSprite compact_;

    Enforcer enforcers_[];
    OrderNode lowest_;
    boolean undoing_;
    Point move_[], old_[];

    LoadPanel panel_;
    SpanGraph left_, right_;

    public DominanceGraph(Applet applet) {
	super(true, WIDTH, HEIGHT, true);

	SetNewEdgeColor(Color.white);
        SetUpdateMode(NO_UPDATING);
	
        solve_ = new ButtonSprite(this, this, START_X, START_Y, BUTTON_WIDTH,
                                  BUTTON_HEIGHT, "Solve");
        clear_ = new ButtonSprite(this, this, CLEAR_X, CLEAR_Y, BUTTON_WIDTH,
                                  BUTTON_HEIGHT, "Clear");
//        undo_ = new ButtonSprite(this, this, UNDO_X, UNDO_Y, BUTTON_WIDTH,
//				 BUTTON_HEIGHT, "Undo");
//	undo_.Disable();
	compact_ = new CheckboxSprite(this, COMPACT_X, COMPACT_Y, "Compact");
	compact_.SetFore(Color.white);

	enforcers_ = new Enforcer[4];
	Enforcer.SetEnforcers(enforcers_);
	
	enforcers_[0] = new UpwardEnforcer(this, 0);	
	enforcers_[1] = new PlanarityEnforcer(this, 2);
	enforcers_[2] = new SourceSink(this, 1);	
	enforcers_[3] = new TransitiveEnforcer(this, 3);
	
	SetUpdateMode(DELAYED_UPDATING);

	applet.setLayout(new BorderLayout());
	
	Panel top = new Panel();
	Panel bottom = new Panel();
	applet.add("North", top);
	applet.add("South", bottom);
	
	top.add(this);
        applet.resize(applet.preferredSize());
        applet.show();
        WaitForGraphics();
        
	Graphics back = GetBackgroundGraphics();
	undoing_ = false;

        String base = applet.getCodeBase().toString();
	Tile(applet, back, WIDTH, HEIGHT, base + "252.gif");
//	back.setColor(Color.black);
//	back.fillRect(0, 0, WIDTH, HEIGHT);
        BackgroundDirty();

	panel_ = new LoadPanel (applet, top, this);
	left_ = new SpanGraph(bottom, true);
	right_ = new SpanGraph(bottom, false);
        applet.resize(applet.preferredSize());	
	FixButtons();
    }

    public void LoadGraph(String s) {
	super.LoadGraph(s);
	FixButtons();
    }
    
    public Node GetNewNode(int x, int y) {
	return new OrderNode(this, x, y, false);
    }

    public void ChangePositions(boolean mirrors) {
	OrderNode nodes[] = GetOrderArray();
	
	for (int loop = 0; loop < nodes.length; ++loop) {
	    if (mirrors)
		nodes[loop].JumpMirrors(move_[loop].x, move_[loop].y);	    
	    nodes[loop].SlideTo(move_[loop].x, move_[loop].y,
				20, 50, false, true);
	}
    }

    public void SavePositions() {
	Node nodes[] = GetGraphArray();	

	old_ = new Point[nodes.length];
	for (int loop = 0; loop < nodes.length; ++loop)
	    old_[loop] = new Point(nodes[loop].x_, nodes[loop].y_);
    }
    
    public void ComputeDominance() {
	ClearVisited();

	Edge edges[] = GetEdgeArray();
	if (edges.length == 0) {
	    left_.CopySingleNode(lowest_);
	    right_.CopySingleNode(lowest_);
	}
	else {
	    left_.CopyGraph(edges);
	    right_.CopyGraph(edges);
	}
	
	lowest_.Prepare();
	lowest_.LeftOrder(1, null, compact_.GetState(), left_);
	lowest_.RightOrder(1, null, compact_.GetState(), right_);
    }
    
    public void ShowDominance() {
	OrderNode nodes[] = GetOrderArray();
	move_ = new Point[nodes.length];
	
	for (int loop = 0; loop < nodes.length; ++loop) {
	    nodes[loop].SetShowPos(false);
	    int left = nodes[loop].GetLeft();
	    int right = nodes[loop].GetRight();
	    if (!(left == 0 && right == 0)) {
		int x = LEFT + left * BETWEEN;
		int y = BOTTOM - right * BETWEEN;
		move_[loop] = new Point(x, y);
	    }
	    else
		move_[loop] = new Point(nodes[loop].x_, nodes[loop].y_);
	}
	ChangePositions(true);
    }

    public void Upward() {
    }

    public void ClearVisited() {
	OrderNode nodes[] = GetOrderArray();
	for (int loop = 0; loop < nodes.length; ++loop)
	    nodes[loop].ClearVisited();
    }
    
    public void ClearMirrors() {
	OrderNode nodes[] = GetOrderArray();
	for (int loop = 0; loop < nodes.length; ++loop)
	    nodes[loop].ClearMirrors();
    }

    public void Start() {
	if (graph_.size() > 0) {
	    kicker_ = new Thread(this);
	    kicker_.start();
	}
    }
    
    public void FixButtons() {
        if (kicker_ != null) {
            solve_.Disable();
            clear_.Disable();
	    compact_.Disable();
	    panel_.Disable();
            return;
        }
	else {
	    compact_.Enable();
	    panel_.Enable();	    
	}
        
        if (graph_.size() == 0) {
	    solve_.Disable();
	    clear_.Disable();
	}
	else {
	    solve_.Enable();
	    clear_.Enable();
	}
    }

    public void ButtonClicked(ButtonSprite button) {
        if (button == solve_) {
	    SavePositions();
	    Start();
	}
	else if (button == clear_) {
	    ClearGraph();
	    left_.ClearGraph();
	    right_.ClearGraph();	    
//	    undo_.Disable();
	    AllowEditing();
	}
// 	else if (button == undo_) {
// 	    undo_.Disable();
// 	    move_ = old_;
// 	    undoing_ = true;
// 	    Start();
// 	}
	FixButtons();
    }

    public void HandleBackgroundEvent(Event e) {
	if (CanEdit()) {
	    if (e.id == Event.MOUSE_DOWN) {
		new OrderNode(this, e.x, e.y, false);
		FixButtons();
	    }
	}
	if (e.id == Event.KEY_PRESS && e.key == 'o')
	    System.out.println(this);
    }

    public void run() {
	if (undoing_) {
	    DisallowEditing();
	    left_.ClearGraph();
	    right_.ClearGraph();
	    ClearMirrors();
	    for (int loop = enforcers_.length - 1; loop >= 0; --loop)
		enforcers_[loop].Undo();
	    
	    ChangePositions(false);
	    AllowEditing();
	    kicker_ = null;	    
	    undoing_ = false;
	    FixButtons();
	}
	else {
	    DisallowEditing();
	    
	    enforcers_[0].Enforce(graph_, edges_, null);		
	    enforcers_[1].Enforce(graph_, edges_, null);
	    enforcers_[2].Enforce(graph_, edges_, null);
	    lowest_ = ((SourceSink)enforcers_[2]).GetSource();
	    enforcers_[3].Enforce(graph_, edges_, lowest_);	    
	    
	    ComputeDominance();
	    Delay(PAUSE_DELAY);
	    ShowDominance();
	    
	    if (DidAnything())
		Delay(PAUSE_DELAY);
	    
	    for (int loop = enforcers_.length - 1; loop >= 0; --loop)
		enforcers_[loop].Restore();
	    
	    kicker_ = null;
	    clear_.Enable();
//	    undo_.Enable();
	}
    }    

    public OrderNode[] GetOrderArray() {
	OrderNode[] result = new OrderNode[graph_.size()];
	graph_.copyInto(result);
	return result;
    }

    public boolean DidAnything() {
	boolean result = false;
	for (int loop = 0; !result && loop < enforcers_.length; ++loop)
	    result = enforcers_[loop].DidAnything();
	return result;
    }
    
    public void AddDelay() {
	Delay(ADD_DELAY);
    }
    
    public void RemoveDelay() {
	Delay(REMOVE_DELAY);
    }

    final public static int WIDTH = 350;
    final public static int HEIGHT = 350;

    final public static int OFFSET = 16;
    final public static int LEFT = OFFSET;
    final public static int BOTTOM = HEIGHT - OFFSET;
    final public static int BETWEEN = Node.DIAMETER + 7;
    
    final public static int BUTTON_WIDTH = 60;
    final public static int BUTTON_HEIGHT = 20;
    
    final public static int START_X = 10;
    final public static int START_Y = 10;
    final public static int CLEAR_X = START_X + BUTTON_WIDTH + 15;
    final public static int CLEAR_Y = START_Y;
    final public static int UNDO_X = CLEAR_X + BUTTON_WIDTH + 15;
    final public static int UNDO_Y = START_Y;
    final public static int COMPACT_X = START_X;
    final public static int COMPACT_Y = START_Y + BUTTON_HEIGHT + 10;
    final public static int NOT_UP_X = 0;
    final public static int NOT_UP_Y = COMPACT_Y+CheckboxSprite.BOX_SIZE+10;

    final public static int PAUSE_DELAY = 2000;
    final public static int REMOVE_DELAY = 1000;
    final public static int ADD_DELAY = 400;    
    final public static int BAD_DELAY = 5000;    
    final public static int SHOW_DELAY = 800;    
}
