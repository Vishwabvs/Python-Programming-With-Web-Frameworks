/*
 * @(#)PSTNode.java	1.0 5/2/96 Michael John Radwin
 */

package mjr.pstree;

import mjr.heap.*;
import java.awt.*;
import leda.*;
import sprite.*;
import graph.*;
import java.util.Vector;

/**
 * A specialized node for priority search trees. Doesn't allow
 * edges to be drawn.
 *
 * @version 1.0 5/2/96
 * @author <A HREF="http://www.cs.brown.edu/people/mjr/">Michael John Radwin</A>
 */
public class PSTNode extends GIFNode implements Heapable {
    protected LineSprite h_split = null, v_split = null;
    protected PolySprite tip = null;
    protected PSTGraph pstgraph;
    protected ParameterInfo info;
    static public final int UNVISITED = GIFNode.BLUE;
    static public final int VISITED_SUCCESS = GIFNode.MAGENTA;
    static public final int VISITED_FAILURE = GIFNode.CYAN;

    public PSTNode(PSTGraph area, int x, int y, Vector images, ParameterInfo info)
    {
	super(area, x, y, images);
	pstgraph = area;
	this.info = info;
    }

    public void handleEvent(Event e)
    {
	if (pstgraph.CanEdit()) {
	    switch (e.id) {
	    case Event.MOUSE_DOWN:
	    case Event.MOUSE_DRAG:
		if (pstgraph.Inside(e.x, e.y) &&
		    pstgraph.getNodeAt(e.x, e.y) == null)
		    MoveTo(e.x, e.y);
		break;
	    case Event.MOUSE_UP:
		if (pstgraph.Inside(e.x, e.y) &&
		    pstgraph.getNodeAt(e.x, e.y) == null)
		    MoveTo(e.x, e.y);
		Anchor();
		break;
	    case Event.KEY_PRESS:
		if (e.key == 8 || e.key == 127)
		    Remove();
		break;
	    }
	}
    }

    
    public void makeSplitLine(ps_item p)
    {
	if (p.x_value() <= 0 || p.y_value() <= 0)
	    return;

	// only draw a horizontal line if the split is a node other than me.
	if (p.split_value_x() != p.x_value() || p.split_value_y() != p.y_value()) {
	    h_split =
		new LineSprite(pstgraph,
			       p.x_value(), p.y_value(),
			       p.split_value_x(), p.y_value(),
			       info.MEDIAN);
	    h_split.Add(); h_split.Anchor(); h_split.Hide();
	}
	
	v_split =
	    new LineSprite(pstgraph,
			   p.split_value_x(), p.y_value(),
			   p.split_value_x(), pstgraph.size().height,
			   info.MEDIAN);
	v_split.Add(); v_split.Anchor(); v_split.Hide();

	int xPts[] = new int[3];
	int yPts[] = new int[3];
	xPts[0] = p.split_value_x();
	xPts[1] = p.split_value_x() - 3;
	xPts[2] = p.split_value_x() + 3;
	yPts[0] = pstgraph.size().height;
	yPts[1] = pstgraph.size().height - 8;
	yPts[2] = pstgraph.size().height - 8;
	tip = new PolySprite(pstgraph, xPts, yPts, 3, info.MEDIAN);
	tip.Add(); tip.Anchor(); tip.Hide();
    }

    public void showSplitLine()
    {
	if (v_split != null) {
	    if (h_split != null) h_split.Show();
	    v_split.Show();
	    tip.Show();

	    if (h_split != null) h_split.ZToBottom();
	    v_split.ZToBottom();
	    tip.ZToBottom();
	}
    }
    

    public void hideSplitLine()
    {
	if (v_split != null) {
	    if (h_split != null) h_split.Hide();
	    v_split.Hide();
	    tip.Hide();
	}
    }

    public void Remove()
    {
	if (v_split != null) {
	    if (h_split != null) h_split.Remove();
	    v_split.Remove();
	    tip.Remove();
	}
	super.Remove();
    }
    
    public boolean greaterThan(Object other)
    {
	PSTNode n = (PSTNode) other;
	return y_ > n.y_;
    }
    
    public boolean lessThan(Object other)
    {
	PSTNode n = (PSTNode) other;
	return y_ < n.y_;
    }
    
    public boolean equalTo(Object other)
    {
	PSTNode n = (PSTNode) other;
	return y_ == n.y_;
    }
    public static void mjr() { ; }
}
