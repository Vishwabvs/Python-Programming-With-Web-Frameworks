
import java.awt.*;
import java.io.*;
import java.util.Vector;
import java.util.Random;

class GraphUpdate implements Runnable
{
    IGem igem;
    AlgoThread algo;
    int algo_type = NONE;

    final static int UPDATE_DELAY = 20;
    final static int NONE = 0;
    final static int RANDOMIZE = 1;
    final static int ARRANGE = 2;
    final static int OPTIMIZE = 3;

    public GraphUpdate(IGem g) { igem = g; }
    public void start() {}
    public void stop() {}

    public void run() {
        while (true) {
            if (algo_type==NONE) return;
            algoGraphUpdate();
            try {
                Debug.println("Sending update thread to sleep... ");
                algo.sleep(UPDATE_DELAY);
            } catch (InterruptedException e) {
                break;
            }
        }
    }

    public void setAlgo(int type)
    {
        if (algo_type!=NONE) algo.stop();
        algo_type = type;
        switch (algo_type) {
            case RANDOMIZE:
                algo = new AlgoRANDOMIZE(this,igem);
                break;
            case ARRANGE:
                algo = new AlgoFRICK(this,igem,ARRANGE);
                break;
            case OPTIMIZE:
                algo = new AlgoFRICK(this,igem,OPTIMIZE);
                break;
            default:
                return;
        }
        algo.start();
    }

    final static int REFRESH_RATE = 10;

    protected synchronized void algoGraphUpdate()
    {
        int flag = algo.update();
        if (flag==AlgoThread.FLAG_STOPPED) {
            algo_type=NONE;
            igem.setCheckButtonStopped();
            igem.setMessage("Algorithm converged ("+algo.iteration+" iterations).");
            igem.disp_area.repaint();
        } else
        if (flag==AlgoThread.FLAG_ALGOSWITCHED) {
            igem.setMessage("iteration: "+algo.iteration);
            igem.disp_area.repaint();
            algoGraphUpdate();
        } else
        if ((algo.iteration%REFRESH_RATE)==0) {
            igem.setMessage("iteration: "+algo.iteration);
            igem.disp_area.repaint();
        }
    }
}

class AlgoThread extends Thread
{
    IGem igem;
    Graph g;
    static Random rand = new Random();
    final static int UPDATE_DELAY = 20;

    int iteration, prev_iterations;
    static int FLAG_RUNNING = 0;
    static int FLAG_STOPPED = 1;
    static int FLAG_ALGOSWITCHED = 2;

    public AlgoThread(Runnable target,IGem gm) {
        super(target);
        igem = gm;
        g = igem.graph;
        iteration = 1;
        init();
    }

    public void init() {}
    public int update() { return FLAG_STOPPED; }

    public int updateWait()
    {
        igem.disp_area.repaint();
        try {
            if (igem.graph_algo.algo != this) return FLAG_ALGOSWITCHED;
            Thread.sleep(UPDATE_DELAY);
        } catch (InterruptedException e) {
        }
        return FLAG_RUNNING;
    }
}

class AlgoRANDOMIZE extends AlgoThread
{
    public AlgoRANDOMIZE(Runnable target, IGem gm) { super(target,gm); }

    public int update()
    {
        DisplayArea disp = igem.disp_area;
        Dimension d = disp.size();
        int x_from = disp.dc.toWorldX(0);
        int x_to = disp.dc.toWorldX(d.width-1);
        int y_from = disp.dc.toWorldY(0);
        int y_to = disp.dc.toWorldY(d.height-1);

        for (int i=0;i<g.vertices.size();i++)
        {
            Vertex v = (Vertex) g.vertices.elementAt(i);
            if (v!=null && v.fixed==false) {
                v.x = x_from + (int)( Math.random()*(x_to-x_from) );
                v.y = y_from + (int)( Math.random()*(y_to-y_from) );
            }
            if (updateWait()==FLAG_ALGOSWITCHED) return FLAG_ALGOSWITCHED;
        }
        return FLAG_STOPPED;
    }
}

class AlgoFRICKData
{
    int    mass;    // mass/weight
    double heat;    // current temperature
    Vec2d  imp;     // last impulse
    int    dir;     // direction gauge, for detection of rotations
    int    degree;  // number of incident edges

    public AlgoFRICKData() {
        imp = new Vec2d(0,0);
    }
}

class AlgoFRICK extends AlgoThread
{
    Vec2d center = new Vec2d(0,0);
    double oscillation, rotation;

    double temperature;
    double stop_temperature;
    double maxtemp;

    int stop_iteration;

    static int ELEN = 50; // 128;
    static int ELENSQR = (ELEN*ELEN);
    static int MAXATTRACT = 1048576;

    int i_maxiter, a_maxiter, o_maxiter;
    double i_maxtemp, a_maxtemp, o_maxtemp,
                i_starttemp, a_starttemp, o_starttemp,
                i_finaltemp, a_finaltemp, o_finaltemp,
                i_gravity, i_oscillation, i_rotation,
                i_shake, a_gravity, a_oscillation,
                a_rotation, a_shake, o_gravity,
                o_oscillation, o_rotation, o_shake;

    int map[];
    int stage;
    int type;

    public static void setEdgeLength(int i) {
        ELEN = i;
        ELENSQR = (ELEN*ELEN);
    }

    public AlgoFRICK(Runnable target,IGem gm,int t)
    {
        super(target,gm); type = t;
    }

    public void init()
    {
        stage = 0;
        i_maxiter       = 10;
        a_maxiter       = 3;
        o_maxiter       = 3;
        i_maxtemp       = 1.0;
        a_maxtemp       = 1.5;
        o_maxtemp       = 0.25;
        i_starttemp     = 0.3;
        a_starttemp     = 1.0;
        o_starttemp     = 0.05;
        i_finaltemp     = 0.05;
        a_finaltemp     = 0.05;
        o_finaltemp     = 0.045;
        i_gravity       = 0.05;
        a_gravity       = 0.1;
        o_gravity       = 0.1;
        i_oscillation   = 0.4;
        a_oscillation   = 0.4;
        o_oscillation   = 0.4;
        i_rotation      = 0.5;
        a_rotation      = 0.9;
        o_rotation      = 0.9;
        i_shake         = 0.2;
        a_shake         = 0.3;
        o_shake         = 0.3;
    }

    public void updateMeter() {
        int number_vertices = g.vertices.size();
        double val = (temperature-stop_temperature)/(ELEN * number_vertices);
        igem.meter.setValue( val );
    }

    public int update()
    {
        if (g.vertices.size()==0) return FLAG_STOPPED;
        switch (type) {
            case GraphUpdate.ARRANGE:
                Debug.println(1,"# Insert()");
                return insert();

            case GraphUpdate.OPTIMIZE:
                switch (stage) {
                    case 0:
                        a_init();
                        stage++;
                        return FLAG_RUNNING;
                    case 1:
                        if (arrange()==true) {
                            Debug.println(1,"# Arrange()");
                            o_init();
                            stage++;
                        }
                        updateMeter();
                        return FLAG_RUNNING;
                    case 2:
                        if (optimize()==true) {
                            Debug.println(1,"# Optimize()");
                            updateMeter();
                            return FLAG_STOPPED;
                        }
                        updateMeter();
                        return FLAG_RUNNING;
                }
        }
        return FLAG_STOPPED;
    }

    protected void init_vertices(double starttemp)
    {
        temperature = 0;
        center.x = center.y = 0;
        int number_vertices = g.vertices.size();
        for (int i=0;i<number_vertices;i++) {
            Vertex v = (Vertex) g.vertices.elementAt(i);
            AlgoFRICKData v_data = new AlgoFRICKData();
            v.data = v_data;
            v_data.heat = starttemp * ELEN;
            temperature += v_data.heat * v_data.heat;
            v_data.imp.x = v_data.imp.y = 0;
            v_data.dir = 0;
            v_data.mass = 1 + v_data.degree / 3;
            center.x += v.x;
            center.y += v.y;
        }
        map = new int[number_vertices+1];
    }

    protected void o_init()
    {
        init_vertices(o_starttemp);
        int number_vertices = g.vertices.size();
        oscillation = o_oscillation;
        rotation = o_rotation;
        maxtemp = o_maxtemp * ELEN;
        stop_temperature = o_finaltemp * o_finaltemp * ELENSQR * number_vertices;
        stop_iteration = o_maxiter * number_vertices * number_vertices;
        iteration = 0;
    }

    protected void a_init()
    {
        init_vertices(a_starttemp);
        int number_vertices = g.vertices.size();
        oscillation = a_oscillation;
        rotation = a_rotation;
        maxtemp = a_maxtemp * ELEN;
        stop_temperature = a_finaltemp * a_finaltemp * ELENSQR * number_vertices;
        stop_iteration = a_maxiter * number_vertices * number_vertices;
        iteration = 0;
    }

    protected Vertex select ()
    {
        int number_vertices = g.vertices.size();
        if (iteration == 0) {
            for (int i=0;i<number_vertices;i++) {
                map[i] = i;
            }
        }
        int n = number_vertices - iteration % number_vertices;
        int v = 1+Math.abs(rand.nextInt()) % n;
        int u = map[v];
        map[v] = map[n];
        map[n] = u;
        return (Vertex) g.vertices.elementAt(u);
    }

    protected double NORM2(int x,int y) {
        return Math.sqrt((x)*(x)+(y)*(y));
    }

    protected void EVdistance (Edge e, Vertex v, Vec2d ret)
    {
        Vec2d a = new Vec2d(e.v1);
        Vec2d b = new Vec2d(e.v2);
        Vec2d c = new Vec2d(v);

        b.x -= a.x; b.y -= a.y; // b' = b - a
        int m = b.x * (c.x - a.x) + b.y * (c.y - a.y); // m = <b'|c-a> = <b-a|c-a>
        int n = b.x * b.x + b.y * b.y; // n = |b'|^2 = |b-a|^2
        if (m < 0) m = 0;
        if (m > n) m = n = 1;
        if (n == 0) n=1;
        a.x += b.x * m / n;  // a' = m/n b' = a + m/n (b-a)
        a.y += b.y * m / n;
        ret.set(a);
    }

    protected void displace (Vertex v, Vec2d i)
    {
        if (i.x==0 && i.y==0) return;
        if (v.fixed == true) return;

        int number_vertices = g.vertices.size();
        int n = Math.max( Math.abs(i.x), Math.abs(i.y)) / 16384;
        if (n > 1) {
            i.x /= n;
            i.y /= n;
        }
        AlgoFRICKData v_data = (AlgoFRICKData) v.data;
        double t = v_data.heat;
        n = (int) NORM2(i.x, i.y);
        Debug.print(3,"# displace: "+i+", t="+t+", n="+n+", ");

        i.x = (int) (i.x * t / n);
        i.y = (int) (i.y * t / n);
        v.x += i.x;
        v.y += i.y;
        center.x += i.x;
        center.y += i.y;
        Vec2d imp = v_data.imp;
        n = (int) (t * NORM2 (imp.x, imp.y));
        if (n>0) {
            temperature -= t * t;
            t += t * oscillation * (i.x * imp.x + i.y * imp.y) / n;
            t = Math.min (t, maxtemp);
            v_data.dir += rotation * (i.x * imp.y - i.y * imp.x) / n;
            t -= t * Math.abs(v_data.dir) / number_vertices;
            t = Math.max(t, 2);
            temperature += t * t;
            v_data.heat = t;
        }
        v_data.imp.set(i);
        Debug.println(3," result: "+v);
    }

    protected void o_impulse (Vertex v, Vec2d i)
    {
        AlgoFRICKData v_data, u_data, w_data;
        v_data = (AlgoFRICKData) v.data;

        int number_vertices = g.vertices.size();
        Vertex d = new Vertex(0,0);
        Vec2d p = v;

        int n = (int) (o_shake * ELEN);
        i.x = Math.abs(rand.nextInt()) % (2*n+1) - n;
        i.y = Math.abs(rand.nextInt()) % (2*n+1) - n;
        i.x += (center.x / number_vertices - p.x) * v_data.mass * o_gravity;
        i.y += (center.y / number_vertices - p.y) * v_data.mass * o_gravity;

        for (int e_num=0; e_num<g.edges.size(); e_num++) {
            Edge e = (Edge) g.edges.elementAt(e_num);
            Vertex u = e.v1;
            Vertex w = e.v2;
            u_data = (AlgoFRICKData) u.data;
            w_data = (AlgoFRICKData) w.data;

            if (u != v && w != v) {
                d.x = (u.x + w.x) / 2 - p.x;
                d.y = (u.y + w.y) / 2 - p.y;
                n = d.x * d.x + d.y * d.y;
                if (n < 8 * ELENSQR) {
                    EVdistance (e, v, d);
                    d.x -= p.x;
                    d.y -= p.y;
                    n = d.x * d.x + d.y * d.y;
                }
                if (n > 0) {
                    i.x -= d.x * ELENSQR / n;
                    i.y -= d.y * ELENSQR / n;
                }
            } else {
                if (u == v) u = w;
                d.x = p.x - u.x;
                d.y = p.y - u.y;
                n = (d.x * d.x + d.y * d.y) / v_data.mass;
                n = Math.min(n, MAXATTRACT);
                i.x -= d.x * n / ELENSQR;
                i.y -= d.y * n / ELENSQR;
            }
        }
        Debug.println(3,"# o_impulse: "+i);
    }

    protected void a_impulse (Vertex v, Vec2d i)
    {
        AlgoFRICKData v_data, u_data, w_data;
        v_data = (AlgoFRICKData) v.data;

        int number_vertices = g.vertices.size();
        Vertex d = new Vertex(0,0);
        Vec2d p = v;

        int n = (int) (a_shake * ELEN);
        i.x = Math.abs(rand.nextInt()) % (2 * n + 1) - n;
        i.y = Math.abs(rand.nextInt()) % (2 * n + 1) - n;
        i.x += (center.x / number_vertices - p.x) * v_data.mass * a_gravity;
        i.y += (center.y / number_vertices - p.y) * v_data.mass * a_gravity;

        for (int u_num=0; u_num<g.vertices.size(); u_num++) {
            Vertex u = (Vertex) g.vertices.elementAt(u_num);
            d.x = p.x - u.x;
            d.y = p.y - u.y;
            n = d.x * d.x + d.y * d.y;
            if (n>0) {
                i.x += d.x * ELENSQR / n;
                i.y += d.y * ELENSQR / n;
            }
        }

        for (int e_num=0; e_num<v.adjedges.size(); e_num++) {
            Edge e = (Edge) v.adjedges.elementAt(e_num);
            Vertex u = e.otherVertex(v);
            d.x = p.x - u.x;
            d.y = p.y - u.y;
            n = (d.x * d.x + d.y * d.y) / v_data.mass;
            n = Math.min(n, MAXATTRACT);
            i.x -= d.x * n / ELENSQR;
            i.y -= d.y * n / ELENSQR;
        }
        Debug.println(3,"# a_impulse: "+i);
    }

    protected void i_impulse (Vertex v, Vec2d i)
    {
        AlgoFRICKData v_data, u_data, w_data;
        v_data = (AlgoFRICKData) v.data;

        int number_vertices = g.vertices.size();
        Vertex d = new Vertex(0,0);
        Vec2d p = v;

        int n = (int) (i_shake * ELEN);
        i.x = Math.abs(rand.nextInt()) % (2 * n + 1) - n;
        i.y = Math.abs(rand.nextInt()) % (2 * n + 1) - n;
        i.x += (center.x / number_vertices - p.x) * v_data.mass * i_gravity;
        i.y += (center.y / number_vertices - p.y) * v_data.mass * i_gravity;

        Debug.println(3,"# entered i_impulse: "+i);

        for (int u_num=0; u_num<g.vertices.size(); u_num++) {
            Vertex u = (Vertex) g.vertices.elementAt(u_num);
            if (u.in > 0) {
                d.x = p.x - u.x;
                d.y = p.y - u.y;
                n = d.x * d.x + d.y * d.y;
                if (n>0) {
                    i.x += d.x * ELENSQR / n;
                    i.y += d.y * ELENSQR / n;
                }
            }
        }

        for (int e_num=0; e_num<v.adjedges.size(); e_num++) {
            Edge e = (Edge) v.adjedges.elementAt(e_num);
            Vertex u = e.otherVertex(v);
            if (u.in > 0) {
                d.x = p.x - u.x;
                d.y = p.y - u.y;
                n = (d.x * d.x + d.y * d.y) / v_data.mass;
                n = Math.min(n, MAXATTRACT);
                i.x -= d.x * n / ELENSQR;
                i.y -= d.y * n / ELENSQR;
            }
        }
        Debug.println(3,"# i_impulse: "+i);
    }

    protected void a_round ()
    {
        Vec2d u = new Vec2d(0,0);
        for (int i=0; i<g.vertices.size(); i++) {
            Vertex v = select();
            a_impulse(v,u);
            displace (v,u);
            iteration ++;
        }
    }

    protected void o_round ()
    {
        Vec2d u = new Vec2d(0,0);
        for (int i=0; i<g.vertices.size(); i++) {
            Vertex v = select();
            o_impulse(v,u);
            Debug.println(3,"displace = "+u.x+","+u.y);
            displace (v,u);
            iteration ++;
        }
    }

    protected boolean arrange ()
    {
        if (!converged()) {
            a_round ();
            return false;
        }
        return true; // end iterations.
    }

    protected boolean optimize()
    {
        if (!converged()) {
            o_round();
            return false;
        }
        return true; // end iterations.
    }

    protected int insert()
    {
        init_vertices(i_starttemp);
        oscillation = i_oscillation;
        rotation = i_rotation;
        maxtemp = i_maxtemp * ELEN;

        Vertex v = g.findCenterVertex();

        for (int u_num=0; u_num<g.vertices.size(); u_num++) {
            Vertex u = (Vertex) g.vertices.elementAt(u_num);
            u.in = 0;
        }
        v.in = -1;

        for (int i_num=0; i_num<g.vertices.size(); i_num++)
        {
            //Vertex i = (Vertex) g.vertices.elementAt(i_num);
            int d = 0;
            for (int u_num=0; u_num<g.vertices.size(); u_num++) {
                Vertex u = (Vertex) g.vertices.elementAt(u_num);
                if (u.in < d) {
                    d = u.in;
                    v = u;
                    //break; ?
                }
            }
            v.in = 1;
            for (int e_num=0; e_num < v.adjedges.size(); e_num++) {
                Edge e = (Edge) v.adjedges.elementAt(e_num);
                Vertex u = e.otherVertex(v);
                if (u.in <= 0) u.in--;
            }

            if (v.fixed==false) {
                v.x = v.y = 0;

                d = 0;
                for (int e_num=0; e_num < v.adjedges.size(); e_num++) {
                    Edge e = (Edge) v.adjedges.elementAt(e_num);
                    Vertex w = e.otherVertex(v);
                    if (w.in > 0) {
                        v.x += w.x;
                        v.y += w.y;
                        d ++;
                    }
                }
                if (d > 1) {
                    v.x /= d;
                    v.y /= d;
                }

                AlgoFRICKData v_data = (AlgoFRICKData) v.data;
                Vec2d u = new Vec2d(0,0);
                d=0;
                while ((d++ < i_maxiter) && (v_data.heat > i_finaltemp * ELEN)) {
                    i_impulse (v,u);
                    displace (v,u);
                }
                Debug.println(3,"Inserted["+i_num+"] "+v.x+","+v.y);
            }
            if (updateWait()==FLAG_ALGOSWITCHED) return FLAG_ALGOSWITCHED;
        }
        return FLAG_STOPPED;
    }

    protected boolean converged()
    {
        return (temperature < stop_temperature || iteration > stop_iteration);
    }
}
