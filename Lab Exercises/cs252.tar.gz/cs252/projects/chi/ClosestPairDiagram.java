import java.awt.*; 
import java.util.*;
import java.applet.*; 
import java.lang.*; 

public class ClosestPairDiagram extends Applet implements Runnable {
   static final int INFTY = ClosestPair.INFTY; 
   static final int RIGHT = ClosestPair.RIGHT;
   static final int LEFT = ClosestPair.LEFT; 
   static final int NODERADIUS = 3; 
   static final int LINERESOLUTION = 2; 
   static final int PRIOR = 0; 
   static final int POST = 1; 
   static final int GRID = 20; 

   static final Color controlPanelBackground = new Color(60, 150, 60); 
   static final Color backgroundColor = new Color(100, 200, 100); 
   static final Color labelBackgroundColor =  controlPanelBackground; 
   static final Color labelForegroundColor =  Color.green; 
   static final Color buttonBackgroundColor =  Color.gray; 
   static final Color buttonForegroundColor =  Color.green; 
   static final Color checkboxBackgroundColor =  Color.gray; 
   static final Color checkboxForegroundColor =  Color.green; 

   static final Color sweepLineColor = new Color(60, 150, 60); 
   static final Color queryBoxColor = Color.red; 

   static final Font characterFont = new Font("TimesRoman", Font.BOLD, 14); 

   FunctionSet tools; 

   Amination aminator = null;
   // a thread for the applet itself. 
   private Thread timeKeeper = null; 

   private ClosestPair cp; 
   public ClosestPair getClosestPair() {
      return cp; 
   } 
   
   private boolean isDeleted;
   private boolean dragAble; 
   private boolean isDragged; 
   private boolean isNewNode; 
   private boolean dragLine; 
   private boolean dragNode; 
   private boolean nodeBounced; 

   private int dx; 
   private int dy; 
   private int dl; 

   private int linePosition; 
   public int getLinePosition() {
      return linePosition; 
   }
   protected void setLinePosition(int a) {
      linePosition = a;
   }
   private int iniLinePosition; 

   // the tempary coord of the center of circle during mousedrag   
   private int lastCenter_x; 
   private int lastCenter_y; 
   private Key lastCenter; 
   private int initCenter_x; 
   private int initCenter_y; 

   private Date currentTime = null; 

   private Label mouse_label; 
   private Label min_label; 

   private Panel control_panel; 
   private Button clear_button;
   private Button restart_button;
   private Button forward_button; 
   private Button backward_button; 
   private CheckboxGroup checkbox_group; 

   private Checkbox[] checkboxes; 
   int dim_check_boxes= 2; 

   private boolean checkSweep = false; 
   private boolean checkDemo = false; 
   private Checkbox grid_choice;   
   private boolean wait_for_change_grid = false; 
   private boolean grid_on = false; 
   public boolean getGridChoice() {
      return grid_on; 
   }

   private Panel draw_panel; 
   private DrawingArea drawArea = null; 
   private Dimension dim_drawArea; 
   public DrawingArea getDrawingArea() {
      return drawArea; 
   }

   private Panel help_panel; 
   //private Button help_button; 

   private long mouseDownTime; 
   private long mouseUpTime;
   private long timeSpan=0; 

   public void init() {
      super.init();
      cp = new ClosestPair(); 
      
      GridBagLayout gridBag = new GridBagLayout(); 
      GridBagConstraints c = new GridBagConstraints(); 

      setLayout(gridBag); 

      c.fill = GridBagConstraints.BOTH; 
      c.insets = new Insets(0, 0, 0, 0); 
      c.weightx = 0.0; 
      c.weighty = 0.0; 
      c.gridwidth = GridBagConstraints.REMAINDER; 
   
      control_panel = new Panel(); 
      control_panel.setBackground(controlPanelBackground); 
      control_panel.setLayout(gridBag); 
 
      c.gridx = 0;  c.gridy = 0; 
      constrain(control_panel, new Label("mouse:"), 
           labelBackgroundColor, labelForegroundColor, gridBag, c); 

      c.gridx = 0;  c.gridy = 1; 
      mouse_label =  new Label(" "); 
      constrain(control_panel, mouse_label, 
           labelBackgroundColor, labelForegroundColor, gridBag, c); 

      c.gridx = 0;  c.gridy = 2; 
      constrain(control_panel, new Label("min distance:"), 
           labelBackgroundColor, labelForegroundColor, gridBag, c); 
      
      c.gridx = 0;  c.gridy = 3; 
      min_label = new Label(" "); 
      constrain(control_panel, min_label, 
           labelBackgroundColor, labelForegroundColor, gridBag, c); 

      c.gridx = 0;  c.gridy = 4; 
      forward_button = new Button("Forward");
      constrain(control_panel, forward_button, 
           buttonBackgroundColor, buttonForegroundColor, gridBag, c); 

      c.gridx = 0;  c.gridy = 5; 
      backward_button = new Button("Backward");
      constrain(control_panel, backward_button, 
           buttonBackgroundColor, buttonForegroundColor, gridBag, c); 

      c.gridx = 0;  c.gridy = 6; 
      restart_button = new Button("Restart");
      constrain(control_panel, restart_button, 
           buttonBackgroundColor, buttonForegroundColor, gridBag, c); 

      c.gridx = 0;  c.gridy = 7; 
      clear_button = new Button("Clear");
      constrain(control_panel, clear_button, 
           buttonBackgroundColor, buttonForegroundColor, gridBag, c); 

      c.gridx = 0; c.gridy = 8; 
      Label label = new Label(" "); 
      gridBag.setConstraints(label, c); 
      control_panel.add(label); 

      c.gridx = 0; c.gridy = 9; 
      label = new Label(" "); 
      gridBag.setConstraints(label, c); 
      control_panel.add(label); 

      c.gridx = 0; c.gridy = 10; 
      constrain(control_panel, new Label("mode selection"), 
           labelBackgroundColor, labelForegroundColor, gridBag, c); 

      checkbox_group = new CheckboxGroup(); 
      checkboxes = new Checkbox[dim_check_boxes]; 
      checkboxes[0] = new Checkbox("Sweep", checkbox_group, true); 
      checkboxes[1] = new Checkbox("Demo", checkbox_group, false); 

      c.gridx = 0; c.gridy = 11; 
      constrain(control_panel, checkboxes[0], 
           checkboxBackgroundColor, checkboxForegroundColor, gridBag, c); 

      c.gridx = 0; c.gridy = 12; 
      constrain(control_panel, checkboxes[1], 
           checkboxBackgroundColor, checkboxForegroundColor, gridBag, c); 

      c.gridx = 0; c.gridy = 13; 
      label = new Label(" "); 
      gridBag.setConstraints(label, c); 
      control_panel.add(label); 

      c.gridx = 0; c.gridy = 14; 
      grid_choice = new Checkbox("Show Grid"); 
      constrain(control_panel, grid_choice, 
           checkboxBackgroundColor, checkboxForegroundColor, gridBag, c); 

      draw_panel = new Panel(); 
      draw_panel.setBackground(Color.gray); 
      draw_panel.setLayout(gridBag); 
      drawArea = new DrawingArea(this); 

      c.fill = GridBagConstraints.BOTH; 
      c.insets = new Insets(4, 4, 4, 4); 
      c.gridx = 0;  c.gridy = 0; 
      c.weightx = 1.0;  c.weighty = 1.0; 
      c.gridwidth = 1;
      gridBag.setConstraints(drawArea, c); 
      draw_panel.add(drawArea); 

      help_panel = new Panel(); 
      help_panel.setLayout(new FlowLayout(FlowLayout.CENTER)); 
      help_panel.add(new Label(" ")); 
      //help_button = new Button("Help"); 
      //help_button.setForeground(buttonForegroundColor); 
      //help_button.setBackground(buttonBackgroundColor); 
      //help_panel.add(help_button); 

      setBackground(backgroundColor); 
      c.gridx = 0;  c.gridy = 0; 
      c.gridwidth = GridBagConstraints.REMAINDER;  c.gridheight = 1; 
      c.weightx = 1.0;  c.weighty = 0.0; 
      gridBag.setConstraints(help_panel, c); 
      add(help_panel); 

      c.gridx = 0;  c.gridy = 1; 
      c.gridwidth = 1;  c.gridheight = 1; 
      c.fill = GridBagConstraints.VERTICAL; 
      c.anchor = GridBagConstraints.WEST; 
      c.weightx = 0.0;  c.weighty = 1.0; 
      c.insets = new Insets(10, 10, 5, 5); 
      gridBag.setConstraints(control_panel, c); 
      add(control_panel); 

      c.gridx = 1;  c.gridy = 1; 
      c.gridwidth = 1;  c.gridheight = 2; 
      c.fill = GridBagConstraints.BOTH; 
      c.anchor = GridBagConstraints.CENTER; 
      c.weightx = 1.0;  c.weighty = 1.0; 
      c.insets = new Insets(10, 10, 5, 10); 
      gridBag.setConstraints(draw_panel, c); 
      add(draw_panel); 
  
      tools = new FunctionSet(this); 
   }

   void constrain(Container container, Component cmp, 
           Color background,  Color foreground, 
           GridBagLayout gridbag, GridBagConstraints c) {
      cmp.setBackground(background); 
      cmp.setForeground(foreground); 
      gridbag.setConstraints(cmp, c); 
      container.add(cmp); 
   }

   public void start() {
      super.start(); 
      diagramInit(); 
      // Give *this* a thread such that the object can be run in it. 
      timeKeeper = new Thread(this); 
      timeKeeper.setPriority(Thread.MIN_PRIORITY); 
      timeKeeper.start(); 
      wait_for_change_grid = false; 
   }
   
   public void diagramInit() { 
      currentTime = new Date(); 
      lastCenter = null; 

      linePosition = 0; 
      iniLinePosition = 0; 

      mouse_label.setText(" "); 
      min_label.setText(" "); 

      checkboxes[0].setState(true);  
      checkboxes[1].setState(false); 

      grid_choice.setState(false); 
      grid_on = false; 
      wait_for_change_grid=false; 

      dim_drawArea = drawArea.size(); 
      cp.start();
      repaint(); 
   } 

   public void stop() {
      if(timeKeeper !=null) timeKeeper.stop();
      timeKeeper = null;
   }

   public void run() {
      while(true) {
	 while(aminator!=null&&aminator.isAlive()) {
	    Thread.yield(); 
	 } 
         Dimension d=drawArea.size(); 
         if(d.height!=dim_drawArea.height||
         d.width!=dim_drawArea.width) {
            tools.adjust(); 
            dim_drawArea = d; 
         }
	 if(wait_for_change_grid) {
	    if(!grid_on) {   
	       tools.drawGrid(drawArea, Color.black);  
	       grid_on = true;   
	    } else { 
	       tools.removeGrid(drawArea);  
	       grid_on = false;   
	    }
	    wait_for_change_grid = false; 
         }
         try Thread.sleep(100);  catch(InterruptedException e); 
      }
   }

   public boolean mouseEnter(Event event, int x, int y) {
      if(aminator!=null&&aminator.isAlive()) 
         return true; 
      repaint(); 
      return true; 
   }

   public void update(Graphics g) {
      tools.adjust(); 
   }

   public boolean action(Event event, Object arg) {
      checkSweep = checkboxes[0].getState(); 
      checkDemo = checkboxes[1].getState(); 
      double d = cp.getMinDistance(); 

      Graphics g= getGraphics(); 
      if(event.target==clear_button) {
         if(aminator!=null&&aminator.isAlive()) 
            return true; 
         diagramInit(); 
         return true; 
      } else if(event.target==forward_button) {
         if(checkSweep) {
            if(aminator!=null&&aminator.isAlive()) 
               return true; 
            if(cp.getTail().getNext().getKey().getX()<INFTY) { 
               tools.Sweep(RIGHT);
            }
            DrawingMethods.drawSweepLine(drawArea, linePosition, Color.red);
            showMinD(); 
         } else if(checkDemo) { 
            if(aminator==null||aminator.isAlive()==false) {
               if(cp.getTail().getNext().getKey().getX()<INFTY) { 
                  aminator = new Amination(this); 
                  aminator.setPriority(Thread.MAX_PRIORITY); 
                  aminator.start(); 
               }
            } 
         } 
         tools.drawClosestPair(drawArea, cp, Color.green);  
         return true; 
      } else if(event.target==backward_button) {
         if(aminator!=null&&aminator.isAlive()) 
            return true; 
         if(linePosition>cp.getTail().getKey().getX()) {
            tools.erraseQueryBand(cp, linePosition, 
                     tools.getBandWidth()); 
            linePosition=cp.getTail().getKey().getX();
            if(linePosition<=0) {
               linePosition = 0; 
            } 
            tools.drawQueryBand(cp, linePosition, d); 
            DrawingMethods.drawSweepLine(drawArea, linePosition, Color.red);
            tools.drawClosestPair(drawArea, cp, Color.green);  
            showMinD(); 
            return true; 
         } 
         tools.Sweep(LEFT);
         if(linePosition<=0) {
            linePosition = 0; 
         } 
         DrawingMethods.drawSweepLine(drawArea, linePosition, Color.red);
         showMinD(); 
         tools.drawClosestPair(drawArea, cp, Color.green);  
         return true; 
      } else if (event.target==restart_button) {
         if(aminator!=null&&aminator.isAlive()) 
            return true; 
         tools.erraseQueryBand(cp, linePosition, tools.getBandWidth()); 
         linePosition = 0; 
         iniLinePosition = 0; 
         DrawingMethods.drawSweepLine(drawArea, linePosition, Color.red); 
         cp.reSet();
         showMinD(); 
         return true; 
      } else if(event.target==grid_choice) {
         wait_for_change_grid = !wait_for_change_grid; 
         return true; 
      } else {   
         return super.action(event, arg); 
      } 
   } 

   public boolean diagramMouseMove(Event e, int x, int y) {
      if(aminator!=null&&aminator.isAlive()) 
         return true; 
      Graphics g = getGraphics(); 
      DrawingMethods.drawSweepLine(drawArea, linePosition, Color.red); 
      showMouse(x, y); 
      if(x<linePosition) return true; 
      Key currentCenter = null;  
      QueryNode currentCircleNode = tools.circleContaining(cp, x, y);
      if(currentCircleNode!=null) {
         currentCenter = currentCircleNode.getKey();
      } 
      QueryNode lastCircleNode =cp.pointAt(lastCenter); 
      if(currentCenter==null) {
         if(x < linePosition + 3&&dragLine==false) {
            DrawingMethods.drawSweepLine(drawArea, linePosition, 
                                         sweepLineColor);
            return true; 
         } else if(lastCircleNode!=null) {
            Key k = lastCircleNode.getKey(); 
            tools.drawNodesNear(cp, k.getX(), k.getY()); 
         }  
         lastCenter = null; 
         return true; 
      } else {
         if(currentCenter.getX()<=linePosition) return true; 
         if(lastCircleNode!=null) {
            x = lastCenter.getX(); 
            y = lastCenter.getY(); 
            DrawingMethods.drawCircleAt(drawArea, x, y, Color.blue); 
         } 
         x = currentCenter.getX(); 
         y = currentCenter.getY(); 
         DrawingMethods.drawCircleAt(drawArea, x, y, Color.red); 
         lastCenter = currentCenter; 
         return true; 
      }
   } 

   public boolean diagramMouseDown(Event e, int x, int y) { 
      if(aminator!=null&&aminator.isAlive()) 
         return true; 
      Graphics g = getGraphics(); 
      showMouse(x, y); 

      checkSweep = checkboxes[0].getState(); 
      checkDemo = checkboxes[1].getState(); 

      if(x < linePosition-2) {
         dragAble = false;
         return true; 
      } 
      QueryNode currentCircleNode = tools.circleContaining(cp, x, y);
      if(currentCircleNode == null) {
         if(x<linePosition+3&&dragLine==false) {
            iniLinePosition = linePosition; 
            DrawingMethods.drawSweepLine(drawArea, linePosition, 
                                          sweepLineColor);
            if(checkSweep) {
               dragLine = true;  
               dl = linePosition - x; 
            } else {
               dragLine = false;  
            }
            dragAble = false;
            return true; 
         }
         if(grid_choice.getState()==true) {
            if(x<GRID || y<GRID) 
               return true; 
            int tx = x/GRID*GRID; 
            int ty = y/GRID*GRID; 
            if(tx <=linePosition) { 
               tx = tx + GRID; 
            } 
            if(tx >=drawArea.size().width) { 
               return true; 
            } 
            QueryNode tnode = tools.circleContaining(cp, tx, ty);
            if(tnode!=null) { 
               isDeleted = true;  isDragged = false;  
               dragAble = false;  dragLine = false;  
               return true; 
            } 
            x = tx; y = ty; 
         } 
         DrawingMethods.drawCircleAt(drawArea, x, y, Color.blue); 
         Key currentCenter = new Key(x, y); 
         currentTime = new Date(); 
         mouseDownTime = currentTime.getTime(); 
         cp.addPoint(new QueryNode(currentCenter)); 
         isDeleted = false;  isDragged=false;  
         dragAble = true;  dragLine = false;   
         lastCenter_x = x;  lastCenter_y = y;  
         initCenter_x = x;  initCenter_y = y;  
         dx = 0; dy = 0; 
         return true; 
      } else if(currentCircleNode.getKey().getX()<linePosition+4) {
         dragLine = false;  dragAble = false;
         return true; 
      } else {    
         long ptime = mouseDownTime; 
         currentTime = new Date(); 
         mouseDownTime = currentTime.getTime(); 
         timeSpan = mouseDownTime - ptime; 
         Key currentCenter = currentCircleNode.getKey(); 
         if(timeSpan < 250) {
            tools.deleteCircleAt(cp, currentCircleNode); 
            isDeleted = true;  isDragged = false;  
            dragAble = false;  dragLine = false;  
            return true; 
         } else { 
            lastCenter_x = currentCenter.getX(); 
            lastCenter_y = currentCenter.getY(); 
            initCenter_x = currentCenter.getX(); 
            initCenter_y = currentCenter.getY(); 
            DrawingMethods.drawCircleAt(drawArea, lastCenter_x, 
               lastCenter_y, Color.red); 
            // distance between the mouse and the center of the center.  
            // When dragging mouse and draw circles, the distance between 
            // the center of the new circle and the mouse should be the same; 
            dx = lastCenter_x - x; 
            dy = lastCenter_y - y; 
            isDeleted = false; isDragged = false; 
            dragAble = true;  dragLine = false;  
            return true; 
         }
      }
   }
   
   public boolean diagramMouseDrag(Event e, int x, int y) {   
      if(aminator!=null&&aminator.isAlive()) 
         return true; 
      Rectangle r = drawArea.bounds(); 
      int w = r.width; 
      int h = r.height; 

      if(x<0||x>w||y<0||y>h) {
         return true;
      }
      isDragged = true; 
      showMouse(x, y); 
      
      if(dragLine) { 
         //System.out.println("DragLine..."); 
         tools.MouseSweep(cp, linePosition, x, dl); 
         showMinD(); 
         return true; 
      } 
      //System.out.println("Pia..."); 
      Key previousCenter = new Key(lastCenter_x, lastCenter_y); 
      if(x+dx < linePosition+LINERESOLUTION+1) {
         nodeBounced = true; 
         return true;
      }
      nodeBounced = false; 
      if(dragAble) {
         if(isDeleted!=true) {
            QueryNode cn_ = cp.pointAt(previousCenter); 
            if(cn_!=null) {
               tools.deleteCircleAt(cp, cn_); 
            } 
            isDeleted = true; 
         } 
         tools.drawNodesNear(cp, 
             previousCenter.getX(), previousCenter.getY()); 
         DrawingMethods.drawCircleAt(drawArea, x+dx, y+dy, Color.red);
         lastCenter_x = x+dx; 
         lastCenter_y = y+dy; 
      }
      DrawingMethods.drawSweepLine(drawArea, linePosition, Color.red);
      return true;  
   }
 
   public boolean diagramMouseUp(Event e, int x, int y) {
      if(aminator!=null&&aminator.isAlive()) 
         return true; 
      if(dragLine) {
         tools.MouseSweep(cp, linePosition, x, dl); 
         DrawingMethods.drawSweepLine(drawArea, linePosition, Color.red);
         dragLine = false; 
         showMinD(); 
         return true; 
      } 
      if(dragAble && isDragged) {
         tools.drawNodesNear(cp, lastCenter_x, lastCenter_y);   
         if(!nodeBounced) {
            lastCenter_x = x+dx; lastCenter_y = y+dy; 
         } else if(grid_choice.getState()==true) {
            lastCenter_x = lastCenter_x+GRID;  
         } 
         if(grid_choice.getState()==true) {
            if(lastCenter_x<GRID || lastCenter_y<GRID) { 
               lastCenter_x = initCenter_x; 
               lastCenter_y = initCenter_y; 
            } else {
               int tx = lastCenter_x/GRID*GRID; 
               int ty = lastCenter_y/GRID*GRID; 
               QueryNode tnode = tools.circleContaining(cp, tx, ty);
               if(tnode!=null)  { 
                  lastCenter_x = initCenter_x; 
                  lastCenter_y = initCenter_y; 
               } else if(tx <=linePosition+LINERESOLUTION) { 
                  lastCenter_x = tx+GRID; lastCenter_y = ty;  
               } else { 
                  lastCenter_x = tx; lastCenter_y = ty; 
               } 
            } 
         } 
         DrawingMethods.drawCircleAt(drawArea, 
                       lastCenter_x, lastCenter_y, Color.blue);
         cp.addPoint(new QueryNode(new Key(lastCenter_x, lastCenter_y))); 
      } 
      currentTime = new Date(); 
      mouseUpTime = currentTime.getTime(); 
      DrawingMethods.drawSweepLine(drawArea, linePosition, Color.red);
      showMinD(); 
      return true;
   }

   public void lineSweep() {
      QueryNode tail = cp.getTail(); 
      if(tail.getKey().getX() < iniLinePosition) {
         while(tail.getNext().getKey().getX() <=iniLinePosition) {
            tools.Sweep(RIGHT);
            tail = cp.getTail();
            showMinD(); 
         } 
      } else if(tail.getKey().getX() > iniLinePosition) {
         while(tail.getKey().getX()>iniLinePosition) {
            tools.Sweep(LEFT);
            tail = cp.getTail();
            showMinD(); 
         }
      } 
   }
 
   public void showMinD() {
      double d = cp.getClosestPairSecondNode().getMinDistance(); 
      if(d < INFTY) {
         if(d==(int)d) {
            min_label.setText(" "+" "+" " + d+".000"); 
         } else { 
            min_label.setText(" "+" "+" " + d); 
         }
      } 
      else 
         min_label.setText(" "); 
   } 

   public void showMouse(int x, int y) {
      mouse_label.setText(" "+ " "+"( " + x + ", " + y + " )"); 
   } 
}
